/* Timeline toolbox: one-click utilities, overlays, voice-over, delivery. */
const Toolbox = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const row = (label, ctrl, hint) => { const r = h('div', 'row'); const l = h('label', '', label); if (hint) l.innerHTML += ' <span class="hint">' + hint + '</span>'; r.append(l, ctrl); return r; };
  const btn = (label, cls, fn) => { const b = h('button', cls || 'ghost', label); b.addEventListener('click', fn); return b; };
  const num = (v, min, max, step, w) => { const n = h('input'); n.type = 'number'; n.value = v; n.min = min; n.max = max; n.step = step; n.style.width = (w || 70) + 'px'; return n; };
  const sel = (opts, v) => { const s = h('select', 'sel'); for (const [k, n] of opts) { const o = h('option'); o.value = k; o.textContent = n; s.appendChild(o); } s.value = v; return s; };
  const txt = (v, ph) => { const t = h('input'); t.type = 'text'; t.value = v || ''; t.placeholder = ph || ''; t.className = 'qname'; return t; };
  const need = () => { if (!CS.inCEP) throw new Error('This works inside Premiere Pro only.'); };
  async function call(fn, ...args) { need(); const r = await CS.call(fn, ...args); if (!r.ok) throw new Error(r.error); return r; }
  const run = (fn) => async () => { try { await fn(); } catch (e) { toast(e.message || String(e), 'err'); } };
  const done = (msg, warnings) => toast(msg + (warnings && warnings.length ? ' · ' + warnings[0] : ''), warnings && warnings.length ? 'err' : 'ok');
  async function toolsDir(sub) {
    const p = await CS.call('OS_getPaths');
    const base = (p.ok && (p.projectDir || p.documents)) || CS.os.homedir();
    const d = CS.path.join(base, 'OutflowStudio', sub);
    CS.mkdirp(d);
    return d;
  }
  async function pngFromCanvas(cv, file) {
    const g = cv.getContext('2d');
    return Exporter.writePNGFree(file, g.getImageData(0, 0, cv.width, cv.height).data, cv.width, cv.height);
  }
  const fmtTc = (s) => { const m = Math.floor(s / 60), ss = Math.floor(s % 60); return (m >= 60 ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };
  const srtTime = (s) => { const ms = Math.round(s * 1000); const hh = Math.floor(ms / 3600000), mm = Math.floor(ms / 60000) % 60, ss = Math.floor(ms / 1000) % 60, mss = ms % 1000; return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0') + ':' + String(ss).padStart(2, '0') + ',' + String(mss).padStart(3, '0'); };
  function writeSRT(cues, file) {
    const out = cues.map((c, i) => (i + 1) + '\n' + srtTime(c.s) + ' --> ' + srtTime(c.e) + '\n' + c.text + '\n').join('\n');
    CS.fs.writeFileSync(file, out, 'utf8');
    return file;
  }

  const GROUPS = [
    { id: 'clips', name: 'Clips', icon: 'toolbox', tools: [
      { id: 'unnest', icon: 'unnest', name: 'Un-nest', desc: 'Replace selected nested sequence clips with the clips inside them.' },
      { id: 'fit', icon: 'fit', name: 'Fit / fill frame', desc: 'Scale selected clips to fit or fill the sequence frame.' },
      { id: 'rename', icon: 'rename', name: 'Rename selected', desc: 'Batch rename with {n}, {nn}, {name}.' },
      { id: 'labels', icon: 'labels', name: 'Colour label', desc: 'Label the media of the selected clips.' },
      { id: 'disabled', icon: 'disabled', name: 'Delete disabled clips', desc: 'Ripple-delete every disabled clip.' },
      { id: 'gaps', icon: 'gaps', name: 'Close all gaps', desc: 'Remove empty space between clips on every track.' },
      { id: 'transitions', icon: 'transitions', name: 'Transitions at every cut', desc: 'Add a transition between all selected clips.' }
    ] },
    { id: 'overlays', name: 'Overlays & generators', icon: 'visual', tools: [
      { id: 'watermark', icon: 'watermark', name: 'Watermark', desc: 'Logo or image on top of the whole sequence.' },
      { id: 'margins', icon: 'margins', name: 'Safe margins', desc: 'Action/title safe guides on a top track (disable before export).' },
      { id: 'progress', icon: 'progress', name: 'Progress bar', desc: 'Bar that fills over the sequence or In/Out range.' },
      { id: 'countdown', icon: 'countdown', name: 'Countdown', desc: 'Caption-track countdown at the playhead.' },
      { id: 'lowerthird', icon: 'lowerthird', name: 'Lower third', desc: 'Name and title as an editable caption.' },
      { id: 'tts', icon: 'tts', name: 'Voice-over (offline TTS)', hot: true, desc: 'Windows text-to-speech straight onto an audio track.' }
    ] },
    { id: 'delivery', name: 'Delivery', icon: 'export', tools: [
      { id: 'chapters', icon: 'chapters', name: 'YouTube chapters', desc: 'Markers to a chapter list you can paste.' },
      { id: 'stills', icon: 'stills', name: 'Stills at markers', desc: 'Export a PNG frame at every marker (thumbnails).' },
      { id: 'export', icon: 'export', name: 'Export pack', desc: 'Render YouTube / Instagram / Vimeo versions with Premiere presets.' }
    ] }
  ];
  const builders = {};

  builders.unnest = (b) => { b.append(h('div', 'kbd', 'Select one or more nested sequence clips in the timeline. Their inner clips are placed on the tracks above with matching in/out points; effects on the nest itself are dropped.'), btn('Un-nest selected', 'primary', run(async () => { const r = await call('TL_unnest'); done(r.done + ' nest(s) expanded.', r.warnings); }))); };
  builders.fit = (b) => { const w = h('div', 'inline'); w.append(btn('Fit to frame', 'primary', run(async () => { const r = await call('TL_fitToFrame', 'fit'); done(r.done + ' clip(s) fitted.', r.warnings); })), btn('Fill frame (crop)', 'primary', run(async () => { const r = await call('TL_fitToFrame', 'fill'); done(r.done + ' clip(s) filled.', r.warnings); }))); b.append(h('div', 'kbd', 'Uses the source size from the project metadata. Works on the selected clips.'), w); };
  builders.rename = (b) => { const p = txt('Clip {nn}', 'pattern'); b.append(row('Pattern', p, '{n} number, {nn} zero-padded, {name} old name'), btn('Rename selected', 'primary', run(async () => { const r = await call('TL_renameSelected', p.value); done(r.done + ' clips renamed.'); }))); };
  builders.labels = (b) => { const names = ['Violet', 'Iris', 'Caribbean', 'Lavender', 'Cerulean', 'Forest', 'Rose', 'Mango', 'Purple', 'Blue', 'Teal', 'Magenta', 'Tan', 'Green', 'Brown', 'Yellow']; const s = sel(names.map((n, i) => [String(i), n]), '2'); b.append(row('Label', s), h('div', 'kbd', 'Labels the project items of the selected clips (Premiere shows the label on the clips). If your Premiere build refuses, the message tells you.'), btn('Apply to selected', 'primary', run(async () => { const r = await call('TL_labelSelected', parseInt(s.value, 10)); done(r.done + ' item(s) labelled.', r.warnings); }))); };
  builders.disabled = (b) => b.append(h('div', 'kbd', 'Every disabled (greyed) clip is removed and the gap closed. Handy after Auto Cut in "Disable" mode.'), btn('Delete disabled clips', 'primary', run(async () => { const r = await call('TL_deleteDisabled'); done(r.applied + ' gap(s) closed.', r.warnings); })));
  builders.gaps = (b) => b.append(btn('Close all gaps', 'primary', run(async () => { const r = await call('TL_closeGaps'); done(r.closed + ' of ' + r.gaps + ' gaps closed.'); })));
  builders.transitions = (b) => {
    const name = sel([['Cross Dissolve', 'Cross Dissolve'], ['Dip to Black', 'Dip to Black'], ['Dip to White', 'Dip to White'], ['Film Dissolve', 'Film Dissolve'], ['Additive Dissolve', 'Additive Dissolve'], ['Morph Cut', 'Morph Cut'], ['Push', 'Push'], ['Slide', 'Slide'], ['Wipe', 'Wipe'], ['Cross Zoom', 'Cross Zoom'], ['Iris Round', 'Iris Round']], 'Cross Dissolve');
    const dur = num(15, 1, 120, 1); const edges = h('input'); edges.type = 'checkbox';
    b.append(row('Transition', name), row('Length', dur, 'frames'), row('Also at the first start / last end', edges), btn('Add between selected clips', 'primary', run(async () => { const r = await call('TL_transitions', JSON.stringify({ name: name.value, duration: parseInt(dur.value, 10), edges: edges.checked })); done(r.done + ' clip(s) got transitions.', r.warnings); })));
  };
  builders.watermark = (b) => {
    let file = null; const pick = btn('Choose image…', 'ghost', () => { const p = CS.pickFiles(); if (p && p[0]) { file = p[0]; pick.textContent = p[0].split(/[\\/]/).pop(); } });
    const size = num(18, 2, 100, 1), op = num(70, 5, 100, 5), pos = sel([['tr', 'Top right'], ['tl', 'Top left'], ['br', 'Bottom right'], ['bl', 'Bottom left'], ['c', 'Centre']], 'br');
    b.append(row('Image', pick), row('Width', size, '% of frame'), row('Opacity', op, '%'), row('Position', pos), btn('Place watermark', 'primary', run(async () => {
      if (!file) throw new Error('Choose an image first.');
      const info = await call('AS_range');
      const src = await Sources.add(file);
      const scale = (size.value / 100) * info.width / (src.ow || src.w) * 100;
      const m = 0.04, P = { tr: [1 - m, m], tl: [m, m], br: [1 - m, 1 - m], bl: [m, 1 - m], c: [0.5, 0.5] }[pos.value];
      const wFrac = size.value / 100, hFrac = wFrac * ((src.oh || src.h) / (src.ow || src.w)) * (info.width / info.height);
      const px = P[0] + (P[0] < 0.5 ? wFrac / 2 : P[0] > 0.5 ? -wFrac / 2 : 0), py = P[1] + (P[1] < 0.5 ? hFrac / 2 : P[1] > 0.5 ? -hFrac / 2 : 0);
      const r = await call('TL_placeImage', JSON.stringify({ path: file, start: 0, duration: info.duration || 10, scale, posX: px, posY: py, opacity: +op.value, name: 'Watermark' }));
      done('Watermark placed on V' + (r.track + 1) + '.', r.warnings);
    })));
  };
  builders.margins = (b) => b.append(h('div', 'kbd', 'Draws action-safe (90%), title-safe (80%) and centre guides on a new top track for the whole sequence. Disable or delete it before export.'), btn('Add safe margins', 'primary', run(async () => {
    const info = await call('AS_range');
    const W = info.width, H = info.height, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const g = cv.getContext('2d'); g.lineWidth = Math.max(2, W / 800);
    const box = (f, col) => { g.strokeStyle = col; g.strokeRect(W * (1 - f) / 2, H * (1 - f) / 2, W * f, H * f); };
    box(0.9, 'rgba(255,214,102,.9)'); box(0.8, 'rgba(120,200,255,.9)');
    g.strokeStyle = 'rgba(255,255,255,.5)'; g.setLineDash([12, 12]); g.beginPath(); g.moveTo(W / 2, 0); g.lineTo(W / 2, H); g.moveTo(0, H / 2); g.lineTo(W, H / 2); g.stroke();
    const file = await pngFromCanvas(cv, CS.path.join(await toolsDir('overlays'), 'safe_margins_' + W + 'x' + H + '.png'));
    const r = await call('TL_placeImage', JSON.stringify({ path: file, start: 0, duration: info.duration || 10, scale: 100, name: 'Safe margins (disable before export)' }));
    done('Safe margins on V' + (r.track + 1) + '.', r.warnings);
  })));
  builders.progress = (b) => {
    const col = h('input'); col.type = 'color'; col.value = '#ff3b6b';
    const hgt = num(1.2, 0.2, 10, 0.1), pos = sel([['bottom', 'Bottom'], ['top', 'Top']], 'bottom'), range = sel([['whole', 'Whole sequence'], ['inout', 'In / Out range']], 'whole');
    b.append(row('Colour', col), row('Height', hgt, '% of frame'), row('Position', pos), row('Range', range), btn('Add progress bar', 'primary', run(async () => {
      const info = await call('AS_range');
      const s = range.value === 'inout' && info.hasInOut ? info.inPoint : 0, e = range.value === 'inout' && info.hasInOut ? info.outPoint : info.duration;
      if (e - s < 0.2) throw new Error('Sequence is empty.');
      const W = info.width, H = info.height, hp = Math.max(2, Math.round(H * hgt.value / 100));
      const cv = document.createElement('canvas'); cv.width = W; cv.height = hp; const g = cv.getContext('2d'); g.fillStyle = col.value; g.fillRect(0, 0, W, hp);
      const file = await pngFromCanvas(cv, CS.path.join(await toolsDir('overlays'), 'bar_' + col.value.slice(1) + '_' + W + 'x' + hp + '.png'));
      const py = pos.value === 'bottom' ? 1 - hp / H / 2 : hp / H / 2;
      const r = await call('TL_placeImage', JSON.stringify({ path: file, start: s, duration: e - s, scale: 100, posX: 0.5, posY: py, name: 'Progress bar', cropKeys: [[0, 100], [e - s, 0]] }));
      done('Progress bar on V' + (r.track + 1) + '.', r.warnings);
    })));
  };
  builders.countdown = (b) => {
    const from = num(5, 1, 60, 1), step = num(1, 0.5, 5, 0.5);
    b.append(row('Count from', from), row('Seconds per number', step), h('div', 'kbd', 'Creates a caption track at the playhead. Style it in Essential Graphics (font, size, colour).'), btn('Add countdown', 'primary', run(async () => {
      const info = await call('AS_range');
      const cues = []; let t = info.playhead;
      for (let n = +from.value; n >= 1; n--) { cues.push({ s: t, e: t + (+step.value) - 0.02, text: String(n) }); t += +step.value; }
      const file = writeSRT(cues, CS.path.join(await toolsDir('captions'), 'countdown_' + Date.now().toString(36) + '.srt'));
      await call('TL_captionsFromSRT', file, 0);
      done('Countdown added as a caption track.');
    })));
  };
  builders.lowerthird = (b) => {
    const name = txt('', 'Name'), title = txt('', 'Title / role'), dur = num(4, 1, 30, 0.5);
    b.append(row('Name', name), row('Title', title), row('Duration', dur, 's'), h('div', 'kbd', 'Placed at the playhead as an editable caption; style it in Essential Graphics.'), btn('Add lower third', 'primary', run(async () => {
      if (!name.value.trim()) throw new Error('Enter a name.');
      const info = await call('AS_range');
      const file = writeSRT([{ s: info.playhead, e: info.playhead + (+dur.value), text: name.value.trim() + (title.value.trim() ? '\n' + title.value.trim() : '') }], CS.path.join(await toolsDir('captions'), 'lowerthird_' + Date.now().toString(36) + '.srt'));
      await call('TL_captionsFromSRT', file, 0);
      done('Lower third added.');
    })));
  };
  builders.tts = (b) => {
    const text = h('textarea'); text.rows = 4; text.placeholder = 'Type the voice-over text…'; text.className = 'tta';
    const voice = sel([['', 'Default voice']], ''); const rate = num(0, -5, 5, 1);
    if (CS.inCEP) {
      try {
        const cp = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('child_process');
        const add = (out) => { for (const v of String(out).split(/\r?\n/).map(s => s.trim()).filter(Boolean)) { const o = h('option'); o.value = v; o.textContent = v; voice.appendChild(o); } };
        /* the Mac's own voices: "say -v ?" lists "Name   lang  # sample"; the name is what comes before the language */
        if (CS.mac) cp.execFile('say', ['-v', '?'], { encoding: 'utf8' }, (err, out) => { if (!err) add(String(out).split(/\r?\n/).map(l => (/^(.+?)\s{2,}\S+\s/.exec(l) || [])[1] || '').filter(Boolean).join('\n')); });
        else cp.exec('powershell -NoProfile -Command "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }"', { windowsHide: true }, (err, out) => { if (!err) add(out); });
      } catch (e) {}
    }
    b.append(text, row('Voice', voice), row('Speed', rate, '-5 … 5'), btn('Generate & place at playhead', 'primary', run(async () => {
      need();
      const t = text.value.trim(); if (!t) throw new Error('Type some text first.');
      const cp = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('child_process');
      const out = CS.path.join(await toolsDir('voiceover'), 'vo_' + Date.now().toString(36) + '.wav');
      const txtFile = out.replace(/\.wav$/, '.txt'); CS.fs.writeFileSync(txtFile, t, 'utf8');
      if (CS.mac) {
        /* the Mac's speech: rate is words per minute (about 175 normal), the file straight to WAV */
        const args = (voice.value ? ['-v', voice.value] : []).concat(['-r', String(175 + parseInt(rate.value, 10) * 25), '-o', out, '--file-format=WAVE', '--data-format=LEI16@44100', '-f', txtFile]);
        await new Promise((res, rej) => cp.execFile('say', args, (err, so, se) => err ? rej(new Error('Text-to-speech failed: ' + (se || err.message))) : res()));
      } else {
      const ps = "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; " + (voice.value ? "$s.SelectVoice('" + voice.value.replace(/'/g, "''") + "'); " : '') + "$s.Rate = " + parseInt(rate.value, 10) + "; $s.SetOutputToWaveFile('" + out.replace(/'/g, "''") + "'); $s.Speak([IO.File]::ReadAllText('" + txtFile.replace(/'/g, "''") + "')); $s.Dispose()";
      await new Promise((res, rej) => cp.execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true }, (err, so, se) => err ? rej(new Error('Text-to-speech failed: ' + (se || err.message))) : res()));
      }
      const info = await call('AS_range');
      const r = await call('TL_placeAudio', out, info.playhead, 'Voice-over');
      done('Voice-over (' + r.duration.toFixed(1) + ' s) placed on A' + (r.track + 1) + '.');
    })));
  };
  builders.chapters = (b) => {
    const ta = h('textarea'); ta.rows = 8; ta.className = 'tta'; ta.readOnly = true;
    b.append(btn('Read markers', 'primary', run(async () => {
      const r = await call('TL_markers');
      if (!r.markers.length) throw new Error('No sequence markers found.');
      const lines = r.markers.map(m => fmtTc(m.start) + ' ' + (m.name || 'Chapter'));
      if (r.markers[0].start > 0.5) lines.unshift('0:00 Intro');
      ta.value = lines.join('\n');
    })), ta, h('div', 'inline').appendChild(btn('Copy', 'ghost', () => { ta.select(); document.execCommand('copy'); toast('Copied.', 'ok'); })).parentElement);
  };
  builders.stills = (b) => b.append(h('div', 'kbd', 'Exports a full-resolution PNG at every sequence marker into a folder next to your project.'), btn('Export stills', 'primary', run(async () => {
    const r = await call('TL_markers');
    if (!r.markers.length) throw new Error('No sequence markers found.');
    let dir = (await toolsDir('stills')).replace(/\\/g, '/');
    const prefix = (r.name || 'still').replace(/[^a-z0-9_-]+/gi, '_');
    let res = await call('TL_exportStills', JSON.stringify({ times: r.markers.map(m => m.start), dir, prefix }));
    /*  Premiere's frame export writes nothing, and says nothing, when it dislikes the folder - a project
        path with a "+" or a character outside ASCII did that. A plain folder in Documents is the second try. */
    if (!res.exported && r.markers.length) {
      const alt = CS.path.join(CS.os.homedir(), 'Documents', 'OutflowStudio', 'stills').replace(/\\/g, '/');
      CS.mkdirp(alt);
      const res2 = await call('TL_exportStills', JSON.stringify({ times: r.markers.map(m => m.start), dir: alt, prefix }));
      if (res2.exported) { dir = alt; res = res2; }
    }
    done(res.exported + ' stills saved to ' + dir, res.warnings);
  })));
  builders.export = (b) => {
    const list = h('div'); const found = [];
    const roots = ['C:\\Program Files\\Adobe'];
    if (CS.fs) for (const root of roots) { if (!CS.fs.existsSync(root)) continue; for (const app of CS.fs.readdirSync(root)) { if (!/premiere/i.test(app)) continue; const d = CS.path.join(root, app, 'MediaIO', 'systempresets'); if (!CS.fs.existsSync(d)) continue; for (const sub of CS.fs.readdirSync(d)) { const sd = CS.path.join(d, sub); let files = []; try { files = CS.fs.readdirSync(sd); } catch (e) { continue; } for (const f of files) if (/\.epr$/i.test(f) && /youtube|instagram|vimeo|facebook|twitter|tiktok|match source - high/i.test(f)) found.push({ name: f.replace(/\.epr$/i, ''), path: CS.path.join(sd, f) }); } } }
    found.sort((a, b) => a.name.localeCompare(b.name));
    const checks = [];
    const seen = new Set();
    for (const f of found) { if (seen.has(f.name)) continue; seen.add(f.name); const r = h('label', 'row'); const c = h('input'); c.type = 'checkbox'; c.checked = /YouTube 1080p HD|Instagram|Vimeo 1080p HD/i.test(f.name); r.append(h('span', '', f.name), c); list.appendChild(r); checks.push({ f, c }); }
    if (!found.length) list.appendChild(h('div', 'kbd', CS.inCEP ? 'No social presets found in the Premiere install.' : 'Preset list appears inside Premiere.'));
    const range = sel([['whole', 'Whole sequence'], ['inout', 'In / Out range']], 'whole');
    b.append(h('div', 'kbd', 'Uses Premiere\'s own export presets (H.264). Files go to a folder you choose. Premiere is busy while it renders.'), list, row('Range', range), btn('Export selected presets…', 'primary', run(async () => {
      const picked = checks.filter(x => x.c.checked).map(x => x.f);
      if (!picked.length) throw new Error('Tick at least one preset.');
      const folder = CS.pickFolder('Export folder'); if (!folder) return;
      const info = await call('AS_range');
      const base = (info.name || 'sequence').replace(/[^a-z0-9_-]+/gi, '_');
      const ok = [];
      for (const p of picked) {
        toast('Exporting ' + p.name + '…');
        const r = await call('TL_export', JSON.stringify({ preset: p.path, out: CS.path.join(folder, base + ' - ' + p.name + '.mp4'), inOut: range.value === 'inout' }));
        if (r.ok) ok.push(p.name);
      }
      done(ok.length + ' file(s) exported to ' + folder);
    })));
  };

  /* Timeline tools screen = sidebar configuration + the detailed tool pages */
  function openMenu() {
    const box = $('#tools-list'); box.innerHTML = '';
    const cfg = Sidebar.cfg(), saveCfg = () => { Sidebar.save(); Sidebar.render(); };
    const sw = (v, fn) => { const b = h('button', 'switch' + (v ? ' on' : '')); b.addEventListener('click', () => { const on = !b.classList.contains('on'); b.classList.toggle('on', on); fn(on); }); return b; };
    box.appendChild(h('div', 'cat', icon('sidebar', 14) + ' Sidebar (visible everywhere, one click)'));
    box.append(
      row('Show sidebar', sw(cfg.enabled, v => { cfg.enabled = v; saveCfg(); })),
      row('Side', sel([['right', 'Right'], ['left', 'Left']], cfg.side).addEventListener ? (() => { const s = sel([['right', 'Right'], ['left', 'Left']], cfg.side); s.addEventListener('change', () => { cfg.side = s.value; saveCfg(); }); return s; })() : null),
      row('Size', (() => { const s = sel([['normal', 'Normal'], ['small', 'Compact']], cfg.size); s.addEventListener('change', () => { cfg.size = s.value; saveCfg(); }); return s; })())
    );
    box.appendChild(h('div', 'cat', 'Buttons'));
    box.appendChild(h('div', 'kbd', 'Click a block to run it now. The switch decides whether it sits in the sidebar.'));
    const grid = h('div', 'tgrid');
    for (const t of Sidebar.TOOLS) {
      const card = h('div', 'tcell' + (cfg.show[t.id] ? '' : ' off'));
      const run = h('button', 'tcell-run', '<span class="ico">' + icon(t.icon, 22) + '</span><b>' + t.name + '</b><span>' + t.desc + '</span>');
      run.addEventListener('click', () => Sidebar.run(t.id));
      const s = sw(!!cfg.show[t.id], v => { cfg.show[t.id] = v; card.classList.toggle('off', !v); saveCfg(); });
      s.classList.add('small'); s.title = 'Show in the sidebar';
      card.append(run, s);
      grid.appendChild(card);
    }
    box.appendChild(grid);

    /* the panel's own tools, pinned into the same strip */
    box.appendChild(h('div', 'cat', icon('star', 14) + ' Outflow Studio tools in the sidebar'));
    box.appendChild(h('div', 'kbd', 'Pin any of the panel\u2019s own tools to the bottom of the sidebar, under a line. They glow blue so you can tell them from the one-click timeline buttons.'));
    const pgrid = h('div', 'tgrid');
    for (const t of Sidebar.panelTools()) {
      const card = h('div', 'tcell panel' + (cfg.panel[t.id] ? '' : ' off'));
      const open = h('button', 'tcell-run', '<span class="ico">' + icon(t.icon, 22) + '</span><b>' + t.name + '</b><span>' + (t.desc || '') + '</span>');
      open.addEventListener('click', () => { try { t.go(); } catch (e) {} });
      const s2 = sw(!!cfg.panel[t.id], v => { cfg.panel[t.id] = v; card.classList.toggle('off', !v); saveCfg(); });
      s2.classList.add('small'); s2.title = 'Pin to the sidebar';
      card.append(open, s2);
      pgrid.appendChild(card);
    }
    box.appendChild(pgrid);

    box.appendChild(h('div', 'cat', 'One-click defaults'));
    const tr = sel([['Cross Dissolve', 'Cross Dissolve'], ['Film Dissolve', 'Film Dissolve'], ['Dip to Black', 'Dip to Black'], ['Dip to White', 'Dip to White'], ['Morph Cut', 'Morph Cut']], cfg.transition); tr.addEventListener('change', () => { cfg.transition = tr.value; Sidebar.save(); });
    const fr = num(cfg.frames, 1, 120, 1); fr.addEventListener('change', () => { cfg.frames = parseInt(fr.value, 10) || 15; Sidebar.save(); });
    const bc = h('input'); bc.type = 'color'; bc.value = cfg.barColor; bc.addEventListener('input', () => { cfg.barColor = bc.value; Sidebar.save(); });
    const bh = num(cfg.barHeight, 0.2, 10, 0.1); bh.addEventListener('change', () => { cfg.barHeight = parseFloat(bh.value) || 1.2; Sidebar.save(); });
    const bp = sel([['bottom', 'Bottom'], ['top', 'Top']], cfg.barPos); bp.addEventListener('change', () => { cfg.barPos = bp.value; Sidebar.save(); });
    const wm = btn(cfg.watermarkFile ? cfg.watermarkFile.split(/[\\/]/).pop() : 'Choose image…', 'ghost', () => { const p = CS.pickFiles(); if (p && p[0]) { cfg.watermarkFile = p[0]; wm.textContent = p[0].split(/[\\/]/).pop(); Sidebar.save(); } });
    const ws = num(cfg.watermarkSize, 2, 100, 1); ws.addEventListener('change', () => { cfg.watermarkSize = +ws.value || 18; Sidebar.save(); });
    const wo = num(cfg.watermarkOpacity, 5, 100, 5); wo.addEventListener('change', () => { cfg.watermarkOpacity = +wo.value || 70; Sidebar.save(); });
    const wp = sel([['tr', 'Top right'], ['tl', 'Top left'], ['br', 'Bottom right'], ['bl', 'Bottom left'], ['c', 'Centre']], cfg.watermarkPos); wp.addEventListener('change', () => { cfg.watermarkPos = wp.value; Sidebar.save(); });
    const cd = num(cfg.countdownFrom, 1, 60, 1); cd.addEventListener('change', () => { cfg.countdownFrom = parseInt(cd.value, 10) || 5; Sidebar.save(); });
    /* the shortcuts the person gave Premiere's mask tools and its tracker; the capture field lives in the sidebar */
    cfg.maskKeys = cfg.maskKeys || { object: '', rect: '', ellipse: '', pen: '' };
    if (cfg.maskKeys.ecPanel === undefined) cfg.maskKeys.ecPanel = 'shift+5';
    const mk = Sidebar.keycap;
    const mkObject = mk('object'), mkRect = mk('rect'), mkEllipse = mk('ellipse'), mkPen = mk('pen');
    box.append(row('Dissolve type', tr), row('Dissolve length', fr, 'frames'), row('Progress bar colour', bc), row('Progress bar height', bh, '% of frame'), row('Progress bar position', bp),
      row('Watermark image', wm), row('Watermark width', ws, '% of frame'), row('Watermark opacity', wo, '%'), row('Watermark position', wp), row('Countdown from', cd));
    box.appendChild(h('div', 'cat', 'Mask tool keys'));
    box.appendChild(h('div', 'kbd', 'The Mask button presses a Premiere shortcut to open the mask tool. Object is set to Shift+Q here: give the Object Mask Tool that shortcut in Premiere (Edit › Keyboard Shortcuts, search "Mask Tool"). If Shift+Q is already taken, pick another key there and record it here: click the field, press the keys. Shift or Ctrl+Shift with a letter; not Alt.'));
    box.appendChild(row('Setup video', btn('Show it again', 'ghost', () => Sidebar.maskIntro())));
    box.append(row('Object Mask Tool', mkObject), row('Ellipse Mask Tool', mkEllipse), row('Rectangle Mask Tool', mkRect), row('Pen Mask Tool', mkPen));
    box.appendChild(h('div', 'kbd', 'Auto track (the switch in the Mask button\'s popover) presses Premiere\'s own "track forward and backward" button for you once the mask lands on Opacity. Premiere gives that button no shortcut, so the panel first brings up Effect Controls with Premiere\'s panel shortcut, then finds the button on the screen; when the row is out of view the frame is maximised for a moment. These are Premiere\'s defaults; change them here if you changed them there. Windows for now.'));
    box.appendChild(row('Auto track', btn('Show the card', 'ghost', () => Sidebar.maskTrackIntro())));
    box.append(row('Effect Controls panel', mk('ecPanel')));
    box.appendChild(h('div', 'cat', 'Detailed tools (with options)'));
    for (const g of GROUPS) {
      const l2 = h('div', 'alist');
      for (const t of g.tools) {
        const b = h('button', 'arow' + (t.hot ? ' hot' : ''));
        b.innerHTML = '<span class="ico">' + icon(t.icon, 20) + '</span><span class="txt"><b>' + t.name + '</b><span>' + t.desc + '</span></span><span class="chev">›</span>';
        b.addEventListener('click', () => openTool(t));
        l2.appendChild(b);
      }
      box.appendChild(l2);
    }
    Hub.show('tools');
  }
  function openTool(t) {
    $('#tool-title').textContent = t.name;
    $('#tool-back').onclick = openMenu;
    const body = $('#tool-body'); body.innerHTML = '';
    builders[t.id](body);
    Hub.show('tool');
  }
  return { openMenu, openTool, GROUPS };
})();
