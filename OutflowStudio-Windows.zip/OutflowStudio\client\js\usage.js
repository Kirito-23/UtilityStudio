/* Usage statistics: one tick per finished job (carousel export, transition, Auto Edit run, ...). Only tool names and
   numbers are kept, never content. Sent to the licence server with the device token (so only logged-in panels
   report) and shown in the owner dashboard. What is collected, all counts and no content:
     - jobs per tool per day, with how long a job took and how long the clip was
     - the editing session (panel open → last seen, jobs in it)
     - failed or cancelled jobs: the tool and the error text, with file names and emails stripped out
     - the first tool ever used and when
     - a few settings choices (quality, GPU on/off, preset, template) as "set:" counts
     - once per computer: GPU model and memory, CPU cores, RAM, Windows and Premiere version
   Settings › "Share usage statistics" switches all of it off. */
const Usage = (() => {
  const KEY = 'os.usage';
  let st = { days: {}, sent: {}, meta: {}, errors: [], first: null, device: null, reason: null };
  try { Object.assign(st, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) {}
  st.meta = st.meta || {}; st.errors = Array.isArray(st.errors) ? st.errors : [];
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} };
  const today = () => new Date().toISOString().slice(0, 10);
  const now = () => new Date().toISOString();
  const off = () => { try { return !!(typeof Hub !== 'undefined' && Hub.keys && Hub.keys().usageOff); } catch (e) { return false; } };
  const isJob = (tool) => !/^(limit|set):/.test(String(tool));
  /* an editing session = one run of the panel: started when it opened, "ended" = the last moment it was seen,
     jobs = finished jobs in it. The previous run's session is sent on the next start if it was not sent yet. */
  const newId = () => Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  st.pending = Array.isArray(st.pending) ? st.pending : [];
  if (st.session && st.session.id) { st.pending.push(st.session); st.pending = st.pending.slice(-20); }
  st.session = { id: newId(), started: now(), ended: now(), jobs: 0 };
  /* tick(tool, n, { seconds, clip }): seconds = how long the job took, clip = the clip's length in seconds */
  function tick(tool, n, meta) {
    const d = today(); st.days[d] = st.days[d] || {}; st.days[d][tool] = (st.days[d][tool] || 0) + (n || 1);
    if (isJob(tool)) {
      st.session.jobs += (n || 1); st.session.ended = now();
      if (!st.first) st.first = { tool, at: now() };
      if (meta && (meta.seconds > 0 || meta.clip > 0)) { st.meta[d] = st.meta[d] || {}; const m = st.meta[d][tool] = st.meta[d][tool] || { n: 0, seconds: 0, clip: 0 }; m.n += 1; m.seconds += +meta.seconds || 0; m.clip += +meta.clip || 0; }
    }
    for (const k of Object.keys(st.days)) if (k < today() && (Date.now() - new Date(k)) > 14 * 864e5) { delete st.days[k]; delete st.meta[k]; }   /* keep two weeks locally */
    save(); schedule();
  }
  /* a job that failed or was cancelled: the tool and a cleaned error text (no paths, no file names, no emails) */
  const clean = (msg) => String(msg || '').replace(/[A-Za-z]:\\[^\s"']+/g, '<path>').replace(/\/[^\s"']+\/[^\s"']+/g, '<path>').replace(/[\w.-]+@[\w.-]+\.\w+/g, '<email>').replace(/[\w-]+\.(mp4|mov|mkv|webm|wav|mp3|png|jpg|jpeg|prproj|mxf|avi)\b/gi, '<file>').replace(/\s+/g, ' ').trim().slice(0, 200);
  function fail(tool, kind, msg) {
    if (!tool || tool === 'home' || tool === 'settings') tool = 'panel';
    st.errors.push({ tool: String(tool).slice(0, 40), kind: kind === 'cancel' ? 'cancel' : kind === 'hint' ? 'hint' : 'fail', msg: clean(msg), at: now() });
    st.errors = st.errors.slice(-50); save(); schedule();
  }
  /* the computer, read once (and again after an update): GPU, cores, RAM, Windows, Premiere */
  async function readDevice() {
    const ver = (window.OUTFLOW || {}).version || '';
    if (st.device && st.device.v === ver && st.device.gpu) return;
    const d = { v: ver };
    try { const os = window.cep_node.require('os'); d.cores = os.cpus().length; d.ram = Math.round(os.totalmem() / 1073741824); d.os = CS.osName(); } catch (e) {}
    try { const r = await CS.call('C3D_ping'); if (r && r.version) d.host = String(r.version).slice(0, 20); } catch (e) {}
    if (CS.mac) { try { const g = await CS.gpuInfo(); if (g) { d.gpu = g.gpu; d.vram = g.vram; } } catch (e) {} st.device = d; save(); return; }
    try {
      const cp = window.cep_node.require('child_process');
      const out = await new Promise((res) => { cp.execFile('powershell.exe', ['-NoProfile', '-Command', "Get-CimInstance Win32_VideoController | Where-Object { $_.AdapterRAM -gt 0 } | Sort-Object AdapterRAM -Descending | Select-Object -First 1 | ForEach-Object { $_.Name + '|' + [math]::Round($_.AdapterRAM / 1MB) }"], { windowsHide: true, timeout: 15000 }, (err, so) => res(err ? '' : String(so))); });
      const [name, mb] = out.trim().split('|'); if (name) { d.gpu = name.trim().slice(0, 60); d.vram = parseInt(mb, 10) || 0; }
    } catch (e) {}
    st.device = d; save();
  }
  let timer = null, sending = false;
  function schedule() { clearTimeout(timer); timer = setTimeout(flush, 90 * 1000); }
  /* sends every day that changed since the last send; the server keeps the highest count per day and tool */
  async function flush() {
    if (sending || off() || typeof License === 'undefined' || !License.loggedIn() || !License.api) return;
    const days = Object.keys(st.days).filter((d) => JSON.stringify(st.days[d]) !== st.sent[d]);
    st.session.ended = now();
    const sessions = st.pending.concat([st.session]).filter((x) => x.jobs > 0 || (new Date(x.ended) - new Date(x.started)) > 60 * 1000);   /* skip runs of under a minute with nothing done */
    const sessionKey = JSON.stringify(sessions.map((x) => [x.id, x.jobs, x.ended.slice(0, 16)]));
    const metrics = Object.keys(st.meta).map((d) => ({ day: d, tools: st.meta[d] }));
    const metricsKey = JSON.stringify(metrics);
    const errors = st.errors.slice();
    const first = st.first && !st.firstSent ? st.first : null;
    /* the tool they said they came for, sent once */
    const reason = st.reason && !st.reasonSent ? st.reason : null;
    const device = st.device && st.device.gpu !== undefined && JSON.stringify(st.device) !== st.deviceSent ? st.device : null;
    /*  A fingerprint of the file that decides the free exports, once per version. The server knows what
        the real file of this version hashes to; a different hash is an edited panel. Not a lock - the
        line that sends this can be edited too - but it tells the dashboard who did.                  */
    let integrity = null;
    try {
      const ver = (window.OUTFLOW || {}).version || '';
      if (CS.inCEP && CS.fs && st.integritySent !== ver) {
        const crypto = window.cep_node.require('crypto');
        const file = CS.path.join(CS.extensionDir(), 'client', 'js', 'license.js');
        integrity = { version: ver, license: crypto.createHash('sha256').update(CS.fs.readFileSync(file)).digest('hex') };
      }
    } catch (e) { integrity = null; }
    if (!days.length && sessionKey === st.sentSessions && metricsKey === st.sentMetrics && !errors.length && !first && !device && !reason && !integrity) return;
    sending = true;
    try {
      const ver = (window.OUTFLOW || {}).version || '';
      await License.api('/usage', { method: 'POST', body: { version: ver, days: days.map((d) => ({ day: d, tools: st.days[d] })), sessions, metrics, errors, first, device, reason, integrity } });
      for (const d of days) st.sent[d] = JSON.stringify(st.days[d]);
      for (const k of Object.keys(st.sent)) if (!st.days[k]) delete st.sent[k];
      st.pending = []; st.sentSessions = sessionKey; st.sentMetrics = metricsKey;
      st.errors = st.errors.slice(errors.length);
      if (first) st.firstSent = true;
      if (reason) st.reasonSent = true;
      if (device) st.deviceSent = JSON.stringify(device);
      if (integrity) st.integritySent = integrity.version;
      save();
    } catch (e) { /* offline or not linked: try again on the next tick or start */ }
    sending = false;
  }
  function init() {
    save();
    setTimeout(() => { readDevice().then(flush); }, 20 * 1000);
    setInterval(flush, 10 * 60 * 1000);
    window.addEventListener('beforeunload', () => { st.session.ended = now(); save(); });
  }
  const setReason = (tool) => { if (!st.reason) { st.reason = String(tool || '').slice(0, 40); flush(); } };
  return { tick, fail, flush, init, setReason, counts: () => st.days, device: () => st.device };
})();
