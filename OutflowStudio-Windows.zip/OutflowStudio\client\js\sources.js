/* Media sources: images become power-of-two canvases (mipmaps), videos stay
   <video> elements sampled every frame. */
const Sources = (() => {
  const map = new Map();
  let counter = 0;
  const MAX_TEX = 2048;
  const pot = (v) => { const p = Math.pow(2, Math.round(Math.log2(Math.max(1, v)))); return Math.min(MAX_TEX, Math.max(64, p)); };
  const VIDEO_EXT = /\.(mp4|mov|webm|m4v|ogv|mkv)$/i;

  /* what the carousel can show: pictures (HEIC and TIFF after conversion) and videos */
  const MEDIA_EXT = /\.(png|jpe?g|jfif|webp|gif|bmp|avif|heic|heif|tiff?|mp4|mov|webm|m4v|ogv|mkv|avi|mts)$/i;
  function isMedia(input) {
    if (typeof input === 'string') return MEDIA_EXT.test(input);
    if (!input) return false;
    /* a piece off the timeline carries its clip name, which need not end in an extension: the path decides */
    return /^(image|video)\//.test(input.type || '') || MEDIA_EXT.test(String(input.name || '')) || MEDIA_EXT.test(String(input.path || ''));
  }
  function isVideo(name, mime) {
    if (mime && mime.startsWith('video/')) return true;
    if (mime && mime.startsWith('image/')) return false;
    return VIDEO_EXT.test(name || '');
  }

  function makeThumb(el, w, h) {
    const c = document.createElement('canvas');
    c.width = 108; c.height = 84;
    const g = c.getContext('2d');
    const sa = w / h, ta = c.width / c.height;
    let sw = w, sh = h, sx = 0, sy = 0;
    if (sa > ta) { sw = h * ta; sx = (w - sw) / 2; } else { sh = w / ta; sy = (h - sh) / 2; }
    try { g.drawImage(el, sx, sy, sw, sh, 0, 0, c.width, c.height); } catch (e) {}
    return c.toDataURL('image/jpeg', 0.8);
  }

  /*  Pictures the panel's browser cannot draw: HEIC / HEIF (every iPhone photo) and TIFF. Turned into a JPG
      next to the panel's data first. Mac: sips, which every Mac has. Windows: the video engine when it is
      installed, else Windows' own picture decoder (HEIC needs the HEIF extension from the Store).        */
  const CONVERT = /\.(heic|heif|tiff?)$/i;
  async function toJpeg(path, name) {
    const cp = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('child_process');
    const dir = CS.dataDir('converted');
    const out = CS.path.join(dir, String(name).replace(/\.[^.]+$/, '').replace(/[^\w.-]+/g, '_') + '_' + (CS.fs.statSync(path).size % 100000) + '.jpg');
    if (CS.fs.existsSync(out) && CS.fs.statSync(out).size > 1000) return out;
    const run = (cmd, args) => new Promise((ok) => cp.execFile(cmd, args, { windowsHide: true, timeout: 60000 }, () => ok(CS.fs.existsSync(out) && CS.fs.statSync(out).size > 1000)));
    if (CS.mac) { if (await run('sips', ['-s', 'format', 'jpeg', path, '--out', out])) return out; }
    else {
      const ff = typeof Social !== 'undefined' && Social.ffmpeg ? Social.ffmpeg() : null;
      if (ff && await run(ff, ['-y', '-v', 'error', '-i', path, '-frames:v', '1', '-q:v', '2', out])) return out;
      const q = (s) => "'" + String(s).replace(/'/g, "''") + "'";
      if (await run('powershell', ['-NoProfile', '-NonInteractive', '-Command', 'Add-Type -AssemblyName PresentationCore; $d = [Windows.Media.Imaging.BitmapDecoder]::Create([Uri]' + q(path) + ", 'None', 'OnLoad'); $e = New-Object Windows.Media.Imaging.JpegBitmapEncoder; $e.QualityLevel = 92; $e.Frames.Add($d.Frames[0]); $s = [IO.File]::Create(" + q(out) + '); $e.Save($s); $s.Close()'])) return out;
    }
    throw new Error(/\.hei[cf]$/i.test(name) ? 'This iPhone photo (HEIC) cannot be read on this computer. Save it as JPG first - on a Mac: open it in Preview, File, Export, JPEG; on Windows: open it in Photos, Save as, JPG - then add it again.' : 'This TIFF picture cannot be read. Save it as JPG or PNG first, then add it again.');
  }
  async function loadImage(url) {
    const img = new Image();
    img.src = url;
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('Could not load image')); });
    const w = img.naturalWidth, h = img.naturalHeight;
    const c = document.createElement('canvas');
    c.width = pot(w); c.height = pot(h);
    const g = c.getContext('2d');
    g.imageSmoothingQuality = 'high';
    g.drawImage(img, 0, 0, c.width, c.height);
    return { el: c, w: c.width, h: c.height, ow: w, oh: h, aspect: w / h, pot: true, thumb: makeThumb(img, w, h), duration: 0 };
  }

  async function loadVideo(url, at) {
    const v = document.createElement('video');
    v.muted = true; v.loop = true; v.playsInline = true; v.preload = 'auto'; v.crossOrigin = 'anonymous';
    v.src = url;
    await new Promise((res, rej) => {
      const to = setTimeout(() => rej(new Error('Video took too long to load')), 15000);
      v.onloadedmetadata = () => { clearTimeout(to); res(); };
      v.onerror = () => { clearTimeout(to); rej(new Error('Could not load video')); };
    });
    /* the picture the card shows comes from the moment this source starts at, not from the top of the file:
       eight trims of one clip must not all look the same */
    /* it loops on its own, so bring it back to this source's own start rather than to the top of the file */
    if (at > 0.001) v.addEventListener('timeupdate', () => { if (v.currentTime < at - 0.05) { try { v.currentTime = at; } catch (e) {} } });
    await seekVideo(v, (at || 0) + 0.1);
    const thumb = makeThumb(v, v.videoWidth, v.videoHeight);
    return { el: v, w: v.videoWidth, h: v.videoHeight, ow: v.videoWidth, oh: v.videoHeight, aspect: v.videoWidth / v.videoHeight, pot: false, thumb, duration: v.duration || 0 };
  }

  function seekVideo(v, t) {
    return new Promise((res) => {
      const target = v.duration ? (t % v.duration) : 0;
      if (Math.abs(v.currentTime - target) < 0.0005 && v.readyState >= 2) return res();
      let done = false;
      const finish = () => { if (done) return; done = true; v.removeEventListener('seeked', finish); res(); };
      v.addEventListener('seeked', finish);
      setTimeout(finish, 2000);
      try { v.currentTime = target; } catch (e) { finish(); }
    });
  }

  /*  input can be a path, a File, or { path, in, name } for a piece taken off the timeline. Each call makes its own
      source with its own video element, so the same file can appear several times showing different moments.      */
  async function add(input) {
    let url, name, path = null, mime = '', file = null, at = 0;
    if (typeof input === 'string') { path = input; url = CS.fileURL(input); name = input.split(/[\\/]/).pop(); }
    else if (typeof File !== 'undefined' && input instanceof File) { url = URL.createObjectURL(input); name = input.name; mime = input.type || ''; path = input.path || null; file = input; }
    else { path = input.path; at = +input['in'] || 0; url = CS.fileURL(path); name = input.name || String(path).split(/[\\/]/).pop(); }
    const type = isVideo(name, mime) ? 'video' : 'image';
    if (type === 'image' && CONVERT.test(name || '')) {
      if (!path || !CS.fs) throw new Error('HEIC and TIFF pictures can only be added from a file on this computer.');
      path = await toJpeg(path, name); url = CS.fileURL(path);
    }
    let data;
    try { data = type === 'video' ? await loadVideo(url, at) : await loadImage(url); }
    catch (e) { throw new Error(type === 'image' ? 'This picture cannot be read (' + (String(name).split('.').pop() || 'unknown') + '). JPG, PNG, WebP, GIF, HEIC and TIFF work.' : e.message); }
    const id = 's' + (++counter) + '_' + Date.now().toString(36);
    const src = Object.assign({ id, name, type, url, path, file, in: type === 'video' ? at : 0 }, data);
    map.set(id, src);
    return src;
  }

  return {
    add, isMedia, get: (id) => map.get(id), all: () => Array.from(map.values()),
    seekVideo,
    remove(id) { const s = map.get(id); if (s && s.url.startsWith('blob:')) URL.revokeObjectURL(s.url); map.delete(id); },
    playAll(ids) { for (const id of ids) { const s = map.get(id); if (!s || s.type !== 'video') continue; if (s['in'] > 0.001 && s.el.currentTime < s['in']) { try { s.el.currentTime = s['in']; } catch (e) {} } s.el.play().catch(() => {}); } },
    pauseAll() { for (const s of map.values()) if (s.type === 'video') s.el.pause(); }
  };
})();
