/* ============================================================================
   Preset library.
   The animation is layered:  LAYOUT (where cards sit)  x  MOTION (how the
   focus moves over time)  x  EASING  x  INTRO/OUTRO  x  CAMERA move  x  card FX.
   TEMPLATES are curated combinations of those layers.
   ========================================================================== */
const TAU = Math.PI * 2, DEG = Math.PI / 180;
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const T = (o) => Object.assign({ x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, s: 1, o: 1, blur: 0, g: null }, o);
/* fade cards that sit at the wrap seam of a linear layout */
const seamFade = (d, n, m) => clamp((n / 2 - Math.abs(d)) / (m || 1), 0, 1);
/* deterministic pseudo random in [0,1) */
function hashRand(a, b) {
  let h = (a * 374761393 + b * 668265263 + 1013904223) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h = (h ^ (h >>> 16)) >>> 0;
  return h / 4294967296;
}
function smoothNoise(t) {
  return (Math.sin(t * 1.0) * 0.5 + Math.sin(t * 2.3 + 1.7) * 0.3 + Math.sin(t * 4.1 + 0.4) * 0.2);
}
const P = (k, name, min, max, step, def, unit) => ({ k, name, min, max, step, def, unit: unit || '' });

/* ---------------------------------------------------------------------------
   LAYOUTS.  fn(d, i, n, c) -> transform
     d : signed distance (in cards) of card i from the focus, wrapped to (-n/2, n/2]
     c : { phase, frac, t, dur, w, h, R, Rv, p, camDist, viewW, viewH, rnd(i,k) }
   Returned transform: x,y,z position; rx,ry,rz card rotation; s scale;
   o opacity; blur extra blur (px); g [gx,gy,gz] group rotation applied
   around the world origin (used for tilted rings, wall sway ...).
   ------------------------------------------------------------------------- */
const LAYOUTS = {
  carousel: {
    name: 'Carousel', icon: '🎠', desc: 'Ring, cards face outward',
    params: [P('tilt', 'Ring tilt', -60, 60, 1, 0, '°'), P('yGap', 'Vertical wave', 0, 2, 0.05, 0)],
    fn(d, i, n, c) {
      const a = d / n * TAU;
      return T({ x: c.R * Math.sin(a), y: Math.sin(a) * c.p.yGap, z: c.R * Math.cos(a), ry: a, g: [c.p.tilt * DEG, 0, 0] });
    }
  },
  curved: {
    name: 'Curved ring', icon: '🌀', desc: 'Bend a flat row into a full loop',
    params: [P('curve', 'Curvature', 0, 100, 1, 60, '%'), P('bowIn', 'Bow inward (0 / 1)', 0, 1, 1, 0), P('visible', 'Visible arc', 10, 100, 1, 100, '%'), P('feather', 'Edge fade', 0, 50, 1, 8, '%'), P('tilt', 'Ring tilt', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) {
      /* the path length stays fixed (MachiCut's "fixed path"): 0% = flat filmstrip, 100% = closed ring */
      const spread = c.p.curve / 100 * TAU, PL = c.R * TAU, bs = c.p.bowIn >= 0.5 ? -1 : 1;
      const vis = c.p.visible / 100, fe = Math.max(0.0001, c.p.feather / 100);
      const fade = (u) => { const lim = vis, f = fe; return u <= lim - f ? 1 : clamp((lim - u) / f, 0, 1); };
      if (spread < 0.004) {
        const x = d / n * PL;
        return T({ x, z: 0, ry: 0, o: fade(Math.abs(x) / (PL / 2)), g: [c.p.tilt * DEG, 0, 0] });
      }
      const Rr = PL / spread, a = d / n * spread;
      return T({ x: Rr * Math.sin(a), z: bs * Rr * (Math.cos(a) - 1), ry: bs * a, o: fade(Math.abs(a) / (spread / 2)), g: [c.p.tilt * DEG, 0, 0] });
    }
  },
  ring: {
    name: 'Billboard ring', icon: '⭕', desc: 'Ring, cards always face you',
    params: [P('tilt', 'Ring tilt', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) {
      const a = d / n * TAU;
      return T({ x: c.R * Math.sin(a), z: c.R * Math.cos(a), g: [c.p.tilt * DEG, 0, 0] });
    }
  },
  inward: {
    name: 'Inward ring', icon: '🔄', desc: 'Ring, cards face the centre',
    params: [P('tilt', 'Ring tilt', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) {
      const a = d / n * TAU;
      return T({ x: c.R * Math.sin(a), z: c.R * Math.cos(a), ry: a + Math.PI, g: [c.p.tilt * DEG, 0, 0] });
    }
  },
  prism: {
    name: 'Prism / cube', icon: '🧊', desc: 'Closed shape, faces touch',
    params: [P('gap', 'Face gap', 0.9, 2, 0.02, 1.02), P('tilt', 'Tilt', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) {
      const R = n >= 3 ? c.w / (2 * Math.tan(Math.PI / n)) * c.p.gap : c.w * 0.5 * c.p.gap;
      const a = d / n * TAU;
      return T({ x: R * Math.sin(a), z: R * Math.cos(a), ry: a, g: [c.p.tilt * DEG, 0, 0] });
    }
  },
  coverflow: {
    name: 'Coverflow', icon: '🎞️', desc: 'Centre card, sides angled back',
    params: [P('gap0', 'Centre gap', 0.5, 2, 0.05, 1.1), P('side', 'Side spacing', 0.15, 1.5, 0.05, 0.45), P('depth', 'Side depth', 0, 4, 0.1, 1.5), P('angle', 'Side angle', 0, 90, 1, 60, '°')],
    fn(d, i, n, c) {
      const k = clamp(Math.abs(d), 0, 1), s = Math.sign(d);
      const x = s * (k * c.p.gap0 * c.w + Math.max(Math.abs(d) - 1, 0) * c.p.side * c.w);
      return T({ x, z: -k * c.p.depth - Math.max(Math.abs(d) - 1, 0) * 0.02, ry: -s * k * c.p.angle * DEG, o: seamFade(d, n, 0.7) });
    }
  },
  wall: {
    name: 'Wall / grid', icon: '🧱', desc: 'Flat grid, focus card pops',
    params: [P('cols', 'Columns (0 = auto)', 0, 8, 1, 0), P('gap', 'Gap', 0, 0.6, 0.02, 0.12), P('sway', 'Sway', 0, 60, 1, 14, '°'), P('pop', 'Focus pop', 0, 3, 0.1, 0.8)],
    fn(d, i, n, c) {
      const cols = c.p.cols > 0 ? c.p.cols : Math.ceil(Math.sqrt(n)), rows = Math.ceil(n / cols);
      const cw = c.w * (1 + c.p.gap), ch = c.h * (1 + c.p.gap);
      const fit = Math.min(1, c.viewW * 0.92 / (cols * cw), c.viewH * 0.92 / (rows * ch));
      const col = i % cols, row = Math.floor(i / cols);
      const lastRowCount = n - (rows - 1) * cols;
      const colsInRow = row === rows - 1 ? lastRowCount : cols;
      return T({
        x: (col - (colsInRow - 1) / 2) * cw * fit,
        y: ((rows - 1) / 2 - row) * ch * fit,
        z: (1 - clamp(Math.abs(d), 0, 1)) * c.p.pop,
        s: fit, g: [0, Math.sin(c.frac * TAU) * c.p.sway * DEG, 0]
      });
    }
  },
  fan: {
    name: 'Fan', icon: '🪭', desc: 'Cards hinged at one point',
    params: [P('spread', 'Spread', 2, 45, 0.5, 14, '°'), P('pivot', 'Pivot distance', 0.5, 3, 0.05, 1.3)],
    fn(d, i, n, c) {
      const a = -d * c.p.spread * DEG, pv = c.h * c.p.pivot;
      return T({ x: -pv * Math.sin(a), y: -pv + pv * Math.cos(a), z: -Math.abs(d) * 0.08, rz: a, o: seamFade(d, n, 0.8) });
    }
  },
  stack: {
    name: 'Card stack', icon: '🗂️', desc: 'Deck, top card swipes away',
    params: [P('depth', 'Depth step', 0.1, 2.5, 0.05, 0.7), P('rise', 'Rise step', -1.5, 1.5, 0.05, 0.7), P('shrink', 'Shrink', 0, 0.3, 0.01, 0.08), P('throw', 'Throw distance', 0.5, 5, 0.1, 2.2), P('visible', 'Visible cards', 2, 12, 1, 5)],
    fn(d, i, n, c) {
      if (d >= 0) {
        return T({ z: -d * c.p.depth, y: d * c.p.rise, s: Math.max(0.2, 1 - d * c.p.shrink), o: clamp(1 - (d - c.p.visible + 1) / 1.2, 0, 1) });
      }
      const k = -d;
      if (k > 1) return T({ o: 0 });
      return T({ x: -k * c.p.throw * c.w, z: k * 0.4, rz: -k * 25 * DEG, o: 1 - k });
    }
  },
  inside: {
    name: 'Inside the ring', icon: '🌀', desc: 'Camera sits in the middle',
    params: [P('radius', 'Radius', 2, 14, 0.1, 6.5), P('rise', 'Rise', -2, 2, 0.05, 0)],
    fn(d, i, n, c) {
      const a = d / n * TAU + Math.PI, R = c.p.radius;
      return T({ x: R * Math.sin(a), y: d * c.p.rise, z: c.camDist + R * Math.cos(a), ry: a + Math.PI });
    }
  },
  helix: {
    name: 'Helix', icon: '🧬', desc: 'Spiral staircase ring',
    params: [P('rise', 'Rise per card', 0.1, 2.5, 0.05, 0.9)],
    fn(d, i, n, c) {
      const a = d / n * TAU;
      return T({ x: c.R * Math.sin(a), y: -d * c.p.rise, z: c.R * Math.cos(a), ry: a, o: seamFade(d, n, 1) });
    }
  },
  wave: {
    name: 'Wave', icon: '🌊', desc: 'Row riding a sine wave',
    params: [P('gap', 'Gap', 0.6, 2.5, 0.05, 1.15), P('amp', 'Amplitude', 0, 3, 0.05, 0.8), P('freq', 'Frequency', 0.2, 3, 0.05, 1.1), P('yaw', 'Yaw', 0, 45, 1, 8, '°')],
    fn(d, i, n, c) {
      return T({ x: d * c.w * c.p.gap, y: Math.sin(d * c.p.freq + c.frac * TAU) * c.p.amp, z: Math.cos(d * c.p.freq) * c.p.amp * 0.5, ry: -d * c.p.yaw * DEG, o: seamFade(d, n, 1) });
    }
  },
  arc: {
    name: 'Curved wall', icon: '🌉', desc: 'Row bent around you',
    params: [P('step', 'Angle per card', 4, 60, 0.5, 24, '°'), P('radius', 'Radius', 2, 16, 0.1, 7)],
    fn(d, i, n, c) {
      const a = d * c.p.step * DEG, R = c.p.radius;
      return T({ x: R * Math.sin(a), z: R * (Math.cos(a) - 1), ry: a, o: seamFade(d, n, 0.8) });
    }
  },
  tunnel: {
    name: 'Fly through', icon: '🚀', desc: 'Cards fly towards the camera',
    params: [P('depth', 'Depth step', 0.5, 6, 0.1, 2.4), P('sway', 'Sway', 0, 3, 0.05, 0)],
    fn(d, i, n, c) {
      const sx = Math.sin(d * 0.9) * c.p.sway, sy = Math.cos(d * 0.9) * c.p.sway;
      if (d >= 0) return T({ x: sx, y: sy, z: -d * c.p.depth, o: clamp(1 - (d - n * 0.5 + 1), 0, 1) });
      const k = -d;
      return T({ x: sx, y: sy, z: k * c.p.depth, o: clamp(1 - k * 1.3, 0, 1) });
    }
  },
  orbit: {
    name: 'Tilted orbit', icon: '🪐', desc: 'Ring on a tilted plane',
    params: [P('tilt', 'Tilt', -80, 80, 1, 28, '°'), P('roll', 'Roll', -45, 45, 1, 0, '°')],
    fn(d, i, n, c) {
      const a = d / n * TAU;
      return T({ x: c.R * Math.sin(a), z: c.R * Math.cos(a), g: [c.p.tilt * DEG, 0, c.p.roll * DEG] });
    }
  },
  cascade: {
    name: 'Staircase', icon: '🪜', desc: 'Diagonal steps into depth',
    params: [P('sx', 'X step', 0, 1.5, 0.05, 0.55), P('sy', 'Y step', -1, 1, 0.05, 0.28), P('sz', 'Depth step', 0, 2, 0.05, 0.6)],
    fn(d, i, n, c) {
      return T({ x: d * c.p.sx * c.w, y: -d * c.p.sy * c.h, z: -Math.abs(d) * c.p.sz, o: seamFade(d, n, 1) });
    }
  },
  filmstrip: {
    name: 'Film strip', icon: '📽️', desc: 'Straight horizontal row',
    params: [P('gap', 'Gap', 0.6, 3, 0.05, 1.15), P('yaw', 'Yaw', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) { return T({ x: d * c.w * c.p.gap, ry: c.p.yaw * DEG, o: seamFade(d, n, 0.8) }); }
  },
  column: {
    name: 'Column', icon: '🧮', desc: 'Straight vertical row',
    params: [P('gap', 'Gap', 0.6, 3, 0.05, 1.15), P('pitch', 'Pitch', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) { return T({ y: -d * c.h * c.p.gap, rx: c.p.pitch * DEG, o: seamFade(d, n, 0.8) }); }
  },
  ferris: {
    name: 'Ferris wheel', icon: '🎡', desc: 'Vertical ring, cards upright',
    params: [P('roll', 'Wheel tilt', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) {
      const a = d / n * TAU;
      return T({ y: -c.Rv * Math.sin(a), z: c.Rv * Math.cos(a), g: [0, 0, c.p.roll * DEG] });
    }
  },
  drum: {
    name: 'Drum', icon: '🥁', desc: 'Vertical ring, cards on the surface',
    params: [P('roll', 'Drum tilt', -60, 60, 1, 0, '°')],
    fn(d, i, n, c) {
      const a = d / n * TAU;
      return T({ y: -c.Rv * Math.sin(a), z: c.Rv * Math.cos(a), rx: a, g: [0, 0, c.p.roll * DEG] });
    }
  },
  scatter: {
    name: 'Polaroid scatter', icon: '🖼️', desc: 'Loose pile, focus card comes forward',
    params: [P('spread', 'Spread', 0.5, 8, 0.1, 3.2), P('depth', 'Depth', 0, 8, 0.1, 3), P('rot', 'Rotation', 0, 90, 1, 35, '°'), P('pop', 'Focus pop', 0, 4, 0.1, 1.2), P('float', 'Float', 0, 0.6, 0.01, 0.15)],
    fn(d, i, n, c) {
      const sx = (c.rnd(i, 0) - 0.5) * 2 * c.p.spread, sy = (c.rnd(i, 1) - 0.5) * 2 * c.p.spread * (c.viewH / c.viewW);
      const sz = -c.rnd(i, 2) * c.p.depth - 0.3, srz = (c.rnd(i, 3) - 0.5) * 2 * c.p.rot * DEG;
      const f = 1 - clamp(Math.abs(d), 0, 1);
      const fl = Math.sin(c.t * 1.3 + i * 1.7) * c.p.float;
      return T({ x: lerp(sx, 0, f), y: lerp(sy, 0, f) + fl, z: lerp(sz, c.p.pop, f), rz: lerp(srz, 0, f), s: lerp(0.85, 1.1, f) });
    }
  },
  zigzag: {
    name: 'Zigzag', icon: '⚡', desc: 'Alternating up/down row',
    params: [P('gap', 'Gap', 0.5, 2.5, 0.05, 0.95), P('amp', 'Offset', 0, 1.5, 0.05, 0.5), P('angle', 'Angle', 0, 60, 1, 20, '°'), P('pop', 'Focus pop', 0, 3, 0.1, 0.6)],
    fn(d, i, n, c) {
      const sgn = (i % 2) * 2 - 1;
      return T({ x: d * c.w * c.p.gap, y: sgn * c.p.amp * c.h * 0.5, z: (1 - clamp(Math.abs(d), 0, 1)) * c.p.pop, ry: sgn * c.p.angle * DEG, o: seamFade(d, n, 0.8) });
    }
  },
  domino: {
    name: 'Domino', icon: '🁫', desc: 'Standing cards topple one by one',
    params: [P('gap', 'Gap', 0.5, 2.5, 0.05, 1.05), P('fall', 'Fall angle', 10, 90, 1, 80, '°')],
    fn(d, i, n, c) {
      const k = clamp(-d, 0, 1);
      const rx = -ease('easeInQuad', k) * c.p.fall * DEG;
      return T({ x: d * c.w * c.p.gap, y: -c.h / 2 + (c.h / 2) * Math.cos(rx), z: (c.h / 2) * Math.sin(rx), rx, o: seamFade(d, n, 0.8) });
    }
  },
  flip: {
    name: 'Flip card', icon: '🔃', desc: 'One card flips to the next',
    params: [P('axis', 'Axis (0 = horizontal, 1 = vertical)', 0, 1, 1, 0), P('slide', 'Slide', 0, 2, 0.05, 0.3)],
    fn(d, i, n, c) {
      if (Math.abs(d) > 0.5) return T({ o: 0 });
      const a = d * Math.PI;
      const off = Math.sin(d * Math.PI) * c.p.slide;
      return c.p.axis >= 0.5 ? T({ rx: -a, y: off }) : T({ ry: a, x: off });
    }
  },
  hinge: {
    name: 'Page turn', icon: '📖', desc: 'Pages hinged on the left edge',
    params: [P('angle', 'Turn angle', 90, 180, 1, 170, '°')],
    fn(d, i, n, c) {
      const k = clamp(-d, 0, 1);
      const ry = -ease('easeInOutSine', k) * c.p.angle * DEG;
      const base = d >= 0 ? -d * 0.03 : -(1 - k) * 0.03;
      return T({ x: -c.w / 2 + (c.w / 2) * Math.cos(ry) + c.w / 2, z: -(c.w / 2) * Math.sin(ry) + base, ry, o: d < -1.5 ? 0 : 1 });
    }
  },
  sphere: {
    name: 'Planet', icon: '🌍', desc: 'Cards on a rotating sphere',
    params: [P('radius', 'Radius', 1.5, 8, 0.1, 3.4), P('tilt', 'Axis tilt', -60, 60, 1, 18, '°')],
    fn(d, i, n, c) {
      const y = 1 - (i + 0.5) / n * 2, r = Math.sqrt(1 - y * y);
      const th = i * 2.399963 + c.phase / n * TAU;
      const nx = r * Math.sin(th), nz = r * Math.cos(th), ny = y, R = c.p.radius;
      return T({ x: nx * R, y: ny * R, z: nz * R, ry: Math.atan2(nx, nz), rx: -Math.asin(ny), g: [c.p.tilt * DEG, 0, 0] });
    }
  },
  spiral: {
    name: 'Vortex', icon: '🌪️', desc: 'Twisting tunnel',
    params: [P('depth', 'Depth step', 0.5, 5, 0.1, 2), P('r', 'Radius', 0, 4, 0.05, 1.6), P('twist', 'Twist', 0, 180, 1, 55, '°'), P('roll', 'Card roll', 0, 1, 0.05, 0.5)],
    fn(d, i, n, c) {
      const a = d * c.p.twist * DEG;
      const z = -d * c.p.depth;
      const o = d >= 0 ? clamp(1 - (d - n * 0.5 + 1), 0, 1) : clamp(1 + d * 1.3, 0, 1);
      return T({ x: c.p.r * Math.sin(a), y: c.p.r * Math.cos(a), z, rz: -a * c.p.roll, o });
    }
  },
  swing: {
    name: 'Swing gallery', icon: '🎐', desc: 'Hanging cards that sway',
    params: [P('gap', 'Gap', 0.6, 3, 0.05, 1.15), P('amp', 'Swing', 0, 40, 1, 10, '°'), P('speed', 'Speed', 0.2, 5, 0.1, 1.4)],
    fn(d, i, n, c) {
      const rz = Math.sin(c.t * c.p.speed + i * 0.9) * c.p.amp * DEG;
      return T({ x: d * c.w * c.p.gap + (c.h / 2) * Math.sin(rz), y: c.h / 2 - (c.h / 2) * Math.cos(rz), rz, o: seamFade(d, n, 0.8) });
    }
  }
};

/* ---------------------------------------------------------------------------
   MOTIONS: fn(t, c) -> phase (in cards).  c = { dur, n, p, ease(x), rnd(k) }
   ------------------------------------------------------------------------- */
function stepPhase(t, c, hold, easeFn, turns) {
  const steps = Math.max(1, Math.round(c.n * turns));
  const sd = c.dur / steps;
  const k = Math.floor(t / sd), f = (t - k * sd) / sd;
  const m = clamp((f - hold) / Math.max(0.0001, 1 - hold), 0, 1);
  return k + easeFn(m);
}
const MOTIONS = {
  still:     { name: 'Still', params: [], fn: () => 0 },
  spin:      { name: 'Continuous spin', params: [P('turns', 'Turns per clip', 0.05, 8, 0.05, 1)], fn: (t, c) => t / c.dur * c.p.turns * c.n },
  step:      { name: 'Step by step', params: [P('hold', 'Hold', 0, 0.95, 0.05, 0.55), P('turns', 'Turns per clip', 0.25, 4, 0.25, 1)], fn: (t, c) => stepPhase(t, c, c.p.hold, c.ease, c.p.turns) },
  pulse:     { name: 'Pulse (no hold)', params: [P('turns', 'Turns per clip', 0.25, 4, 0.25, 1)], fn: (t, c) => stepPhase(t, c, 0, c.ease, c.p.turns) },
  kick:      { name: 'Kick (overshoot)', params: [P('hold', 'Hold', 0, 0.95, 0.05, 0.5), P('turns', 'Turns per clip', 0.25, 4, 0.25, 1)], fn: (t, c) => stepPhase(t, c, c.p.hold, EASINGS.easeOutBack.fn, c.p.turns) },
  bounce:    { name: 'Bounce steps', params: [P('hold', 'Hold', 0, 0.95, 0.05, 0.45), P('turns', 'Turns per clip', 0.25, 4, 0.25, 1)], fn: (t, c) => stepPhase(t, c, c.p.hold, EASINGS.easeOutBounce.fn, c.p.turns) },
  elastic:   { name: 'Elastic steps', params: [P('hold', 'Hold', 0, 0.95, 0.05, 0.4), P('turns', 'Turns per clip', 0.25, 4, 0.25, 1)], fn: (t, c) => stepPhase(t, c, c.p.hold, EASINGS.easeOutElastic.fn, c.p.turns) },
  stutter:   { name: 'Stutter (micro steps)', params: [P('sub', 'Sub-steps', 2, 8, 1, 3), P('turns', 'Turns per clip', 0.25, 4, 0.25, 1)], fn: (t, c) => stepPhase(t, { dur: c.dur, n: c.n * c.p.sub }, 0.3, c.ease, c.p.turns) / c.p.sub },
  pingpong:  { name: 'Ping-pong', params: [P('amp', 'Amplitude (cards)', 0.25, 6, 0.25, 1.5), P('cycles', 'Cycles per clip', 0.5, 8, 0.5, 2)], fn: (t, c) => c.p.amp * Math.sin(t / c.dur * c.p.cycles * TAU) },
  swingStep: { name: 'Back and forth', params: [P('cycles', 'Cycles per clip', 0.5, 8, 0.5, 2), P('amp', 'Amplitude (cards)', 0.5, 4, 0.5, 1)], fn: (t, c) => { const cyc = (t / c.dur * c.p.cycles) % 1; return c.p.amp * (cyc < 0.5 ? c.ease(cyc * 2) : 1 - c.ease((cyc - 0.5) * 2)); } },
  easeWhole: { name: 'One eased move', params: [P('turns', 'Turns per clip', 0.1, 6, 0.1, 1)], fn: (t, c) => c.ease(t / c.dur) * c.p.turns * c.n },
  roulette:  { name: 'Roulette (spin & stop)', params: [P('turns', 'Turns', 0.5, 10, 0.5, 3)], fn: (t, c) => EASINGS.easeOutQuart.fn(clamp(t / c.dur, 0, 1)) * c.p.turns * c.n },
  rampUp:    { name: 'Ramp up', params: [P('turns', 'Turns', 0.5, 10, 0.5, 2)], fn: (t, c) => EASINGS.easeInCubic.fn(clamp(t / c.dur, 0, 1)) * c.p.turns * c.n },
  wobble:    { name: 'Wobble', params: [P('turns', 'Turns per clip', 0, 4, 0.05, 0.5), P('wobble', 'Wobble (cards)', 0, 2, 0.05, 0.35), P('speed', 'Wobble speed', 0.2, 10, 0.1, 3)], fn: (t, c) => t / c.dur * c.p.turns * c.n + Math.sin(t * c.p.speed) * c.p.wobble },
  random:    { name: 'Random jumps', params: [P('hold', 'Hold', 0, 0.95, 0.05, 0.5), P('turns', 'Jumps per clip (x cards)', 0.25, 4, 0.25, 1)],
    fn: (t, c) => {
      const steps = Math.max(1, Math.round(c.n * c.p.turns)), sd = c.dur / steps;
      const k = Math.min(steps, Math.floor(t / sd)), f = (t - k * sd) / sd;
      const m = clamp((f - c.p.hold) / Math.max(0.0001, 1 - c.p.hold), 0, 1);
      const inc = (j) => c.n <= 1 ? 1 : 1 + Math.floor(c.rnd(j, 7) * (c.n - 1));
      let ph = 0; for (let j = 0; j < k; j++) ph += inc(j);
      return ph + c.ease(m) * inc(k);
    } },
  breathe:   { name: 'Breathe (in place)', params: [P('amp', 'Amplitude (cards)', 0.05, 1, 0.05, 0.25), P('speed', 'Speed', 0.2, 6, 0.1, 1.5)], fn: (t, c) => Math.sin(t * c.p.speed) * c.p.amp }
};

/* ---------------------------------------------------------------------------
   INTROS / OUTROS.  Per-card fn(p, i, n, c) -> modifiers, identity at p = 1.
   Group presets act on the whole arrangement: group(p, c).
   ------------------------------------------------------------------------- */
const ID = {};
const INTROS = {
  none:       { name: 'None', fn: () => ID },
  fade:       { name: 'Fade', fn: p => ({ o: p }) },
  scaleUp:    { name: 'Scale up', fn: p => ({ s: p, o: Math.min(1, p * 2) }) },
  zoomOut:    { name: 'Zoom out (from big)', fn: p => ({ s: 1 + (1 - p) * 2.5, o: p }) },
  rise:       { name: 'Rise from below', fn: (p, i, n, c) => ({ y: -(1 - p) * c.viewH * 0.75, o: Math.min(1, p * 1.5) }) },
  drop:       { name: 'Drop from above', fn: (p, i, n, c) => ({ y: (1 - p) * c.viewH * 0.75, o: Math.min(1, p * 1.5) }) },
  slideLeft:  { name: 'Slide from left', fn: (p, i, n, c) => ({ x: -(1 - p) * c.viewW * 0.9, o: Math.min(1, p * 1.5) }) },
  slideRight: { name: 'Slide from right', fn: (p, i, n, c) => ({ x: (1 - p) * c.viewW * 0.9, o: Math.min(1, p * 1.5) }) },
  flip:       { name: 'Flip', fn: p => ({ ry: -(1 - p) * Math.PI / 2, o: Math.min(1, p * 1.6) }) },
  flipX:      { name: 'Flip vertical', fn: p => ({ rx: -(1 - p) * Math.PI / 2, o: Math.min(1, p * 1.6) }) },
  spinIn:     { name: 'Spin in', fn: p => ({ rz: (1 - p) * Math.PI, s: p, o: Math.min(1, p * 2) }) },
  zoomThrough:{ name: 'Zoom through camera', fn: (p, i, n, c) => ({ z: (1 - p) * c.camDist * 0.9, o: p }) },
  explode:    { name: 'Explode / assemble', fn: (p, i, n, c) => { const q = 1 - p; return { x: (c.rnd(i, 0) - 0.5) * 16 * q, y: (c.rnd(i, 1) - 0.5) * 16 * q, z: (c.rnd(i, 2) - 0.5) * 10 * q, rx: (c.rnd(i, 3) - 0.5) * 4 * q, ry: (c.rnd(i, 4) - 0.5) * 4 * q, rz: (c.rnd(i, 5) - 0.5) * 4 * q, o: Math.min(1, p * 2) }; } },
  blurIn:     { name: 'Blur in', fn: p => ({ blur: (1 - p) * 40, o: p }) },
  unfold:     { name: 'Unfold', fn: p => ({ rx: (1 - p) * -Math.PI * 0.5, y: -(1 - p) * 0.5, o: Math.min(1, p * 2) }) },
  pop:        { name: 'Elastic pop', fn: p => ({ s: EASINGS.easeOutElastic.fn(p), o: Math.min(1, p * 4) }) },
  swing:      { name: 'Swing in', fn: p => ({ rz: Math.sin((1 - p) * Math.PI * 2) * (1 - p) * 0.6, x: -(1 - p) * 2, o: Math.min(1, p * 2) }) },
  rollIn:     { name: 'Roll in', fn: (p, i, n, c) => ({ x: -(1 - p) * c.viewW * 0.8, rz: (1 - p) * TAU, o: Math.min(1, p * 2) }) },
  tumble:     { name: 'Tumble', fn: (p, i, n, c) => ({ y: (1 - p) * c.viewH * 0.8, rx: (1 - p) * Math.PI, rz: (1 - p) * (c.rnd(i, 0) - 0.5) * 3, o: Math.min(1, p * 2) }) },
  squash:     { name: 'Squash & stretch', fn: p => ({ sx: 1 + (1 - p) * 1.2, sy: Math.max(0.02, p), o: Math.min(1, p * 3) }) },
  wipeUp:     { name: 'Grow upward', fn: p => ({ sy: Math.max(0.02, p), y: -(1 - p) * 0.5, o: Math.min(1, p * 3) }) },
  jitter:     { name: 'Glitch jitter', fn: (p, i, n, c) => { const q = 1 - p; return { x: (c.rnd(i, Math.floor(p * 40)) - 0.5) * q * 3, y: (c.rnd(i, Math.floor(p * 40) + 99) - 0.5) * q * 3, o: p < 0.1 ? 0 : (c.rnd(i, Math.floor(p * 60)) > q * 0.8 ? 1 : 0.15) }; } },
  whirl:      { name: 'Whirl (whole ring spins)', group: (p, c) => ({ phase: (1 - p) * c.n * 0.75, s: 0.2 + 0.8 * p, o: p }) },
  curtain:    { name: 'Curtain (scale height)', group: (p) => ({ sy: Math.max(0.02, p), o: p }) },
  drawer:     { name: 'Drawer (slide up)', group: (p, c) => ({ y: -(1 - p) * c.viewH, o: 1 }) },
  tiltIn:     { name: 'Tilt in', group: (p, c) => ({ gx: (1 - p) * -1.2, y: (1 - p) * -2, o: p }) },
  orbitIn:    { name: 'Orbit in', group: (p) => ({ gy: (1 - p) * Math.PI, o: p }) },
  zoomAll:    { name: 'Zoom all', group: (p) => ({ s: 0.05 + 0.95 * p, o: p }) },
  dropAll:    { name: 'Drop all', group: (p, c) => ({ y: (1 - p) * c.viewH, o: 1 }) }
};

/* ---------------------------------------------------------------------------
   CAMERA moves.  fn(t, c) -> { yaw, pitch, roll, dist, fovMul, x, y }
   ------------------------------------------------------------------------- */
const CAMERAS = {
  static:    { name: 'Static', params: [], fn: () => ({}) },
  orbit:     { name: 'Gentle orbit', params: [P('angle', 'Angle', 2, 90, 1, 18, '°')], fn: (t, c) => ({ yaw: Math.sin(t / c.dur * TAU) * c.p.angle * DEG }) },
  orbitFull: { name: 'Full orbit', params: [P('turns', 'Turns', 0.25, 4, 0.25, 1)], fn: (t, c) => ({ yaw: t / c.dur * TAU * c.p.turns }) },
  dollyIn:   { name: 'Dolly in', params: [P('amount', 'Amount', 0.05, 2, 0.05, 0.35)], fn: (t, c) => ({ dist: 1 + c.p.amount * (1 - ease('easeInOutSine', t / c.dur)) }) },
  dollyOut:  { name: 'Dolly out', params: [P('amount', 'Amount', 0.05, 2, 0.05, 0.35)], fn: (t, c) => ({ dist: 1 + c.p.amount * ease('easeInOutSine', t / c.dur) }) },
  rise:      { name: 'Rise (crane up)', params: [P('amount', 'Amount', 0.1, 1.5, 0.05, 0.5)], fn: (t, c) => ({ pitch: (t / c.dur - 0.5) * c.p.amount }) },
  tiltDown:  { name: 'Crane down', params: [P('amount', 'Amount', 0.1, 1.5, 0.05, 0.5)], fn: (t, c) => ({ pitch: (0.5 - t / c.dur) * c.p.amount }) },
  handheld:  { name: 'Handheld', params: [P('amount', 'Amount', 0.1, 3, 0.1, 1)], fn: (t, c) => ({ yaw: smoothNoise(t * 0.9) * 0.05 * c.p.amount, pitch: smoothNoise(t * 1.1 + 5) * 0.04 * c.p.amount, roll: smoothNoise(t * 0.7 + 9) * 0.02 * c.p.amount, dist: 1 + smoothNoise(t * 0.5 + 3) * 0.03 * c.p.amount }) },
  dutch:     { name: 'Dutch roll', params: [P('angle', 'Angle', 1, 45, 1, 8, '°')], fn: (t, c) => ({ roll: Math.sin(t / c.dur * TAU) * c.p.angle * DEG }) },
  breathe:   { name: 'Zoom breathe', params: [P('amount', 'Amount', 0.01, 0.4, 0.01, 0.06), P('cycles', 'Cycles', 0.5, 8, 0.5, 2)], fn: (t, c) => ({ dist: 1 + Math.sin(t / c.dur * TAU * c.p.cycles) * c.p.amount }) },
  swoop:     { name: 'Swoop in', params: [P('time', 'Duration', 0.3, 4, 0.1, 1.2)], fn: (t, c) => { const p = ease('easeOutCubic', Math.min(1, t / c.p.time)); return { dist: 1 + (1 - p) * 1.2, pitch: (1 - p) * 0.6, yaw: (1 - p) * 0.8 }; } },
  spiralOut: { name: 'Spiral out', params: [P('amount', 'Amount', 0.1, 2, 0.05, 0.6)], fn: (t, c) => ({ yaw: t / c.dur * TAU, dist: 1 + t / c.dur * c.p.amount, pitch: 0.3 * (1 - t / c.dur) }) },
  vertigo:   { name: 'Vertigo (dolly zoom)', params: [P('amount', 'Amount', 0.1, 1.5, 0.05, 0.6)], fn: (t, c) => { const k = Math.sin(t / c.dur * Math.PI) * c.p.amount; return { fovMul: 1 + k, dist: 1 / (1 + k) }; } },
  pan:       { name: 'Pan across', params: [P('amount', 'Amount', 0.2, 6, 0.1, 2)], fn: (t, c) => ({ x: (t / c.dur - 0.5) * c.p.amount }) },
  bob:       { name: 'Bob (floating)', params: [P('amount', 'Amount', 0.05, 1, 0.05, 0.25)], fn: (t, c) => ({ y: Math.sin(t * 1.6) * c.p.amount, roll: Math.sin(t * 1.1) * 0.02 }) }
};

/* ---------------------------------------------------------------------------
   Card / fx / camera defaults
   ------------------------------------------------------------------------- */
const DEFAULTS = {
  template: 'classic',
  layout: 'carousel', lp: {},
  motion: 'step', mp: {},
  ease: 'easeInOutCubic',
  dir: 1,
  duration: 5,
  aspect: '16:9',
  card: { size: 1, aspect: 'auto', fit: 'cover', spacing: 1.25, radiusScale: 1, corner: 24, border: 0, borderColor: '#ffffff', yOffset: 0, focusOffset: 0, offX: 0, offY: 0 },
  fx: { depthBlur: true, blurAmt: 1, focus: 'front', dim: 0.35, gray: 0, reflection: 0, reflBlur: 6, shadow: 0, glow: 0, glowColor: '#5b9dff', parallax: 0, vignette: 0, tint: '#ff8a3d', tintAmt: 0, backface: 'dim', bright: 1 },
  camera: { preset: 'static', cp: {}, fov: 45, zoom: 1, height: 0, pitch: 0, roll: 0, yaw: 0 },
  group: { rx: 0, ry: 0, rz: 0 },
  fps: 'seq',
  intro: { enabled: false, style: 'scaleUp', dur: 0.8, stagger: 0.08, ease: 'easeOutBack' },
  outro: { enabled: false, style: 'fade', dur: 0.6, stagger: 0.05, ease: 'easeInCubic' },
  bg: { enabled: false, source: 'focus', blur: 0.6, zoom: 1.3, opacity: 1, dark: 0.35, sat: 0.7, fade: 0.5, move: 'drift', moveAmt: 1, bgp: {} },
  previewBg: 'black',
  output: 'render',
  native: { method: 'cornerpin', bake: true },
  speed: 0.75,
  linger: 0.1,
  split: false
};

/* "Linger at front": the fractional phase is warped through a cubic Bezier from
   (0,0) to (1,1). Handles near the ends make the card slow into and out of the
   front position. d = 0 -> identity. The curve can also be edited by hand
   (state.lingerCurve = [x1, y1, x2, y2]). */
function lingerHandles(d, curve) {
  if (curve && curve.length === 4) return curve;
  const k = clamp(d, 0, 1) * 0.92;
  return [k, 0, 1 - k, 1];
}
function bezierWarp(f, c) {
  if (f <= 0) return 0; if (f >= 1) return 1;
  const bx = (t) => 3 * (1 - t) * (1 - t) * t * c[0] + 3 * (1 - t) * t * t * c[2] + t * t * t;
  const by = (t) => 3 * (1 - t) * (1 - t) * t * c[1] + 3 * (1 - t) * t * t * c[3] + t * t * t;
  let lo = 0, hi = 1, t = f;
  for (let i = 0; i < 18; i++) { t = (lo + hi) / 2; if (bx(t) < f) lo = t; else hi = t; }
  return clamp(by(t), 0, 1);
}
function lingerWarp(f, d, curve) {
  if (d <= 0 && !curve) return f;
  return bezierWarp(f, lingerHandles(d, curve));
}

/* ---------------------------------------------------------------------------
   Background movement presets.  fn(t, c) -> { x, y (units), s (scale), rz }
   c = { dur, phase, n, p, focusX }
   ------------------------------------------------------------------------- */
const BG_MOVES = {
  none:     { name: 'Static', params: [], fn: () => ({}) },
  drift:    { name: 'Slow drift', params: [P('speed', 'Speed', 0.1, 3, 0.1, 1)], fn: (t, c) => ({ x: Math.sin(t * 0.35 * c.p.speed) * 0.7, y: Math.cos(t * 0.27 * c.p.speed) * 0.45 }) },
  zoomIn:   { name: 'Zoom in', params: [P('amount', 'Amount', 0.05, 1, 0.05, 0.25)], fn: (t, c) => ({ s: 1 + t / c.dur * c.p.amount }) },
  zoomOut:  { name: 'Zoom out', params: [P('amount', 'Amount', 0.05, 1, 0.05, 0.25)], fn: (t, c) => ({ s: 1 + (1 - t / c.dur) * c.p.amount }) },
  parallax: { name: 'Follow the ring', params: [P('amount', 'Amount', 0.1, 3, 0.1, 1)], fn: (t, c) => ({ x: -Math.sin(c.phase / c.n * TAU) * 0.9 * c.p.amount }) },
  follow:   { name: 'Follow focus card', params: [P('amount', 'Amount', 0.1, 3, 0.1, 1)], fn: (t, c) => ({ x: c.focusX * 0.25 * c.p.amount }) },
  rotate:   { name: 'Gentle rotate', params: [P('angle', 'Angle', 1, 30, 1, 5, '°')], fn: (t, c) => ({ rz: Math.sin(t * 0.25) * c.p.angle * DEG }) },
  pulse:    { name: 'Pulse', params: [P('speed', 'Speed', 0.2, 6, 0.1, 1.5)], fn: (t, c) => ({ s: 1 + Math.sin(t * c.p.speed) * 0.035 }) },
  breathe:  { name: 'Breathe', params: [P('amount', 'Amount', 0.02, 0.4, 0.01, 0.08)], fn: (t, c) => ({ s: 1 + Math.sin(t / c.dur * TAU) * c.p.amount }) },
  pan:      { name: 'Pan across', params: [P('amount', 'Amount', 0.2, 4, 0.1, 1.5)], fn: (t, c) => ({ x: (t / c.dur - 0.5) * c.p.amount }) },
  tiltPan:  { name: 'Diagonal pan', params: [P('amount', 'Amount', 0.2, 4, 0.1, 1.2)], fn: (t, c) => ({ x: (t / c.dur - 0.5) * c.p.amount, y: (0.5 - t / c.dur) * c.p.amount * 0.6 }) },
  handheld: { name: 'Handheld', params: [P('amount', 'Amount', 0.1, 3, 0.1, 1)], fn: (t, c) => ({ x: smoothNoise(t * 0.8) * 0.3 * c.p.amount, y: smoothNoise(t * 1.1 + 4) * 0.2 * c.p.amount, rz: smoothNoise(t * 0.6 + 8) * 0.01 * c.p.amount }) },
  spin:     { name: 'Slow spin', params: [P('turns', 'Turns per clip', 0.05, 1, 0.05, 0.15)], fn: (t, c) => ({ rz: t / c.dur * TAU * c.p.turns, s: 1.35 }) }
};

/* ---------------------------------------------------------------------------
   TEMPLATES: curated combinations.  `set` is deep-merged over DEFAULTS.
   ------------------------------------------------------------------------- */
const TEMPLATES = [
  /* basic: clean, no effects */
  { id: 'basicSlide',     cat: 'Basic', name: 'Simple Slide', icon: '▶️', set: { layout: 'filmstrip', motion: 'step', ease: 'easeInOutCubic', fx: { depthBlur: false, dim: 0 }, card: { corner: 16 } } },
  { id: 'basicRing',      cat: 'Basic', name: 'Simple Ring', icon: '⭕', set: { layout: 'carousel', motion: 'step', fx: { depthBlur: false, dim: 0.25 } } },
  { id: 'basicCoverflow', cat: 'Basic', name: 'Simple Coverflow', icon: '🎞️', set: { layout: 'coverflow', motion: 'step', fx: { depthBlur: false, dim: 0.2 } } },
  { id: 'basicGrid',      cat: 'Basic', name: 'Simple Grid', icon: '🧱', set: { layout: 'wall', lp: { wall: { pop: 1.2, sway: 6 } }, motion: 'step', ease: 'easeInOutCubic', fx: { depthBlur: false, dim: 0.2 } } },
  { id: 'basicStack',     cat: 'Basic', name: 'Simple Stack', icon: '🗂️', set: { layout: 'stack', motion: 'step', ease: 'easeInOutQuart', fx: { depthBlur: false, dim: 0.15 } } },
  { id: 'basicZoom',      cat: 'Basic', name: 'Simple Zoom', icon: '🔍', set: { layout: 'tunnel', motion: 'step', ease: 'easeInOutCubic', fx: { depthBlur: false, dim: 0.3 } } },
  { id: 'basicFlip',      cat: 'Basic', name: 'Simple Flip', icon: '🔃', set: { layout: 'flip', motion: 'step', card: { size: 1.3 }, fx: { depthBlur: false, dim: 0 } } },
  { id: 'basicSpin',      cat: 'Basic', name: 'Simple Spin', icon: '🌀', set: { layout: 'ring', motion: 'spin', fx: { depthBlur: false, dim: 0.2 } } },
  /* rings */
  { id: 'classic',    cat: 'Rings', name: 'Classic Carousel', icon: '🎠', set: {} },
  { id: 'smoothSpin', cat: 'Rings', name: 'Smooth Spin', icon: '🌀', set: { motion: 'spin', fx: { dim: 0.45 } } },
  { id: 'billboard',  cat: 'Rings', name: 'Billboard Ring', icon: '⭕', set: { layout: 'ring', motion: 'spin', fx: { dim: 0.3 } } },
  { id: 'inward',     cat: 'Rings', name: 'Inward Ring', icon: '🔄', set: { layout: 'inward', motion: 'step', ease: 'easeInOutQuart', fx: { backface: 'dim' } } },
  { id: 'prism',      cat: 'Rings', name: 'Prism Cube', icon: '🧊', set: { layout: 'prism', motion: 'step', ease: 'easeInOutBack', card: { corner: 4 }, fx: { dim: 0.5, depthBlur: false } } },
  { id: 'tiltedOrbit',cat: 'Rings', name: 'Tilted Orbit', icon: '🪐', set: { layout: 'orbit', motion: 'spin', camera: { preset: 'orbit' } } },
  { id: 'helix',      cat: 'Rings', name: 'Helix Rise', icon: '🧬', set: { layout: 'helix', motion: 'spin', mp: { turns: 1 }, card: { spacing: 1.1 } } },
  { id: 'insideRing', cat: 'Rings', name: 'Inside the Ring', icon: '🌐', set: { layout: 'inside', motion: 'spin', fx: { depthBlur: true, blurAmt: 0.6, dim: 0.25 } } },
  { id: 'planet',     cat: 'Rings', name: 'Planet', icon: '🌍', set: { layout: 'sphere', motion: 'spin', card: { size: 0.75 }, fx: { dim: 0.4 } } },
  { id: 'neonRing',   cat: 'Rings', name: 'Neon Ring', icon: '💠', set: { layout: 'ring', motion: 'spin', fx: { glow: 0.9, glowColor: '#5b9dff', dim: 0.2 }, card: { border: 3, borderColor: '#9cc4ff', corner: 32 } } },
  { id: 'mirrorFloor',cat: 'Rings', name: 'Mirror Floor', icon: '🪞', set: { fx: { reflection: 0.45, shadow: 0.35, dim: 0.3 }, camera: { pitch: 8 } } },
  { id: 'roulette',   cat: 'Rings', name: 'Roulette', icon: '🎰', set: { motion: 'roulette', mp: { turns: 3 }, fx: { blurAmt: 1.4 } } },
  { id: 'ferris',     cat: 'Rings', name: 'Ferris Wheel', icon: '🎡', set: { layout: 'ferris', motion: 'spin', card: { size: 0.8, spacing: 1.15 } } },
  { id: 'drum',       cat: 'Rings', name: 'Drum Roll', icon: '🥁', set: { layout: 'drum', motion: 'step', ease: 'easeInOutQuart', card: { spacing: 1.1 }, fx: { dim: 0.45 } } },
  { id: 'slot',       cat: 'Rings', name: 'Slot Machine', icon: '🎲', set: { layout: 'drum', motion: 'roulette', mp: { turns: 4 }, card: { spacing: 1.05 }, fx: { blurAmt: 1.8, dim: 0.5 } } },
  /* rows */
  { id: 'coverflow',  cat: 'Rows', name: 'Coverflow Snap', icon: '🎞️', set: { layout: 'coverflow', motion: 'step', ease: 'easeOutBack', fx: { dim: 0.3, reflection: 0.3 } } },
  { id: 'coverGlide', cat: 'Rows', name: 'Coverflow Glide', icon: '🛝', set: { layout: 'coverflow', motion: 'spin', mp: { turns: 1 }, fx: { dim: 0.3 } } },
  { id: 'filmstrip',  cat: 'Rows', name: 'Film Strip', icon: '📽️', set: { layout: 'filmstrip', motion: 'spin', fx: { depthBlur: false, dim: 0 }, card: { corner: 12 } } },
  { id: 'curvedWall', cat: 'Rows', name: 'Curved Wall', icon: '🌉', set: { layout: 'arc', motion: 'step', ease: 'easeInOutCubic', fx: { dim: 0.25 } } },
  { id: 'wave',       cat: 'Rows', name: 'Ocean Wave', icon: '🌊', set: { layout: 'wave', motion: 'spin', fx: { dim: 0.2 } } },
  { id: 'zigzag',     cat: 'Rows', name: 'Zigzag Run', icon: '⚡', set: { layout: 'zigzag', motion: 'step', ease: 'easeInOutQuint', card: { size: 0.85 } } },
  { id: 'domino',     cat: 'Rows', name: 'Domino Fall', icon: '🁫', set: { layout: 'domino', motion: 'step', ease: 'easeInOutSine', mp: { hold: 0.4 }, fx: { shadow: 0.4, depthBlur: false }, camera: { pitch: 18 } } },
  { id: 'staircase',  cat: 'Rows', name: 'Staircase', icon: '🪜', set: { layout: 'cascade', motion: 'step', ease: 'easeInOutCubic' } },
  { id: 'column',     cat: 'Rows', name: 'Column Scroll', icon: '🧮', set: { layout: 'column', motion: 'spin', fx: { depthBlur: false, dim: 0 } } },
  { id: 'swingGal',   cat: 'Rows', name: 'Swing Gallery', icon: '🎐', set: { layout: 'swing', motion: 'spin', mp: { turns: 0.5 }, fx: { shadow: 0.3 } } },
  { id: 'pingpong',   cat: 'Rows', name: 'Ping-Pong', icon: '🏓', set: { layout: 'coverflow', motion: 'pingpong', fx: { dim: 0.3 } } },
  { id: 'monoFocus',  cat: 'Rows', name: 'Mono Focus', icon: '🎯', set: { layout: 'coverflow', motion: 'step', fx: { gray: 1, dim: 0.5, blurAmt: 1.3 } } },
  /* stacks & flips */
  { id: 'stack',      cat: 'Stacks & flips', name: 'Card Stack Swipe', icon: '🗂️', set: { layout: 'stack', motion: 'step', ease: 'easeInOutQuart', fx: { shadow: 0.4, dim: 0.3 } } },
  { id: 'fan',        cat: 'Stacks & flips', name: 'Fan Deck', icon: '🪭', set: { layout: 'fan', motion: 'step', ease: 'easeInOutCubic', fx: { shadow: 0.35, depthBlur: false } } },
  { id: 'flip',       cat: 'Stacks & flips', name: 'Flip Card', icon: '🔃', set: { layout: 'flip', motion: 'step', ease: 'easeInOutCubic', card: { size: 1.4 }, fx: { depthBlur: false, dim: 0 } } },
  { id: 'flipV',      cat: 'Stacks & flips', name: 'Flip Vertical', icon: '🔁', set: { layout: 'flip', lp: { flip: { axis: 1 } }, motion: 'step', ease: 'easeInOutBack', card: { size: 1.4 }, fx: { depthBlur: false, dim: 0 } } },
  { id: 'pageTurn',   cat: 'Stacks & flips', name: 'Page Turn', icon: '📖', set: { layout: 'hinge', motion: 'step', ease: 'easeInOutSine', card: { size: 1.2 }, fx: { shadow: 0.3, depthBlur: false } } },
  { id: 'polaroid',   cat: 'Stacks & flips', name: 'Polaroid Float', icon: '🖼️', set: { layout: 'scatter', motion: 'step', ease: 'easeInOutBack', card: { border: 14, borderColor: '#ffffff', corner: 6, size: 0.85 }, fx: { shadow: 0.5, dim: 0.2 } } },
  { id: 'heroPop',    cat: 'Stacks & flips', name: 'Hero Pop', icon: '💥', set: { layout: 'stack', motion: 'kick', card: { size: 1.1 }, intro: { enabled: true, style: 'pop', dur: 0.9, stagger: 0.12 }, outro: { enabled: true, style: 'scaleUp' } } },
  /* grids */
  { id: 'reelWall',   cat: 'Grids', name: 'Reel Wall', icon: '🧱', set: { layout: 'wall', motion: 'still', intro: { enabled: true, style: 'drop', dur: 0.7, stagger: 0.1, ease: 'easeOutBounce' }, outro: { enabled: true, style: 'fade', dur: 0.5 }, fx: { depthBlur: false, dim: 0 } } },
  { id: 'wallSway',   cat: 'Grids', name: 'Wall Sway', icon: '🪟', set: { layout: 'wall', motion: 'spin', fx: { depthBlur: false, dim: 0 } } },
  { id: 'gridPop',    cat: 'Grids', name: 'Grid Pop', icon: '🔲', set: { layout: 'wall', lp: { wall: { pop: 1.4, sway: 6 } }, motion: 'random', fx: { dim: 0.35 } } },
  { id: 'gridFlip',   cat: 'Grids', name: 'Grid Flip In', icon: '🃏', set: { layout: 'wall', motion: 'still', intro: { enabled: true, style: 'flip', dur: 0.6, stagger: 0.1, ease: 'easeOutBack' }, outro: { enabled: true, style: 'flip', dur: 0.5, stagger: 0.06 }, fx: { depthBlur: false, dim: 0 } } },
  /* motion styles */
  { id: 'bounce',     cat: 'Motion styles', name: 'Bounce Steps', icon: '🏀', set: { motion: 'bounce' } },
  { id: 'elastic',    cat: 'Motion styles', name: 'Elastic Snap', icon: '🧲', set: { layout: 'coverflow', motion: 'elastic', fx: { dim: 0.3 } } },
  { id: 'pulse',      cat: 'Motion styles', name: 'Pulse Rotate', icon: '💓', set: { motion: 'pulse', ease: 'easeInOutSine' } },
  { id: 'wobble',     cat: 'Motion styles', name: 'Wobble Ring', icon: '🫨', set: { layout: 'inward', motion: 'wobble' } },
  { id: 'stutter',    cat: 'Motion styles', name: 'Stutter', icon: '⏭️', set: { motion: 'stutter', ease: 'easeOutExpo' } },
  { id: 'backForth',  cat: 'Motion styles', name: 'Back & Forth', icon: '↔️', set: { layout: 'carousel', motion: 'swingStep', ease: 'easeInOutBack' } },
  { id: 'rampUp',     cat: 'Motion styles', name: 'Ramp Up', icon: '📈', set: { motion: 'rampUp', fx: { blurAmt: 1.6 } } },
  { id: 'randomJump', cat: 'Motion styles', name: 'Random Jump', icon: '🎲', set: { motion: 'random', ease: 'easeOutExpo' } },
  { id: 'flyThrough', cat: 'Motion styles', name: 'Fly Through', icon: '🚀', set: { layout: 'tunnel', motion: 'spin', fx: { blurAmt: 0.8, dim: 0.5 } } },
  { id: 'vortex',     cat: 'Motion styles', name: 'Vortex', icon: '🌪️', set: { layout: 'spiral', motion: 'spin', fx: { dim: 0.5 } } },
  /* camera */
  { id: 'dollyIn',    cat: 'Camera', name: 'Dolly In', icon: '🎥', set: { motion: 'spin', mp: { turns: 0.5 }, camera: { preset: 'dollyIn' } } },
  { id: 'handheld',   cat: 'Camera', name: 'Handheld', icon: '🤳', set: { layout: 'coverflow', motion: 'step', camera: { preset: 'handheld' } } },
  { id: 'dutch',      cat: 'Camera', name: 'Dutch Roll', icon: '🎢', set: { layout: 'ring', motion: 'spin', camera: { preset: 'dutch' } } },
  { id: 'swoop',      cat: 'Camera', name: 'Swoop In', icon: '🦅', set: { motion: 'spin', mp: { turns: 0.75 }, camera: { preset: 'swoop' } } },
  { id: 'vertigo',    cat: 'Camera', name: 'Vertigo', icon: '😵‍💫', set: { layout: 'coverflow', motion: 'step', camera: { preset: 'vertigo' } } },
  { id: 'crane',      cat: 'Camera', name: 'Crane Up', icon: '🏗️', set: { motion: 'spin', mp: { turns: 0.5 }, camera: { preset: 'rise', height: 0.4 } } },
  { id: 'tunnelSpin', cat: 'Camera', name: 'Tunnel Spin', icon: '🕳️', set: { layout: 'spiral', motion: 'spin', camera: { preset: 'orbit' }, fx: { dim: 0.5 } } },
  { id: 'floating',   cat: 'Camera', name: 'Floating', icon: '🎈', set: { layout: 'ring', motion: 'breathe', camera: { preset: 'bob' } } },
  /* appear & disappear */
  { id: 'explodeIn',  cat: 'Appear & disappear', name: 'Explode In', icon: '🎆', set: { motion: 'spin', mp: { turns: 0.5 }, intro: { enabled: true, style: 'explode', dur: 1, stagger: 0.05, ease: 'easeOutCubic' }, outro: { enabled: true, style: 'explode', dur: 0.8, stagger: 0.04, ease: 'easeInCubic' } } },
  { id: 'blurReveal', cat: 'Appear & disappear', name: 'Blur Reveal', icon: '🌫️', set: { layout: 'filmstrip', motion: 'spin', intro: { enabled: true, style: 'blurIn', dur: 0.8, stagger: 0.1 }, outro: { enabled: true, style: 'blurIn', dur: 0.6 }, fx: { depthBlur: false, dim: 0 } } },
  { id: 'whirlIn',    cat: 'Appear & disappear', name: 'Whirl In', icon: '🌀', set: { intro: { enabled: true, style: 'whirl', dur: 1.1, ease: 'easeOutCubic' }, outro: { enabled: true, style: 'whirl', dur: 0.9, ease: 'easeInCubic' } } },
  { id: 'curtain',    cat: 'Appear & disappear', name: 'Curtain', icon: '🎭', set: { layout: 'wall', motion: 'still', intro: { enabled: true, style: 'curtain', dur: 0.8, ease: 'easeOutQuart' }, outro: { enabled: true, style: 'curtain', dur: 0.6, ease: 'easeInQuart' }, fx: { depthBlur: false, dim: 0 } } },
  { id: 'drawer',     cat: 'Appear & disappear', name: 'Slide Up', icon: '⬆️', set: { layout: 'coverflow', motion: 'step', intro: { enabled: true, style: 'drawer', dur: 0.7, ease: 'easeOutExpo' }, outro: { enabled: true, style: 'drawer', dur: 0.6, ease: 'easeInExpo' } } },
  { id: 'tumbleIn',   cat: 'Appear & disappear', name: 'Tumble In', icon: '🤸', set: { layout: 'filmstrip', motion: 'still', intro: { enabled: true, style: 'tumble', dur: 0.9, stagger: 0.12, ease: 'easeOutBack' }, outro: { enabled: true, style: 'rise', dur: 0.6, stagger: 0.06 } } },
  { id: 'rollIn',     cat: 'Appear & disappear', name: 'Roll In', icon: '🎳', set: { layout: 'filmstrip', motion: 'step', intro: { enabled: true, style: 'rollIn', dur: 0.9, stagger: 0.1, ease: 'easeOutCubic' }, outro: { enabled: true, style: 'rollIn', dur: 0.7 } } },
  { id: 'glitch',     cat: 'Appear & disappear', name: 'Glitch In', icon: '📺', set: { layout: 'wall', motion: 'spin', intro: { enabled: true, style: 'jitter', dur: 0.6, stagger: 0.05, ease: 'linear' }, outro: { enabled: true, style: 'jitter', dur: 0.5, ease: 'linear' }, fx: { depthBlur: false } } },
  { id: 'orbitIn',    cat: 'Appear & disappear', name: 'Orbit In', icon: '🛰️', set: { layout: 'ring', motion: 'spin', intro: { enabled: true, style: 'orbitIn', dur: 1.2, ease: 'easeOutCubic' }, outro: { enabled: true, style: 'zoomAll', dur: 0.7, ease: 'easeInCubic' } } },
  { id: 'zoomThrough',cat: 'Appear & disappear', name: 'Zoom Through', icon: '🔭', set: { intro: { enabled: true, style: 'zoomThrough', dur: 0.9, stagger: 0.1, ease: 'easeOutCubic' }, outro: { enabled: true, style: 'zoomThrough', dur: 0.7, stagger: 0.06, ease: 'easeInCubic' } } }
];

const ASPECTS = { '9:16': 9 / 16, '4:5': 4 / 5, '1:1': 1, '3:4': 3 / 4, '16:9': 16 / 9 };
const CARD_ASPECTS = { auto: 0, '9:16': 9 / 16, '4:5': 4 / 5, '1:1': 1, '3:4': 3 / 4, '16:9': 16 / 9, '2:3': 2 / 3 };

function deepMerge(base, patch) {
  const out = Array.isArray(base) ? base.slice() : Object.assign({}, base);
  if (!patch) return out;
  for (const k of Object.keys(patch)) {
    const v = patch[k];
    if (v && typeof v === 'object' && !Array.isArray(v) && out[k] && typeof out[k] === 'object') out[k] = deepMerge(out[k], v);
    else out[k] = (v && typeof v === 'object' && !Array.isArray(v)) ? deepMerge({}, v) : v;
  }
  return out;
}
function paramValues(defs, stored) {
  const o = {};
  for (const d of defs || []) o[d.k] = (stored && stored[d.k] !== undefined) ? stored[d.k] : d.def;
  return o;
}
function templateState(id, keep) {
  const t = TEMPLATES.find(x => x.id === id) || TEMPLATES[0];
  const s = deepMerge(deepMerge({}, DEFAULTS), t.set);
  s.template = t.id;
  if (keep) {
    for (const k of ['duration', 'aspect', 'previewBg', 'split', 'output', 'bg', 'native', 'speed', 'linger', 'fps', 'lingerCurve']) if (keep[k] !== undefined) s[k] = keep[k];
  }
  return s;
}
