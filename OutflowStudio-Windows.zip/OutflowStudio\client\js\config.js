/* Built-in API keys. Paste your own keys here once and every copy of the panel
   works without asking users for keys (this is what BadFX does with its own keys).
   Get them free at:
     Pexels : https://www.pexels.com/api/
     Giphy  : https://developers.giphy.com/dashboard/
   (Tenor's public API was shut down by Google in 2026; Giphy covers GIFs.)
   Keys entered in Settings override these. Openverse needs no key. */
/* Website and licence API. In the browser preview (localhost:8765) the fake dev API on :8766 is used. */
window.OUTFLOW = (location.hostname === 'localhost' && location.port === '8765')
  ? { site: 'http://localhost:8766', api: 'http://localhost:8766', pricing: '/dev/pricing', version: '1.14.4' }
  : { site: 'https://outflowstudio.com', api: 'https://egymovdfigpfgdnenajq.supabase.co/functions/v1', pricing: '/pricing', version: '1.14.4' };
window.BUILTIN_KEYS = {
  pexels: 'SnK3K2D0E5bJgNpSjQu8VronC0gQDhC5WX13s9S3ZqJNj5F3MMz1BYCM',
  giphy: '5l2Epna8EfYWbNAU11MFZ2pnS5bPb6Ob',
  tenor: '',
  freesound: '',   /* sound effects: https://freesound.org/apiv2/apply/ */
  openai: ''   /* optional: Whisper transcription for Word Captions (paid per minute) */
};
