/* Outflow Studio hub: start screen, screen routing, settings, shared toast. */
const Hub = (() => {
  const $ = (s) => document.querySelector(s);
  let current = 'home';
  let keys = {};
  try { Vault.init(); keys = Vault.loadKeys(); } catch (e) { keys = {}; }

  const TOOLS = [
    { id: 'carousel', name: '3D Carousel', icon: 'carousel', hot: true, desc: '3D card carousels from your images and video, 74 templates.', go: () => window.CarouselTool.show('gallery') },
    { id: 'stock', name: 'Stock media', icon: 'stock', desc: 'Pexels photos and videos, Openverse audio, Freesound SFX, Giphy GIFs.', go: () => Stock.open('photos') },
    { id: 'assist', name: 'Auto Edit', icon: 'assist', hot: true, desc: 'The whole edit in one click, or step by step: auto cut, captions, takes, fillers, profanity, multicam, zoom, beats, reframe.', go: () => Assist.openMenu() },
    { id: 'curves', name: 'Motion Curves', icon: 'curves', hot: true, desc: 'Ease any keyframes on a clip: pick a curve or drag the handles, apply. Position, scale, rotation, opacity, any effect.', go: () => Curves.open() },
    { id: 'montage', name: 'Zoom Montage', icon: 'zoom', hot: true, desc: 'Clips cut to length back to back, each with a zoom on the cut. Pick the moment of every clip with a drag.', go: () => Montage.open() },
    { id: 'transitions', name: 'Transitions', icon: 'transitions', hot: true, desc: '60+ keyframed transitions (zoom, whip, spin, glitch, light, distort, colour) on an adjustment layer or on the clips, with live previews.', go: () => Transitions.open() },
    /* Guide is held back: it is built and works in the panel, but it has not been tested in Premiere and there
       is no page for it on the site yet. Put the id back in SECTIONS and drop the // to bring it back. */
    // { id: 'guide', name: 'Guide', icon: 'reframe', desc: 'The Instagram, TikTok and YouTube overlays drawn over your sequence, so you can see what they cover while you edit.', go: () => Guide.open() },
    { id: 'tools', name: 'Timeline tools', icon: 'toolbox', desc: 'One-click sidebar: paste from clipboard, un-nest, fit, gaps, dissolves, overlays, voice-over, chapters… Configure it here.', go: () => Toolbox.openMenu() },
    { id: 'social', name: 'Download media', icon: 'download', hot: true, desc: 'YouTube, Instagram, TikTok, X, Vimeo… paste a link, it downloads and lands in your project or at the playhead.', go: () => Social.open() },
    { id: 'quickfx', name: 'Quick FX wheel', icon: 'quickfx', hot: true, desc: 'Radial menu with your saved effects and their settings. Ctrl+Alt+X or the round button.', go: () => QuickFX.openManager() },
    { id: 'audioai', name: 'Audio edit', icon: 'audioai', hot: true, desc: 'Remove or extract vocals, isolate voice, remove echo. Free and local, on your own GPU.', go: () => AudioAI.open() },
    /* Remove background is archived: Premiere has its own now. The tool still works - put the id back in
       SECTIONS and drop the // below to bring it back. */
    // { id: 'matte', name: 'Remove background', icon: 'matte', hot: true, desc: 'Cut a person or object out of a video clip: transparent, a colour or a blurred background. On your GPU.', go: () => Matte.open() },
    { id: 'relight', name: 'Relight', icon: 'relight', hot: true, desc: 'Place lights on a clip: key, rim, spot, neon. Ground shadow, dappled light and colour, on your GPU.', go: () => Relight.open() },
    { id: 'settings', name: 'Settings', icon: 'settings', desc: 'API keys, download folder, video quality.', go: () => show('settings') }
  ];

  function show(name) {
    document.querySelectorAll('.screen').forEach(s => s.classList.toggle('active', s.id === 'screen-' + name));
    current = name;
    document.dispatchEvent(new CustomEvent('screenchange', { detail: name }));
  }

  let toastTimer = null;
  const HINT = /^(Set up the transcription engine|Nothing to paste|Skipped |Give Premiere|Draw a mask first|Your \d+ free |Log in to use |.* is part of Pro\.?$|Select .*first\.?$|Open a sequence first|Add some clips first|No (disabled clips|sequence markers|video clips|repeated takes|clips|speech recognised)|Tick at least one|Nothing (selected|to )|Only (available )?inside Premiere|Pick |Set In|Choose |Load a transcript|Paste a link|Enter a link)/i;
  /*  Raw file-system errors in plain words: "ENOSPC: no space left on device" came in as a bug report.  */
  function plain(msg) {
    const m = String(msg || '');
    if (/ENOSPC|no space left/i.test(m)) return 'The disk is full. Free some space (or choose another folder in Settings), then try again.';
    if (/EACCES|EPERM|operation not permitted|permission denied/i.test(m)) return 'The panel may not write to that folder. Choose another folder in Settings, or check the folder\'s permissions' + (/\\OneDrive\\|OneDrive/i.test(m) ? ' (OneDrive folders can lock files while they sync)' : '') + '.';
    if (/EBUSY|resource busy or locked/i.test(m)) return 'A file is in use by another program. Close it (or wait for a sync to finish), then try again.';
    return m;
  }
  function toast(msg, kind) {
    if (kind === 'err') msg = plain(msg);
    /*  Failed and cancelled jobs are counted (tool + cleaned message, no content) for the owner dashboard.
        The panel's own guidance - "Select clips first", "Your 3 free exports are used" - is shown in red
        too but is not a failure: it is counted apart, as a hint, so the failure rate means something.  */
    const hint = kind === 'err' && HINT.test(String(msg || ''));
    try { if (typeof Usage !== 'undefined' && (kind === 'err' || msg === 'Cancelled.')) Usage.fail(current, msg === 'Cancelled.' ? 'cancel' : hint ? 'hint' : 'fail', msg); } catch (e) {}
    const t = $('#toast'); if (!t) return;
    t.textContent = msg; t.className = 'toast show ' + (kind || '');
    if (kind === 'err' && !hint && typeof BugReport !== 'undefined' && msg !== 'Cancelled.') {
      const b = document.createElement('button'); b.className = 'rep'; b.textContent = 'Report';
      b.addEventListener('click', () => { BugReport.open(null, msg); t.classList.remove('show'); });
      t.appendChild(b);
    }
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), kind === 'err' ? 7000 : 3500);
  }

  function renderHome() {
    const box = $('#home-tiles'); box.innerHTML = ''; box.classList.add('sectioned');
    /* the home screen in sections: create, edit, media, timeline + settings */
    const SECTIONS = [['Create', ['carousel', 'transitions', 'curves']], ['Edit', ['montage', 'assist', 'audioai']], ['VFX', ['relight']], ['Media', ['stock', 'social']], ['Timeline', ['tools', 'quickfx', 'settings']]];
    const byId = Object.fromEntries(TOOLS.map(t => [t.id, t]));
    const rest = TOOLS.filter(t => !SECTIONS.some(s => s[1].includes(t.id)));
    const groups = SECTIONS.map(([name, ids]) => [name, ids.map(id => byId[id]).filter(Boolean)]).concat(rest.length ? [['More', rest]] : []);
    for (const [name, list] of groups) {
      const sec = document.createElement('div'); sec.className = 'home-sec';
      sec.innerHTML = '<div class="home-sec-title">' + name + '</div>';
      const grid = document.createElement('div'); grid.className = 'tiles'; sec.appendChild(grid); box.appendChild(sec);
      for (const t of list) {
      const b = document.createElement('button');
      b.className = 'tile' + (t.soon ? ' soon' : '') + (t.hot ? ' hot' : '');
      b.innerHTML = '<div class="ico">' + icon(t.icon, 28) + '</div><div class="nm">' + t.name + '</div><div class="ds">' + t.desc + '</div>';
      const locked = typeof License !== 'undefined' && License.lock(b, t.id);
      /* free accounts see how many of their free exports are left on the try-before-you-buy tools */
      if (typeof License !== 'undefined' && License.TRIAL_TOOLS.indexOf(t.id) >= 0 && !License.hasTool(t.id)) {
        const left = License.exportsLeft(t.id);
        const s = document.createElement('span');
        s.className = 'left' + (left ? '' : ' none');
        const word = (License.TRIAL_WORD && License.TRIAL_WORD[t.id]) || 'export';
        s.textContent = left ? left + ' free ' + word + (left === 1 ? '' : 's') + ' left' : 'Free ' + word + 's used';
        s.title = left ? 'Free accounts get ' + License.FREE_EXPORTS + ' ' + word + 's in this tool to try it with. Pro makes it unlimited.'
                       : 'Your free ' + word + 's in this tool are used. Pro makes it unlimited.';
        b.appendChild(s);
      }
      if (t.soon) b.disabled = true;
      else b.addEventListener('click', () => { if (typeof License !== 'undefined' && !License.can(t.id)) License.promptUnlock(t.id); else t.go(); });
      grid.appendChild(b);
      }
    }
    $('#home-cep').textContent = CS.inCEP ? 'Connected to Premiere Pro' : 'Browser preview (not inside Premiere)';
    const chip = $('#home-plan');
    if (chip && typeof License !== 'undefined') {
      const pro = License.isPro(), me = License.info();
      chip.className = 'plan' + (pro ? ' pro' : ' free');
      const tools = (me && me.tools && me.tools.length) ? me.tools.map(t => t === 'carousel' ? '3D Carousel' : 'Transitions').join(' + ') : '';
      chip.textContent = pro ? 'Pro · ' + (me.plan || '') : (License.loggedIn() ? (tools ? tools + ' · Unlock Pro' : 'Free · Unlock Pro') : 'Log in');
      chip.onclick = () => { if (pro || License.loggedIn()) show('settings'); else License.showLogin(); };
      /* a gold Get Pro button next to it for everyone who is not Pro yet */
      let get = $('#home-getpro');
      if (!get) { get = document.createElement('button'); get.id = 'home-getpro'; get.className = 'getpro'; get.textContent = 'Get Pro'; get.title = 'See the plans on outflowstudio.com'; get.addEventListener('click', () => CS.openURL(License.pricingUrl('topbar'))); chip.parentNode.insertBefore(get, chip); }
      get.style.display = pro ? 'none' : '';
    }
  }

  function saveKeys() {
    try { Vault.saveKeys(keys); } catch (e) {}
  }
  function renderSettings() {
    const form = $('#settings-form'); form.innerHTML = '';
    const fields = [
      { k: 'pexels', name: 'Pexels API key', hint: 'free at pexels.com/api', url: 'https://www.pexels.com/api/' },
      { k: 'giphy', name: 'Giphy API key', hint: 'free at developers.giphy.com', url: 'https://developers.giphy.com/dashboard/' },
      { k: 'freesound', name: 'Freesound API key (sound effects)', hint: 'free at freesound.org/apiv2/apply', url: 'https://freesound.org/apiv2/apply/' },
      { k: 'openai', name: 'OpenAI API key (optional cloud transcription)', hint: 'platform.openai.com, paid per minute of audio', url: 'https://platform.openai.com/api-keys' },
      { k: 'whisperExe', name: 'Custom transcription engine (optional)', hint: 'leave empty to auto-install', url: 'https://github.com/ggerganov/whisper.cpp/releases', plain: true }
    ];
    for (const f of fields) {
      const row = document.createElement('div'); row.className = 'srow';
      row.innerHTML = '<label>' + f.name + ' <a href="#" class="hint">' + f.hint + '</a></label><div class="inline"><input type="' + (f.plain ? 'text' : 'password') + '" spellcheck="false" placeholder="' + (f.plain ? 'C:\\path\\to\\whisper-cli.exe' : 'paste key') + '"><button class="ghost">Save</button></div>';
      const inp = row.querySelector('input'); inp.value = keys[f.k] || '';
      row.querySelector('a').addEventListener('click', (e) => { e.preventDefault(); CS.openURL(f.url); });
      if (f.url2) { const a2 = document.createElement('a'); a2.href = '#'; a2.className = 'hint'; a2.textContent = ' · start a subscription'; a2.addEventListener('click', (e) => { e.preventDefault(); CS.openURL(f.url2); }); row.querySelector('label').appendChild(a2); }
      row.querySelector('button').addEventListener('click', () => { keys[f.k] = inp.value.trim(); saveKeys(); toast(f.name + (keys[f.k] ? ' saved' : ' cleared'), 'ok'); });
      form.appendChild(row);
    }
    /* something wrong? */
    if (typeof BugReport !== 'undefined') {
      const bug = document.createElement('div'); bug.className = 'srow';
      bug.innerHTML = '<label>Something not working?</label><div class="inline"></div>';
      const b = document.createElement('button'); b.className = 'ghost'; b.textContent = 'Report a problem'; b.addEventListener('click', () => BugReport.open());
      bug.querySelector('.inline').appendChild(b);
      const l = document.createElement('span'); l.className = 'hint'; l.textContent = ' Three clicks; the panel attaches its own log.'; bug.querySelector('.inline').appendChild(l);
      form.appendChild(bug);
    }
    /* account */
    if (typeof License !== 'undefined') {
      const acc = document.createElement('div'); acc.className = 'srow account';
      const me = License.info(), pro = License.isPro();
      if (License.loggedIn()) {
        acc.innerHTML = '<label>Account</label><div class="kbd"><b>' + me.email + '</b> · ' + (pro ? 'Pro (' + me.plan + ')' : (me.tools && me.tools.length ? 'Tools owned: ' + me.tools.join(', ') : 'Free')) + (me.seats ? ' · ' + me.seats.used + '/' + me.seats.max + ' computers' : '') + '</div><div class="inline"></div>';
        const row = acc.querySelector('.inline');
        const mk = (label, fn, cls) => { const b = document.createElement('button'); b.className = cls || 'ghost'; b.textContent = label; b.addEventListener('click', fn); row.appendChild(b); };
        if (!pro) mk('Unlock Pro', () => CS.openURL(License.pricingUrl('settings')), 'primary');
        if (me.portalUrl) mk('Manage subscription', () => CS.openURL(me.portalUrl));
        if (me.affiliate && me.affiliate.url) mk('Your referral link', () => { try { navigator.clipboard.writeText(me.affiliate.url); toast('Referral link copied: ' + me.affiliate.url, 'ok'); } catch (e) { toast(me.affiliate.url); } });
        mk('Refresh', () => License.refresh().then(() => { renderSettings(); renderHome(); }));
        mk('Log out', () => License.logout().then(() => { renderSettings(); renderHome(); }));
      } else {
        acc.innerHTML = '<label>Account</label><div class="kbd">Not logged in · Free features · log in for your ' + License.FREE_EXPORTS + ' free exports in each Pro tool</div><div class="inline"></div>';
        const b = document.createElement('button'); b.className = 'primary'; b.textContent = 'Log in / Create account'; b.addEventListener('click', () => License.showLogin()); acc.querySelector('.inline').appendChild(b);
      }
      form.appendChild(acc);
    }
    /* usage statistics switch */
    const us = document.createElement('div'); us.className = 'srow';
    us.innerHTML = '<label>Share usage statistics <span class="hint">counts only: which tools ran, how long, whether they failed, and what computer they ran on. Never your media, projects or text.</span></label><div class="inline"><button class="switch' + (keys.usageOff ? '' : ' on') + '" id="usage-switch" title="Sends counts to Outflow Studio so the tools can be improved"></button><span class="kbd" id="usage-switch-note">' + (keys.usageOff ? 'Off: nothing is sent.' : 'On: thank you, this is how we see what to improve.') + '</span></div>';
    us.querySelector('#usage-switch').addEventListener('click', () => { keys.usageOff = !keys.usageOff; saveKeys(); renderSettings(); });
    form.appendChild(us);
    /* engines: every downloadable part, with a checkmark when it is on this computer */
    const eng = document.createElement('div'); eng.className = 'srow engines'; eng.id = 'engines';
    const renderEngines = () => {
      const list = engineList();
      const ready = list.filter((e) => e.ready).length, needed = list.filter((e) => !e.optional);
      eng.innerHTML = '<label>Engines <span class="hint">' + ready + ' of ' + list.length + ' installed · downloaded once, kept in ' + CS.dataDirLabel() + '</span></label>' +
        '<div class="elist">' + list.map((e, i) => '<div class="erow' + (e.ready ? ' ok' : '') + '"><span class="emark">' + (e.ready ? icon('check', 12) : '') + '</span><span class="ename">' + e.name + (e.optional ? ' <em>optional</em>' : '') + '</span><span class="euse">' + e.uses + '</span><span class="esize">' + e.size + '</span>' + (e.ready ? '<span class="eok">Installed</span>' : '<button class="ghost small" data-i="' + i + '">Install</button>') + '</div>').join('') + '</div>' +
        '<div class="inline">' + (needed.every((e) => e.ready) ? '<span class="kbd">' + icon('check', 12) + ' Everything the tools need is installed.</span>' : '<button class="primary" id="eng-all">Install everything (' + needed.filter((e) => !e.ready).length + ' left, about ' + Math.round(needed.filter((e) => !e.ready).reduce((a, e) => a + (parseFloat(e.size) * (/GB/.test(e.size) ? 1000 : 1) || 0), 0)) + ' MB)</button>') + '</div>';
      eng.querySelectorAll('button[data-i]').forEach((b) => b.addEventListener('click', () => installEngines([list[+b.dataset.i]])));
      const all = eng.querySelector('#eng-all'); if (all) all.addEventListener('click', () => installEngines(needed.filter((e) => !e.ready)));
    };
    renderEngines();
    form.appendChild(eng);
    engineRefresh = renderEngines;
    /* updates */
    if (typeof Update !== 'undefined') {
      const u = document.createElement('div'); u.className = 'srow';
      u.innerHTML = '<label>Updates <span class="hint">version ' + Update.version() + '</span></label><div class="inline"><select class="sel"><option value="stable">Stable channel</option><option value="beta">Beta channel (early builds)</option></select><button class="primary">Check for updates</button></div>';
      const sel = u.querySelector('select'); sel.value = Update.channel();
      sel.addEventListener('change', () => { Update.setChannel(sel.value); toast(sel.value === 'beta' ? 'Beta channel on. Early builds may have rough edges.' : 'Stable channel.', 'ok'); Update.check({ force: true }); });
      u.querySelector('button').addEventListener('click', () => Update.check({ force: true }));
      /* first thing in Settings: it is what a bug-report reply asks people to press */
      form.insertBefore(u, form.firstChild);
    }
    /* owner only: the mask probe, results in the panel log */
    try {
      const meInfo = (typeof License !== 'undefined' && License.info) ? License.info() : null;
      if (meInfo && /^kevin\.outflowstudios@gmail\.com$/i.test(meInfo.email || '')) {
        const dv = document.createElement('div'); dv.className = 'srow';
        dv.innerHTML = '<label>Developer <span class="hint">only you see this</span></label><div class="inline"><button class="ghost" id="dev-probe">Mask probe</button><button class="ghost" id="dev-probe2">Try adding Opacity</button><button class="ghost" id="dev-probe3">Tool probe</button><button class="ghost" id="dev-key">Send key C</button><span class="kbd" id="dev-note">draw a mask on a clip, select the clip, press</span></div>';
        dv.querySelector('#dev-probe').addEventListener('click', async () => { const r = await CS.call('OS_probeMask'); $('#dev-note').textContent = r.ok ? r.lines + ' lines in the log · ' + (r.maskish || []).join(' | ').slice(0, 300) : r.error; });
        dv.querySelector('#dev-probe3').addEventListener('click', async () => { const r = await CS.call('OS_probeTools'); $('#dev-note').textContent = r.ok ? r.lines + ' lines in the log · hits: ' + (r.hits || []).join(' ').slice(0, 400) : r.error; });
        /* keystroke relay test: the panel has focus after the click; a key typed now goes to Premiere as a shortcut (C = razor) */
        dv.querySelector('#dev-key').addEventListener('click', () => { try { const r = CS.sendKey('c'); $('#dev-note').textContent = 'sent C (' + r + '). Did the toolbar switch to the razor?'; } catch (e) { $('#dev-note').textContent = 'send failed: ' + e.message; } });
        dv.querySelector('#dev-probe2').addEventListener('click', async () => { const r = await CS.call('OS_probeAddOpacity'); $('#dev-note').textContent = r.ok ? (r.lines || []).join(' || ').slice(0, 400) : r.error; });
        form.appendChild(dv);
      }
    } catch (e) {}
    const sec = document.createElement('div'); sec.className = 'srow';
    const vs = Vault.status();
    sec.innerHTML = '<label>Security</label><div class="kbd">' + (vs.encrypted ? icon('check', 12) + ' Keys are encrypted with ' + vs.method + '.' : 'Keys are stored with ' + vs.method + '.') + ' Settings are mirrored to a file in your AppData folder so they survive panel resets.</div>';
    form.appendChild(sec);
    const q = document.createElement('div'); q.className = 'srow';
    q.innerHTML = '<label>Video download quality</label><select class="sel"><option value="sd">Up to 720p (small)</option><option value="hd">Up to 1080p</option><option value="best">Best available (4K)</option></select>';
    const sel = q.querySelector('select'); sel.value = keys.videoQuality || 'hd';
    sel.addEventListener('change', () => { keys.videoQuality = sel.value; saveKeys(); });
    form.appendChild(q);
    const d = document.createElement('div'); d.className = 'srow';
    d.innerHTML = '<label>Save folder for stock media and video downloads <span class="hint">default: OutflowStudio next to your project file</span></label><div class="inline"><span class="path"></span><button class="ghost">Choose…</button><button class="ghost">Default</button></div>';
    const upd = () => { d.querySelector('.path').textContent = keys.downloadDir || '(project folder)/OutflowStudio'; };
    upd();
    d.querySelectorAll('button')[0].addEventListener('click', () => { const p = CS.pickFolder('Download folder'); if (p) { keys.downloadDir = p; saveKeys(); upd(); } else if (!CS.inCEP) toast('Only available inside Premiere Pro.'); });
    d.querySelectorAll('button')[1].addEventListener('click', () => { delete keys.downloadDir; saveKeys(); upd(); });
    form.appendChild(d);
  }

  /* ---- engines: the list every module contributes, and the shared installer with the progress overlay ---- */
  let engineRefresh = null, installing = false;
  function engineList() {
    const out = [];
    for (const m of [typeof Social !== 'undefined' && Social, typeof LocalWhisper !== 'undefined' && LocalWhisper, typeof AudioAI !== 'undefined' && AudioAI, typeof Matte !== 'undefined' && Matte, typeof Relight !== 'undefined' && Relight]) { if (m && m.engines) { try { out.push(...m.engines()); } catch (e) {} } }
    return out;
  }
  async function installEngines(list) {
    if (!CS.inCEP) { toast('Engines install inside Premiere Pro only.'); return; }
    if (installing || !list.length) return;
    installing = true;
    const prog = $('#progress'), bar = $('#prog-bar'), txt = $('#prog-text'), title = $('#prog-title'), cancel = $('#prog-cancel');
    prog.classList.add('show'); if (cancel) cancel.style.display = 'none';
    let done = 0;
    try {
      for (const e of list) {
        title.textContent = 'Installing ' + e.name + ' (' + (done + 1) + '/' + list.length + ')'; bar.style.width = '0%'; txt.textContent = '';
        await e.install((p, t) => { if (p >= 0) bar.style.width = Math.round(p * 100) + '%'; if (t) txt.textContent = String(t).slice(0, 110); });
        done++;
      }
      toast(done === 1 ? list[0].name + ' installed.' : done + ' engines installed.', 'ok');
    } catch (err) { toast(err.message || String(err), 'err'); }
    finally { installing = false; prog.classList.remove('show'); if (cancel) cancel.style.display = ''; if (engineRefresh) engineRefresh(); }
  }
  function showEngines() { show('settings'); setTimeout(() => { const e = $('#engines'); if (e) e.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 50); }
  function init() {
    renderHome();
    renderSettings();
    document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => {
      const target = b.dataset.go;
      if (target === 'stock') Stock.open('photos'); else show(target);
    }));
    document.addEventListener('screenchange', (e) => { if (e.detail === 'home') renderHome(); if (e.detail === 'settings') renderSettings(); });
    document.addEventListener('licensechange', () => { renderHome(); if (current === 'settings') renderSettings(); });
  }

  return { TOOLS, showEngines, installEngines, engineList, show, current: () => current, toast, keys: () => keys, saveKeys, init };
})();
window.toast = Hub.toast;
