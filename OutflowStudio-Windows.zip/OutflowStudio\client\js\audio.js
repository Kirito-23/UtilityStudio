/* Audio analysis: Premiere exports a WAV of the sequence (in/out range), the
   panel reads it with Node and computes a loudness envelope. */
const AudioTool = (() => {
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const WIN = 0.02;   /* envelope window in seconds */

  function findWavPreset() {
    try {
      const cached = localStorage.getItem('os.wavPreset');
      if (cached && CS.fs.existsSync(cached)) return cached;
    } catch (e) {}
    if (!CS.fs) return null;
    const roots = ['C:\\Program Files\\Adobe', '/Applications'];
    const found = [];
    for (const root of roots) {
      if (!CS.fs.existsSync(root)) continue;
      for (const app of CS.fs.readdirSync(root)) {
        if (!/premiere|media encoder/i.test(app)) continue;
        /* Windows: <app folder>\MediaIO; Mac: /Applications/<folder>/<folder>.app/Contents/MediaIO (or the .app straight in /Applications) */
        const cands = [CS.path.join(root, app, 'MediaIO', 'systempresets', '3F3F3F3F_57415645'), CS.path.join(root, app, 'Contents', 'MediaIO', 'systempresets', '3F3F3F3F_57415645'), CS.path.join(root, app, app.replace(/\.app$/, '') + '.app', 'Contents', 'MediaIO', 'systempresets', '3F3F3F3F_57415645')];
        for (const d of cands) {
          if (!CS.fs.existsSync(d)) continue;
          for (const f of CS.fs.readdirSync(d)) if (/\.epr$/i.test(f) && /wav|waveform/i.test(f)) found.push({ p: CS.path.join(d, f), pri: (/premiere/i.test(app) ? 0 : 1) + (/48kHz 16/i.test(f) ? 0 : 0.5) });
        }
      }
    }
    found.sort((a, b) => a.pri - b.pri);
    const p = found.length ? found[0].p : null;
    if (p) { try { localStorage.setItem('os.wavPreset', p); } catch (e) {} }
    return p;
  }

  function parseWav(buf) {
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    if (dv.getUint32(0, false) !== 0x52494646) throw new Error('Not a WAV file');
    let off = 12, fmt = null, data = null;
    while (off + 8 <= dv.byteLength) {
      const id = String.fromCharCode(dv.getUint8(off), dv.getUint8(off + 1), dv.getUint8(off + 2), dv.getUint8(off + 3));
      const size = dv.getUint32(off + 4, true);
      if (id === 'fmt ') fmt = { format: dv.getUint16(off + 8, true), channels: dv.getUint16(off + 10, true), sampleRate: dv.getUint32(off + 12, true), bits: dv.getUint16(off + 22, true) };
      if (id === 'data') { data = { off: off + 8, size: Math.min(size, dv.byteLength - off - 8) }; break; }
      off += 8 + size + (size & 1);
    }
    if (!fmt || !data) throw new Error('WAV chunks missing');
    const ch = fmt.channels, bytes = fmt.bits / 8, frames = Math.floor(data.size / (bytes * ch));
    const mono = new Float32Array(frames);
    for (let i = 0; i < frames; i++) {
      let acc = 0;
      for (let c = 0; c < ch; c++) {
        const p = data.off + (i * ch + c) * bytes;
        let v = 0;
        if (fmt.bits === 16) v = dv.getInt16(p, true) / 32768;
        else if (fmt.bits === 24) v = ((dv.getUint8(p) | (dv.getUint8(p + 1) << 8) | (dv.getInt8(p + 2) << 16))) / 8388608;
        else if (fmt.bits === 32) v = fmt.format === 3 ? dv.getFloat32(p, true) : dv.getInt32(p, true) / 2147483648;
        else if (fmt.bits === 8) v = (dv.getUint8(p) - 128) / 128;
        acc += v;
      }
      mono[i] = acc / ch;
    }
    return { sampleRate: fmt.sampleRate, samples: mono, duration: frames / fmt.sampleRate };
  }

  /* decode with the browser's audio decoder (handles every WAV flavour); falls back to the parser */
  async function decode(buf) {
    try {
      const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
      const Ctx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
      const ctx = new Ctx(1, 1, 48000);
      const ad = await new Promise((res, rej) => { const p = ctx.decodeAudioData(ab, res, rej); if (p && p.then) p.then(res, rej); });
      const n = ad.length, ch = ad.numberOfChannels;
      const mono = new Float32Array(n);
      for (let c = 0; c < ch; c++) { const d = ad.getChannelData(c); for (let i = 0; i < n; i++) mono[i] += d[i] / ch; }
      return { sampleRate: ad.sampleRate, samples: mono, duration: n / ad.sampleRate };
    } catch (e) { return parseWav(buf); }
  }

  /* threshold between the noise floor and typical speech level */
  function autoThreshold(envObj) {
    const v = Array.from(envObj.env).filter(x => x > -80).sort((a, b) => a - b);
    if (!v.length) return -35;
    const q = (p) => v[Math.min(v.length - 1, Math.floor(p * v.length))];
    const noise = q(0.15), speech = q(0.85);
    return Math.round(Math.max(-60, Math.min(-15, noise + (speech - noise) * 0.4)));
  }

  function envelope(samples, sr, win) {
    win = win || WIN;
    const n = Math.floor(win * sr), count = Math.max(1, Math.floor(samples.length / n));
    const env = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      let sum = 0;
      const base = i * n;
      for (let k = 0; k < n; k++) { const v = samples[base + k]; sum += v * v; }
      const rms = Math.sqrt(sum / n);
      env[i] = 20 * Math.log10(rms + 1e-6);
    }
    return { env, win };
  }

  /* silences below thresholdDb lasting at least minSilence.
     padLeft keeps air after the speech before the cut, padRight before the speech after it.
     spike: audible islands shorter than this are cut too. */
  function detectSilences(envObj, o) {
    const { env, win } = envObj;
    const padL = o.padLeft !== undefined ? o.padLeft : (o.pad || 0), padR = o.padRight !== undefined ? o.padRight : (o.pad || 0);
    const out = [];
    let start = -1;
    for (let i = 0; i <= env.length; i++) {
      const quiet = i < env.length && env[i] < o.thresholdDb;
      if (quiet && start < 0) start = i;
      if (!quiet && start >= 0) {
        const s = start * win + padL, e = i * win - padR;
        if (e - s >= o.minSilence) out.push([s, e]);
        start = -1;
      }
    }
    /* drop cuts that would leave a tiny speech island (spike) between them */
    const spike = o.spike !== undefined ? o.spike : (o.minKeep || 0.15);
    const merged = [];
    for (const c of out) {
      const last = merged[merged.length - 1];
      if (last && c[0] - last[1] < spike) last[1] = c[1]; else merged.push(c.slice());
    }
    return merged;
  }

  /* loud moments: local maxima above threshold with a minimum gap */
  function peaks(envObj, o) {
    const { env, win } = envObj;
    const times = [];
    const smooth = new Float32Array(env.length);
    const r = Math.max(1, Math.round(0.15 / win));
    for (let i = 0; i < env.length; i++) { let s = 0, c = 0; for (let k = -r; k <= r; k++) { const j = i + k; if (j >= 0 && j < env.length) { s += env[j]; c++; } } smooth[i] = s / c; }
    let lastT = -1e9;
    for (let i = 1; i < smooth.length - 1; i++) {
      if (smooth[i] < o.thresholdDb) continue;
      if (smooth[i] >= smooth[i - 1] && smooth[i] > smooth[i + 1]) {
        const t = i * win;
        if (t - lastT >= o.minGap) { times.push(t); lastT = t; }
      }
    }
    return times;
  }

  /* 16 kHz mono 16-bit WAV (for speech APIs) */
  function wav16k(samples, sr) {
    const ratio = sr / 16000, n = Math.floor(samples.length / ratio);
    const Buf = window.Buffer || window.cep_node.Buffer;
    const out = Buf.alloc(44 + n * 2);
    const w32 = (o, v) => out.writeUInt32LE(v, o), w16 = (o, v) => out.writeUInt16LE(v, o);
    out.write('RIFF', 0); w32(4, 36 + n * 2); out.write('WAVE', 8); out.write('fmt ', 12); w32(16, 16); w16(20, 1); w16(22, 1); w32(24, 16000); w32(28, 32000); w16(32, 2); w16(34, 16); out.write('data', 36); w32(40, n * 2);
    for (let i = 0; i < n; i++) {
      const a = Math.floor(i * ratio), b = Math.min(samples.length, Math.floor((i + 1) * ratio));
      let s = 0; for (let k = a; k < b; k++) s += samples[k];
      const v = Math.max(-1, Math.min(1, s / Math.max(1, b - a)));
      out.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
    }
    return out;
  }

  async function tempDir() {
    const r = await CS.call('OS_getPaths');
    const base = (r.ok && (r.projectDir || r.documents)) || (CS.os ? CS.os.tmpdir() : '');
    const d = CS.path.join(base, 'OutflowStudio', 'analysis');
    CS.mkdirp(d);
    return d;
  }

  /* exports [start,end] of the active sequence to WAV and returns samples + envelope */
  async function exportRange(start, end, solo, tag) {
    if (!CS.inCEP || !CS.fs) throw new Error('Audio analysis runs inside Premiere Pro only.');
    const preset = findWavPreset();
    if (!preset) throw new Error('No WAV export preset found in the Premiere / Media Encoder install.');
    const dir = await tempDir();
    const out = CS.path.join(dir, (tag || 'audio') + '_' + Date.now().toString(36) + '.wav');
    const r = await CS.call('AS_exportAudio', JSON.stringify({ out, preset, start, end, solo: solo || null }));
    if (!r.ok) throw new Error(r.error || 'Audio export failed');
    const buf = CS.fs.readFileSync(out);
    const wav = await decode(buf);
    const envObj = envelope(wav.samples, wav.sampleRate);
    try {
      let mn = 1e9, mx = -1e9, sum = 0; for (const v of envObj.env) { if (v < mn) mn = v; if (v > mx) mx = v; sum += v; }
      Log.info('audio', 'exportRange', { file: out, start, end, wanted: +(end - start).toFixed(2), bytes: buf.length, sampleRate: wav.sampleRate, seconds: +(wav.samples.length / wav.sampleRate).toFixed(2), envMin: +mn.toFixed(1), envMax: +mx.toFixed(1), envMean: +(sum / Math.max(1, envObj.env.length)).toFixed(1) });
    } catch (e) {}
    return Object.assign({ file: out, start, end }, wav, envObj);
  }

  /* Premiere-like view: mirrored waveform, cut regions shaded, kept regions dark */
  function drawEnvelope(canvas, envObj, cuts, offset, marks) {
    const g = canvas.getContext('2d'), W = canvas.width, H = canvas.height, mid = H / 2;
    g.clearRect(0, 0, W, H);
    g.fillStyle = '#1e2a3a'; g.fillRect(0, 0, W, H);
    const { env, win } = envObj, total = env.length * win;
    g.fillStyle = 'rgba(214, 90, 140, .55)';
    for (const c of cuts || []) { const x0 = (c[0] - offset) / total * W, x1 = (c[1] - offset) / total * W; g.fillRect(x0, 0, Math.max(1, x1 - x0), H); }
    g.fillStyle = '#8fb8ff';
    for (let x = 0; x < W; x++) {
      const i0 = Math.floor(x / W * env.length), i1 = Math.max(i0 + 1, Math.floor((x + 1) / W * env.length));
      let m = -90; for (let i = i0; i < i1 && i < env.length; i++) m = Math.max(m, env[i]);
      const amp = Math.pow(Math.max(0, Math.min(1, Math.pow(10, m / 20))), 0.6);
      const h = Math.max(1, amp * mid * 0.95);
      g.fillRect(x, mid - h, 1, h * 2);
    }
    g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(0, mid, W, 1);
    g.fillStyle = '#ffd166';
    for (const t of marks || []) { const x = (t - offset) / total * W; g.fillRect(x - 1, 0, 2, H); }
  }

  return { findWavPreset, parseWav, decode, autoThreshold, envelope, detectSilences, peaks, wav16k, exportRange, drawEnvelope, tempDir };
})();
