/* Remove background: the selected clip minus its background, on the track above it, with a transparent, colour or
   blurred background. Runs the RVM model in the panel's Node runtime on the GPU (js/matte/matte.js). */
const Matte = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const cp = nodeReq ? nodeReq('child_process') : null;
  const proc = (window.cep_node && window.cep_node.process) || (typeof process !== 'undefined' ? process : null);
  const MODEL_URL = 'https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx';
  const MODEL_NAME = 'rvm_mobilenetv3_fp32.onnx';
  const HQ_URL = 'https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_resnet50_fp32.onnx', HQ_NAME = 'rvm_resnet50_fp32.onnx';
  /* BEN2 (MIT, PramaLLC): any subject, not just people. One square picture per frame, no memory between frames. */
  const BEN_URL = 'https://huggingface.co/PramaLLC/BEN2/resolve/main/BEN2_Base.onnx', BEN_NAME = 'ben2_base.onnx';
  const st = { bg: 'none', color: '00ff00', blur: 24, gpu: true, place: 'above', quality: 'fast', contrast: 0.1, shrink: 0, feather: 1, largest: true, detail: 0, steady: true, enc: 'best', unspill: true, gentle: false };
  try { Object.assign(st, JSON.parse(localStorage.getItem('os.matte') || '{}')); } catch (e) {}
  const save = () => { try { localStorage.setItem('os.matte', JSON.stringify(st)); } catch (e) {} try { if (typeof MattePreview !== 'undefined' && MattePreview.has()) MattePreview.render(st); } catch (e) {} };
  const exists = (p) => { try { return !!(CS.fs && p && CS.fs.existsSync(p)); } catch (e) { return false; } };
  function home() { return CS.dataDir('matte'); }
  const ok = () => !!(CS.fs && CS.path);
  const modelPath = () => ok() ? CS.path.join(home(), MODEL_NAME) : null;
  const modelReady = () => ok() && exists(modelPath()) && CS.fs.statSync(modelPath()).size > 1e6;
  const benPath = () => ok() ? CS.path.join(home(), BEN_NAME) : null;
  const benReady = () => ok() && exists(benPath()) && CS.fs.statSync(benPath()).size > 2e8;
  async function ensureBen(onProgress) { if (benReady()) return benPath(); await Net.download(BEN_URL, benPath(), (q) => onProgress(q, 'Downloading the any-subject model (213 MB, once)' + (q >= 0 ? ' · ' + Math.round(q * 100) + '%' : ''))); return benPath(); }
  const hqPath = () => ok() ? CS.path.join(home(), HQ_NAME) : null;
  const hqReady = () => ok() && exists(hqPath()) && CS.fs.statSync(hqPath()).size > 1e7;
  async function ensureHq(onProgress) { if (hqReady()) return hqPath(); await Net.download(HQ_URL, hqPath(), (q) => onProgress(q, 'Downloading the best-quality matting model (100 MB, once)' + (q >= 0 ? ' · ' + Math.round(q * 100) + '%' : ''))); return hqPath(); }
  const scriptJs = () => CS.path.join(CS.extensionDir(), 'client', 'js', 'matte', 'matte.js');
  /* the clip's frame size, straight from the file; 0 when it cannot be read */
  function probePixels(file, ffmpeg) {
    try {
      const probe = CS.path.join(CS.path.dirname(ffmpeg), CS.bin('ffprobe'));
      if (!exists(probe)) return 0;
      const r = cp.spawnSync(probe, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', file], { encoding: 'utf8', windowsHide: true });
      const m = /(\d+),(\d+)/.exec(String(r.stdout || ''));
      return m ? +m[1] * +m[2] : 0;
    } catch (e) { return 0; }
  }
  async function ensureModel(onProgress) {
    if (modelReady()) return modelPath();
    await Net.download(MODEL_URL, modelPath(), (q) => onProgress(q, 'Downloading the matting model (15 MB, once)' + (q >= 0 ? ' · ' + Math.round(q * 100) + '%' : '')));
    return modelPath();
  }
  async function ensureAll(onProgress) {
    await AudioAI.ensureNode(onProgress); await AudioAI.ensureOrt(onProgress);
    const ffmpeg = Social.ffmpeg() || (await Social.installFfmpeg(onProgress), Social.ffmpeg());
    if (!ffmpeg) throw new Error('The video engine is missing.');
    const model = st.quality === 'ben2' ? await ensureBen(onProgress) : st.quality === 'hq' ? await ensureHq(onProgress) : await ensureModel(onProgress);
    return { ffmpeg, model };
  }
  let current = null, cancelled = false;
  const live = new Set();
  function runOne(cmd, args, onLine) {
    return new Promise((resolve, reject) => {
      if (cancelled) { reject(new Error('Cancelled.')); return; }
      const p = CS.track(cp.spawn(cmd, args, { windowsHide: true, env: proc ? proc.env : undefined }));
      live.add(p);
      let out = '', err = '';
      p.stdout.on('data', (d) => { const s = String(d); out += s; if (onLine) s.split(/[\r\n]+/).forEach((l) => l.trim() && onLine(l.trim())); });
      p.stderr.on('data', (d) => { err += String(d); });
      p.on('error', (e) => { live.delete(p); reject(e); });
      p.on('close', (code) => { live.delete(p); if (cancelled) { reject(new Error('Cancelled.')); return; } code === 0 ? resolve(out) : reject(new Error((err + out).trim().split('\n').filter((l) => /error/i.test(l)).slice(-1)[0] || ('The matting engine stopped (' + code + ')'))); });
    });
  }
  function run(cmd, args, onLine) {
    return new Promise((resolve, reject) => {
      if (cancelled) { reject(new Error('Cancelled.')); return; }
      const p = CS.track(cp.spawn(cmd, args, { windowsHide: true, env: proc ? proc.env : undefined }));
      current = p;
      let out = '', err = '';
      p.stdout.on('data', (d) => { const s = String(d); out += s; if (onLine) s.split(/[\r\n]+/).forEach((l) => l.trim() && onLine(l.trim())); });
      p.stderr.on('data', (d) => { const s = String(d); err += s; });
      p.on('error', (e) => { current = null; reject(e); });
      p.on('close', (code) => { current = null; if (cancelled) { reject(new Error('Cancelled.')); return; } code === 0 ? resolve(out) : reject(new Error((err + out).trim().split('\n').filter((l) => /error/i.test(l)).slice(-1)[0] || ('The matting engine stopped (' + code + ')'))); });
    });
  }
  function cancel() { cancelled = true; for (const p of Array.from(live).concat(current ? [current] : [])) { CS.killTree(p.pid); try { p.kill(); } catch (e2) {} } }
  const prog = {
    show(t) { cancelled = false; $('#progress').classList.add('show'); $('#prog-title').textContent = t; $('#prog-bar').style.width = '0%'; $('#prog-text').textContent = ''; const c = $('#prog-cancel'); if (c) { c.style.display = ''; c.dataset.matte = '1'; } },
    set(p, txt) { if (p >= 0) $('#prog-bar').style.width = Math.round(p * 100) + '%'; if (txt) $('#prog-text').textContent = txt; },
    hide() { $('#progress').classList.remove('show'); const c = $('#prog-cancel'); if (c) delete c.dataset.matte; }
  };
  /* the first selected video clip with a file behind it */
  async function selectedClip() {
    const r = await CS.call('C3D_getSelectedClips');
    if (!r.ok) throw new Error(r.error);
    const clips = (r.clips || []).filter((c) => c.path && /\.(mp4|mov|m4v|mkv|webm|avi|mts|m2ts|mxf)$/i.test(c.path));
    if (!clips.length) throw new Error('Select a video clip in the timeline first.');
    return clips[0];
  }
  const baseArgs = (clip, eng) => [scriptJs(), '--in', clip.path, '--model', eng.model, '--ffmpeg', eng.ffmpeg, '--ort', AudioAI.ortDir(), '--bg', st.bg, '--color', st.color, '--blur', String(st.blur), '--contrast', String(st.contrast), '--shrink', String(st.shrink), '--feather', String(st.feather)].concat(st.largest ? ['--largest', '0.05'] : []).concat(st.steady ? [] : ['--stab', '0', '--refine', '0', '--median', '0']).concat(st.detail && st.quality !== 'ben2' ? ['--detail', String(st.detail)] : []).concat(st.quality === 'ben2' ? ['--engine', 'ben2'] : []).concat(st.enc && st.enc !== 'best' ? ['--enc', st.enc] : []).concat(st.unspill ? [] : ['--unspill', '0']).concat(st.gentle ? ['--threads', '4'] : []).concat(st.gpu ? [] : ['--cpu']);
  let running = false;
  const zoom = { z: 1, x: 0, y: 0, fit: 1, wired: false };
  function fitPreview() {
    const box = $('#mt-zoom'), cv = $('#mt-preview'); if (!box || !cv || !cv.width) return;
    const bw = box.clientWidth, bh = box.clientHeight; zoom.fit = Math.min(bw / cv.width, bh / cv.height);
    zoom.z = 1; zoom.x = (bw - cv.width * zoom.fit) / 2; zoom.y = (bh - cv.height * zoom.fit) / 2; applyZoom();
  }
  function applyZoom() {
    const box = $('#mt-zoom'), cv = $('#mt-preview'); if (!box || !cv) return;
    const s = zoom.fit * zoom.z, bw = box.clientWidth, bh = box.clientHeight, cw = cv.width * s, ch = cv.height * s;
    /* keep the picture inside the box, centred when smaller */
    zoom.x = cw <= bw ? (bw - cw) / 2 : Math.min(0, Math.max(bw - cw, zoom.x));
    zoom.y = ch <= bh ? (bh - ch) / 2 : Math.min(0, Math.max(bh - ch, zoom.y));
    cv.style.transform = 'translate(' + zoom.x + 'px,' + zoom.y + 'px) scale(' + s + ')';
    box.classList.toggle('pixels', zoom.z >= 4);
    document.querySelectorAll('.mt-zoombar [data-zoom]').forEach((b) => b.classList.toggle('on', +b.dataset.zoom === zoom.z));
  }
  function zoomTo(z, cx, cy) {
    const box = $('#mt-zoom'); if (!box) return;
    if (cx == null) { cx = box.clientWidth / 2; cy = box.clientHeight / 2; }
    const s0 = zoom.fit * zoom.z, z1 = Math.max(1, Math.min(8, z)), s1 = zoom.fit * z1;
    /* keep the point under the cursor where it is */
    zoom.x = cx - (cx - zoom.x) * (s1 / s0); zoom.y = cy - (cy - zoom.y) * (s1 / s0); zoom.z = z1; applyZoom();
  }
  function wireZoom() {
    if (zoom.wired) return; zoom.wired = true;
    const box = $('#mt-zoom'); if (!box) return;
    box.addEventListener('wheel', (e) => { e.preventDefault(); const r = box.getBoundingClientRect(); zoomTo(zoom.z * (e.deltaY < 0 ? 1.25 : 0.8), e.clientX - r.left, e.clientY - r.top); }, { passive: false });
    let drag = null;
    box.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY, ox: zoom.x, oy: zoom.y }; box.setPointerCapture(e.pointerId); box.classList.add('dragging'); });
    box.addEventListener('pointermove', (e) => { if (!drag) return; zoom.x = drag.ox + (e.clientX - drag.x); zoom.y = drag.oy + (e.clientY - drag.y); applyZoom(); });
    const up = (e) => { drag = null; box.classList.remove('dragging'); };
    box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
    box.addEventListener('dblclick', () => fitPreview());
    document.querySelectorAll('.mt-zoombar [data-zoom]').forEach((b) => b.addEventListener('click', () => { if (+b.dataset.zoom === 1) fitPreview(); else zoomTo(+b.dataset.zoom); }));
    window.addEventListener('resize', () => { if (MattePreview.has()) fitPreview(); });
  }
  const engineReady = () => safe(AudioAI.mdxReady) && (st.quality === 'ben2' ? benReady() : st.quality === 'hq' ? hqReady() : modelReady()) && !!(typeof Social !== 'undefined' && Social.ffmpeg && Social.ffmpeg());
  async function preview(auto) {
    if (!CS.inCEP || !cp) { if (!auto) toast('Remove background runs inside Premiere Pro.'); return; }
    if (running) return;
    let clip;
    try { clip = await selectedClip(); }
    catch (e) { $('#mt-preview-note').textContent = 'Select a video clip in the timeline, then come back here or press Preview one frame.'; if (!auto) toast(e.message, 'err'); return; }
    if (auto && !engineReady()) { $('#mt-preview-note').textContent = 'Press Preview one frame: the first run downloads the engine and the model.'; return; }
    running = true; prog.show('Preview');
    try {
      const eng = await ensureAll(prog.set);
      const dir = CS.path.join(home(), 'preview'); CS.mkdirp(dir);
      const frac = Math.max(0, Math.min(1, (+$('#mt-at').value || 50) / 100));
      const at = (clip.inPoint || 0) + Math.max(0, (clip.end - clip.start)) * frac;
      prog.set(0.3, 'Cutting out one frame' + (st.gpu ? ' on the GPU' : '') + '…');
      await run(AudioAI.nodeExe(), baseArgs(clip, eng).concat(['--preview', dir, '--at', String(at)]), () => {});
      const t = '?t=' + Date.now();
      await MattePreview.set({ original: CS.fileURL(CS.path.join(dir, 'original.png')) + t, alpha: CS.fileURL(CS.path.join(dir, 'alpha.png')) + t, fgr: CS.fileURL(CS.path.join(dir, 'fgr.png')) + t }, $('#mt-preview'));
      $('#mt-preview').style.display = ''; $('#mt-preview-wrap').style.display = '';
      MattePreview.render(st); wireZoom(); requestAnimationFrame(fitPreview);
      $('#mt-preview-note').textContent = clip.name + ' at ' + Math.round(frac * 100) + '%. Move the sliders: the preview follows them live. Quality and Detail need a new frame.';
    } catch (e) { toast(cancelled ? 'Cancelled.' : (e.message || String(e)), cancelled ? '' : 'err'); }
    finally { running = false; prog.hide(); }
  }
  async function process() {
    if (!CS.inCEP || !cp) { toast('Remove background runs inside Premiere Pro.'); return; }
    if (running) { toast('Please wait for the current job.'); return; }
    running = true; prog.show('Remove background');
    try {
      const clip = await selectedClip();
      const eng = await ensureAll(prog.set);
      const dir = CS.path.join(await outDir(), 'matte'); CS.mkdirp(dir);
      const out = CS.path.join(dir, CS.path.basename(clip.path).replace(/\.[^.]+$/, '') + '_nobg_' + Date.now().toString(36) + '.mov');
      const start = clip.inPoint || 0, duration = Math.max(0.05, clip.end - clip.start);
      /* a 4K frame costs four times an HD one in memory, on the graphics card most of all. Fewer at once. */
      const px = probePixels(clip.path, eng.ffmpeg);
      const t0 = Date.now();
      /* the ProRes encoder is the slow part: matte the clip in segments at once, one process (own GPU session, own
         encoder) each, then join the pieces without re-encoding. Later segments start a moment early to warm the model up. */
      let cores = 8; try { cores = nodeReq('os').cpus().length; } catch (e) {}
      /* measured on a 16-core PC at HD: 4 parts is the sweet spot, 5 and 6 are slower again. The any-subject model
         waits on the graphics card, so two. A big frame gets fewer still, so the card is never asked for too much. */
      const byPixels = px >= 7.5e6 ? 1 : px >= 3.5e6 ? 3 : 4;   /* 4K: one part; it is the memory and the power draw both */
      /* the memory that is actually free right now decides too: a part at this size wants roughly this much */
      const freeMB = (() => { try { return Math.round(CS.os.freemem() / 1048576); } catch (e) { return 0; } })();
      const perPartMB = 350 + Math.round((px || 2.1e6) / 1e6) * 110;
      const byMemory = freeMB ? Math.max(1, Math.floor((freeMB - 2500) / perPartMB)) : 4;
      const segments = duration < 4 || !st.gpu || st.gentle ? 1 : Math.max(1, Math.min(st.quality === 'ben2' ? 2 : byPixels, byMemory, Math.floor(cores / 4)));
      try { Log.info('matte', 'start', { clip: clip.name, pixels: px, seconds: +duration.toFixed(2), parts: segments, freeMB, perPartMB, gentle: !!st.gentle, quality: st.quality, cores }); } catch (e) {}
      prog.set(0.02, 'Removing the background' + (st.gpu ? ' on the GPU' : ' on the CPU') + (segments > 1 ? ' · ' + segments + ' parts at once' : '') + '…');
      /* the clip's frame rate, so every part gets an exact frame count */
      let fps = 30; try { const pr = cp.spawnSync(CS.path.join(CS.path.dirname(eng.ffmpeg), CS.bin('ffprobe')), ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=r_frame_rate', '-of', 'default=nw=1:nk=1', clip.path], { encoding: 'utf8', windowsHide: true }); const [fa, fb] = String(pr.stdout || '').trim().split('/').map(Number); if (fa > 0) fps = fb ? fa / fb : fa; } catch (e) {}
      const totalFrames = Math.max(1, Math.round(duration * fps));
      /* the run-up before each part: the people model has memory of the frames before, so it needs about a second;
         the any-subject model has none, so three frames (enough for the steady-edge filter) save a lot of time */
      const leadFrames = st.quality === 'ben2' ? 3 : Math.max(3, Math.round(0.8 * fps));
      const parts = [], progressOf = new Array(segments).fill(0);
      const report = () => { const p = progressOf.reduce((a, b) => a + b, 0) / segments; const el = (Date.now() - t0) / 1000; const eta = p > 0.05 ? Math.round(el / p - el) : 0; prog.set(0.03 + p * 0.92, Math.round(p * 100) + '%' + (eta > 0 ? ' · about ' + (eta >= 60 ? Math.round(eta / 60) + ' min' : eta + ' s') + ' left' : '')); };
      const jobs = [];
      for (let k = 0; k < segments; k++) {
        const f0 = Math.round(totalFrames * k / segments), f1 = Math.round(totalFrames * (k + 1) / segments), frames = f1 - f0;
        const skip = k > 0 ? Math.min(leadFrames, f0) : 0, segStart = start + (f0 - skip) / fps, segLen = (frames + skip) / fps + 0.25;
        const file = segments > 1 ? out.replace(/\.mov$/, '_part' + k + '.mov') : out;
        parts.push(file);
        jobs.push(runOne(AudioAI.nodeExe(), baseArgs(clip, eng).concat(['--out', file, '--start', String(segStart), '--duration', String(segLen), '--frames', String(frames), '--skipframes', String(skip)]), (l) => { const mm = /^progress ([\d.]+)/.exec(l); if (mm) { progressOf[k] = +mm[1]; report(); } }));
      }
      await Promise.all(jobs);
      if (segments > 1) {
        prog.set(0.96, 'Joining the parts');
        const list = out.replace(/\.mov$/, '_parts.txt');
        CS.fs.writeFileSync(list, parts.map((p) => "file '" + p.replace(/'/g, "'\\''") + "'").join('\n'), 'utf8');
        await runOne(eng.ffmpeg, ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', out], null);
        for (const p of parts) { try { CS.fs.unlinkSync(p); } catch (e) {} } try { CS.fs.unlinkSync(list); } catch (e) {}
      }
      if (!exists(out)) throw new Error('The matting engine produced no file.');
      prog.set(0.98, 'Placing the clip');
      /* two tracks above the source: the empty track between is for the new background */
      const r = await CS.call('C3D_importAndInsert', out, 0, duration, -1, 'Outflow Matte', clip.name + ' · no background', clip.start, clip.track + 2);
      if (!r.ok) throw new Error(r.error);
      let off = null; try { off = await CS.call('MT_disableVideo', JSON.stringify({ track: clip.track, start: clip.start, end: clip.end })); } catch (e) {}
      toast('Background removed · placed on V' + (r.track + 1) + (off && off.ok && off.disabled ? ' · original video switched off, audio kept' : '') + '. V' + (clip.track + 2) + ' is free for a background.', 'ok');
      try { Log.info('matte', 'done', { clip: clip.name, seconds: +((Date.now() - t0) / 1000).toFixed(1), duration, bg: st.bg }); } catch (e) {}
      try { Usage.tick('matte', 1, { seconds: (Date.now() - t0) / 1000, clip: duration }); Usage.tick('set:matte:quality:' + st.quality); Usage.tick('set:matte:gpu:' + (st.gpu ? 'on' : 'off')); Usage.tick('set:matte:bg:' + st.bg); Usage.tick('set:matte:steady:' + (st.steady ? 'on' : 'off')); Usage.tick('set:matte:enc:' + (st.enc || 'best')); Usage.tick('set:matte:gentle:' + (st.gentle ? 'on' : 'off')); } catch (e) {}
    } catch (e) { toast(cancelled ? 'Cancelled.' : (e.message || String(e)), cancelled ? '' : 'err'); }
    finally { running = false; prog.hide(); }
  }
  async function outDir() {
    const k = Hub.keys(); let base = k.downloadDir;
    if (!base) { const r = await CS.call('OS_getPaths'); base = (r.ok && (r.projectDir || r.documents)) || (CS.os ? CS.os.homedir() : ''); base = CS.path.join(base, 'OutflowStudio'); }
    return base;
  }
  function renderStatus() {
    const s = $('#mt-status'); if (!s) return;
    const rt = safe(AudioAI.mdxReady);
    s.innerHTML = (rt ? icon('check', 12) + ' Engine ready' + (st.gpu ? ' · GPU' : ' · CPU') : 'The engine (150 MB, shared with Remove music) downloads on first use') + ' · ' + (modelReady() ? icon('check', 12) + ' Model ready' : 'Matting model (15 MB) downloads on first use') + (st.quality === 'hq' ? ' · ' + (hqReady() ? icon('check', 12) + ' Best-quality model ready' : 'Best-quality model (100 MB) downloads on first use') : '') + (st.quality === 'ben2' ? ' · ' + (benReady() ? icon('check', 12) + ' Any-subject model ready' : 'Any-subject model (213 MB) downloads on first use') : '');
  }
  function open() {
    Hub.show('matte');
    const bg = $('#mt-bg'); bg.value = st.bg; bg.onchange = () => { st.bg = bg.value; save(); syncBg(); };
    const col = $('#mt-color'); col.value = '#' + st.color; col.oninput = () => { st.color = col.value.replace('#', ''); save(); };
    const bl = $('#mt-blur'); bl.value = st.blur; bl.oninput = () => { st.blur = +bl.value; $('#mt-blur-val').textContent = bl.value + ' px'; save(); }; $('#mt-blur-val').textContent = st.blur + ' px';
    const q = $('#mt-quality'); q.value = st.quality; q.onchange = () => { st.quality = q.value; save(); renderStatus(); };
    const d = $('#mt-detail'); d.value = String(st.detail || 0); d.onchange = () => { st.detail = +d.value; save(); };
    const ec = $('#mt-enc'); if (ec) { ec.value = st.enc || 'best'; ec.onchange = () => { st.enc = ec.value; save(); }; }
    const bindRange = (id, key, fmt) => { const el = $('#' + id), lab = $('#' + id + '-val'); el.value = st[key]; lab.textContent = fmt(st[key]); el.oninput = () => { st[key] = +el.value; lab.textContent = fmt(st[key]); save(); }; };
    bindRange('mt-contrast', 'contrast', (v) => Math.round(v * 100) + '%');
    bindRange('mt-shrink', 'shrink', (v) => (v > 0 ? '+' : '') + v + ' px');
    bindRange('mt-feather', 'feather', (v) => v + ' px');
    const lg = $('#mt-largest'); lg.classList.toggle('on', !!st.largest); lg.onclick = () => { st.largest = !st.largest; lg.classList.toggle('on', st.largest); save(); };
    const us = $('#mt-unspill'); if (us) { us.classList.toggle('on', !!st.unspill); us.onclick = () => { st.unspill = !st.unspill; us.classList.toggle('on', st.unspill); save(); }; }
    const ge = $('#mt-gentle'); if (ge) { ge.classList.toggle('on', !!st.gentle); ge.onclick = () => { st.gentle = !st.gentle; ge.classList.toggle('on', st.gentle); save(); }; }
    const sd = $('#mt-steady'); if (sd) { sd.classList.toggle('on', !!st.steady); sd.onclick = () => { st.steady = !st.steady; sd.classList.toggle('on', st.steady); save(); }; }
    const g = $('#mt-gpu'); g.classList.toggle('on', !!st.gpu); g.onclick = () => { st.gpu = !st.gpu; g.classList.toggle('on', st.gpu); save(); renderStatus(); };
    const syncBg = () => { $('#mt-color-row').style.display = st.bg === 'color' ? '' : 'none'; $('#mt-blur-row').style.display = st.bg === 'blur' ? '' : 'none'; };
    syncBg();
    renderStatus();
    wireZoom();
    if (!MattePreview.has()) $('#mt-preview-note').textContent = 'Getting a preview frame…';
    setTimeout(() => preview(true), 50);
  }
  function init() {
    const c = $('#prog-cancel'); if (c) c.addEventListener('click', () => { if (c.dataset.matte) cancel(); });
    const p = $('#mt-preview-btn'); if (p) p.addEventListener('click', () => preview(false));
    const at = $('#mt-at'); if (at) at.addEventListener('change', () => { if (MattePreview.has()) preview(false); });
    const r = $('#mt-run'); if (r) r.addEventListener('click', process);
    const i = $('#mt-install'); if (i) i.addEventListener('click', () => Hub.showEngines());
  }
  const safe = (fn) => { try { return !!fn(); } catch (e) { return false; } };
  const engines = () => [{ id: 'matte-model', name: 'Matting model', size: '15 MB', uses: 'Remove background', ready: safe(modelReady), install: ensureModel }, { id: 'matte-hq', name: 'Matting model · best quality', size: '100 MB', uses: 'Remove background (Best quality)', ready: safe(hqReady), install: ensureHq, optional: true }];
  return { open, init, engines };
})();
