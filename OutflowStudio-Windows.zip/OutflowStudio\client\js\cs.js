/* Minimal CEP bridge: host script calls, Node fs access, file dialogs.
   Works in the real panel (window.__adobe_cep__) and degrades in a plain browser. */
(function () {
  const cep = window.__adobe_cep__ || null;
  let nodeReq = null;
  try {
    if (window.cep_node && window.cep_node.require) nodeReq = window.cep_node.require;
    else if (typeof window.require === 'function') nodeReq = window.require;
  } catch (e) { nodeReq = null; }

  let fs = null, path = null, os = null, Buf = null;
  try {
    if (nodeReq) {
      fs = nodeReq('fs'); path = nodeReq('path'); os = nodeReq('os');
      Buf = window.Buffer || (window.cep_node && window.cep_node.Buffer) || nodeReq('buffer').Buffer;
    }
  } catch (e) { fs = null; }

  const CS = {
    inCEP: !!cep,
    hasNode: !!fs,
    fs, path, os,
    evalScript(script) {
      return new Promise((resolve) => {
        if (!cep) return resolve('{"ok":false,"error":"Not running inside Premiere Pro"}');
        try { cep.evalScript(script, (r) => resolve(r)); }
        catch (e) { resolve('{"ok":false,"error":"' + String(e).replace(/"/g, "'") + '"}'); }
      });
    },
    /* calls made on a timer (a screen watching the selection) would fill the log with the same line every second:
       CS.quiet counts up while such a call runs, and only the first one in a row is written. */
    quiet: 0,
    /*  The host scripts load after the panel is already on screen (nine files, one round trip each). A click
        in that first second used to reach a host function that did not exist yet and came back as
        "EvalScript error." - so every call waits for the loading to finish, and if Premiere still answers
        with EvalScript error (the engine dropped the scripts), they are loaded once more and the call
        made again. */
    hostReady: null, hostLoading: false,
    async call(fn, ...args) {
      const argStr = args.map(a => JSON.stringify(a)).join(',');
      const t0 = Date.now();
      const still = CS.quiet > 0 && CS.lastQuiet === fn + argStr;
      if (CS.quiet > 0) CS.lastQuiet = fn + argStr;
      const inner = fn === 'C3D_ping' || fn === 'C3D_setLogFile';
      if (CS.hostLoading && CS.hostReady && !inner) { try { await Promise.race([CS.hostReady, new Promise((r) => setTimeout(r, 20000))]); } catch (e) {} }
      if (typeof Log !== 'undefined' && !still) Log.debug('call', fn, argStr.length > 600 ? argStr.slice(0, 600) + '…(' + argStr.length + ')' : argStr);
      let raw = await CS.evalScript(fn + '(' + argStr + ')');
      if (/^EvalScript error/.test(String(raw)) && !inner && !CS.hostLoading) {
        try { if (typeof Log !== 'undefined') Log.warn('call', fn + ': EvalScript error, loading the host scripts again'); } catch (e) {}
        try { await CS.loadHostScript(); } catch (e) {}
        raw = await CS.evalScript(fn + '(' + argStr + ')');
      }
      let out;
      try { out = JSON.parse(raw); }
      catch (e) { out = { ok: false, error: 'Host script error: ' + raw }; }
      if (typeof Log !== 'undefined') { const ms = Date.now() - t0; if (out && out.ok === false) Log.error('call', fn + ' failed in ' + ms + 'ms', Log.summary(out)); else if (!still) Log.debug('call', fn + ' ok in ' + ms + 'ms', Log.summary(out)); }
      return out;
    },
    /* another extension of this bundle (the floating wheel): Premiere opens or fronts its window */
    openExtension(id) {
      try { if (cep && cep.requestOpenExtension) { cep.requestOpenExtension(id, ''); return true; } } catch (e) {}
      return false;
    },
    extensionPath() {
      try { return cep ? cep.getSystemPath('extension') : ''; } catch (e) { return ''; }
    },
    /* the extension folder as a plain Windows path (CEP may report it as a file:/// URL) */
    extensionDir() {
      let p = String(CS.extensionPath() || '');
      if (/^file:/i.test(p)) { p = p.replace(/^file:\/*/i, ''); try { p = decodeURIComponent(p); } catch (e) {} if (/^\/[a-z]:/i.test(p)) p = p.slice(1); }
      /* Windows wants backslashes; a Mac path must keep its slashes, and its leading one, or nothing is found */
      if (CS.mac) return ('/' + p.replace(/^\/+/, '')).replace(/\/$/, '');
      return p.replace(/\//g, '\\').replace(/\\$/, '');
    },
    async loadHostScript() {
      if (!cep) return false;
      let done = null; CS.hostReady = new Promise((r) => { done = r; }); CS.hostLoading = true;
      try { return await CS.loadHostScriptNow(); }
      finally { CS.hostLoading = false; done(true); }
    },
    async loadHostScriptNow() {
      const base = CS.extensionPath().replace(/\\/g, '/') + '/host/';
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'index.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'native.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'stock.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'assist.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'quickfx.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'tools.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'transitions.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'curves.jsx') + ')');
      await CS.evalScript('$.evalFile(' + JSON.stringify(base + 'montage.jsx') + ')');
      const r = await CS.call('C3D_ping');
      try { if (window.Log && Log.file()) await CS.call('C3D_setLogFile', Log.file()); } catch (e) {}
      return !!r.ok;
    },
    writeFile(file, arrayBuffer) {
      fs.writeFileSync(file, Buf.from(arrayBuffer));
    },
    mkdirp(dir) {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    },
    /* the current Windows open dialog (WPF, through PowerShell). Blocks like the older CEP dialog did. Returns an
       array of paths (empty when cancelled), or null when it could not run so the caller can fall back. */
    /* ---- platform: Windows or macOS. Everything that shells out goes through here. ---- */
    get mac() { try { return os ? os.platform() === 'darwin' : /mac/i.test(navigator.platform); } catch (e) { return false; } },
    arch() { try { return os && os.arch() === 'arm64' ? 'arm64' : 'x64'; } catch (e) { return 'x64'; } },
    env() { return (window.cep_node && window.cep_node.process && window.cep_node.process.env) || (window.process && window.process.env) || {}; },
    /* %APPDATA%\OutflowStudio on Windows, ~/Library/Application Support/OutflowStudio on a Mac */
    dataDir(sub) {
      if (!path || !os) return '';   /* a plain browser: no Node, no folders */
      const base = CS.mac ? path.join(os.homedir(), 'Library', 'Application Support') : (CS.env().APPDATA || (os ? os.homedir() : ''));
      const d = sub ? path.join(base, 'OutflowStudio', sub) : path.join(base, 'OutflowStudio');
      try { CS.mkdirp(d); } catch (e) {}
      return d;
    },
    dataDirLabel() { return CS.mac ? '~/Library/Application Support/OutflowStudio' : '%APPDATA%\\OutflowStudio'; },
    /* the name of a downloaded program: yt-dlp.exe there, yt-dlp here */
    bin(name) { return CS.mac ? name : name + '.exe'; },
    tar() { if (!path) return 'tar'; return CS.mac ? '/usr/bin/tar' : path.join(CS.env().SystemRoot || 'C:\\Windows', 'System32', 'tar.exe'); },
    unzip(zip, dest) {
      return new Promise((res, rej) => {
        const cp = nodeReq('child_process'); CS.mkdirp(dest);
        const done = (err, so, se) => err ? rej(new Error(String(se || err.message).slice(0, 300))) : res();
        if (CS.mac) cp.execFile('/usr/bin/unzip', ['-o', '-q', zip, '-d', dest], done);
        else cp.execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', "Expand-Archive -LiteralPath '" + zip.replace(/'/g, "''") + "' -DestinationPath '" + dest.replace(/'/g, "''") + "' -Force"], { windowsHide: true }, done);
      });
    },
    /* a program downloaded by the panel has no execute bit on a Mac until it is given one */
    /* a program downloaded by the panel: the execute bit, and no quarantine flag that Gatekeeper would refuse it on */
    chmodX(file) {
      if (!CS.mac || !fs || !file) return;
      try { fs.chmodSync(file, 0o755); } catch (e) {}
      try { nodeReq('child_process').spawnSync('xattr', ['-d', 'com.apple.quarantine', file], { stdio: 'ignore' }); } catch (e) {}
    },
    /* does this program run here? (the wrong CPU build, a missing execute bit or Gatekeeper all show up as "no") */
    runs(file) {
      try { if (!file || !fs.existsSync(file)) return false; const r = nodeReq('child_process').spawnSync(file, ['-version'], { windowsHide: true, timeout: 15000, stdio: 'ignore' }); return !r.error && r.status === 0; } catch (e) { return false; }
    },
    /*  Every engine process the panel starts, while it runs. Cancel kills them all; a process killed this
        way carries `cancelled`, and its wrapper reports "Cancelled." instead of an exit code.        */
    jobs: new Set(),
    track(p) {
      if (!p || !p.pid) return p;
      CS.jobs.add(p);
      const drop = () => CS.jobs.delete(p);
      p.once('close', drop); p.once('error', drop); p.once('exit', drop);
      return p;
    },
    cancelJobs() {
      let n = 0;
      for (const p of Array.from(CS.jobs)) { try { p.cancelled = true; CS.killTree(p.pid); n++; } catch (e) {} }
      return n;
    },
    isCancel(p, e) { return !!(p && p.cancelled) || /^Cancelled\.?$/.test(String((e && e.message) || e || '')); },
    /*  A keystroke to Premiere. The panel has focus right after a click on it, and CEP hands every key that
        is not typed into a text field on to the host - so a key sent now lands as a Premiere shortcut.
        Windows: SendKeys; Mac: System Events (asks for Accessibility permission once).                */
    sendKey(spec) {
      const cp = nodeReq('child_process');
      /* "shift+m", "ctrl+alt+k", "m": the last part is the key, the rest are modifiers */
      const parts = String(spec || '').toLowerCase().split('+').map((x) => x.trim()).filter(Boolean);
      let key = (parts.pop() || '');
      key = key === '`' || key === 'backtick' ? '`' : key.replace(/[^a-z0-9]/g, '');
      if (!key) throw new Error('No key given.');
      const mods = new Set(parts);
      if (CS.mac) {
        const using = [];
        if (mods.has('shift')) using.push('shift down'); if (mods.has('ctrl') || mods.has('control')) using.push('control down'); if (mods.has('alt') || mods.has('option')) using.push('option down'); if (mods.has('cmd') || mods.has('command') || mods.has('meta')) using.push('command down');
        cp.spawn('osascript', ['-e', 'tell application "System Events" to keystroke "' + key + '"' + (using.length ? ' using {' + using.join(', ') + '}' : '')], { stdio: 'ignore' });
        return 'osascript';
      }
      const pre = (mods.has('shift') ? '+' : '') + (mods.has('ctrl') || mods.has('control') ? '^' : '') + (mods.has('alt') ? '%' : '');
      cp.spawn('powershell', ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', 'Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait("' + pre + (key === '`' ? '``' : key) + '")'], { windowsHide: true, stdio: 'ignore' });
      return 'sendkeys';
    },
    killTree(pid) {
      try { const cp = nodeReq('child_process'); if (CS.mac) { cp.spawn('pkill', ['-9', '-P', String(pid)]); cp.spawn('kill', ['-9', String(pid)]); } else cp.spawn('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }); } catch (e) {}
    },
    clipboardText() {
      try {
        const cp = nodeReq('child_process');
        if (CS.mac) return String(cp.execFileSync('pbpaste', [], { encoding: 'utf8', timeout: 5000 }));
        return String(cp.execFileSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', 'Get-Clipboard -Raw'], { windowsHide: true, encoding: 'utf8', timeout: 5000 }));
      } catch (e) { return ''; }
    },
    clipboardWrite(text) {
      const cp = nodeReq('child_process');
      if (CS.mac) { const p = cp.spawn('pbcopy'); p.stdin.end(String(text)); return; }
      const tmp = path.join(CS.dataDir('clipboard'), 'clip_' + Date.now().toString(36) + '.txt');
      fs.writeFileSync(tmp, String(text), 'utf8');
      cp.execFileSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', "Set-Clipboard -Value (Get-Content -Raw -LiteralPath '" + tmp.replace(/'/g, "''") + "')"], { windowsHide: true, timeout: 5000 });
      try { fs.unlinkSync(tmp); } catch (e) {}
    },
    /* the graphics card, for the dashboard: { gpu, vram (MB) } or null */
    gpuInfo() {
      return new Promise((res) => {
        try {
          const cp = nodeReq('child_process');
          if (CS.mac) {
            cp.execFile('system_profiler', ['SPDisplaysDataType', '-json'], { timeout: 15000, encoding: 'utf8', maxBuffer: 1e7 }, (e, out) => {
              if (e) return res(null);
              try {
                const g = (JSON.parse(out).SPDisplaysDataType || [])[0] || {};
                const raw = String(g.spdisplays_vram || g.spdisplays_vram_shared || ''), n = parseInt(raw, 10) || 0;
                res({ gpu: String(g.sppci_model || g._name || '').slice(0, 60), vram: /GB/i.test(raw) ? n * 1024 : n });
              } catch (e2) { res(null); }
            });
          } else {
            cp.execFile('powershell.exe', ['-NoProfile', '-Command', "Get-CimInstance Win32_VideoController | Where-Object { $_.AdapterRAM -gt 0 } | Sort-Object AdapterRAM -Descending | Select-Object -First 1 | ForEach-Object { $_.Name + '|' + [math]::Round($_.AdapterRAM / 1MB) }"], { windowsHide: true, timeout: 15000, encoding: 'utf8' }, (e, out) => {
              if (e) return res(null);
              const [name, mb] = String(out).trim().split('|');
              res(name ? { gpu: name.trim().slice(0, 60), vram: parseInt(mb, 10) || 0 } : null);
            });
          }
        } catch (e) { res(null); }
      });
    },
    osName() {
      try {
        if (CS.mac) { const cp = nodeReq('child_process'); return 'macOS ' + String(cp.execFileSync('sw_vers', ['-productVersion'], { encoding: 'utf8', timeout: 5000 })).trim(); }
        return 'Windows ' + os.release();
      } catch (e) { return CS.mac ? 'macOS' : 'Windows'; }
    },
    /* the Mac's own file and folder dialogs, through AppleScript; null when not on a Mac, [] when cancelled */
    macDialog(o) {
      try {
        const cp = nodeReq ? nodeReq('child_process') : null;
        if (!cp || !CS.mac) return null;
        const q = (t) => String(t == null ? '' : t).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
        const args = [];
        if (o.folder) args.push('-e', 'POSIX path of (choose folder with prompt "' + q(o.title || 'Choose folder') + '")');
        else if (o.multi) args.push('-e', 'set fs to choose file with prompt "' + q(o.title || 'Choose files') + '" with multiple selections allowed', '-e', 'set out to ""', '-e', 'repeat with f in fs', '-e', 'set out to out & POSIX path of f & linefeed', '-e', 'end repeat', '-e', 'out');
        else args.push('-e', 'POSIX path of (choose file with prompt "' + q(o.title || 'Choose file') + '")');
        const r = cp.spawnSync('osascript', args, { encoding: 'utf8', maxBuffer: 1e7 });
        if (r.status !== 0) return [];   /* cancelled */
        return String(r.stdout || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean).map((x) => x.replace(/\/$/, ''));
      } catch (e) { return null; }
    },
    winDialog(o) {
      try {
        const cp = nodeReq ? nodeReq('child_process') : null;
        if (!cp || !/win/i.test(navigator.platform)) return null;
        const q = (t) => String(t == null ? '' : t).replace(/'/g, "''");
        const pat = (o.exts && o.exts.length) ? o.exts.map((e) => '*.' + e).join(';') : '*.*';
        let script = "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Add-Type -AssemblyName PresentationFramework; $d = New-Object Microsoft.Win32.OpenFileDialog; $d.Title = '" + q(o.title || 'Choose file') + "'; ";
        if (o.folder) script += "$d.CheckFileExists = $false; $d.CheckPathExists = $true; $d.ValidateNames = $false; $d.FileName = 'Choose this folder'; $d.Filter = 'Folder|*.folder'; ";
        else script += "$d.Filter = '" + q(o.filterName || 'Supported files') + "|" + pat + "|All files|*.*'; $d.Multiselect = $" + (o.multi ? 'true' : 'false') + "; ";
        script += "if ($d.ShowDialog()) { $d.FileNames | ForEach-Object { Write-Output $_ } }";
        const r = cp.spawnSync('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', script], { encoding: 'utf8', windowsHide: true, maxBuffer: 1e7 });
        if (r.error) return null;
        const lines = String(r.stdout || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
        if (r.status !== 0 && !lines.length) return null;
        if (o.folder) return lines.length ? [lines[0].replace(/[\\/][^\\/]*$/, '')] : [];
        return lines;
      } catch (e) { return null; }
    },
    /* native multi-file picker; returns array of absolute paths, or null if unavailable */
    pickFiles(title, exts) {
      const ex = exts || ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'heic', 'heif', 'tif', 'tiff', 'avif', 'mp4', 'mov', 'webm', 'm4v', 'mkv'];
      const w = this.winDialog({ title: title || 'Add images / video', exts: ex, multi: true, filterName: 'Images and video' }) || this.macDialog({ title: title || 'Add images / video', multi: true }); if (w) return w;
      try {
        if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
          const r = window.cep.fs.showOpenDialogEx(true, false, title || 'Add images / video', '', ex);
          return (r && r.data) ? r.data : [];
        }
      } catch (e) {}
      return null;
    },
    /* one file; resolves to a path or null */
    pickFile(title, exts, filterName) {
      return new Promise((resolve) => {
        const w = this.winDialog({ title, exts, multi: false, filterName }) || this.macDialog({ title }); if (w) return resolve(w[0] || null);
        try { if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) { const r = window.cep.fs.showOpenDialogEx(false, false, title || 'Choose file', '', exts || []); return resolve((r && r.data && r.data[0]) || null); } } catch (e) {}
        resolve(null);
      });
    },
    /* single text file (subtitles etc.) -> contents, null if cancelled */
    pickTextFile(title, exts) {
      return new Promise((resolve) => {
        const w = this.winDialog({ title: title || 'Choose file', exts, multi: false, filterName: 'Text files' }) || this.macDialog({ title: title || 'Choose file' });
        if (w) { const p = w[0]; if (!p) return resolve(null); try { return resolve(fs.readFileSync(p, 'utf8')); } catch (e) { return resolve(null); } }
        try {
          if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
            const r = window.cep.fs.showOpenDialogEx(false, false, title || 'Choose file', '', exts || []);
            const p = r && r.data && r.data[0];
            if (!p) return resolve(null);
            return resolve(fs.readFileSync(p, 'utf8'));
          }
        } catch (e) { return resolve(null); }
        const inp = document.createElement('input'); inp.type = 'file';
        inp.accept = (exts || []).map(e => '.' + e).join(',');
        inp.onchange = () => { const f = inp.files[0]; if (!f) return resolve(null); const rd = new FileReader(); rd.onload = () => resolve(String(rd.result)); rd.readAsText(f); };
        inp.click();
      });
    },
    pickFolder(title) {
      const w = this.winDialog({ title: (title || 'Choose folder') + ' · open the folder, then press Open', folder: true }) || this.macDialog({ title: title || 'Choose folder', folder: true }); if (w) return w[0] || null;
      try {
        if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
          const r = window.cep.fs.showOpenDialogEx(false, true, title || 'Choose folder', '', []);
          return (r && r.data && r.data[0]) ? r.data[0] : null;
        }
      } catch (e) {}
      return null;
    },
    openURL(url) {
      try { Log.info('cs', 'openURL', url); } catch (e) {}
      /* CEP's own opener drops everything after an ampersand on Windows, so query strings go through the shell instead */
      try {
        if (this.inCEP && /win/i.test(navigator.platform) && /[&#]/.test(url)) {
          const cp = nodeReq ? nodeReq('child_process') : null;
          if (cp) { cp.exec('start "" "' + String(url).replace(/"/g, '') + '"', { windowsHide: true }); return; }
        }
      } catch (e) { try { Log.warn('cs', 'openURL via shell failed: ' + e.message); } catch (e2) {} }
      try { if (this.inCEP && CS.mac && nodeReq) { nodeReq('child_process').execFile('open', [String(url)]); return; } } catch (e) {}
      try { if (window.cep && window.cep.util) { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) {}
      window.open(url, '_blank');
    },
    fileURL(p) {
      let s = String(p).replace(/\\/g, '/');
      if (/^[a-zA-Z]:/.test(s)) s = '/' + s;
      else if (!s.startsWith('/')) s = '/' + s;
      return 'file://' + encodeURI(s).replace(/#/g, '%23').replace(/\?/g, '%3F');
    }
  };
  window.CS = CS;
})();
