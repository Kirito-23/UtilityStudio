/* Transitions: keyframed-effect presets applied on an adjustment layer across a
   cut. Gallery with animated Canvas 2D previews, favorites, show-all toggle. */
const Transitions = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const clamp01 = (x) => Math.max(0, Math.min(1, x));
  const bump = (p) => Math.sin(clamp01(p) * Math.PI);                       /* 0 → 1 → 0 */
  const sbump = (p) => { const x = bump(p); return x * x * (3 - 2 * x); };  /* smoother */
  /* motion curve chosen by the user; presets call io/oi/ii so every preset follows it */
  const CURVES = {
    smooth:    { name: 'Smooth', in: 'easeInCubic', out: 'easeOutCubic', io: 'easeInOutCubic' },
    linear:    { name: 'Linear', in: 'linear', out: 'linear', io: 'linear' },
    snappy:    { name: 'Snappy', in: 'easeInQuint', out: 'easeOutQuint', io: 'easeInOutExpo' },
    overshoot: { name: 'Overshoot', in: 'easeInBack', out: 'easeOutBack', io: 'easeInOutBack' },
    bounce:    { name: 'Bounce', in: 'easeInQuad', out: 'easeOutBounce', io: 'easeInOutBounce' },
    elastic:   { name: 'Elastic', in: 'easeInCubic', out: 'easeOutElastic', io: 'easeInOutElastic' },
    anticipate:{ name: 'Anticipate', in: 'anticipate', out: 'easeOutCubic', io: 'easeInOutQuart' }
  };
  CURVES.custom = { name: 'Custom (drag the handles)', bezier: true };
  let curve = CURVES.smooth;
  const bez = (p) => bezierWarp(clamp01(p), (st && st.bezier) || [0.65, 0, 0.35, 1]);
  const io = (p) => curve.bezier ? bez(p) : EASINGS[curve.io].fn(clamp01(p));
  /* the custom curve spans the whole transition: the first half feeds the "in" easing, the second half the "out" */
  const oi = (p) => curve.bezier ? clamp01(2 * bez(0.5 + clamp01(p) / 2) - 1) : EASINGS[curve.out].fn(clamp01(p));
  const ii = (p) => curve.bezier ? clamp01(2 * bez(clamp01(p) / 2)) : EASINGS[curve.in].fn(clamp01(p));
  /* eased slide progress 0..1 across the cut */
  const se = (p) => p < 0.5 ? 0.5 * ii(p * 2) : 0.5 + 0.5 * oi((p - 0.5) * 2);
  const half = (p, a, b) => (p < 0.5 ? a(p * 2) : b((p - 0.5) * 2));         /* two-phase shape */
  const noise = (p, seed) => Math.sin(p * 97.3 + seed * 13.1) * Math.cos(p * 41.7 + seed * 7.7);
  const DEG = Math.PI / 180;

  /* Each preset returns effect values for progress p (0 → 1 across the transition) and intensity I.
     Keys: tf (Transform), gb (Gaussian Blur), db (Directional Blur), off (Offset), mir (Mirror),
     lens (Lens Distortion), bc (Brightness & Contrast), hls (Color Balance HLS), mos (Mosaic),
     noi (Noise), inv (Invert), tw (Twirl), sph (Spherize), wav (Wave Warp), post (Posterize),
     sol (Solarize), tint (Tint), cam (Camera Blur), chb (Channel Blur). */
  const P = [
    /* basics */
    /* slides shift the frame by one full width through the Offset effect (wrap-around), so
       nothing is left black; a touch of directional blur hides the wrap seam at the cut */
    { id: 'bSlideL', cat: 'Basics', name: 'Slide Left', fn: (p, I) => ({ off: { x: -se(p) }, db: { dir: 90, len: 16 * I * sbump(p) } }) },
    { id: 'bSlideR', cat: 'Basics', name: 'Slide Right', fn: (p, I) => ({ off: { x: se(p) }, db: { dir: 90, len: 16 * I * sbump(p) } }) },
    { id: 'bSlideU', cat: 'Basics', name: 'Slide Up', fn: (p, I) => ({ off: { y: -se(p) }, db: { dir: 0, len: 16 * I * sbump(p) } }) },
    { id: 'bSlideD', cat: 'Basics', name: 'Slide Down', fn: (p, I) => ({ off: { y: se(p) }, db: { dir: 0, len: 16 * I * sbump(p) } }) },
    { id: 'bZoomIn', cat: 'Basics', name: 'Simple Zoom In', fn: (p, I) => ({ tf: { scale: 100 + 40 * I * sbump(p) } }) },
    { id: 'bZoomOut', cat: 'Basics', name: 'Simple Zoom Out', fn: (p, I) => ({ tf: { scale: Math.max(60, 100 - 25 * I * sbump(p)) } }) },
    { id: 'bDipBlack', cat: 'Basics', name: 'Dip to Black', fn: (p, I) => ({ bc: { bright: -100 * sbump(p) } }) },
    { id: 'bDipWhite', cat: 'Basics', name: 'Dip to White', fn: (p, I) => ({ bc: { bright: 100 * sbump(p) } }) },
    { id: 'bBlur', cat: 'Basics', name: 'Soft Blur', fn: (p, I) => ({ gb: { blur: 40 * I * sbump(p) } }) },
    /* zoom */
    { id: 'zoomIn', cat: 'Zoom', name: 'Zoom In', fn: (p, I) => ({ tf: { scale: 100 + 70 * I * sbump(p) }, gb: { blur: 30 * I * sbump(p) } }) },
    { id: 'zoomOut', cat: 'Zoom', name: 'Zoom Out', fn: (p, I) => ({ tf: { scale: Math.max(50, 100 - 35 * I * sbump(p)) }, gb: { blur: 25 * I * sbump(p) } }) },
    { id: 'zoomPunch', cat: 'Zoom', name: 'Zoom Punch', fn: (p, I) => ({ tf: { scale: 100 + 90 * I * half(p, ii, x => 1 - oi(x)) }, gb: { blur: 45 * I * sbump(p) } }) },
    { id: 'zoomThrough', cat: 'Zoom', name: 'Zoom Through', fn: (p, I) => ({ tf: { scale: p < 0.5 ? 100 + 140 * I * ii(p * 2) : 40 + 60 * oi((p - 0.5) * 2) }, gb: { blur: 50 * I * sbump(p) } }) },
    { id: 'zoomBounce', cat: 'Zoom', name: 'Zoom Bounce', fn: (p, I) => ({ tf: { scale: 100 + 45 * I * (p < 0.5 ? oi(p * 2) : 1 - EASINGS.easeOutBounce.fn((p - 0.5) * 2)) }, gb: { blur: 12 * I * sbump(p) } }) },
    { id: 'zoomSpin', cat: 'Zoom', name: 'Zoom Spin', fn: (p, I) => ({ tf: { scale: 100 + 60 * I * sbump(p), rot: 30 * I * sbump(p) }, gb: { blur: 20 * I * sbump(p) } }) },
    { id: 'zoomBlurOut', cat: 'Zoom', name: 'Zoom Blur Out', fn: (p, I) => ({ tf: { scale: 100 + 25 * I * sbump(p) }, gb: { blur: 70 * I * sbump(p) } }) },
    { id: 'heartbeat', cat: 'Zoom', name: 'Heartbeat', fn: (p, I) => ({ tf: { scale: 100 + 22 * I * (bump(clamp01(p * 2)) + bump(clamp01(p * 2 - 1))) } }) },
    { id: 'elasticPop', cat: 'Zoom', name: 'Elastic Pop', fn: (p, I) => ({ tf: { scale: p < 0.5 ? 100 + 40 * I * ii(p * 2) : 100 + 40 * I * (1 - EASINGS.easeOutElastic.fn((p - 0.5) * 2)) } }) },
    /* spin */
    { id: 'spinCW', cat: 'Spin', name: 'Spin Clockwise', fn: (p, I) => ({ tf: { rot: 360 * io(p), scale: 100 + 35 * sbump(p) }, gb: { blur: 25 * I * sbump(p) } }) },
    { id: 'spinCCW', cat: 'Spin', name: 'Spin Counter', fn: (p, I) => ({ tf: { rot: -360 * io(p), scale: 100 + 35 * sbump(p) }, gb: { blur: 25 * I * sbump(p) } }) },
    { id: 'halfTurn', cat: 'Spin', name: 'Half Turn', fn: (p, I) => ({ tf: { rot: 180 * io(p), scale: 100 + 45 * sbump(p) }, gb: { blur: 15 * I * sbump(p) } }) },
    { id: 'spinZoom', cat: 'Spin', name: 'Spin Zoom', fn: (p, I) => ({ tf: { rot: 180 * I * io(p), scale: 100 + 90 * sbump(p) }, gb: { blur: 30 * sbump(p) } }) },
    { id: 'wobble', cat: 'Spin', name: 'Wobble', fn: (p, I) => ({ tf: { rot: Math.sin(p * Math.PI * 4) * 10 * I * bump(p), scale: 100 + 8 * bump(p) } }) },
    { id: 'rollTumble', cat: 'Spin', name: 'Tumble', fn: (p, I) => ({ tf: { rot: p < 0.5 ? -25 * I * ii(p * 2) : 25 * I * (1 - oi((p - 0.5) * 2)), posY: p < 0.5 ? 0.6 * ii(p * 2) : -0.6 * (1 - oi((p - 0.5) * 2)), scale: 115 }, gb: { blur: 10 * sbump(p) } }) },
    /* whips (wrap-around offset) */
    { id: 'whipLeft', cat: 'Whip', name: 'Whip Left', fn: (p, I) => ({ off: { x: p < 0.5 ? -ii(p * 2) : 1 - oi((p - 0.5) * 2), y: 0 }, db: { dir: 90, len: 90 * I * sbump(p) } }) },
    { id: 'whipRight', cat: 'Whip', name: 'Whip Right', fn: (p, I) => ({ off: { x: p < 0.5 ? ii(p * 2) : -(1 - oi((p - 0.5) * 2)), y: 0 }, db: { dir: 90, len: 90 * I * sbump(p) } }) },
    { id: 'whipUp', cat: 'Whip', name: 'Whip Up', fn: (p, I) => ({ off: { x: 0, y: p < 0.5 ? -ii(p * 2) : 1 - oi((p - 0.5) * 2) }, db: { dir: 0, len: 90 * I * sbump(p) } }) },
    { id: 'whipDown', cat: 'Whip', name: 'Whip Down', fn: (p, I) => ({ off: { x: 0, y: p < 0.5 ? ii(p * 2) : -(1 - oi((p - 0.5) * 2)) }, db: { dir: 0, len: 90 * I * sbump(p) } }) },
    { id: 'whipDiag', cat: 'Whip', name: 'Whip Diagonal', fn: (p, I) => ({ off: { x: p < 0.5 ? -ii(p * 2) : 1 - oi((p - 0.5) * 2), y: p < 0.5 ? -ii(p * 2) : 1 - oi((p - 0.5) * 2) }, db: { dir: 45, len: 90 * I * sbump(p) } }) },
    { id: 'whipZoom', cat: 'Whip', name: 'Whip Zoom', fn: (p, I) => ({ off: { x: p < 0.5 ? -ii(p * 2) : 1 - oi((p - 0.5) * 2), y: 0 }, tf: { scale: 100 + 40 * sbump(p) }, db: { dir: 90, len: 70 * I * sbump(p) } }) },
    /* slides with motion blur */
    { id: 'slideLeft', cat: 'Slide', name: 'Slide Left (blur)', fn: (p, I) => ({ off: { x: -se(p) }, db: { dir: 90, len: 40 * I * sbump(p) } }) },
    { id: 'slideRight', cat: 'Slide', name: 'Slide Right (blur)', fn: (p, I) => ({ off: { x: se(p) }, db: { dir: 90, len: 40 * I * sbump(p) } }) },
    { id: 'slideUp', cat: 'Slide', name: 'Slide Up (blur)', fn: (p, I) => ({ off: { y: -se(p) }, db: { dir: 0, len: 40 * I * sbump(p) } }) },
    { id: 'slideDown', cat: 'Slide', name: 'Slide Down (blur)', fn: (p, I) => ({ off: { y: se(p) }, db: { dir: 0, len: 40 * I * sbump(p) } }) },
    { id: 'slideDiag', cat: 'Slide', name: 'Slide Diagonal', fn: (p, I) => ({ off: { x: -se(p), y: -se(p) }, db: { dir: 45, len: 24 * I * sbump(p) } }) },
    { id: 'slideZoom', cat: 'Slide', name: 'Slide + Zoom', fn: (p, I) => ({ off: { x: -se(p) }, tf: { scale: 100 + 30 * sbump(p) }, db: { dir: 90, len: 20 * I * sbump(p) } }) },
    { id: 'dropIn', cat: 'Slide', name: 'Drop & Bounce', fn: (p, I) => ({ tf: { posY: p < 0.5 ? 1.05 * ii(p * 2) : -1.05 * (1 - EASINGS.easeOutBounce.fn((p - 0.5) * 2)) } }) },
    { id: 'shake', cat: 'Slide', name: 'Shake', fn: (p, I) => ({ tf: { posX: noise(p, 1) * 0.04 * I * bump(p), posY: noise(p, 2) * 0.03 * I * bump(p), rot: noise(p, 3) * 3 * I * bump(p) } }) },
    /* blur */
    { id: 'blurDissolve', cat: 'Blur', name: 'Blur Dissolve', fn: (p, I) => ({ gb: { blur: 70 * I * sbump(p) } }) },
    { id: 'dirBlurH', cat: 'Blur', name: 'Motion Blur H', fn: (p, I) => ({ db: { dir: 90, len: 140 * I * sbump(p) } }) },
    { id: 'dirBlurV', cat: 'Blur', name: 'Motion Blur V', fn: (p, I) => ({ db: { dir: 0, len: 140 * I * sbump(p) } }) },
    { id: 'focusPull', cat: 'Blur', name: 'Focus Pull', fn: (p, I) => ({ cam: { pct: 70 * I * sbump(p) } }) },
    { id: 'blurZoom', cat: 'Blur', name: 'Soft Zoom Blur', fn: (p, I) => ({ tf: { scale: 100 + 15 * sbump(p) }, gb: { blur: 55 * I * sbump(p) } }) },
    { id: 'chromaSplit', cat: 'Blur', name: 'Chroma Split', fn: (p, I) => ({ chb: { r: 60 * I * sbump(p), g: 10 * I * sbump(p), b: 60 * I * sbump(p) } }) },
    /* glitch */
    { id: 'glitchShake', cat: 'Glitch', name: 'Glitch Shake', fn: (p, I) => ({ tf: { posX: (Math.round(noise(p, 5) * 3) / 3) * 0.05 * I * bump(p), posY: (Math.round(noise(p, 6) * 3) / 3) * 0.02 * I * bump(p) }, mos: { blocks: Math.max(6, Math.round(240 - 220 * I * bump(p) * Math.abs(noise(p, 7)))) }, hls: { hue: noise(p, 8) * 40 * I * bump(p) } }) },
    { id: 'pixelate', cat: 'Glitch', name: 'Pixelate', fn: (p, I) => ({ mos: { blocks: Math.max(4, Math.round(240 - 232 * I * sbump(p))) } }) },
    { id: 'noiseBurst', cat: 'Glitch', name: 'Noise Burst', fn: (p, I) => ({ noi: { amount: 90 * I * sbump(p) } }) },
    { id: 'invertFlash', cat: 'Glitch', name: 'Invert Flash', fn: (p, I) => ({ inv: { blend: 100 - 100 * (bump(p) > 0.85 ? 1 : 0) } }) },
    { id: 'solarize', cat: 'Glitch', name: 'Solarize Flash', fn: (p, I) => ({ sol: { threshold: Math.round(100 - 85 * I * sbump(p)) } }) },
    { id: 'posterize', cat: 'Glitch', name: 'Posterize', fn: (p, I) => ({ post: { level: Math.max(2, Math.round(24 - 22 * I * sbump(p))) } }) },
    { id: 'strobe', cat: 'Glitch', name: 'Strobe', fn: (p, I) => ({ bc: { bright: (Math.floor(p * 8) % 2 === 0 ? 80 : -60) * I * bump(p) } }) },
    /* light */
    { id: 'flashWhite', cat: 'Light', name: 'Flash White', fn: (p, I) => ({ bc: { bright: 100 * I * sbump(p), contrast: -30 * sbump(p) } }) },
    { id: 'dipBlack', cat: 'Light', name: 'Dip to Black', fn: (p, I) => ({ bc: { bright: -100 * I * sbump(p) } }) },
    { id: 'bloom', cat: 'Light', name: 'Bloom', fn: (p, I) => ({ bc: { bright: 45 * I * sbump(p) }, gb: { blur: 35 * I * sbump(p) } }) },
    { id: 'contrastPunch', cat: 'Light', name: 'Contrast Punch', fn: (p, I) => ({ bc: { contrast: 80 * I * sbump(p) } }) },
    { id: 'lightLeak', cat: 'Light', name: 'Light Leak', fn: (p, I) => ({ bc: { bright: 60 * I * sbump(p) }, hls: { hue: 20 * sbump(p), sat: 30 * sbump(p) }, gb: { blur: 10 * sbump(p) } }) },
    /* distort */
    { id: 'twirl', cat: 'Distort', name: 'Twirl', fn: (p, I) => ({ tw: { angle: 200 * I * sbump(p), radius: 50 }, gb: { blur: 8 * sbump(p) } }) },
    { id: 'bulge', cat: 'Distort', name: 'Bulge', fn: (p, I) => ({ sph: { radius: 900 * I * sbump(p) }, tf: { scale: 100 + 10 * sbump(p) } }) },
    { id: 'waveWarp', cat: 'Distort', name: 'Wave Warp', fn: (p, I) => ({ wav: { height: 45 * I * sbump(p), width: 70 } }) },
    { id: 'lensWarp', cat: 'Distort', name: 'Lens Warp', fn: (p, I) => ({ lens: { curvature: -70 * I * sbump(p) }, tf: { scale: 100 + 30 * sbump(p) } }) },
    { id: 'turbulence', cat: 'Distort', name: 'Turbulence', fn: (p, I) => ({ turb: { amount: 70 * I * sbump(p), size: 60 } }) },
    { id: 'mirrorFold', cat: 'Distort', name: 'Mirror Fold', fn: (p, I) => ({ mir: { cx: 1 - 0.5 * sbump(p), angle: 90 } }) },
    { id: 'squeezeH', cat: 'Distort', name: 'Squeeze H', fn: (p, I) => ({ tf: { scaleW: Math.max(5, 100 - 95 * I * sbump(p)), scaleH: 100 + 20 * sbump(p) }, db: { dir: 90, len: 40 * sbump(p) } }) },
    { id: 'squeezeV', cat: 'Distort', name: 'Squeeze V', fn: (p, I) => ({ tf: { scaleH: Math.max(5, 100 - 95 * I * sbump(p)), scaleW: 100 + 20 * sbump(p) }, db: { dir: 0, len: 40 * sbump(p) } }) },
    { id: 'skewShear', cat: 'Distort', name: 'Shear', fn: (p, I) => ({ tf: { skew: p < 0.5 ? 45 * I * ii(p * 2) : -45 * I * (1 - oi((p - 0.5) * 2)), scale: 100 + 25 * sbump(p) }, db: { dir: 90, len: 30 * sbump(p) } }) },
    { id: 'stretch', cat: 'Distort', name: 'Stretch', fn: (p, I) => ({ tf: { scaleH: 100 + 90 * I * sbump(p) }, db: { dir: 0, len: 50 * sbump(p) } }) },
    /* colour */
    { id: 'desat', cat: 'Colour', name: 'Desaturate Dip', fn: (p, I) => ({ hls: { sat: -100 * I * sbump(p) } }) },
    { id: 'hueRoll', cat: 'Colour', name: 'Hue Roll', fn: (p, I) => ({ hls: { hue: 360 * I * io(p) } }) },
    { id: 'tintFlash', cat: 'Colour', name: 'Mono Flash', fn: (p, I) => ({ tint: { amount: 100 * I * sbump(p) } }) },
    { id: 'lightDip', cat: 'Colour', name: 'Shadow Dip', fn: (p, I) => ({ hls: { light: -70 * I * sbump(p) }, gb: { blur: 10 * sbump(p) } }) },
    { id: 'satPunch', cat: 'Colour', name: 'Saturation Punch', fn: (p, I) => ({ hls: { sat: 80 * I * sbump(p) }, bc: { contrast: 20 * sbump(p) } }) }
  ];
  const BY_ID = {}; for (const p of P) BY_ID[p.id] = p;

  /* -------- Premiere mapping: effect + parameter names, point flags -------- */
  function toEffects(preset, frames, fps, I) {
    const samples = [];
    for (let f = 0; f <= frames; f++) samples.push({ t: f / fps, v: preset.fn(f / frames, I) });
    const used = {};
    const addKey = (fxName, param, extra, get) => {
      const key = fxName + '|' + param;
      if (!used[key]) used[key] = { fx: fxName, name: param, alias: extra.alias || [], point: !!extra.point, rel: !!extra.rel, optional: !!extra.optional, keys: [] };
      for (const s of samples) { const v = get(s.v); if (v === undefined) continue; used[key].keys.push([s.t].concat(Array.isArray(v) ? v : [v])); }
      /* blur amounts must start and end at zero so the clips outside the transition stay sharp */
      if (extra.zeroEnds && used[key].keys.length > 1) { used[key].keys[0][1] = 0; used[key].keys[used[key].keys.length - 1][1] = 0; }
    };
    const has = (k) => samples.some(s => s.v[k]);
    const r3 = (x) => Math.round(x * 1000) / 1000;
    if (has('tf')) {
      /* Transform: "Uniform Scale" is a checkbox; the value lives in "Scale Height" (shown as "Scale") */
      const anyW = samples.some(s => s.v.tf && (s.v.tf.scaleW !== undefined || s.v.tf.scaleH !== undefined));
      if (samples.some(s => s.v.tf && s.v.tf.scale !== undefined) && !anyW) {
        addKey('Transform', 'Uniform Scale', {}, () => true);
        addKey('Transform', 'Scale Height', { alias: ['Scale'] }, v => v.tf ? r3(v.tf.scale !== undefined ? v.tf.scale : 100) : 100);
      }
      if (anyW) {
        addKey('Transform', 'Uniform Scale', {}, () => false);
        addKey('Transform', 'Scale Width', {}, v => v.tf ? r3(v.tf.scaleW !== undefined ? v.tf.scaleW : (v.tf.scale || 100)) : 100);
        addKey('Transform', 'Scale Height', { alias: ['Scale'] }, v => v.tf ? r3(v.tf.scaleH !== undefined ? v.tf.scaleH : (v.tf.scale || 100)) : 100);
      }
      if (samples.some(s => s.v.tf && (s.v.tf.posX !== undefined || s.v.tf.posY !== undefined))) addKey('Transform', 'Position', { point: true, rel: true }, v => v.tf ? [r3(v.tf.posX || 0), r3(v.tf.posY || 0)] : [0, 0]);
      if (samples.some(s => s.v.tf && s.v.tf.rot !== undefined)) addKey('Transform', 'Rotation', {}, v => v.tf ? r3(v.tf.rot || 0) : 0);
      if (samples.some(s => s.v.tf && s.v.tf.skew !== undefined)) addKey('Transform', 'Skew', {}, v => v.tf ? r3(v.tf.skew || 0) : 0);
      addKey('Transform', "Use Composition's Shutter Angle", {}, () => false);
      addKey('Transform', 'Shutter Angle', {}, () => 250);
    }
    /* Premiere 2025 replaced the blur effects: Gaussian Blur is now Amount + Edge Behavior, Directional Blur is
       Angle + Amount (+ Chromatic Aberration); the old names stay as aliases for older builds */
    if (has('gb')) { addKey('Gaussian Blur', 'Blurriness', { alias: ['Amount'], zeroEnds: true }, v => v.gb ? r3(v.gb.blur) : 0); addKey('Gaussian Blur', 'Repeat Edge Pixels', { optional: true }, () => true); addKey('Gaussian Blur', 'Edge Behavior', { optional: true }, () => 1); }
    if (has('db')) { addKey('Directional Blur', 'Direction', { alias: ['Angle'] }, v => v.db ? v.db.dir : 0); addKey('Directional Blur', 'Blur Length', { alias: ['Amount'], zeroEnds: true }, v => v.db ? r3(v.db.len) : 0); addKey('Directional Blur', 'Edge Behavior', { optional: true }, () => 1); }
    if (has('off')) addKey('Offset', 'Shift Center To', { point: true, rel: true }, v => v.off ? [r3(v.off.x), r3(v.off.y)] : [0, 0]);
    if (has('mir')) { addKey('Mirror', 'Reflection Center', { point: true }, v => v.mir ? [r3(v.mir.cx), 0.5] : [1, 0.5]); addKey('Mirror', 'Reflection Angle', {}, v => v.mir ? v.mir.angle : 90); }
    if (has('lens')) addKey('Lens Distortion', 'Curvature', {}, v => v.lens ? r3(v.lens.curvature) : 0);
    if (has('bc')) { addKey('Brightness & Contrast', 'Brightness', {}, v => v.bc ? r3(v.bc.bright || 0) : 0); addKey('Brightness & Contrast', 'Contrast', {}, v => v.bc ? r3(v.bc.contrast || 0) : 0); }
    if (has('hls')) { addKey('Color Balance (HLS)', 'Hue', {}, v => v.hls ? r3(v.hls.hue || 0) : 0); addKey('Color Balance (HLS)', 'Lightness', {}, v => v.hls ? r3(v.hls.light || 0) : 0); addKey('Color Balance (HLS)', 'Saturation', {}, v => v.hls ? r3(v.hls.sat || 0) : 0); }
    if (has('mos')) { addKey('Mosaic', 'Horizontal Blocks', {}, v => v.mos ? v.mos.blocks : 240); addKey('Mosaic', 'Vertical Blocks', {}, v => v.mos ? Math.round(v.mos.blocks * 9 / 16) : 135); }
    if (has('noi')) addKey('Noise', 'Amount of Noise', {}, v => v.noi ? r3(v.noi.amount) : 0);
    if (has('inv')) addKey('Invert', 'Blend With Original', {}, v => v.inv ? v.inv.blend : 100);
    if (has('tw')) { addKey('Twirl', 'Angle', {}, v => v.tw ? r3(v.tw.angle) : 0); addKey('Twirl', 'Twirl Radius', {}, v => v.tw ? v.tw.radius : 50); }
    if (has('sph')) addKey('Spherize', 'Radius', {}, v => v.sph ? r3(v.sph.radius) : 0);
    if (has('wav')) { addKey('Wave Warp', 'Wave Height', {}, v => v.wav ? r3(v.wav.height) : 0); addKey('Wave Warp', 'Wave Width', {}, v => v.wav ? v.wav.width : 40); }
    if (has('turb')) { addKey('Turbulent Displace', 'Amount', {}, v => v.turb ? r3(v.turb.amount) : 0); addKey('Turbulent Displace', 'Size', {}, v => v.turb ? v.turb.size : 50); }
    if (has('post')) addKey('Posterize', 'Level', {}, v => v.post ? v.post.level : 24);
    if (has('sol')) addKey('Solarize', 'Threshold', {}, v => v.sol ? v.sol.threshold : 100);
    if (has('tint')) addKey('Tint', 'Amount to Tint', {}, v => v.tint ? r3(v.tint.amount) : 0);
    /* Camera Blur and Channel Blur are gone in 2025: camera blur becomes a Gaussian, channel blur a directional
       blur with chromatic aberration (the old Channel Blur is still tried first on builds that have it) */
    if (has('cam')) { addKey('Gaussian Blur', 'Blurriness', { alias: ['Amount'], zeroEnds: true }, v => v.cam ? r3(v.cam.pct * 1.2) : 0); addKey('Gaussian Blur', 'Edge Behavior', { optional: true }, () => 1); }
    if (has('chb')) { addKey('Directional Blur', 'Direction', { alias: ['Angle'] }, () => 90); addKey('Directional Blur', 'Blur Length', { alias: ['Amount'], zeroEnds: true }, v => v.chb ? r3(Math.max(v.chb.r, v.chb.g || 0, v.chb.b || 0) * 0.3) : 0); addKey('Directional Blur', 'Chromatic Aberration', { optional: true, zeroEnds: true }, v => v.chb ? r3(Math.max(v.chb.r, v.chb.b || 0) * 0.6) : 0); addKey('Directional Blur', 'Edge Behavior', { optional: true }, () => 1); }
    /* group by effect, in the order they were first used; static params collapse to one key */
    const effects = [];
    for (const k of Object.keys(used)) {
      const u = used[k];
      let fx = effects.find(e => e.name === u.fx);
      if (!fx) { fx = { name: u.fx, params: [] }; effects.push(fx); }
      const allSame = u.keys.every(kk => kk.slice(1).every((v, i) => v === u.keys[0][i + 1]));
      fx.params.push({ name: u.name, alias: u.alias, point: u.point, rel: u.rel, keys: allSame ? [u.keys[0]] : thin(u.keys) });
    }
    return effects;
  }

  /*  A key that sits on the straight line between its neighbours adds nothing: Premiere would draw the same motion
      without it. Whole stretches of a transition are linear (a slide holding its speed, a value already at rest),
      so this typically removes most of them while leaving the shape untouched. The tolerance is a fraction of how
      far the parameter travels overall, so it scales from opacity to pixels without being told which is which.  */
  function thin(keys) {
    if (!keys || keys.length < 3) return keys;
    const dim = keys[0].length - 1;
    const tol = [];
    for (let d = 0; d < dim; d++) {
      let lo = Infinity, hi = -Infinity;
      for (const kk of keys) { const v = kk[d + 1]; if (v < lo) lo = v; if (v > hi) hi = v; }
      tol.push(Math.max(1e-4, (hi - lo) * 0.004));
    }
    const out = [keys[0]];
    let anchor = keys[0];
    for (let i = 1; i < keys.length - 1; i++) {
      const next = keys[i + 1], span = next[0] - anchor[0];
      let needed = false;
      if (span > 1e-9) {
        for (let d = 0; d < dim && !needed; d++) {
          /* would a straight line from the last kept key to the next one pass through this one? */
          for (let j = out.length ? i : i; j <= i; j++) {
            const kk = keys[j], f = (kk[0] - anchor[0]) / span;
            const guess = anchor[d + 1] + (next[d + 1] - anchor[d + 1]) * f;
            if (Math.abs(kk[d + 1] - guess) > tol[d]) needed = true;
          }
        }
      } else needed = true;
      if (needed) { out.push(keys[i]); anchor = keys[i]; }
    }
    out.push(keys[keys.length - 1]);
    return out;
  }

  /* ------------------------------------------------------- preview (2D) */
  let imgA = null, imgB = null;
  function demoImages() {
    if (imgA) return;
    const mk = (c1, c2, label) => { const cv = document.createElement('canvas'); cv.width = 240; cv.height = 192; const g = cv.getContext('2d'); const gr = g.createLinearGradient(0, 0, 240, 192); gr.addColorStop(0, c1); gr.addColorStop(1, c2); g.fillStyle = gr; g.fillRect(0, 0, 240, 192); g.fillStyle = 'rgba(255,255,255,.15)'; for (let i = 0; i < 6; i++) g.fillRect(20 + i * 36, 30 + (i % 2) * 60, 24, 60); g.fillStyle = '#fff'; g.font = 'bold 64px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(label, 120, 96); return cv; };
    imgA = mk('#3a7bff', '#8fc0ff', 'A'); imgB = mk('#ff6a4d', '#ffb547', 'B');
  }
  /* frames of the selected clips around the first cut become the preview images */
  function drawPreview(cv, preset, p, I) {
    demoImages();
    const g = cv.getContext('2d'), W = cv.width, H = cv.height, v = preset.fn(p, I || 1), img = p < 0.5 ? imgA : imgB;
    g.clearRect(0, 0, W, H); g.fillStyle = '#0d0f13'; g.fillRect(0, 0, W, H);
    const tf = v.tf || {}, filt = [];
    if (v.gb) filt.push('blur(' + (v.gb.blur * W / 1920 * 2.2) + 'px)');
    if (v.cam) filt.push('blur(' + (v.cam.pct * W / 1920 * 3) + 'px)');
    if (v.bc) { filt.push('brightness(' + (1 + (v.bc.bright || 0) / 100) + ')'); filt.push('contrast(' + (1 + (v.bc.contrast || 0) / 100) + ')'); }
    if (v.hls) { if (v.hls.hue) filt.push('hue-rotate(' + v.hls.hue + 'deg)'); if (v.hls.sat) filt.push('saturate(' + Math.max(0, 1 + v.hls.sat / 100) + ')'); if (v.hls.light) filt.push('brightness(' + Math.max(0, 1 + v.hls.light / 100) + ')'); }
    if (v.inv && v.inv.blend < 50) filt.push('invert(1)');
    if (v.tint) filt.push('grayscale(' + v.tint.amount / 100 + ')');
    if (v.sol && v.sol.threshold < 60) filt.push('invert(.6) contrast(1.6)');
    if (v.post) filt.push('contrast(' + (1 + (24 - v.post.level) / 12) + ') saturate(1.4)');
    if (v.chb) filt.push('blur(' + (v.chb.r * W / 1920) + 'px) saturate(1.8)');
    if (v.noi) filt.push('contrast(' + (1 + v.noi.amount / 200) + ')');
    const sx = (tf.scaleW !== undefined ? tf.scaleW : (tf.scale !== undefined ? tf.scale : 100)) / 100;
    const sy = (tf.scaleH !== undefined ? tf.scaleH : (tf.scale !== undefined ? tf.scale : 100)) / 100;
    g.save();
    g.filter = filt.length ? filt.join(' ') : 'none';
    g.translate(W / 2 + (tf.posX || 0) * W, H / 2 + (tf.posY || 0) * H);
    g.rotate((tf.rot || 0) * DEG);
    if (tf.skew) g.transform(1, 0, Math.tan(tf.skew * DEG), 1, 0, 0);
    g.scale(sx, sy);
    /* slides: A moves out while B follows on the incoming side (what the wrap-around Offset looks like with the blur) */
    const ox = v.off ? (v.off.x || 0) * W : 0, oy = v.off ? (v.off.y || 0) * H : 0, sgx = Math.sign(ox), sgy = Math.sign(oy);
    const drawImg = (dx, dy) => {
      if (v.off) { g.drawImage(imgA, -W / 2 + ox + dx, -H / 2 + oy + dy, W, H); g.drawImage(imgB, -W / 2 + ox - sgx * W + dx, -H / 2 + oy - sgy * H + dy, W, H); }
      else g.drawImage(img, -W / 2 + dx, -H / 2 + dy, W, H);
    };
    if (v.off) drawImg(0, 0);
    else if (v.mos && v.mos.blocks < 200) { const bw = Math.max(2, Math.round(W / (v.mos.blocks / 6))); const tmp = document.createElement('canvas'); tmp.width = Math.max(1, Math.round(W / bw)); tmp.height = Math.max(1, Math.round(H / bw)); const tg = tmp.getContext('2d'); tg.drawImage(img, 0, 0, tmp.width, tmp.height); g.imageSmoothingEnabled = false; g.drawImage(tmp, -W / 2, -H / 2, W, H); g.imageSmoothingEnabled = true; }
    else if (v.mir) { drawImg(0, 0); const cx = (v.mir.cx - 0.5) * W; g.save(); g.beginPath(); g.rect(cx, -H, W, 2 * H); g.clip(); g.translate(cx, 0); g.scale(-1, 1); g.translate(-cx, 0); g.drawImage(img, -W / 2, -H / 2, W, H); g.restore(); }
    else drawImg(0, 0);
    if (v.db && v.db.len > 2) { g.globalAlpha = 0.22; const a = v.db.dir * DEG, L = v.db.len * W / 1920 * 3; for (let i = 1; i <= 3; i++) { const d = (i / 3) * L; drawImg(Math.sin(a) * d, -Math.cos(a) * d); drawImg(-Math.sin(a) * d, Math.cos(a) * d); } g.globalAlpha = 1; }
    if (v.tw && v.tw.angle > 5) { g.globalAlpha = 0.5; g.rotate(v.tw.angle * DEG * 0.2); drawImg(0, 0); g.globalAlpha = 1; }
    if (v.wav && v.wav.height > 1) { g.globalAlpha = 0.5; drawImg(0, Math.sin(p * 20) * v.wav.height * H / 1080 * 3); g.globalAlpha = 1; }
    if (v.sph && v.sph.radius > 20) { g.globalAlpha = 0.5; g.scale(1.15, 1.15); drawImg(0, 0); g.globalAlpha = 1; }
    if (v.lens && Math.abs(v.lens.curvature) > 5) { g.globalAlpha = 0.5; g.scale(1.2, 1.1); drawImg(0, 0); g.globalAlpha = 1; }
    if (v.turb && v.turb.amount > 5) { g.globalAlpha = 0.4; drawImg(Math.sin(p * 30) * 8, Math.cos(p * 25) * 8); g.globalAlpha = 1; }
    g.restore();
    /* cut marker */
    g.fillStyle = 'rgba(255,255,255,.8)'; g.fillRect(Math.round(p * (W - 2)), H - 3, 2, 3);
  }

  /* ------------------------------------------------------------- state */
  const st = { frames: 12, intensity: 1, where: 'between', mode: 'adjustment', selected: 'zoomIn', curve: 'smooth', bezier: [0.65, 0, 0.35, 1] };
  try { Object.assign(st, JSON.parse(localStorage.getItem('os.trans') || '{}')); } catch (e) {}
  curve = CURVES[st.curve] || CURVES.smooth;
  const save = () => { try { localStorage.setItem('os.trans', JSON.stringify(st)); } catch (e) {} };
  let favs = [];
  try { favs = JSON.parse(localStorage.getItem('os.trans.favs') || '[]'); } catch (e) {}
  const saveFavs = () => { try { localStorage.setItem('os.trans.favs', JSON.stringify(favs)); } catch (e) {} };
  let animAll = true;
  try { const v = localStorage.getItem('os.trans.anim'); animAll = v === null ? true : v === '1'; } catch (e) {}

  /* ------------------------------------------------------------ gallery */
  const cards = [];
  let raf = 0, cursor = 0;
  function loop(ts) {
    const live = cards.filter(c => c.cv.isConnected);
    if (!live.length) { raf = 0; return; }
    const per = animAll ? Math.max(1, Math.ceil(live.length / 5)) : live.length;
    let drawn = 0;
    for (let k = 0; k < live.length && drawn < per; k++) {
      const c = live[(cursor + k) % live.length];
      if (!animAll && !c.hover) continue;
      const r = c.cv.getBoundingClientRect();
      if (r.bottom < -40 || r.top > window.innerHeight + 40) continue;
      drawPreview(c.cv, c.preset, ((ts / 1000 + c.phase) % 2.2) / 1.6, st.intensity);
      drawn++;
    }
    cursor = (cursor + per) % live.length;
    raf = requestAnimationFrame(loop);
  }
  function ensureLoop() { if (!raf) raf = requestAnimationFrame(loop); }
  function stillFrame(c) { drawPreview(c.cv, c.preset, 0.5, st.intensity); }

  function render() {
    const box = $('#trans-gallery'); box.innerHTML = ''; cards.length = 0;
    const cats = [];
    const all = favs.map(id => BY_ID[id]).filter(Boolean).map(p => Object.assign({}, p, { cat: 'Favorites' })).concat(P);
    for (const p of all) if (!cats.includes(p.cat)) cats.push(p.cat);
    for (const cat of cats) {
      box.appendChild(h('div', 'cat', cat));
      const grid = h('div', 'ggrid');
      for (const p of all.filter(x => x.cat === cat)) {
        const b = h('button', 'gcard' + (p.id === st.selected ? ' on' : ''));
        const cv = h('canvas', 'pv'); cv.width = 120; cv.height = 96;
        const rec = { cv, preset: p, hover: false, phase: Math.random() * 2 };
        cards.push(rec);
        stillFrame(rec);
        const star = h('button', 'fav' + (favs.includes(p.id) ? ' on' : ''), icon('star', 14));
        star.addEventListener('click', (e) => { e.stopPropagation(); const i = favs.indexOf(p.id); if (i >= 0) favs.splice(i, 1); else favs.push(p.id); saveFavs(); render(); });
        b.append(cv, h('div', 'nm', p.name), h('div', 'sub', p.cat), star);
        b.addEventListener('mouseenter', () => { rec.hover = true; ensureLoop(); });
        b.addEventListener('mouseleave', () => { rec.hover = false; if (!animAll) stillFrame(rec); });
        b.addEventListener('click', () => { st.selected = p.id; save(); document.querySelectorAll('#trans-gallery .gcard').forEach(x => x.classList.remove('on')); b.classList.add('on'); $('#trans-sel').textContent = p.name; apply(); });
        grid.appendChild(b);
      }
      box.appendChild(grid);
    }
    $('#trans-sel').textContent = (BY_ID[st.selected] || P[0]).name;
    $('#sw-trans-anim').classList.toggle('on', animAll);
    if (animAll) ensureLoop();
  }

  async function apply() {
    if (!await License.guardExport('transitions', 'transition export')) return;
    if (!CS.inCEP) { toast('Transitions apply inside Premiere Pro only.'); return; }
    const preset = BY_ID[st.selected] || P[0];
    try {
      const info = await CS.call('AS_range');
      if (!info.ok) throw new Error(info.error);
      const sel = info.selection.slice().sort((a, b) => a.start - b.start);
      if (!sel.length) throw new Error('Select one or more clips in the timeline first.');
      const eps = 0.6 / info.fps, times = [];
      if (st.where === 'between') {
        for (let i = 0; i < sel.length - 1; i++) if (Math.abs(sel[i].end - sel[i + 1].start) < eps) times.push(sel[i + 1].start);
        if (!times.length && sel.length === 1) times.push(sel[0].start);
        if (!times.length) throw new Error('The selected clips are not next to each other. Select adjacent clips, or choose "start" / "end".');
      } else if (st.where === 'start') for (const c of sel) times.push(c.start);
      else for (const c of sel) times.push(c.end);
      const dur = st.frames / info.fps;
      const effects = toEffects(preset, st.frames, info.fps, st.intensity);
      toast('Applying ' + preset.name + ' at ' + times.length + ' cut(s)…');
      const template = CS.extensionPath().replace(/\\/g, '/') + '/client/assets/adjustment-layer.prproj';
      const r = await CS.call('TR_apply', JSON.stringify({ placements: times.map(t => ({ time: t, dur, effects })), mode: st.mode, name: 'Transition ' + preset.name, width: info.width, height: info.height, fps: info.fps, template }));
      if (!r.ok) throw new Error(r.error);
      const real = (r.warnings || []).filter(w => !/adjustment layer unavailable/i.test(w));
      const where = r.mode === 'adjustment' ? ' on adjustment layer V' + (r.track + 1) : ' on the clips';
      const kf = r.keyframes !== undefined ? ', ' + r.keyframes + ' keyframes' : '';
      License.noteExport('transitions'); try { Usage.tick('transitions'); } catch (e) {}
      toast(preset.name + ' applied at ' + r.placed + ' cut(s)' + where + kf + '.' + (real.length ? ' ' + real[0] : ''), real.length || r.keyframes === 0 ? 'err' : 'ok');
      if (r.mode !== 'adjustment' && st.mode === 'adjustment') hintAL();
    } catch (e) { toast(e.message || String(e), 'err'); }
  }
  let hinted = false;
  function hintAL() {
    if (hinted) return; hinted = true;
    const n = $('#trans-note'); if (!n) return;
    n.className = 'st-note show';
    n.innerHTML = 'The adjustment layer template could not be imported, so the keyframes went on the clips themselves (same result, editable in Effect Controls). Creating one Adjustment Layer via <b>File › New › Adjustment Layer</b> also unlocks layer mode.';
  }

  /* graph of the active easing; in Custom mode the two Bezier handles are draggable */
  const curveWin = {};
  function mkCurveEditor(sel) {
    const wrap = h('div', 'curvewrap');
    const cv = h('canvas', 'curve big');
    const pad = 12, W = 200, H = 130;
    const toPx = (x, y) => [pad + x * (W - 2 * pad), H - pad - y * (H - 2 * pad)];
    const fromPx = (px, py) => [clamp01((px - pad) / (W - 2 * pad)), Math.max(-0.5, Math.min(1.5, (H - pad - py) / (H - 2 * pad)))];
    const draw = () => {
      const rc = cv.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 3);
      const cw = Math.max(1, Math.round((rc.width || W) * dpr)), ch = Math.max(1, Math.round((rc.height || H) * dpr));
      if (cv.width !== cw || cv.height !== ch) { cv.width = cw; cv.height = ch; }
      const g = cv.getContext('2d');
      g.setTransform(cw / W, 0, 0, ch / H, 0, 0);
      g.clearRect(0, 0, W, H); g.fillStyle = '#15171c'; g.fillRect(0, 0, W, H);
      g.strokeStyle = '#2b2f38'; g.lineWidth = 1; g.beginPath();
      for (let i = 0; i <= 4; i++) { const a = toPx(i / 4, 0), b = toPx(i / 4, 1), c = toPx(0, i / 4), d = toPx(1, i / 4); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.moveTo(c[0], c[1]); g.lineTo(d[0], d[1]); }
      g.stroke();
      g.strokeStyle = '#3c4250'; g.setLineDash([3, 3]); g.beginPath(); const o = toPx(0, 0), e = toPx(1, 1); g.moveTo(o[0], o[1]); g.lineTo(e[0], e[1]); g.stroke(); g.setLineDash([]);
      const custom = !!curve.bezier, c = st.bezier;
      if (custom) { g.strokeStyle = '#5a6070'; g.setLineDash([3, 3]); g.beginPath(); const p1 = toPx(c[0], c[1]), p2 = toPx(c[2], c[3]); g.moveTo(o[0], o[1]); g.lineTo(p1[0], p1[1]); g.moveTo(e[0], e[1]); g.lineTo(p2[0], p2[1]); g.stroke(); g.setLineDash([]); }
      g.strokeStyle = '#4fb3ff'; g.lineWidth = 2; g.beginPath();
      for (let i = 0; i <= 80; i++) { const f = i / 80, y = io(f); const p = toPx(f, y); if (i === 0) g.moveTo(p[0], p[1]); else g.lineTo(p[0], p[1]); }
      g.stroke();
      if (custom) for (const p of [toPx(c[0], c[1]), toPx(c[2], c[3])]) { g.fillStyle = '#fff'; g.strokeStyle = '#4f8dff'; g.lineWidth = 2; g.beginPath(); g.arc(p[0], p[1], 4.5, 0, Math.PI * 2); g.fill(); g.stroke(); }
      g.fillStyle = '#6b7280'; g.font = '9px sans-serif'; g.fillText(custom ? 'drag the handles · double-click resets' : curve.name + ' · drag to customise', pad, 9);
    };
    let dragging = -1;
    const pos = (ev) => { const rc = cv.getBoundingClientRect(); return [(ev.clientX - rc.left) * W / rc.width, (ev.clientY - rc.top) * H / rc.height]; };
    cv.addEventListener('mousedown', (ev) => {
      const [px, py] = pos(ev);
      if (!curve.bezier) { st.curve = 'custom'; curve = CURVES.custom; sel.value = 'custom'; }
      const c = st.bezier, d1 = Math.hypot(...toPx(c[0], c[1]).map((v, i) => v - [px, py][i])), d2 = Math.hypot(...toPx(c[2], c[3]).map((v, i) => v - [px, py][i]));
      dragging = d1 <= d2 ? 0 : 1;
      ev.preventDefault();
    });
    if (curveWin.move) { window.removeEventListener('mousemove', curveWin.move); window.removeEventListener('mouseup', curveWin.up); window.removeEventListener('resize', curveWin.resize); }
    curveWin.move = (ev) => { if (dragging < 0 || !cv.isConnected) return; const [x, y] = fromPx(...pos(ev)); st.bezier[dragging * 2] = Math.round(x * 100) / 100; st.bezier[dragging * 2 + 1] = Math.round(y * 100) / 100; draw(); if (!animAll) cards.forEach(stillFrame); };
    curveWin.up = () => { if (dragging < 0) return; dragging = -1; save(); };
    curveWin.resize = () => { if (cv.isConnected) draw(); };
    window.addEventListener('mousemove', curveWin.move); window.addEventListener('mouseup', curveWin.up); window.addEventListener('resize', curveWin.resize);
    cv.addEventListener('dblclick', () => { st.bezier = [0.65, 0, 0.35, 1]; save(); draw(); if (!animAll) cards.forEach(stillFrame); });
    wrap.append(cv, sel);
    draw();
    requestAnimationFrame(draw);   /* once laid out, redraw at the real size */
    return { el: wrap, draw };
  }
  function open() {
    Hub.show('transitions');
    const row = (label, ctrl, hint) => { const r = h('div', 'row'); const l = h('label', '', label); if (hint) l.innerHTML += ' <span class="hint">' + hint + '</span>'; r.append(l, ctrl); return r; };
    const slider = (get, set, min, max, step, fmt) => { const w = h('div', 'slider'); const r = h('input'); r.type = 'range'; r.min = min; r.max = max; r.step = step; r.value = get(); const v = h('span', 'val', fmt(get())); r.addEventListener('input', () => { set(parseFloat(r.value)); v.textContent = fmt(parseFloat(r.value)); save(); if (!animAll) cards.forEach(stillFrame); }); w.append(r, v); return w; };
    const ctl = $('#trans-controls'); ctl.innerHTML = '';
    const frames = slider(() => st.frames, v => st.frames = Math.round(v), 2, 60, 1, v => Math.round(v) + ' f');
    const inten = slider(() => st.intensity, v => st.intensity = v, 0.3, 2, 0.05, v => v.toFixed(2) + '×');
    const curveSel = h('select', 'sel'); for (const [k, c] of Object.entries(CURVES)) { const o = h('option'); o.value = k; o.textContent = c.name; curveSel.appendChild(o); } curveSel.value = st.curve;
    const curveUI = mkCurveEditor(curveSel);
    const curveRow = row('Motion curve', curveUI.el, 'pick a preset or drag the handles'); curveRow.classList.add('wrapping');
    curveSel.addEventListener('change', () => { st.curve = curveSel.value; curve = CURVES[st.curve]; save(); if (!animAll) cards.forEach(stillFrame); curveUI.draw(); });
    const where = h('select', 'sel'); for (const [k, n] of [['between', 'Cuts between selected clips'], ['start', 'Start of each selected clip'], ['end', 'End of each selected clip']]) { const o = h('option'); o.value = k; o.textContent = n; where.appendChild(o); } where.value = st.where; where.addEventListener('change', () => { st.where = where.value; save(); });
    const mode = h('select', 'sel'); for (const [k, n] of [['adjustment', 'Adjustment layer above the clips (auto-created)'], ['clips', 'Directly on the clips']]) { const o = h('option'); o.value = k; o.textContent = n; mode.appendChild(o); } mode.value = st.mode; mode.addEventListener('change', () => { st.mode = mode.value; save(); });
    const note = h('div', 'st-note'); note.id = 'trans-note';
    const pvNote = h('div', 'kbd'); pvNote.id = 'trans-pv';
    ctl.append(row('Last used', h('b', '', ''), 'click a transition below to add it'), row('Length', frames), row('Intensity', inten), curveRow, row('Where', where), row('How', mode), note);
    ctl.querySelector('b').id = 'trans-sel';
    imgA = null; imgB = null;   /* always the A/B demo frames */
    render();
  }
  function init() {
    $('#sw-trans-anim').addEventListener('click', () => { animAll = !animAll; try { localStorage.setItem('os.trans.anim', animAll ? '1' : '0'); } catch (e) {} $('#sw-trans-anim').classList.toggle('on', animAll); if (animAll) ensureLoop(); else cards.forEach(stillFrame); });
  }
  return { open, init, presets: P, toEffects, drawPreview };
})();
