/* Relight: a Node script the panel runs with its own node.exe (same runtime as Remove music and Remove background).
   MoGe-2 (Microsoft, MIT; ViT-S) estimates surface normals and depth for every frame on the GPU through
   onnxruntime-node, and virtual lights are shaded onto the original pixels. ffmpeg decodes and encodes.
   (--engine depth keeps the older Depth-Anything path: depth only, normals derived from it.)

   node relight.js --in clip.mp4 --out out.mov --model moge.onnx --ffmpeg ffmpeg.exe --ort <dir with node_modules>
                   --lights rig.json [--tokens 600] [--every 2] [--start 12.5] [--duration 8] [--frames N --skipframes K] [--cpu]
                   [--preview <folder> --at 3.2]      (one frame: original.png, normal.png, depth.png for the live preview)
                   [--match image.png --matchout rig.json]   (read the light of a picture into a rig)
   rig.json: { ambient, wrap, specular, shininess, relief, lights: [{ x, y, z, color: 'rrggbb', intensity, radius }] }
   x, y are 0..1 across the frame, z is the height above the frame in frame-widths, radius the falloff in frame-widths.
   Prints "progress 0.37" lines and "done" on stdout. */
'use strict';
const fs = require('fs'), path = require('path'), { spawn, spawnSync } = require('child_process');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

const args = {}; for (let i = 2; i < process.argv.length; i++) { const a = process.argv[i]; if (a.startsWith('--')) { const k = a.slice(2); const v = process.argv[i + 1]; if (v == null || v.startsWith('--')) { args[k] = true; } else { args[k] = v; i++; } } }
const need = (k) => { if (!args[k]) { console.error('missing --' + k); process.exit(2); } return args[k]; };
const MODEL = need('model'), FFMPEG = need('ffmpeg');
const IN = args.match ? (args.in || args.match) : need('in');
const OUT = (args.preview || args.match) ? null : need('out');
const START = +args.start || 0, DURATION = +args.duration || 0, AT = +args.at || 0;
const ENGINE = args.engine === 'depth' ? 'depth' : 'moge';
const TOKENS = Math.max(300, Math.min(2500, Math.round(+args.tokens || 600)));
const EVERY = Math.max(1, Math.min(4, Math.round(+args.every || 1)));   /* run the model on every Nth frame; the others reuse the smoothed normals */
const ort = require(path.join(args.ort ? path.join(args.ort, 'node_modules') : 'node_modules', 'onnxruntime-node'));

/* --- the model lives on a worker thread: a run there keeps going while this thread composes the previous frame
       (an onnxruntime call made from the main thread only advances while the main thread is idle) --- */
if (!isMainThread) {
  (async () => {
    const session = await ort.InferenceSession.create(workerData.model, { executionProviders: workerData.cpu ? ['cpu'] : (process.platform === 'win32' ? ['dml', 'cpu'] : ['coreml', 'cpu']) });
    const tokens = new ort.Tensor('int64', BigInt64Array.from([BigInt(workerData.tokens)]), []);
    const inName = session.inputNames[0], outName = session.outputNames[0];
    parentPort.postMessage({ ready: true });
    parentPort.on('message', async (m) => {
      try {
        const feeds = workerData.engine === 'moge' ? { image: new ort.Tensor('float32', m.input, [1, 3, m.GH, m.GW]), num_tokens: tokens } : { [inName]: new ort.Tensor('float32', m.input, [1, 3, m.GH, m.GW]) };
        const res = await session.run(feeds);
        const out = {}, transfer = [m.input.buffer];
        for (const k of Object.keys(res)) { const d = Float32Array.from(res[k].data); out[k] = d; transfer.push(d.buffer); }
        if (workerData.engine !== 'moge') out.depth = out[outName];
        parentPort.postMessage({ id: m.id, res: out, input: m.input }, transfer);
      } catch (e) { parentPort.postMessage({ id: m.id, error: e.message || String(e) }); }
    });
  })().catch((e) => { parentPort.postMessage({ fatal: e.message || String(e) }); });
}
const say = (s) => process.stdout.write(s + '\n');
const FFPROBE = path.join(path.dirname(FFMPEG), process.platform === 'win32' ? 'ffprobe.exe' : 'ffprobe');

function probe(file) {
  const r = spawnSync(FFPROBE, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,r_frame_rate,pix_fmt:format=duration', '-of', 'json', file], { encoding: 'utf8', windowsHide: true });
  if (r.status !== 0) throw new Error('ffprobe failed: ' + (r.stderr || '').slice(-200));
  const j = JSON.parse(r.stdout); const s = j.streams[0];
  const [a, b] = String(s.r_frame_rate || '30/1').split('/').map(Number);
  const pf = String(s.pix_fmt || '');
  return { w: s.width, h: s.height, fps: b ? a / b : a, duration: +(j.format && j.format.duration) || 0, alpha: /^(yuva|rgba|argb|bgra|abgr|gbrap|ya|pal)/.test(pf) };
}
function frameReader(stream, bytes) {
  let cur = Buffer.allocUnsafe(bytes), filled = 0, ended = false, waiter = null; const ready = [];
  stream.on('data', (chunk) => { let off = 0; while (off < chunk.length) { const n = Math.min(bytes - filled, chunk.length - off); chunk.copy(cur, filled, off, off + n); filled += n; off += n; if (filled === bytes) { ready.push(cur); cur = Buffer.allocUnsafe(bytes); filled = 0; } } if (ready.length >= 4) stream.pause(); if (waiter) { const w = waiter; waiter = null; w(); } });
  stream.on('end', () => { ended = true; if (waiter) { const w = waiter; waiter = null; w(); } });
  stream.on('error', () => { ended = true; if (waiter) { const w = waiter; waiter = null; w(); } });
  return async function next() { while (!ready.length) { if (ended) return null; await new Promise((r) => { waiter = r; }); } const f = ready.shift(); if (ready.length < 2) stream.resume(); return f; };
}

/* --- the model grid: the frame scaled so its long side is 518, aspect kept, sides multiples of 14 (ViT patches) --- */
let GW = 518, GH = 518, GN = GW * GH;
let CH = 3;   /* bytes per pixel of the decoded frames: 3 (rgb24) or 4 (rgba, clips with transparency) */
const PIXFMT = () => CH === 4 ? 'rgba' : 'rgb24';
function gridFor(W, H) { const s = 518 / Math.max(W, H); GW = Math.max(56, Math.round(W * s / 14) * 14); GH = Math.max(56, Math.round(H * s / 14) * 14); GN = GW * GH; }
const MEAN = [0.485, 0.456, 0.406], STD = [0.229, 0.224, 0.225];
let valid = null;
/* sampled to the grid: 0..1 RGB for MoGe, ImageNet-normalised for the depth engine; plus the validity mask (black bars) */
function toInput(rgb, W, H, dst) {
  for (let y = 0; y < GH; y++) {
    const sy = Math.min(H - 1, Math.floor((y + 0.5) * H / GH));
    for (let x = 0; x < GW; x++) {
      const sx = Math.min(W - 1, Math.floor((x + 0.5) * W / GW)), p = (sy * W + sx) * CH, o = y * GW + x;
      const a = CH === 4 ? rgb[p + 3] / 255 : 1;   /* transparent pixels are shown to the model as black, like the cutout looks */
      const r = rgb[p] / 255 * a, g = rgb[p + 1] / 255 * a, b = rgb[p + 2] / 255 * a;
      if (ENGINE === 'moge') { dst[o] = r; dst[GN + o] = g; dst[2 * GN + o] = b; }
      else { dst[o] = (r - MEAN[0]) / STD[0]; dst[GN + o] = (g - MEAN[1]) / STD[1]; dst[2 * GN + o] = (b - MEAN[2]) / STD[2]; }
      valid[o] = (r + g + b) * 255 > 18 && a > 0.03 ? 1 : 0;
    }
  }
}
/* depth helpers: normalised depth with a running range, a 3x3 blur, normals from the gradient (depth engine) */
let rangeLo = null, rangeHi = null;
function normaliseDepth(d, out) {
  let lo = Infinity, hi = -Infinity; for (let i = 0; i < d.length; i += 7) { if (!valid[i]) continue; const v = d[i]; if (!isFinite(v)) continue; if (v < lo) lo = v; if (v > hi) hi = v; }
  if (!isFinite(lo)) { lo = 0; hi = 1; }
  if (rangeLo === null) { rangeLo = lo; rangeHi = hi; } else { rangeLo += (lo - rangeLo) * 0.1; rangeHi += (hi - rangeHi) * 0.1; }
  const k = 1 / Math.max(1e-6, rangeHi - rangeLo);
  for (let i = 0; i < d.length; i++) { if (!valid[i] || !isFinite(d[i])) { out[i] = 0; continue; } const v = (d[i] - rangeLo) * k; out[i] = v < 0 ? 0 : v > 1 ? 1 : v; }
}
function blur3(src, dst) {
  for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
    let acc = 0, c = 0;
    for (let dy = -1; dy <= 1; dy++) { const yy = y + dy; if (yy < 0 || yy >= GH) continue; for (let dx = -1; dx <= 1; dx++) { const xx = x + dx; if (xx < 0 || xx >= GW) continue; acc += src[yy * GW + xx]; c++; } }
    dst[y * GW + x] = acc / c;
  }
}
function normalsFromDepth(depth, relief, nx, ny, nz) {
  const k = relief * 518 * 0.5;
  for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
    const xm = x > 0 ? x - 1 : x, xp = x < GW - 1 ? x + 1 : x, ym = y > 0 ? y - 1 : y, yp = y < GH - 1 ? y + 1 : y;
    const o0 = y * GW + x, c = depth[o0];
    if (!valid[o0]) { nx[o0] = 0; ny[o0] = 0; nz[o0] = 1; continue; }
    const vxm = valid[y * GW + xm] ? depth[y * GW + xm] : c, vxp = valid[y * GW + xp] ? depth[y * GW + xp] : c, vym = valid[ym * GW + x] ? depth[ym * GW + x] : c, vyp = valid[yp * GW + x] ? depth[yp * GW + x] : c;
    let dzdx = (vxp - vxm) / (xp - xm) * k, dzdy = (vyp - vym) / (yp - ym) * k;
    if (dzdx > 2.5) dzdx = 2.5; else if (dzdx < -2.5) dzdx = -2.5; if (dzdy > 2.5) dzdy = 2.5; else if (dzdy < -2.5) dzdy = -2.5;
    const inv = 1 / Math.sqrt(dzdx * dzdx + dzdy * dzdy + 1);
    nx[o0] = dzdx * inv; ny[o0] = dzdy * inv; nz[o0] = inv;
  }
}
/* invalid samples (black bars, transparent areas) take the nearest valid value, so previews do not show a cliff there */
function fillInvalid(arr) {
  const v = new Uint8Array(valid);
  for (let pass = 0; pass < 40; pass++) {
    let changed = 0;
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const o = y * GW + x; if (v[o]) continue;
      let acc = 0, c = 0;
      if (x > 0 && v[o - 1]) { acc += arr[o - 1]; c++; } if (x < GW - 1 && v[o + 1]) { acc += arr[o + 1]; c++; }
      if (y > 0 && v[o - GW]) { acc += arr[o - GW]; c++; } if (y < GH - 1 && v[o + GW]) { acc += arr[o + GW]; c++; }
      if (c) { arr[o] = acc / c; v[o] = 2; changed++; }
    }
    for (let i = 0; i < v.length; i++) if (v[i] === 2) v[i] = 1;
    if (!changed) break;
  }
}
/* separable box blur on the grid (radius r), used to calm the normals where the model is unsure (sky, haze) */
let blurTmp = null;
function boxBlur(src, dst, r) {
  if (!blurTmp || blurTmp.length !== GN) blurTmp = new Float32Array(GN);
  const t = blurTmp;
  for (let y = 0; y < GH; y++) { const row = y * GW; let acc = 0, c = 0; for (let x = 0; x <= r && x < GW; x++) { acc += src[row + x]; c++; } for (let x = 0; x < GW; x++) { t[row + x] = acc / c; const add = x + r + 1, rem = x - r; if (add < GW) { acc += src[row + add]; c++; } if (rem >= 0) { acc -= src[row + rem]; c--; } } }
  for (let x = 0; x < GW; x++) { let acc = 0, c = 0; for (let y = 0; y <= r && y < GH; y++) { acc += t[y * GW + x]; c++; } for (let y = 0; y < GH; y++) { dst[y * GW + x] = acc / c; const add = y + r + 1, rem = y - r; if (add < GH) { acc += t[add * GW + x]; c++; } if (rem >= 0) { acc -= t[rem * GW + x]; c--; } } }
}
/* where the model has no solid geometry (its mask is low: sky, haze, glare) the normals follow a heavily blurred
   version of themselves, so cloud texture does not turn into ripples of light; solid areas keep every detail */
let mB = null, bx = null, by = null, bz = null;
function calmNormals(mask, nx, ny, nz) {
  if (!mB || mB.length !== GN) { mB = new Float32Array(GN); bx = new Float32Array(GN); by = new Float32Array(GN); bz = new Float32Array(GN); }
  boxBlur(mask, mB, 7); boxBlur(nx, bx, 6); boxBlur(ny, by, 6); boxBlur(nz, bz, 6);
  for (let i = 0; i < GN; i++) {
    let w = (mB[i] - 0.35) / 0.55; w = w < 0 ? 0 : w > 1 ? 1 : w; w = w * w * (3 - 2 * w);
    if (w >= 0.999) continue;
    const x = bx[i] + (nx[i] - bx[i]) * w, y = by[i] + (ny[i] - by[i]) * w, z = bz[i] + (nz[i] - bz[i]) * w;
    const inv = 1 / (Math.sqrt(x * x + y * y + z * z) || 1); nx[i] = x * inv; ny[i] = y * inv; nz[i] = z * inv;
  }
}
/* relief on model normals: scale the tilt, renormalise (relief 0.5 = as the model saw it) */
function applyRelief(nx, ny, nz, relief) {
  const s = Math.max(0.1, relief * 2);
  if (Math.abs(s - 1) < 1e-3) return;
  for (let i = 0; i < GN; i++) { const x = nx[i] * s, y = ny[i] * s, z = nz[i]; const inv = 1 / Math.sqrt(x * x + y * y + z * z); nx[i] = x * inv; ny[i] = y * inv; nz[i] = z * inv; }
}
const hex = (s) => [parseInt(s.slice(0, 2), 16) / 255, parseInt(s.slice(2, 4), 16) / 255, parseInt(s.slice(4, 6), 16) / 255];

/* "match the light of an image": the direction whose shading correlates best with the picture's brightness */
function matchLight(rgb, W, H, nx, ny, nz) {
  const lum = new Float32Array(GN), col = new Float32Array(GN * 3);
  for (let y = 0; y < GH; y++) { const sy = Math.min(H - 1, Math.floor((y + 0.5) * H / GH)); for (let x = 0; x < GW; x++) { const sx = Math.min(W - 1, Math.floor((x + 0.5) * W / GW)), p = (sy * W + sx) * CH, o = y * GW + x; const a = CH === 4 ? rgb[p + 3] / 255 : 1; col[o * 3] = rgb[p] / 255 * a; col[o * 3 + 1] = rgb[p + 1] / 255 * a; col[o * 3 + 2] = rgb[p + 2] / 255 * a; lum[o] = Math.pow(0.299 * col[o * 3] + 0.587 * col[o * 3 + 1] + 0.114 * col[o * 3 + 2], 1 / 2.2); } }
  const idx = []; for (let i = 0; i < GN; i += 2) if (valid[i]) idx.push(i);
  if (idx.length < 100) throw new Error('The reference image is too dark or empty to read the light from.');
  const dirs = [];
  for (let el = 10; el <= 80; el += 14) for (let az = 0; az < 360; az += 20) { const e = el * Math.PI / 180, a = az * Math.PI / 180; dirs.push([Math.cos(e) * Math.cos(a), Math.cos(e) * Math.sin(a), Math.sin(e)]); }
  dirs.push([0, 0, 1]);
  const mean = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const corr = (f, target) => { const xs = idx.map(f), ys = idx.map((i) => target[i]); const mx = mean(xs), my = mean(ys); let sxy = 0, sxx = 0, syy = 0; for (let k = 0; k < xs.length; k++) { const dx = xs[k] - mx, dy = ys[k] - my; sxy += dx * dy; sxx += dx * dx; syy += dy * dy; } return sxx > 0 && syy > 0 ? sxy / Math.sqrt(sxx * syy) : 0; };
  const shade = (d) => (i) => { const v = nx[i] * d[0] + ny[i] * d[1] + nz[i] * d[2]; return v > 0 ? v : 0; };
  let best = null, bestC = -2;
  for (const d of dirs) { const c = corr(shade(d), lum); if (c > bestC) { bestC = c; best = d; } }
  const s1 = idx.map(shade(best)); const ms = mean(s1) || 1;
  const resid = new Float32Array(GN); { const ml = mean(idx.map((i) => lum[i])); idx.forEach((i, k) => { resid[i] = lum[i] - ml * (s1[k] / ms); }); }
  let second = null, secondC = -2;
  for (const d of dirs) { const cosang = d[0] * best[0] + d[1] * best[1] + d[2] * best[2]; if (cosang > 0.5) continue; const c = corr(shade(d), resid); if (c > secondC) { secondC = c; second = d; } }
  const sh = shade(best); const order = idx.slice().sort((a, b) => sh(b) * lum[b] - sh(a) * lum[a]);
  const top = order.slice(0, Math.max(10, Math.floor(order.length * 0.15))), bottom = order.slice(-Math.max(10, Math.floor(order.length * 0.2)));
  const avg = (list) => { let r = 0, g = 0, b = 0; for (const i of list) { r += col[i * 3]; g += col[i * 3 + 1]; b += col[i * 3 + 2]; } return [r / list.length, g / list.length, b / list.length]; };
  const tc = avg(top), bc = avg(bottom);
  const tl = mean(top.map((i) => lum[i])), bl = mean(bottom.map((i) => lum[i])), al = mean(idx.map((i) => lum[i]));
  const mx = Math.max(tc[0], tc[1], tc[2]) || 1; const tint = tc.map((v) => 0.55 + 0.45 * (v / mx));
  const toHex = (c) => c.map((v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0')).join('');
  const contrast = Math.max(0, (tl - bl) / Math.max(0.05, al));
  const intensity = Math.max(0.4, Math.min(2.2, 0.5 + contrast * 1.4)), ambient = Math.max(0.15, Math.min(0.9, bl / Math.max(0.05, al) * 0.8));
  const place = (d, z) => ({ x: +(0.5 + d[0] * 0.55).toFixed(3), y: +(0.5 + d[1] * 0.55).toFixed(3), z: +Math.max(0.15, d[2] * z).toFixed(2) });
  const lights = [Object.assign(place(best, 0.9), { color: toHex(tint), intensity: +intensity.toFixed(2), radius: 1.2 })];
  if (second && secondC > 0.12) { const bm = Math.max(bc[0], bc[1], bc[2]) || 1; const bt = bc.map((v) => 0.6 + 0.4 * (v / bm)); lights.push(Object.assign(place(second, 0.6), { color: toHex(bt), intensity: +Math.max(0.3, Math.min(1.5, intensity * secondC * 1.5)).toFixed(2), radius: 1.0 })); }
  return { ambient: +ambient.toFixed(2), wrap: 0.25, specular: 0.2, shininess: 24, relief: 0.5, lights, fit: { main: +bestC.toFixed(2), second: +secondC.toFixed(2) }, even: (() => { const a = Math.max(0.2, Math.min(0.8, bl / Math.max(0.05, tl))); let acc = 0; for (const i of idx) { const v = nx[i] * best[0] + ny[i] * best[1] + nz[i] * best[2]; acc += a + (1 - a) * (v > 0 ? v : 0); } return { dir: best.map((v) => +v.toFixed(4)), ambient: +a.toFixed(3), mean: +(acc / idx.length).toFixed(4) }; })() };
}

/* --- shading: light terms on the model grid, bilinearly upsampled while composing at full resolution --- */
let gridD = null, gridS = null;
/* dappled light ("gobo"): a fixed random table, read twice at different scales with smooth bilinear steps, drifting
   with time. The preview shader holds the same table, so both show the same leaves. */
const GOBO_N = 128, goboTab = (() => { const t = new Float32Array(GOBO_N * GOBO_N); let x = 1234567; for (let i = 0; i < t.length; i++) { x = (Math.imul(x, 1664525) + 1013904223) >>> 0; t[i] = ((x >>> 8) & 255) / 255; } return t; })();
function goboNoise(u, v) {
  /* u, v in cells; the table wraps every GOBO_N cells */
  let x0 = Math.floor(u), y0 = Math.floor(v); let tx = u - x0, ty = v - y0; tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
  x0 = ((x0 % GOBO_N) + GOBO_N) % GOBO_N; y0 = ((y0 % GOBO_N) + GOBO_N) % GOBO_N; const x1 = (x0 + 1) % GOBO_N, y1 = (y0 + 1) % GOBO_N;
  const a = goboTab[y0 * GOBO_N + x0], b = goboTab[y0 * GOBO_N + x1], c = goboTab[y1 * GOBO_N + x0], d = goboTab[y1 * GOBO_N + x1];
  return (a + (b - a) * tx) + ((c + (d - c) * tx) - (a + (b - a) * tx)) * ty;
}
function goboAt(g, px, py, t) {
  const size = +g.size || 3, sp = +g.speed || 0;
  const dx = t * sp * 0.02 + Math.sin(t * 0.7) * 0.01 * sp, dy = t * sp * 0.013 + Math.cos(t * 0.5) * 0.01 * sp;
  const u = px * size + dx, v = py * size + dy;
  const n = 0.62 * goboNoise(u, v) + 0.38 * goboNoise(u * 2.17 + 0.37, v * 2.17 + 0.71);
  const e = 0.08 + (g.soft == null ? 0.5 : +g.soft) * 0.3; let m = (n - (0.5 - e)) / (2 * e); m = m < 0 ? 0 : m > 1 ? 1 : m; m = m * m * (3 - 2 * m);
  return 1 - (+g.amount || 0) * (1 - m);
}
let curTime = 0, goboCache = null;   /* seconds into the clip, for the moving dapples */
/* the even-out pass: the light the clip already has (direction + base level, read from the first frame) is divided
   out before the new lights go on, so a face lit from the left can be relit from the right */
let evenSh = null;
function evenSetup(fit) { evenSh = fit ? { dx: +fit.dir[0], dy: +fit.dir[1], dz: +fit.dir[2], a: +fit.ambient } : null; }
function lightGrid(W, H, nx, ny, nz, rig) {
  const aspect = H / W;
  const lights = (rig.lights || []).map((l) => {
    const L = { x: +l.x, y: +l.y, z: l.z == null ? 0.6 : +l.z, c: hex(l.color || 'ffffff'), i: +l.intensity || 0, r: Math.max(0.05, +l.radius || 0.8), spot: false, ax: 0, ay: 0, az: 0, co: -2, ci: -1 };
    if (Math.abs(L.z) < 0.02) L.z = L.z < 0 ? -0.02 : 0.02;
    if (l.type === 'spot') {
      /* axis from the light to its aim point on the picture; cone as cosines (outer edge, inner full-strength) */
      let ax = (+l.ax || 0.5) - L.x, ay = ((+l.ay || 0.5) - L.y) * aspect, az = -L.z; const n = Math.sqrt(ax * ax + ay * ay + az * az) || 1;
      const half = Math.max(2, Math.min(89, (+l.cone || 40) / 2)) * Math.PI / 180, soft = Math.max(0.02, Math.min(1, l.soft == null ? 0.5 : +l.soft));
      Object.assign(L, { spot: true, ax: ax / n, ay: ay / n, az: az / n, co: Math.cos(half), ci: Math.cos(half * (1 - soft)) });
    }
    return L;
  });
  const ambient = rig.ambient == null ? 0.55 : +rig.ambient, wrap = rig.wrap == null ? 0.25 : +rig.wrap, spec = rig.specular == null ? 0.25 : +rig.specular, shin = rig.shininess == null ? 24 : +rig.shininess;
  const ac = hex(rig.ambientColor || 'ffffff'), ar = ambient * ac[0], ag = ambient * ac[1], ab = ambient * ac[2];
  const even = Math.max(0, Math.min(1, +rig.even || 0));
  const gobo = rig.gobo && rig.gobo.on && +rig.gobo.amount > 0 ? rig.gobo : null;
  /* the dapples are soft, so they are evaluated on every other grid cell and shared by the 2x2 block */
  let goboRow = null, goboPrev = null;
  if (gobo) { const hw = (GW >> 1) + 1; if (!goboCache || goboCache.length < hw * 2) goboCache = new Float32Array(hw * 2); goboRow = goboCache.subarray(0, hw); goboPrev = goboCache.subarray(hw, hw * 2); }
  let evenMean = 1;
  if (even > 0 && evenSh) { let acc = 0, c = 0; for (let o = 0; o < GN; o++) { if (!valid[o]) continue; let s = nx[o] * evenSh.dx + ny[o] * evenSh.dy + nz[o] * evenSh.dz; if (s < 0) s = 0; acc += evenSh.a + (1 - evenSh.a) * s; c++; } evenMean = c ? acc / c : 1; }
  for (let gy = 0; gy < GH; gy++) {
    const py = ((gy + 0.5) / GH) * aspect;
    if (gobo && (gy & 1) === 0) { for (let gx = 0; gx < GW; gx += 2) goboRow[gx >> 1] = goboAt(gobo, (gx + 1) / GW, ((gy + 1) / GH) * aspect, curTime); }
    for (let gx = 0; gx < GW; gx++) {
      const o = gy * GW + gx, px = (gx + 0.5) / GW;
      const Nx = nx[o], Ny = ny[o], Nz = nz[o];
      let dr = ar, dg = ag, db = ab, sr = 0, sg = 0, sb = 0;
      if (valid[o]) for (let k = 0; k < lights.length; k++) {
        const L = lights[k];
        let lx = L.x - px, ly = L.y * aspect - py, lz = L.z;
        const d2 = lx * lx + ly * ly + lz * lz, d = Math.sqrt(d2) || 1e-4; lx /= d; ly /= d; lz /= d;
        let fall = L.i / (1 + d2 / (L.r * L.r));
        if (L.spot) { const ca = -(lx * L.ax + ly * L.ay + lz * L.az); let t = (ca - L.co) / (L.ci - L.co); t = t < 0 ? 0 : t > 1 ? 1 : t; fall *= t * t * (3 - 2 * t); if (fall <= 0) continue; }
        let ndl = Nx * lx + Ny * ly + Nz * lz; ndl = (ndl + wrap) / (1 + wrap); if (ndl < 0) ndl = 0;
        const diff = ndl * fall; dr += diff * L.c[0]; dg += diff * L.c[1]; db += diff * L.c[2];
        if (spec > 0) { let hx = lx, hy = ly, hz = lz + 1; const hinv = 1 / Math.sqrt(hx * hx + hy * hy + hz * hz); const ndh = (Nx * hx + Ny * hy + Nz * hz) * hinv; if (ndh > 0) { const s = Math.pow(ndh, shin) * spec * fall; sr += s * L.c[0]; sg += s * L.c[1]; sb += s * L.c[2]; } }
      }
      if (gobo) { const gm = goboRow[gx >> 1]; dr *= gm; dg *= gm; db *= gm; }
      if (even > 0 && evenSh && valid[o]) { let sh = Nx * evenSh.dx + Ny * evenSh.dy + Nz * evenSh.dz; if (sh < 0) sh = 0; sh = evenSh.a + (1 - evenSh.a) * sh; let mul = 1 + even * (evenMean / sh - 1); if (mul < 0.4) mul = 0.4; else if (mul > 2.5) mul = 2.5; dr *= mul; dg *= mul; db *= mul; }
      gridD[o * 3] = dr; gridD[o * 3 + 1] = dg; gridD[o * 3 + 2] = db; gridS[o * 3] = sr; gridS[o * 3 + 1] = sg; gridS[o * 3 + 2] = sb;
    }
  }
}
/* colour correction: temperature/tint gains, exposure, contrast, three-zone lift into one table per channel; saturation per pixel */
let lutKey = '', lutR = null, lutG = null, lutB = null, satK = 1, colorOn = false;
function colorSetup(c) {
  const key = JSON.stringify(c || {}); if (key === lutKey) return; lutKey = key;
  c = c || {}; const ex = +c.exposure || 0, ct = +c.contrast || 0, sat = c.saturation == null ? 1 : +c.saturation, te = +c.temp || 0, ti = +c.tint || 0, sh = +c.shadows || 0, mi = +c.mids || 0, hi = +c.highs || 0;
  colorOn = !!(ex || ct || sat !== 1 || te || ti || sh || mi || hi); satK = sat;
  if (!colorOn) return;
  const gains = [1 + 0.25 * te + 0.08 * ti, 1 - 0.2 * ti, 1 - 0.25 * te + 0.08 * ti], gain = Math.pow(2, ex);
  const mk = (g) => { const t = new Float32Array(256); for (let i = 0; i < 256; i++) { let v = i / 255 * g * gain; v = 0.5 + (v - 0.5) * (1 + ct); const ws = (1 - v) * (1 - v), wh = v * v, wm = Math.max(0, 1 - ws - wh); v += 0.25 * (sh * ws + mi * wm + hi * wh); t[i] = v < 0 ? 0 : v > 1 ? 1 : v; } return t; };
  lutR = mk(gains[0]); lutG = mk(gains[1]); lutB = mk(gains[2]);
}
/* ground shadow for clips with transparency: the silhouette, sheared from the feet along the key light, blurred */
let shW = 0, shH = 0, shMask = null, shTmp = null, shAlpha = null, feetY = -1, feetX = 0.5;
function shadowSetup(rgb, W, H, rig) {
  const sc = rig.shadow; if (!sc || !sc.on || CH !== 4 || !(+sc.opacity > 0)) { shMask = null; return; }
  const L = (rig.lights || [])[Math.max(0, Math.min((rig.lights || []).length - 1, +sc.light || 0))]; if (!L) { shMask = null; return; }
  const SW = Math.ceil(W / 4), SH = Math.ceil(H / 4);
  if (shW !== SW || shH !== SH) { shW = SW; shH = SH; shMask = new Float32Array(SW * SH); shTmp = new Float32Array(SW * SH); shAlpha = new Float32Array(SW * SH); }
  /* quarter-size alpha, the feet row (lowest row with a bit of subject) and the subject's centre near the feet */
  let yb = -1, cxs = 0, cxn = 0;
  for (let y = 0; y < SH; y++) { const sy = Math.min(H - 1, y * 4 + 2); let cnt = 0; for (let x = 0; x < SW; x++) { const sx = Math.min(W - 1, x * 4 + 2); const a = rgb[(sy * W + sx) * 4 + 3] / 255; shAlpha[y * SW + x] = a; if (a > 0.5) cnt++; } if (cnt >= 2) yb = y; }
  if (yb < 0) { shMask = null; return; }
  for (let y = Math.max(0, yb - Math.round(SH * 0.12)); y <= yb; y++) for (let x = 0; x < SW; x++) if (shAlpha[y * SW + x] > 0.5) { cxs += x; cxn++; }
  const ybN = (yb + 0.5) / SH, cxN = cxn ? (cxs / cxn + 0.5) / SW : 0.5;
  if (feetY < 0) { feetY = ybN; feetX = cxN; } else { feetY += (ybN - feetY) * 0.3; feetX += (cxN - feetX) * 0.3; }
  const lz = L.z == null ? 0.6 : +L.z, aspect = H / W;
  const k = (+sc.length || 1) * 0.8 / (0.4 + Math.abs(lz));
  let dx = (feetX - +L.x) * 1.2; dx = dx < -1.5 ? -1.5 : dx > 1.5 ? 1.5 : dx;
  let dy = -0.35 * lz / (Math.abs(lz) + 0.3); if (Math.abs(dy) < 0.12) dy = dy < 0 ? -0.12 : 0.12;
  /* inverse map every quarter pixel back onto the silhouette (uv units: x in widths, y in heights) */
  for (let Y = 0; Y < SH; Y++) {
    const vy = (Y + 0.5) / SH; const hgt = (vy - feetY) / (k * dy);   /* height above the feet, in widths */
    for (let X = 0; X < SW; X++) {
      let m = 0;
      if (hgt >= 0) { const sy = feetY - hgt / aspect, sx = (X + 0.5) / SW - hgt * k * dx; if (sy >= 0 && sy < 1 && sx >= 0 && sx < 1) m = shAlpha[Math.floor(sy * SH) * SW + Math.floor(sx * SW)]; }
      shMask[Y * SW + X] = m;
    }
  }
  const r = Math.max(0, Math.round((+sc.soft || 0) * 0.025 * SW)); if (r > 0) { shBlur(shMask, shTmp, SW, SH, r); shBlur(shMask, shTmp, SW, SH, r); }
}
function shBlur(src, tmp, w, hgt, r) {
  for (let y = 0; y < hgt; y++) { const row = y * w; let acc = 0, c = 0; for (let x = 0; x <= r && x < w; x++) { acc += src[row + x]; c++; } for (let x = 0; x < w; x++) { tmp[row + x] = acc / c; const add = x + r + 1, rem = x - r; if (add < w) { acc += src[row + add]; c++; } if (rem >= 0) { acc -= src[row + rem]; c--; } } }
  for (let x = 0; x < w; x++) { let acc = 0, c = 0; for (let y = 0; y <= r && y < hgt; y++) { acc += tmp[y * w + x]; c++; } for (let y = 0; y < hgt; y++) { src[y * w + x] = acc / c; const add = y + r + 1, rem = y - r; if (add < hgt) { acc += tmp[add * w + x]; c++; } if (rem >= 0) { acc -= tmp[rem * w + x]; c--; } } }
}
let rowD = null, rowS = null, xs = null, xt = null, xsW = 0;
function relightFrame(rgb, W, H, nx, ny, nz, rig, out) {
  lightGrid(W, H, nx, ny, nz, rig);
  colorSetup(rig.color); shadowSetup(rgb, W, H, rig);
  const shO = shMask ? Math.max(0, Math.min(1, +rig.shadow.opacity)) : 0, shX = shW / W, shY = shH / H;
  if (!rowD || rowD.length !== GW * 3) { rowD = new Float32Array(GW * 3); rowS = new Float32Array(GW * 3); }
  if (xsW !== W) { xs = new Int32Array(W); xt = new Float32Array(W); xsW = W; for (let x = 0; x < W; x++) { const sx = Math.min(GW - 1.001, Math.max(0, (x + 0.5) / W * GW - 0.5)); xs[x] = (sx | 0) * 3; xt[x] = sx - (sx | 0); } }
  const G3 = GW * 3;
  for (let y = 0; y < H; y++) {
    const sy = Math.min(GH - 1.001, Math.max(0, (y + 0.5) / H * GH - 0.5)), y0 = sy | 0, ty = sy - y0, r0 = y0 * G3, r1 = r0 + G3, ty0 = 1 - ty;
    for (let g = 0; g < G3; g++) { rowD[g] = gridD[r0 + g] * ty0 + gridD[r1 + g] * ty; rowS[g] = gridS[r0 + g] * ty0 + gridS[r1 + g] * ty; }
    let o = y * W * CH;
    for (let x = 0; x < W; x++, o += CH) {
      const x0 = xs[x], tx = xt[x], tx0 = 1 - tx;
      const a = CH === 4 ? rgb[o + 3] / 255 : 1, lum = (rgb[o] + rgb[o + 1] + rgb[o + 2]) / 255 * a;
      /* shine only lands on pixels that have some brightness of their own (never on black edges or matte fringes) */
      let gate = (lum - 0.12) / 0.88; gate = gate < 0 ? 0 : gate > 1 ? 1 : gate; gate = gate * gate * (3 - 2 * gate);
      let vr = rgb[o] / 255 * (rowD[x0] * tx0 + rowD[x0 + 3] * tx) + (rowS[x0] * tx0 + rowS[x0 + 3] * tx) * gate;
      let vg = rgb[o + 1] / 255 * (rowD[x0 + 1] * tx0 + rowD[x0 + 4] * tx) + (rowS[x0 + 1] * tx0 + rowS[x0 + 4] * tx) * gate;
      let vb = rgb[o + 2] / 255 * (rowD[x0 + 2] * tx0 + rowD[x0 + 5] * tx) + (rowS[x0 + 2] * tx0 + rowS[x0 + 5] * tx) * gate;
      /* soft shoulder above 75% that keeps the hue: bright areas roll off instead of clipping to yellow/green */
      const m = vr > vg ? (vr > vb ? vr : vb) : (vg > vb ? vg : vb);
      if (m > 0.75) { const k = (0.75 + 0.25 * (1 - Math.exp(-(m - 0.75) / 0.25))) / m; vr *= k; vg *= k; vb *= k; }
      if (vr < 0) vr = 0; else if (vr > 1) vr = 1; if (vg < 0) vg = 0; else if (vg > 1) vg = 1; if (vb < 0) vb = 0; else if (vb > 1) vb = 1;
      if (colorOn) {
        vr = lutR[(vr * 255) | 0]; vg = lutG[(vg * 255) | 0]; vb = lutB[(vb * 255) | 0];
        if (satK !== 1) { const l = 0.299 * vr + 0.587 * vg + 0.114 * vb; vr = l + (vr - l) * satK; vg = l + (vg - l) * satK; vb = l + (vb - l) * satK; if (vr < 0) vr = 0; else if (vr > 1) vr = 1; if (vg < 0) vg = 0; else if (vg > 1) vg = 1; if (vb < 0) vb = 0; else if (vb > 1) vb = 1; }
      }
      if (CH === 4) {
        let A = rgb[o + 3];
        if (shO > 0) {
          /* black shadow under the transparent parts: alpha grows, colour is the subject's share of it */
          const mx = Math.min(shW - 1.001, x * shX), my = Math.min(shH - 1.001, y * shY), mx0 = mx | 0, my0 = my | 0, ftx = mx - mx0, fty = my - my0;
          const sm = (shMask[my0 * shW + mx0] * (1 - ftx) + shMask[my0 * shW + mx0 + 1] * ftx) * (1 - fty) + (shMask[(my0 + 1) * shW + mx0] * (1 - ftx) + shMask[(my0 + 1) * shW + mx0 + 1] * ftx) * fty;
          const sh = sm * shO * (1 - A / 255);
          if (sh > 0.002) { const A0 = A / 255, An = A0 + sh, f = A0 / An; vr *= f; vg *= f; vb *= f; A = An * 255 + 0.5; }
        }
        out[o + 3] = A;
      }
      out[o] = vr * 255 + 0.5; out[o + 1] = vg * 255 + 0.5; out[o + 2] = vb * 255 + 0.5;
    }
  }
}

if (isMainThread) (async () => {
  const info = probe(IN);
  const W = info.w, H = info.h, fps = info.fps || 30;
  CH = info.alpha ? 4 : 3;
  gridFor(W, H);
  valid = new Uint8Array(GN); gridD = new Float32Array(GN * 3); gridS = new Float32Array(GN * 3);
  const worker = new Worker(__filename, { workerData: { model: MODEL, cpu: !!args.cpu, engine: ENGINE, tokens: TOKENS }, argv: process.argv.slice(2) });
  const pendingRuns = new Map(); let runId = 0;
  await new Promise((res, rej) => { worker.once('message', (m) => m.ready ? res() : rej(new Error(m.fatal || 'model failed to load'))); worker.once('error', rej); });
  worker.on('message', (m) => { const p = pendingRuns.get(m.id); if (!p) { if (m.fatal) console.error('error: ' + m.fatal); return; } pendingRuns.delete(m.id); if (m.error) p.rej(new Error(m.error)); else { spare.push(m.input); p.res(m.res); } });
  worker.on('error', (e) => { for (const p of pendingRuns.values()) p.rej(e); pendingRuns.clear(); });
  const spare = [];   /* input buffers come back from the worker and are reused */
  const runModel = (input) => new Promise((res, rej) => { const id = ++runId; pendingRuns.set(id, { res, rej }); worker.postMessage({ id, input, GW, GH }, [input.buffer]); });
  say('backend ' + (args.cpu ? 'cpu' : 'dml') + ' engine ' + ENGINE + ' grid ' + GW + 'x' + GH);
  let depthN = new Float32Array(GN), depthB = new Float32Array(GN);
  let nx = new Float32Array(GN), ny = new Float32Array(GN), nz = new Float32Array(GN);
  const alloc = () => { spare.length = 0; depthN = new Float32Array(GN); depthB = new Float32Array(GN); nx = new Float32Array(GN); ny = new Float32Array(GN); nz = new Float32Array(GN); valid = new Uint8Array(GN); gridD = new Float32Array(GN * 3); gridS = new Float32Array(GN * 3); };
  /* one frame through the model: start() samples the frame and kicks off the GPU, finish() turns the result into
     nx/ny/nz (our convention: x right, y down, z towards the camera) and depthB (0..1, nearer = brighter) */
  const start = (rgb, w, h) => {
    let buf = spare.pop(); if (!buf || buf.length !== 3 * GN) buf = new Float32Array(3 * GN);
    toInput(rgb, w, h, buf);
    return runModel(buf);
  };
  const finish = (res) => {
    if (ENGINE === 'moge') {
      const n = res.normal, pts = res.points, mask = res.mask || null;
      for (let i = 0; i < GN; i++) {
        let x = n[i * 3], y = n[i * 3 + 1], z = -n[i * 3 + 2];
        const l = Math.sqrt(x * x + y * y + z * z);
        /* the model's normals are smooth even in the sky, so they are used everywhere (its mask is patchy there and would streak) */
        if (!(l > 1e-6) || !valid[i]) { x = 0; y = 0; z = 1; } else { x /= l; y /= l; z /= l; }
        nx[i] = x; ny[i] = y; nz[i] = z;
        const pz = pts[i * 3 + 2]; depthN[i] = isFinite(pz) ? -pz : NaN;
      }
      normaliseDepth(depthN, depthB);
      if (mask) calmNormals(mask, nx, ny, nz);
    } else {
      normaliseDepth(res.depth, depthN); blur3(depthN, depthB);
      normalsFromDepth(depthB, 0.5, nx, ny, nz);
    }
  };
  const analyse = async (rgb, w, h) => finish(await start(rgb, w, h));
  const png = (buf, fmt, w, h, file) => { const r = spawnSync(FFMPEG, ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', fmt, '-s', w + 'x' + h, '-i', 'pipe:0', '-frames:v', '1', '-c:v', 'png', '-compression_level', '1', file], { input: buf, maxBuffer: 1e9, windowsHide: true }); if (r.status !== 0) throw new Error('image failed: ' + (r.stderr || '').toString().slice(-200)); };

  if (args.match) {
    const pr = probe(args.match); CH = pr.alpha ? 4 : 3; gridFor(pr.w, pr.h); alloc();
    const dec = spawnSync(FFMPEG, ['-hide_banner', '-loglevel', 'error', '-i', args.match, '-an', '-sn', '-frames:v', '1', '-pix_fmt', PIXFMT(), '-f', 'rawvideo', 'pipe:1'], { maxBuffer: 1e9, windowsHide: true });
    const rgb = dec.stdout; if (!rgb || rgb.length < pr.w * pr.h * CH) throw new Error('Could not read the reference image');
    await analyse(rgb, pr.w, pr.h);
    const rig = matchLight(rgb, pr.w, pr.h, nx, ny, nz);
    fs.writeFileSync(need('matchout'), JSON.stringify(rig), 'utf8');
    say('match ' + JSON.stringify(rig.fit)); say('done');
    await worker.terminate();
    return;
  }

  if (args.preview) {
    const dec = spawnSync(FFMPEG, ['-hide_banner', '-loglevel', 'error', '-ss', String(AT), '-i', IN, '-an', '-sn', '-frames:v', '1', '-pix_fmt', PIXFMT(), '-f', 'rawvideo', 'pipe:1'], { maxBuffer: 1e9, windowsHide: true });
    const rgb = dec.stdout; if (!rgb || rgb.length < W * H * CH) throw new Error('Could not decode a frame at ' + AT + ' s');
    await analyse(rgb, W, H);
    fillInvalid(depthB); fillInvalid(nx); fillInvalid(ny); fillInvalid(nz);
    const d16 = Buffer.allocUnsafe(GN * 2); for (let i = 0; i < GN; i++) d16.writeUInt16LE(Math.round(Math.max(0, Math.min(1, depthB[i])) * 65535), i * 2);
    const nrm = Buffer.allocUnsafe(GN * 3); for (let i = 0; i < GN; i++) { nrm[i * 3] = (nx[i] * 0.5 + 0.5) * 255 + 0.5; nrm[i * 3 + 1] = (ny[i] * 0.5 + 0.5) * 255 + 0.5; nrm[i * 3 + 2] = (nz[i] * 0.5 + 0.5) * 255 + 0.5; }
    png(rgb, PIXFMT(), W, H, path.join(args.preview, 'original.png')); png(d16, 'gray16le', GW, GH, path.join(args.preview, 'depth.png')); png(nrm, 'rgb24', GW, GH, path.join(args.preview, 'normal.png'));
    try { const fit = matchLight(rgb, W, H, nx, ny, nz); fs.writeFileSync(path.join(args.preview, 'light.json'), JSON.stringify(fit.even), 'utf8'); } catch (e) { try { fs.unlinkSync(path.join(args.preview, 'light.json')); } catch (e2) {} }
    say('preview ' + W + 'x' + H + ' grid ' + GW + 'x' + GH); say('done');
    await worker.terminate();
    return;
  }

  const rig = JSON.parse(fs.readFileSync(need('lights'), 'utf8'));
  const relief = rig.relief == null ? 0.5 : +rig.relief;
  const SKIP = args.skipframes != null ? Math.max(0, Math.round(+args.skipframes)) : 0;
  const dur = DURATION > 0 ? DURATION : Math.max(0, info.duration - START);
  const total = args.frames ? Math.max(1, Math.round(+args.frames)) : Math.max(1, Math.round(dur * fps) - SKIP);
  const decArgs = ['-hide_banner', '-loglevel', 'error']; if (START > 0) decArgs.push('-ss', String(START)); decArgs.push('-i', IN, '-an', '-sn', '-frames:v', String(total + SKIP), '-pix_fmt', PIXFMT(), '-f', 'rawvideo', '-threads', '0', 'pipe:1');
  const dec = spawn(FFMPEG, decArgs, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let decErr = ''; dec.stderr.on('data', (d) => { decErr += d; });
  const next = frameReader(dec.stdout, W * H * CH);
  /* clips with transparency come out as ProRes 4444 with the alpha kept, others as ProRes 422 HQ */
  const enc = spawn(FFMPEG, ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', PIXFMT(), '-s', W + 'x' + H, '-r', String(fps), '-i', 'pipe:0', '-c:v', 'prores_aw', '-profile:v', CH === 4 ? '4' : '3', '-pix_fmt', CH === 4 ? 'yuva444p10le' : 'yuv422p10le', '-vendor', 'apl0', '-threads', '0', OUT], { windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] });
  let encErr = ''; enc.stderr.on('data', (d) => { encErr += d; });
  const encDone = new Promise((res, rej) => { enc.on('close', (c) => c === 0 ? res() : rej(new Error('encoder failed: ' + encErr.slice(-300)))); enc.on('error', rej); });
  const write = (buf) => new Promise((res, rej) => { const ok = enc.stdin.write(buf, (e) => e && rej(e)); if (ok) res(); else enc.stdin.once('drain', res); });
  const out = Buffer.allocUnsafe(W * H * CH);
  /* temporally smoothed normals: most of the last frame, a bit of this one, renormalised */
  const sx = new Float32Array(GN), sy = new Float32Array(GN), sz = new Float32Array(GN), ux = new Float32Array(GN), uy = new Float32Array(GN), uz = new Float32Array(GN);
  let haveSmooth = false;
  const smooth = () => {
    if (!haveSmooth) { sx.set(nx); sy.set(ny); sz.set(nz); haveSmooth = true; return; }
    for (let i = 0; i < GN; i++) { const x = sx[i] + (nx[i] - sx[i]) * 0.4, y = sy[i] + (ny[i] - sy[i]) * 0.4, z = sz[i] + (nz[i] - sz[i]) * 0.4; const inv = 1 / (Math.sqrt(x * x + y * y + z * z) || 1); sx[i] = x * inv; sy[i] = y * inv; sz[i] = z * inv; }
  };
  let n = 0, skipped = 0, lastSay = 0, idx = 0;
  const prof = { wait: 0, model: 0, compose: 0, write: 0 }; const now = () => Number(process.hrtime.bigint()) / 1e6;
  const wantEven = +rig.even > 0;
  /* the model for frame k+1 runs on the GPU while frame k is composed on the CPU */
  let cur = await next(), curP = cur ? start(cur, W, H) : null;
  while (cur) {
    let t = now(); const nxt = await next(); prof.wait += now() - t;
    idx++; const nxtP = nxt && (idx % EVERY === 0) ? start(nxt, W, H) : null;
    t = now(); if (curP) { finish(await curP); if (wantEven && !evenSh) evenSetup(matchLight(cur, W, H, nx, ny, nz).even); smooth(); } prof.model += now() - t;
    if (skipped < SKIP) { skipped++; cur = nxt; curP = nxtP; continue; }
    curTime = START + (skipped + n) / fps;
    t = now(); ux.set(sx); uy.set(sy); uz.set(sz);
    if (ENGINE === 'moge') applyRelief(ux, uy, uz, relief); else if (relief !== 0.5) normalsFromDepth(depthB, relief, ux, uy, uz);
    relightFrame(cur, W, H, ux, uy, uz, rig, out); prof.compose += now() - t;
    t = now(); await write(Buffer.from(out)); prof.write += now() - t;
    n++;
    if (Date.now() - lastSay > 400 || n === total) { lastSay = Date.now(); say('progress ' + Math.min(1, n / total).toFixed(3)); }
    if (n >= total) { if (nxtP) { try { await nxtP; } catch (e) {} } break; }
    cur = nxt; curP = nxtP;
  }
  enc.stdin.end(); await encDone;
  if (!n) throw new Error('No frames decoded' + (decErr ? ': ' + decErr.slice(-200) : ''));
  if (args.prof) say('prof per frame ms: wait ' + (prof.wait / n).toFixed(1) + ' model ' + (prof.model / n).toFixed(1) + ' compose ' + (prof.compose / n).toFixed(1) + ' write ' + (prof.write / n).toFixed(1));
  say('frames ' + n); say('done');
  await worker.terminate();
})().catch((e) => { console.error('error: ' + (e.message || e)); process.exit(1); });
