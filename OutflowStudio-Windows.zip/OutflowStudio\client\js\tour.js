/*  Tour: the walk through the panel that runs the first time it is opened, and any time the Tutorial button
    is pressed. One card per tool, in the order the home screen lists them.

    The moving pictures are the ones already on the website, fetched from outflowstudio.com rather than
    bundled: they are megabytes, they change when a tool changes, and the panel is downloaded a lot more
    often than the tour is watched. Nothing here waits for them - a card shows its icon until its picture
    arrives, and on a machine with no connection it simply keeps the icon.                               */
const Tour = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const SITE = 'https://outflowstudio.com';

  /*  Which picture belongs to which tool. `vid` is one of the recorded panels, `img` the still used in the
      website's own tools menu. A tool with neither shows its icon, which is fine -
      do not invent a picture for it here, add one to the site and put the name in.                      */
  const MEDIA = {
    carousel:    { img: '3d-carousel.png', vid: 'carousel-panel' },
    transitions: { img: 'transitions.png', vid: 'transitions-panel' },
    relight:     { img: 'relight.png', vid: 'relight' },
    curves:      { img: 'motion-curves.png' },
    assist:      { img: 'auto-edit.png' },
    audioai:     { img: 'remove-music.png' },
    social:      { img: 'download.png' },
    tools:       { img: 'timeline-tools.png' },
    quickfx:     { img: 'quick-fx.png' },
    stock:       { img: 'stock.jpg' },
    montage:     { img: 'zoom-montage.jpg' },
    mask:        { vid: 'mask-demo' },
  };
  const SKIP = { settings: 1 };
  /*  Tools that live on the toolbar rather than the home screen, so the hub does not list them. Mask is
      one: its card sits after Download media. "Open it" points at the toolbar button.               */
  const EXTRA = [{ after: 'social', tool: { id: 'mask', name: 'Mask', icon: 'maskobject', desc: 'Press Mask on the toolbar, draw a mask in Premiere, and it lands on Opacity by itself: the clip is cut out. Object, ellipse, rectangle or pen; on the clip, or on a copy above it so the original stays whole. Three free masks, then Pro.', go: () => { try { Hub.show('home'); } catch (e) {} const b = document.querySelector('#sidebar [data-tool="mask"]'); if (b) { b.classList.add('armed'); setTimeout(() => b.classList.remove('armed'), 2500); } toast('Mask lives on the toolbar: select a clip and press the glowing button.', 'ok'); } } }];
  function toolList() {
    let tools = []; try { tools = (Hub.TOOLS || []).filter((t) => !SKIP[t.id]); } catch (e) { tools = []; }
    for (const x of EXTRA) { const i = tools.findIndex((t) => t.id === x.after); tools.splice(i >= 0 ? i + 1 : tools.length, 0, x.tool); }
    return tools;
  }

  const keys = () => { try { return Hub.keys(); } catch (e) { return {}; } };
  const seen = () => { try { return !!keys().tourSeen; } catch (e) { return true; } };
  const markSeen = () => { try { keys().tourSeen = true; Hub.saveKeys(); } catch (e) {} };

  let box = null, step = 0, cards = [];

  /*  The tool they said they came for. Asked on the first card so the tour can start with it: somebody who
      downloaded this for one thing should see that thing first, not a menu of nine others.              */
  let reason = null;
  /*  The list can be opened at any point, so it is a state the tour can be in rather than only the first
      card. `asking` says it is on screen now; `card.kind === 'ask'` is the first run reaching it normally. */
  let asking = false;
  function build() {
    const tools = toolList();
    /* the tool they came for goes first, then the rest in their usual order */
    const ordered = reason ? tools.filter((t) => t.id === reason).concat(tools.filter((t) => t.id !== reason)) : tools;
    /* the tour opens on the All tools list now, so the first card is always the welcome */
    cards = [{ kind: 'hello' }].concat(ordered.map((t, i) => ({ kind: 'tool', tool: t, theirs: reason && i === 0 }))).concat([{ kind: 'done' }]);
  }

  /*  A card's picture: the recorded panel if the tool has one, else the still, else nothing and the icon
      stays. Loaded per card so opening the tour does not pull down every video at once.                 */
  function media(card, into) {
    if (card.kind !== 'tool') return;
    const m = MEDIA[card.tool.id];
    if (!m) return;
    if (m.vid) {
      const v = h('video');
      v.muted = true; v.loop = true; v.autoplay = true; v.playsInline = true; v.preload = 'none';
      v.poster = SITE + '/img/' + m.vid + '-poster.jpg';
      v.innerHTML = '<source src="' + SITE + '/img/' + m.vid + '.webm" type="video/webm"><source src="' + SITE + '/img/' + m.vid + '.mp4" type="video/mp4">';
      v.addEventListener('error', () => v.remove(), true);
      into.appendChild(v);
      try { v.play().catch(() => {}); } catch (e) {}
      return;
    }
    const im = h('img');
    /* no lazy loading: the element is still detached when src is set, so the browser never decides it is
       on screen and the picture never arrives. Only the card being shown loads anything anyway. */
    im.alt = '';
    im.addEventListener('error', () => im.remove());
    im.src = SITE + '/img/menu/' + m.img;   /* the name carries its own extension */
    into.appendChild(im);
  }

  function render() {
    if (!box) return;
    const card = cards[step];
    if (!card) return close();
    const body = box.querySelector('.tour-body');
    body.innerHTML = '';

    if (asking || card.kind === 'ask') {
      body.appendChild(h('div', 'tour-txt', asking
        ? '<h2>All the tools</h2><p>Pick one to jump to it.</p>'
        : '<h2>What did you come here for?</h2><p>Pick the one that made you download this and the tour starts there. You can still see the rest afterwards.</p>'));
      const grid = h('div', 'tour-pick');
      const tools = toolList();
      const here = cards[step] && cards[step].tool ? cards[step].tool.id : '';
      for (const t of tools) {
        const b2 = h('button', 'tour-pick-b' + (t.id === (asking ? here : reason) ? ' on' : ''), '<span>' + icon(t.icon, 22) + '</span><b>' + t.name + '</b>');
        b2.addEventListener('click', () => { choose(t.id); });
        grid.appendChild(b2);
      }
      if (!asking) {
        const skip = h('button', 'ghost tour-pick-skip', 'Just show me everything');
        skip.addEventListener('click', () => { choose(''); });
        grid.appendChild(skip);
      }
      body.appendChild(grid);
      const foot0 = box.querySelector('.tour-foot');
      foot0.innerHTML = '';
      /* opened mid-tour: a way back to where they were */
      if (asking) {
        const back0 = h('button', 'ghost', 'Back');
        back0.addEventListener('click', () => { asking = false; render(); });
        foot0.appendChild(h('span', 'spacer'));
        foot0.appendChild(back0);
      }
      return;
    }
    const vis = h('div', 'tour-vis');
    if (card.kind === 'tool') vis.innerHTML = '<span class="tour-ico">' + icon(card.tool.icon, 38) + '</span>';
    else vis.innerHTML = '<span class="tour-ico"><img class="tour-logo" src="img/logo.png" alt=""></span>';
    media(card, vis);
    body.appendChild(vis);

    const txt = h('div', 'tour-txt');
    if (card.kind === 'hello') {
      txt.innerHTML = '<h2>Welcome to Outflow Studio</h2><p>A quick look at what is in here. ' +
        (cards.length - 2) + ' tools, about a minute. You can stop at any point and start it again from the home screen.</p>';
    } else if (card.kind === 'done') {
      txt.innerHTML = '<h2>That is the tour</h2><p>Everything lives on the home screen. The Tutorial button up there brings this back whenever you want it.</p>';
    } else {
      const locked = (() => { try { return typeof License !== 'undefined' && !License.can(card.tool.id); } catch (e) { return false; } })();
      txt.innerHTML = '<h2>' + card.tool.name + (locked ? ' <em class="tour-pro">Pro</em>' : '') + '</h2><p>' + card.tool.desc + '</p>';
    }
    body.appendChild(txt);

    const foot = box.querySelector('.tour-foot');
    foot.innerHTML = '';
    const dots = h('div', 'tour-dots');
    for (let i = 0; i < cards.length; i++) {
      const d = h('i', i === step ? 'on' : '');
      d.addEventListener('click', () => { step = i; render(); });
      dots.appendChild(d);
    }
    const back = h('button', 'ghost', 'Back');
    back.disabled = step === 0;
    back.addEventListener('click', () => { step = Math.max(0, step - 1); render(); });
    const next = h('button', 'primary', step === cards.length - 1 ? 'Finish' : 'Next');
    next.addEventListener('click', () => { if (step >= cards.length - 1) close(); else { step++; render(); } });
    const open = card.kind === 'tool' ? h('button', 'ghost', 'Open it') : null;
    if (open) open.addEventListener('click', () => { const t = card.tool; close(); try { t.go(); } catch (e) {} });

    foot.appendChild(dots);
    foot.appendChild(h('span', 'spacer'));
    /*  On the card for the tool they came for: the two things they might actually want, said plainly,
        instead of a Next button that walks them through eight tools they did not ask about.           */
    if (card.theirs) {
      const go = h('button', 'primary', 'Take me to ' + card.tool.name);
      go.addEventListener('click', () => { const t = card.tool; close(); try { t.go(); } catch (e) {} });
      const rest = h('button', 'ghost', 'Show me the rest');
      rest.addEventListener('click', () => { step++; render(); });
      foot.appendChild(rest);
      foot.appendChild(go);
      return;
    }
    if (open) foot.appendChild(open);
    foot.appendChild(back);
    foot.appendChild(next);
  }

  /*  Their answer: remembered, reported once, and it reorders the tour. An empty answer means "show me
      everything", which is the old behaviour.                                                          */
  function choose(id) {
    /*  Mid-tour this is just navigation: jump to that tool's card and leave the running order alone, so
        the dots do not shuffle under them. On the first card it is the answer, and it shapes the tour.  */
    if (asking) {
      asking = false;
      /* the first pick ever is also the answer to "what did you come for": remembered and reported once */
      try { const k = keys(); if (!k.tourReason && id) { k.tourReason = id; Hub.saveKeys(); try { Usage.setReason(id); } catch (e) {} } } catch (e) {}
      const i = cards.findIndex((c) => c.tool && c.tool.id === id);
      if (i >= 0) step = i;
      render();
      return;
    }
    reason = id || null;
    try { const k = keys(); k.tourReason = id || 'all'; Hub.saveKeys(); } catch (e) {}
    /* reported once ever, by Usage itself - picking again later does not rewrite why they came */
    try { if (id) Usage.setReason(id); } catch (e) {}
    build();
    step = reason ? 1 : 0;   /* straight to their tool, or to the welcome card */
    render();
  }

  function onKey(e) {
    if (!box) return;
    if (e.key === 'Escape') { e.preventDefault(); if (asking) { asking = false; render(); } else close(); }
    else if (asking) return;
    else if (e.key === 'ArrowRight') { e.preventDefault(); if (step < cards.length - 1) { step++; render(); } }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); if (step > 0) { step--; render(); } }
  }

  function close() {
    markSeen();
    document.removeEventListener('keydown', onKey);
    if (box) { box.remove(); box = null; }
  }

  function start(from) {
    if (box) return;
    /* asked once ever: pressing Tutorial again goes straight into the tour they already shaped */
    try { const r = keys().tourReason; reason = r && r !== 'all' ? r : null; } catch (e) { reason = null; }
    build();
    if (cards.length <= 2) return;   /* nothing to show */
    /* the list of every tool first, always: pick one to jump to it, or Back for the welcome and the walk-through */
    step = 0; asking = true;
    box = h('div', 'tour');
    box.innerHTML =
      '<div class="tour-card">' +
        '<div class="tour-head"><b>Tutorial</b><span class="spacer"></span><button class="ghost tour-all">All tools</button><button class="ghost tour-skip">Skip</button></div>' +
        '<div class="tour-body"></div>' +
        '<div class="tour-foot"></div>' +
      '</div>';
    box.querySelector('.tour-skip').addEventListener('click', close);
    box.querySelector('.tour-all').addEventListener('click', () => { asking = !asking; render(); });
    box.addEventListener('mousedown', (e) => { if (e.target === box) close(); });
    document.body.appendChild(box);
    document.addEventListener('keydown', onKey);
    render();
    try { Usage.tick('tour:' + (from || 'button')); } catch (e) {}
  }

  /* the first time the panel is opened, once the login screen is out of the way */
  function maybeFirstRun() {
    if (seen()) return;
    setTimeout(() => { if (!seen() && Hub.current() === 'home') start('first-run'); }, 700);
  }

  return { start, close, maybeFirstRun, seen };
})();
