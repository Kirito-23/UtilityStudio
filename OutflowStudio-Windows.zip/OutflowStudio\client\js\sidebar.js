/* Fixed one-click sidebar: visible on every screen, configurable (which tools,
   side, defaults). Actions run immediately with saved defaults. */
const Sidebar = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const DEF = {
    enabled: true, side: 'right', size: 'normal',
    /* the default set: seven timeline tools, and five of the panel's own tools pinned under the line */
    show: { paste: true, social: false, adjlayer: true, unnest: true, mask: true, fit: true, fill: true, gaps: true, disabled: false, dissolve: false, margins: true, progress: false, watermark: false, chapters: false, stills: false, countdown: false, lowerthird: false, tts: false },
    panel: { carousel: true, stock: true, curves: true, transitions: true, social: true },
    maskKeys: { object: 'shift+q', rect: '', ellipse: '', pen: '', ecPanel: 'shift+5' },   /* the shortcuts the person gave Premiere's mask tools (Shift+Q is what the setup card asks for), and Premiere's own for the Effect Controls panel, used by Auto track */
    maskType: 'object', maskDup: false, maskTrack: false,
    frames: 15, transition: 'Cross Dissolve', barColor: '#ff3b6b', barHeight: 1.2, barPos: 'bottom', watermarkFile: '', watermarkSize: 18, watermarkOpacity: 70, watermarkPos: 'br', countdownFrom: 5
  };
  let cfg = JSON.parse(JSON.stringify(DEF));
  /* a saved sidebar is kept as it is; a saved one without a pinned list (older versions) gets none, not the default */
  let hadSaved = false;
  try { const s = JSON.parse(localStorage.getItem('os.sidebar') || '{}'); hadSaved = !!s.show; cfg = Object.assign(cfg, s); cfg.show = Object.assign({}, DEF.show, s.show || {}); cfg.panel = Object.assign({}, hadSaved ? {} : DEF.panel, s.panel || {}); cfg.maskKeys = Object.assign({}, DEF.maskKeys, s.maskKeys || {}); } catch (e) {}   /* keys added later (Effect Controls, Maximize Frame) get their defaults on old saves */
  const save = () => { try { localStorage.setItem('os.sidebar', JSON.stringify(cfg)); } catch (e) {} };

  /* opts: quick choices shown in the hover popover; each runs the action with that argument */
  const TOOLS = [
    { id: 'paste', icon: 'paste', name: 'Paste from clipboard', desc: 'Image, files or a link from the clipboard → playhead.' },
    { id: 'social', icon: 'download', name: 'Download link', desc: 'Open the media downloader (uses the clipboard link if there is one).' },
    { id: 'adjlayer', icon: 'lowerthird', name: 'Adjustment layer', desc: 'Adjustment layer over the selected clips (5 s at the playhead when nothing is selected), with the Transform effect on it.' },
    { id: 'unnest', icon: 'unnest', name: 'Un-nest', desc: 'Expand selected nested clips.' },
    { id: 'mask', icon: 'maskobject', name: 'Mask', desc: 'Draw a mask in Premiere; it lands on Opacity by itself.', opts: [['Object', 'object'], ['Ellipse', 'ellipse'], ['Rectangle', 'rect'], ['Pen', 'pen']], optIcons: { object: 'maskobject', ellipse: 'maskellipse', rect: 'maskrect', pen: 'maskpen' }, toggles: [
      { icon: 'newlayer', label: 'On a new layer', hint: 'a copy above, the original stays whole', get: () => !!cfg.maskDup, set: (v) => { cfg.maskDup = v; save(); } },
      { icon: 'masktrack', label: 'Auto track', hint: 'then track the mask through the clip', get: () => !!cfg.maskTrack, set: (v) => { cfg.maskTrack = v; save(); let seen = false; try { seen = !!localStorage.getItem(TRACK_FLAG); } catch (e) {} if (v && !seen) maskTrackIntro(); } }] },
    { id: 'fit', icon: 'fit', name: 'Fit to frame', desc: 'Selected clips fit inside the frame.' },
    { id: 'fill', icon: 'fill', name: 'Fill frame', desc: 'Selected clips fill the frame (crop).' },
    { id: 'gaps', icon: 'gaps', name: 'Close all gaps', desc: 'Remove empty space on all tracks.' },
    { id: 'disabled', icon: 'disabled', name: 'Delete disabled clips', desc: 'Ripple-delete greyed clips.' },
    { id: 'dissolve', icon: 'transitions', name: 'Dissolve at cuts', desc: 'Transition between selected clips (or all clips on V1).', opts: [['4 f', 4], ['8 f', 8], ['15 f', 15], ['30 f', 30]] },
    { id: 'margins', icon: 'margins', name: 'Safe margins', desc: 'Guides on a top track.' },
    { id: 'progress', icon: 'progress', name: 'Progress bar', desc: 'Bar that fills over a range.', opts: [['Whole sequence', 'whole'], ['In / Out', 'inout'], ['Selected clips', 'selected']] },
    { id: 'watermark', icon: 'watermark', name: 'Watermark', desc: 'Your saved logo on a top track (first click picks the file).', opts: [['Top left', 'tl'], ['Top right', 'tr'], ['Bottom left', 'bl'], ['Bottom right', 'br']] },
    { id: 'chapters', icon: 'chapters', name: 'Chapters → clipboard', desc: 'YouTube chapter list from markers.' },
    { id: 'stills', icon: 'stills', name: 'Stills at markers', desc: 'PNG per marker next to the project.' },
    { id: 'countdown', icon: 'countdown', name: 'Countdown', desc: 'Caption countdown at the playhead.', opts: [['3', 3], ['5', 5], ['10', 10]] },
    { id: 'lowerthird', icon: 'lowerthird', name: 'Lower third', desc: 'Asks for "Name | Title", adds a caption.' },
    { id: 'tts', icon: 'tts', name: 'Voice-over', desc: 'Asks for text, speaks it onto an audio track.' }
  ];

  /* Shortcuts to the panel's own screens. Read from the hub, so anything hidden there (an archived tool) is not
     offered here either. Settings and Timeline tools are left out: they already sit at the foot of the sidebar. */
  const SKIP = { settings: 1, tools: 1, quickfx: 1 };
  const panelTools = () => {
    try { return (Hub.TOOLS || []).filter((t) => !SKIP[t.id]); } catch (e) { return []; }
  };

  const need = () => { if (!CS.inCEP) throw new Error('This works inside Premiere Pro only.'); };
  let maskArmed = false, lastOpacityAdd = 0, maskWatch = null;
  /*  The one-time setup card: the screen recording of Premiere's shortcut dialog, and the two lines that
      matter. Shown on the first press; the toolbox menu can bring it back.                            */
  const INTRO_FLAG = 'os.mask.intro';
  /*  Two steps: the shortcut setup (Premiere's dialog, recorded), then how the button works (recorded).
      "Later" closes without remembering, so it comes back on the next press.                          */
  function maskIntro(then) {
    const site = (typeof CFG === 'function' && CFG().site) || 'https://outflowstudio.com';
    let m = $('#mask-intro');
    if (!m) { m = h('div', 'update'); m.id = 'mask-intro'; document.body.appendChild(m); }
    const STEPS = [
      { eyebrow: 'Mask tool · step 1 of 2', title: 'One-time setup', vid: 'mask-setup',
        html: '<p class="small">The Mask button presses a Premiere shortcut to open the mask tool. Premiere ships the tool without one, so give it one:</p>' +
          '<ul class="ulist"><li>In Premiere: <b>Edit › Keyboard Shortcuts</b>, search <b>Mask Tool</b>, give <b>Object Mask Tool</b> the shortcut <b>Shift+Q</b>, click OK.</li>' +
          '<li>Is Shift+Q already taken? Pick another key there, then record the same key in the panel: toolbox button at the foot of the toolbar › <b>Mask tool keys</b>.</li></ul>',
        go: 'Done, next' },
      { eyebrow: 'Mask tool · step 2 of 2', title: 'How it works', vid: 'mask-demo',
        html: '<ul class="ulist"><li>Select a clip and press <b>Mask</b>. Premiere switches to the mask tool.</li>' +
          '<li>Draw the mask. It lands on Opacity by itself: the clip is cut out.</li>' +
          '<li>Hold the button for Object, Ellipse, Rectangle or Pen, and for <b>On a new layer</b>: a copy above, the original stays whole.</li></ul>',
        go: 'Let me mask' }
    ];
    let at = 0;
    const show = () => {
      const s = STEPS[at];
      m.innerHTML = '<div class="ubox"><div class="ueyebrow">' + s.eyebrow + '</div><h2>' + s.title + '</h2>' +
        '<video class="uvideo" autoplay muted loop playsinline poster="' + site + '/img/' + s.vid + '-poster.jpg"><source src="' + site + '/img/' + s.vid + '.webm" type="video/webm"><source src="' + site + '/img/' + s.vid + '.mp4" type="video/mp4"></video>' +
        s.html + '<div class="ubtns"><button class="primary" id="mask-intro-go">' + s.go + '</button>' + (at > 0 ? '<button class="ghost" id="mask-intro-back">Back</button>' : '') + '<button class="ghost" id="mask-intro-later">Later</button></div></div>';
      $('#mask-intro-later').addEventListener('click', () => { m.classList.remove('show'); try { m.querySelector('video').pause(); } catch (e) {} });
      const bk = $('#mask-intro-back'); if (bk) bk.addEventListener('click', () => { at--; show(); });
      $('#mask-intro-go').addEventListener('click', () => {
        if (at < STEPS.length - 1) { at++; show(); return; }
        try { localStorage.setItem(INTRO_FLAG, '1'); } catch (e) {}
        m.classList.remove('show'); try { m.querySelector('video').pause(); } catch (e) {}
        if (then) then();
      });
      try { m.querySelector('video').play(); } catch (e) {}
    };
    show();
    m.classList.add('show');
  }
  /*  A capture field, like Premiere's own dialog: click it, press the real keys, it is recorded. Backspace
      clears. Alt combinations are refused on Windows: a sent Alt+letter also opens the menu with that
      letter (Alt+M opened Markers). Used by the toolbox and by the Auto track card.                     */
  const prettyKey = (spec) => spec ? spec.split('+').map((p) => p.length === 1 ? p.toUpperCase() : p.charAt(0).toUpperCase() + p.slice(1)).join('+') : '';
  function keycap(k) {
    cfg.maskKeys = cfg.maskKeys || {};
    const i = h('input'); i.type = 'text'; i.className = 'keycap'; i.readOnly = true; i.placeholder = 'click, then press the keys'; i.value = prettyKey(cfg.maskKeys[k] || '');
    i.addEventListener('keydown', (e) => {
      e.preventDefault(); e.stopPropagation();
      if (e.key === 'Escape') { i.blur(); return; }
      if (e.key === 'Backspace' || e.key === 'Delete') { cfg.maskKeys[k] = ''; i.value = ''; save(); return; }
      if (['Shift', 'Control', 'Alt', 'Meta'].includes(e.key)) return;
      const mods = [];
      if (e.ctrlKey) mods.push('ctrl'); if (e.altKey) mods.push('alt'); if (e.shiftKey) mods.push('shift'); if (e.metaKey) mods.push('cmd');
      const key = e.key.toLowerCase();
      if (!/^[a-z0-9`]$/.test(key)) { toast('Use a letter or a digit, with Shift or Ctrl if you like.', ''); return; }
      if (e.altKey && !CS.mac) { toast('Alt combinations open the Premiere menus on Windows. Use Shift or Ctrl+Shift instead.', ''); return; }
      cfg.maskKeys[k] = mods.concat(key).join('+'); i.value = prettyKey(cfg.maskKeys[k]); save(); i.blur();
    });
    return i;
  }
  /*  The Auto track card, once: what has to be on screen for the click to find its button.          */
  const TRACK_FLAG = 'os.mask.track.intro';
  function maskTrackIntro(then) {
    let m = $('#mask-track-intro');
    if (!m) { m = h('div', 'update'); m.id = 'mask-track-intro'; document.body.appendChild(m); }
    m.innerHTML = '<div class="ubox"><div class="ueyebrow">Mask tool · Auto track</div><h2>Track the mask by itself</h2>' +
      '<p class="small">With Auto track on, the moment the mask lands on Opacity the panel presses Premiere\'s own <b>Track selected mask forward and backward</b> button for you, so the mask follows the subject through the whole clip.</p>' +
      '<p class="small">Premiere gives that button no shortcut, so the panel brings up Effect Controls itself (Premiere\'s Shift+5) and finds the button on the screen. You do nothing; only:</p>' +
      '<ul class="ulist"><li>Leave the mouse alone for a second after drawing; it is put back where it was.</li>' +
      '<li>Changed Premiere\'s panel shortcuts? Record yours under the toolbox button › Mask tool keys.</li>' +
      (CS.mac ? '<li>Mac: not yet. The switch does nothing there for now.</li>' : '') + '</ul>' +
      '<div class="ubtns"><button class="primary" id="mask-track-go">Got it</button></div></div>';
    $('#mask-track-go').addEventListener('click', () => { try { localStorage.setItem(TRACK_FLAG, '1'); } catch (e) {} m.classList.remove('show'); if (then) then(); });
    m.classList.add('show');
  }
  /*  Auto track: client/bin/masktrack.ps1 takes a screenshot, reads the word "Tracker" off the Effect
      Controls panel, finds the five buttons on that row and clicks the middle one. The result is one JSON
      line. Tracking runs inside Premiere after that, one undo step when it is done; the host is busy while
      it tracks, so the poll returns once it has finished.                                             */
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let trackCancel = false;
  function trackerClick() {
    return new Promise((res, rej) => {
      const cp = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('child_process');
      /* Windows: PowerShell with Windows' text recognition. The Mac counterpart (Apple's Vision, JXA) is parked in docs/archive/masktrack-mac.js, untested. */
      const script = CS.path.join(CS.extensionDir(), 'client', 'bin', 'masktrack.ps1');
      cp.execFile('powershell', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-Click'], { windowsHide: true, timeout: 60000, maxBuffer: 4 * 1024 * 1024 }, (err, out, se) => {
        const line = String(out || '').trim().split('\n').pop();
        try { res(JSON.parse(line)); } catch (e) { rej(new Error((se || err && err.message || out || 'no answer from the finder').toString().slice(0, 200))); }
      });
    });
  }
  async function maskTrack() {
    if (CS.mac) { toast('Auto track is Windows-only for now.', ''); return; }
    const btn = document.querySelector('#sidebar [data-tool="mask"]');
    if (btn) btn.classList.add('busy');
    const t0 = Date.now(), k = cfg.maskKeys || {};
    try {
      const base = (await call('TL_undoIndex')).index;
      toast('Finding the tracking button in Effect Controls…', '');
      /* Effect Controls to the front (opened if it was closed), then the search */
      if (k.ecPanel) { CS.sendKey(k.ecPanel); await sleep(1000); }
      let r = await trackerClick();
      /* a panel that was closed takes a moment to open: one more look */
      if (!(r && r.ok)) { await sleep(1500); r = await trackerClick(); }
      try { Log.info('mask', 'tracker click', { r, ms: Date.now() - t0 }); } catch (e) {}
      if (!r || !r.ok) { maskBusy(null); toast((r && r.error ? r.error : 'The tracker button was not found.') + ' Make the Effect Controls panel taller so the Tracker row is in view, then press the ◀▶ button there.', 'err'); return; }
      toast('Tracking the mask through the clip…', '');
      /*  Premiere moves the playhead through the clip while it tracks. Started: the playhead (or the undo
          stack) moved within a few seconds of the click. Finished: the undo stack moved, or the playhead has
          stood still for a while after moving. Polls come back at once during tracking, so no blocking.  */
      let at0 = null; try { at0 = (await call('TL_maskTrackInfo')).at; } catch (e) {}
      let started = false, moved = false, still = 0, lastAt = at0; const t1 = Date.now();
      while (Date.now() - t1 < 30 * 60 * 1000 && !trackCancel) {
        await sleep(700);
        let u = null, info = null;
        try { u = await CS.call('TL_undoIndex'); } catch (e) {}
        try { info = await CS.call('TL_maskTrackInfo'); } catch (e) {}
        if (u && u.ok && u.index !== base) { moved = true; break; }
        const at = info && info.ok ? info.at : lastAt;
        if (at0 !== null && Math.abs(at - at0) > 0.001) started = true;
        if (started) { if (Math.abs(at - lastAt) < 0.001) still++; else still = 0; if (still >= 4) { moved = true; break; } }
        lastAt = at;
        if (!started && Date.now() - t1 > 8000) break;
      }
      try { Log.info('mask', 'tracked', { moved, started, ms: Date.now() - t1 }); } catch (e) {}
      if (trackCancel) return;
      if (!moved) maskBusy(null);
      toast(moved ? 'Mask tracked through the clip.' : 'The tracker button was clicked, but Premiere did not start tracking. Is the Tracker row in view in Effect Controls?', moved ? 'ok' : 'err');
    } finally { if (btn) btn.classList.remove('busy'); }
  }
  /*  While the Mask button is armed, Premiere's undo stack is watched: the first new step after arming is
      the mask being drawn (a selection or a tool switch adds none), and Opacity is added right after, so
      the person never has to come back to the button. Pen masks are not watched: every point could be a
      step of its own, and Opacity added mid-shape would take an unfinished mask.                     */
  /*  The progress card: the steps of this run, the current one spinning, done ones ticked. It covers the
      panel from the press until the end so nothing else gets pressed halfway; Cancel disarms.       */
  let busyBox = null;
  function maskSteps(which) {
    const steps = [];
    if (cfg.maskDup) steps.push(['copy', 'Copy the clip onto a new layer']);
    steps.push(['draw', 'Draw the mask in Premiere', which === 'pen' ? 'Click the points and close the shape, then press "Mask is drawn" here.' : 'Click the subject in the Program monitor. The panel notices by itself.']);
    steps.push(['opacity', 'Put the mask on Opacity']);
    if (cfg.maskTrack) steps.push(['track', 'Track the mask through the clip', 'Effect Controls opens by itself. Leave the mouse and keyboard alone until this is done.']);
    return steps;
  }
  function maskBusy(step, which) {
    if (!step) { if (busyBox) { busyBox.remove(); busyBox = null; } return; }
    const steps = maskSteps(which || cfg.maskType);
    const idx = step === 'done' ? steps.length : steps.findIndex((s) => s[0] === step);
    if (!busyBox) { busyBox = h('div', 'update show maskbusy'); document.body.appendChild(busyBox); }
    busyBox.innerHTML = '<div class="ubox"><div class="ueyebrow">Mask</div><h2>' + (step === 'done' ? 'Done' : 'Working…') + '</h2><ol class="msteps">' +
      steps.map((s, i) => '<li class="' + (i < idx ? 'done' : i === idx ? 'now' : '') + '"><i></i><span><b>' + s[1] + '</b>' + (s[2] && i === idx ? '<small>' + s[2] + '</small>' : '') + '</span></li>').join('') +
      '</ol>' + (step === 'done' ? '' : '<div class="ubtns">' + (step === 'draw' && which === 'pen' ? '<button class="primary" id="mask-busy-drawn">Mask is drawn</button>' : '') + '<button class="ghost" id="mask-busy-cancel">Cancel</button></div>') + '</div>';
    const c = $('#mask-busy-cancel'); if (c) c.addEventListener('click', maskCancel);
    const d = $('#mask-busy-drawn'); if (d) d.addEventListener('click', () => { maskApply(false).catch((e) => { maskBusy(null); toast(e.message || String(e), 'err'); }); });
  }
  function maskCancel() {
    if (maskWatch) { clearInterval(maskWatch); maskWatch = null; CS.quiet = Math.max(0, CS.quiet - 1); }
    maskArmed = false; trackCancel = true;
    const btn = document.querySelector('#sidebar [data-tool="mask"]'); if (btn) btn.classList.remove('armed');
    maskBusy(null); toast('Mask cancelled.', '');
  }
  async function maskApply(auto) {
    if (maskWatch) { clearInterval(maskWatch); maskWatch = null; CS.quiet = Math.max(0, CS.quiet - 1); }
    maskArmed = false;
    const btn = document.querySelector('#sidebar [data-tool="mask"]'); if (btn) btn.classList.remove('armed');
    maskBusy('opacity');
    let r;
    try { r = await call('TL_maskToOpacity'); lastOpacityAdd = Date.now(); } catch (e) { maskBusy(null); throw e; }
    try { if (typeof License !== 'undefined') License.noteExport('mask'); } catch (e) {}
    done((auto ? 'Mask drawn: ' : '') + r.done + ' clip(s), the mask is on Opacity.', r.warnings);
    if (cfg.maskTrack && r.done) { maskBusy('track'); await sleep(500); await maskTrack(); }
    if (busyBox) { maskBusy('done'); setTimeout(() => { if (busyBox && !maskArmed) maskBusy(null); }, 1400); }
  }
  function maskWatchStart(which) {
    if (which === 'pen') return;
    let base = null; const t0 = Date.now();
    CS.quiet++;
    maskWatch = setInterval(async () => {
      if (!maskArmed) { clearInterval(maskWatch); maskWatch = null; CS.quiet = Math.max(0, CS.quiet - 1); return; }
      if (Date.now() - t0 > 180000) { clearInterval(maskWatch); maskWatch = null; CS.quiet = Math.max(0, CS.quiet - 1); maskArmed = false; const b = document.querySelector('#sidebar [data-tool="mask"]'); if (b) b.classList.remove('armed'); maskBusy(null); toast('No mask was drawn in three minutes; the Mask button is off again.', ''); return; }
      let r; try { r = await CS.call('TL_undoIndex'); } catch (e) { return; }
      if (!r || !r.ok) return;
      if (base === null) { base = r.index; return; }
      if (r.index !== base) {
        clearInterval(maskWatch); maskWatch = null; CS.quiet = Math.max(0, CS.quiet - 1);
        setTimeout(() => { maskApply(true).catch((e) => toast(e.message || String(e), 'err')); }, 700);   /* let Premiere finish the mask first */
      }
    }, 300);
  }
  async function call(fn, ...args) { need(); const r = await CS.call(fn, ...args); if (!r.ok) throw new Error(r.error); return r; }
  const done = (msg, warnings) => toast(msg + (warnings && warnings.length ? ' · ' + warnings[0] : ''), warnings && warnings.length ? 'err' : 'ok');
  async function toolsDir(sub) { const p = await CS.call('OS_getPaths'); const base = (p.ok && (p.projectDir || p.documents)) || CS.os.homedir(); const d = CS.path.join(base, 'OutflowStudio', sub); CS.mkdirp(d); return d; }
  const srtTime = (s) => { const ms = Math.round(s * 1000); const hh = Math.floor(ms / 3600000), mm = Math.floor(ms / 60000) % 60, ss = Math.floor(ms / 1000) % 60, mss = ms % 1000; return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0') + ':' + String(ss).padStart(2, '0') + ',' + String(mss).padStart(3, '0'); };
  const fmtTc = (s) => { const m = Math.floor(s / 60), ss = Math.floor(s % 60); return (m >= 60 ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };
  function writeSRT(cues, file) { CS.fs.writeFileSync(file, cues.map((c, i) => (i + 1) + '\n' + srtTime(c.s) + ' --> ' + srtTime(c.e) + '\n' + c.text + '\n').join('\n'), 'utf8'); return file; }
  async function pngFromCanvas(cv, file) { return Exporter.writePNGFree(file, cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data, cv.width, cv.height); }
  const psSta = (cmd) => new Promise((res, rej) => { const cp = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('child_process'); cp.execFile('powershell', ['-NoProfile', '-NonInteractive', '-STA', '-Command', cmd], { windowsHide: true, maxBuffer: 50 * 1024 * 1024 }, (err, out, se) => err ? rej(new Error(se || err.message)) : res(String(out))); });
  const ps = (cmd) => new Promise((res, rej) => { const cp = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('child_process'); cp.execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', cmd], { windowsHide: true, maxBuffer: 50 * 1024 * 1024 }, (err, out, se) => err ? rej(new Error(se || err.message)) : res(String(out))); });

  /* clipboard: image -> PNG file, files -> paths, text -> link or caption */
  /*  The Mac clipboard, in the same IMAGE| / FILE| / TEXT| lines the Windows side produces: an image is
      written out through AppleScript, a copied file comes as its path, text through pbpaste.       */
  async function macClipboardLines(png) {
    const cp = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('child_process');
    const osa = (args) => new Promise((res) => cp.execFile('osascript', args, { encoding: 'utf8', timeout: 10000 }, (e, out) => res(e ? null : String(out).trim())));
    const img = await osa(['-e', 'set d to the clipboard as \u00abclass PNGf\u00bb', '-e', 'set f to open for access POSIX file "' + png + '" with write permission', '-e', 'write d to f', '-e', 'close access f', '-e', '"ok"']);
    if (img === 'ok' && CS.fs.existsSync(png)) return 'IMAGE|' + png;
    const file = await osa(['-e', 'POSIX path of (the clipboard as \u00abclass furl\u00bb)']);
    if (file && CS.fs.existsSync(file)) return 'FILE|' + file;
    const text = CS.clipboardText();
    return text.trim() ? 'TEXT|' + text : '';
  }
  async function readClipboard() {
    need();
    const dir = await toolsDir('clipboard');
    const png = CS.path.join(dir, 'clip_' + Date.now().toString(36) + '.png').replace(/'/g, "''");
    /*  Windows: the picture as PNG data first (browsers, Snipping Tool, Discord and Photos put it there, often
        with no bitmap next to it - that was "The clipboard is empty" in three reports), then the bitmap, then
        copied files, then an image link inside copied web content, then text. Run STA: the clipboard needs it. */
    const out = CS.mac ? await macClipboardLines(png) : await psSta("Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $png = '" + png + "'; $d = [Windows.Forms.Clipboard]::GetDataObject(); $ok = $false; " +
      "if ($d) { foreach ($fmt in @('PNG', 'image/png')) { if (-not $ok -and $d.GetDataPresent($fmt)) { $s = $d.GetData($fmt); if ($s -is [IO.MemoryStream]) { [IO.File]::WriteAllBytes($png, $s.ToArray()); $ok = $true } } } } " +
      "if (-not $ok) { $img = [Windows.Forms.Clipboard]::GetImage(); if ($img) { $img.Save($png, [Drawing.Imaging.ImageFormat]::Png); $ok = $true } } " +
      "if ($ok) { 'IMAGE|' + $png } else { $f = [Windows.Forms.Clipboard]::GetFileDropList(); if ($f -and $f.Count -gt 0) { $f | ForEach-Object { 'FILE|' + $_ } } " +
      "else { $h = ''; if ($d -and $d.GetDataPresent('HTML Format')) { $h = [string]$d.GetData('HTML Format') }; $m = [regex]::Match($h, '<img[^>]+src=[\"'']?(https?://[^\"'' >]+)'); " +
      "if ($m.Success) { 'IMGURL|' + $m.Groups[1].Value } else { $t = [Windows.Forms.Clipboard]::GetText(); if ($t) { 'TEXT|' + $t } } } }");
    const lines = out.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    if (!lines.length) return { kind: 'empty' };
    if (lines[0].startsWith('IMAGE|')) return { kind: 'image', path: lines[0].slice(6) };
    if (lines[0].startsWith('IMGURL|')) {
      /* a picture copied as part of a web page: fetch it, then place it like any clipboard image */
      const url = lines[0].slice(7), ext = (/\.(png|jpe?g|webp|gif|bmp)(\?|$)/i.exec(url) || [0, 'png'])[1].toLowerCase();
      const file = png.replace(/''/g, "'").replace(/\.png$/, '.' + ext);
      await Net.download(url, file, () => {});
      return { kind: 'image', path: file };
    }
    if (lines[0].startsWith('FILE|')) return { kind: 'files', paths: lines.filter(l => l.startsWith('FILE|')).map(l => l.slice(5)) };
    return { kind: 'text', text: lines.map(l => l.replace(/^TEXT\|/, '')).join('\n') };
  }
  const kindOf = (p) => /\.(mp4|mov|mkv|webm|avi|m4v|mts)$/i.test(p) ? 'video' : /\.(mp3|wav|m4a|aac|flac|ogg)$/i.test(p) ? 'audio' : 'photo';

  const actions = {
    async paste() {
      const c = await readClipboard();
      if (c.kind === 'empty') throw new Error('Nothing to paste yet. Copy a picture (right-click it, Copy image), a file in Explorer, a link or some text, then press Paste.');
      if (c.kind === 'image') { const r = await call('OS_importMedia', c.path, 'Outflow Clipboard', true, 'photo'); done('Clipboard image placed on ' + (r.track || 'the project') + '.'); return; }
      if (c.kind === 'files') { let n = 0; for (const p of c.paths) { if (!CS.fs.existsSync(p)) continue; const r = await CS.call('OS_importMedia', p, 'Outflow Clipboard', true, kindOf(p)); if (r.ok) n++; } done(n + ' file(s) placed at the playhead.'); return; }
      const t = c.text.trim();
      if (/^https?:\/\/\S+$/i.test(t)) { Social.open(t); return; }
      const info = await call('AS_range');
      const file = writeSRT([{ s: info.playhead, e: info.playhead + 4, text: t.slice(0, 200) }], CS.path.join(await toolsDir('captions'), 'clip_' + Date.now().toString(36) + '.srt'));
      await call('TL_captionsFromSRT', file, 0);
      done('Clipboard text added as a caption at the playhead.');
    },
    async social() { let url = ''; try { const c = await readClipboard(); if (c.kind === 'text' && /^https?:\/\/\S+$/i.test(c.text.trim())) url = c.text.trim(); } catch (e) {} Social.open(url); },
    async adjlayer(opt) {
      const template = CS.extensionPath().replace(/\\/g, '/') + '/client/assets/adjustment-layer.prproj';
      let duration = 5;
      if (opt === 'all') { const info = await call('AS_range'); duration = info.duration || 5; await CS.call('C3D_setPlayhead', 0); }
      else if (typeof opt === 'number') duration = opt;
      /* with the Transform effect already on it: that is what an adjustment layer is for nine times out of ten */
      const r = await call('QF_apply', JSON.stringify({ name: 'Adjustment Layer', target: 'adjustment', effects: [{ name: 'Transform', params: [] }], duration, template, ignoreSelection: opt !== 'sel' && opt !== undefined }));
      done('Adjustment layer placed.', r.warnings);
    },
    async unnest() { const r = await call('TL_unnest'); done(r.done + ' nest(s) expanded.', r.warnings); },
    /*  Every press adds an Opacity and Premiere takes any number of them; the scripting side cannot see
        whether the last one got a mask. So a press right after another is refused with a hint - the
        mask has to be drawn in between - instead of stacking empty Opacity effects.                   */
    /*  Two presses. The first sends the mask tool's shortcut to Premiere (a key typed while the panel has
        focus is a Premiere shortcut) and arms the button; the second adds Opacity, which Premiere hands the
        unassigned mask to. Premiere has no way for a panel to switch tools or to see the mask, so this is
        the shortest the flow can be.                                                                    */
    async mask(which) {
      const btn = document.querySelector('#sidebar [data-tool="mask"]');
      if (maskArmed) { await maskApply(false); return; }
      const w = which || cfg.maskType || 'object', key = (cfg.maskKeys || {})[w] || '';
      let seen = false; try { seen = !!localStorage.getItem(INTRO_FLAG); } catch (e) {}
      if (!seen) { maskIntro(() => run('mask', w)); return; }
      if (!key) throw new Error('Give Premiere\'s ' + ({ object: 'Object', rect: 'Rectangle', ellipse: 'Ellipse', pen: 'Pen' })[w] + ' Mask Tool a shortcut first (Edit › Keyboard Shortcuts, search "Mask Tool"), then record it under the toolbox button › Mask tool keys.');
      need();
      if (which) { cfg.maskType = which; save(); }
      /* Pro, with three free masks: asked at the press, counted when the mask lands on Opacity */
      if (typeof License !== 'undefined' && !await License.guardExport('mask', 'mask')) return;
      /*  The duplicate: Premiere's own Copy and Paste, sent as keys (a scripted copy loses the effects). The
          host puts the playhead at the clip and targets the free track above, the paste lands there, and
          the copy becomes the selected clip - the mask is drawn on it, Opacity goes on it.            */
      trackCancel = false;
      if (cfg.maskDup) {
        maskBusy('copy', w);
        let p; try { p = await call('TL_dupAbove'); } catch (e) { maskBusy(null); throw e; }
        toast('Copy on V' + (p.track + 1) + (p.warnings && p.warnings.length ? ' · ' + p.warnings[0] : '') + '. Draw the mask on it.', '');
        await new Promise((r) => setTimeout(r, 250));
      }
      maskBusy('draw', w);
      CS.sendKey(key);
      maskArmed = true; if (btn) btn.classList.add('armed');
      maskWatchStart(w);
      toast(w === 'pen' ? 'Draw the pen mask, close the shape, then press the Mask button again.' : 'Draw the mask on the selected clip. It goes onto Opacity by itself.', 'ok');
    },
    async fit() { const r = await call('TL_fitToFrame', 'fit'); done(r.done + ' clip(s) fitted.', r.warnings); },
    async fill() { const r = await call('TL_fitToFrame', 'fill'); done(r.done + ' clip(s) filled.', r.warnings); },
    async gaps() { const r = await call('TL_closeGaps'); done(r.closed + ' of ' + r.gaps + ' gaps closed.'); },
    async disabled() { const r = await call('TL_deleteDisabled'); done(r.applied + ' gap(s) closed.', r.warnings); },
    async dissolve(frames) {
      const info = await call('AS_range');
      const all = !info.selection.length;
      const r = await call('TL_transitions', JSON.stringify({ name: cfg.transition, duration: typeof frames === 'number' ? frames : cfg.frames, edges: false, all, track: 0 }));
      done(cfg.transition + ' on ' + r.done + ' clip(s)' + (all ? ' (all clips on V1)' : '') + '.', r.warnings);
    },
    async margins() {
      const info = await call('AS_range');
      const W = info.width, H = info.height, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      const g = cv.getContext('2d'); g.lineWidth = Math.max(2, W / 800);
      const box = (f, col) => { g.strokeStyle = col; g.strokeRect(W * (1 - f) / 2, H * (1 - f) / 2, W * f, H * f); };
      box(0.9, 'rgba(255,214,102,.9)'); box(0.8, 'rgba(120,200,255,.9)');
      g.strokeStyle = 'rgba(255,255,255,.5)'; g.setLineDash([12, 12]); g.beginPath(); g.moveTo(W / 2, 0); g.lineTo(W / 2, H); g.moveTo(0, H / 2); g.lineTo(W, H / 2); g.stroke();
      const file = await pngFromCanvas(cv, CS.path.join(await toolsDir('overlays'), 'safe_margins_' + W + 'x' + H + '.png'));
      const r = await call('TL_placeImage', JSON.stringify({ path: file, start: 0, duration: info.duration || 10, scale: 100, name: 'Safe margins (disable before export)' }));
      done('Safe margins on V' + (r.track + 1) + '.', r.warnings);
    },
    async progress(range) {
      const info = await call('AS_range');
      let s = 0, e = info.duration;
      if (range === 'inout' && info.hasInOut) { s = info.inPoint; e = info.outPoint; }
      else if (range === 'selected' && info.selection.length) { s = Math.min(...info.selection.map(c => c.start)); e = Math.max(...info.selection.map(c => c.end)); }
      if (e - s < 0.2) throw new Error('The chosen range is empty.');
      const W = info.width, H = info.height, hp = Math.max(2, Math.round(H * cfg.barHeight / 100));
      const cv = document.createElement('canvas'); cv.width = W; cv.height = hp; const g = cv.getContext('2d'); g.fillStyle = cfg.barColor; g.fillRect(0, 0, W, hp);
      const file = await pngFromCanvas(cv, CS.path.join(await toolsDir('overlays'), 'bar_' + cfg.barColor.slice(1) + '_' + W + 'x' + hp + '.png'));
      const py = cfg.barPos === 'bottom' ? 1 - hp / H / 2 : hp / H / 2;
      const r = await call('TL_placeImage', JSON.stringify({ path: file, start: s, duration: e - s, scale: 100, posX: 0.5, posY: py, name: 'Progress bar', cropKeys: [[0, 100], [e - s, 0]] }));
      done('Progress bar on V' + (r.track + 1) + '.', r.warnings);
    },
    async watermark(pos) {
      if (!cfg.watermarkFile || !CS.fs.existsSync(cfg.watermarkFile)) { const p = CS.pickFiles(); if (!p || !p[0]) return; cfg.watermarkFile = p[0]; save(); }
      const info = await call('AS_range');
      const src = await Sources.add(cfg.watermarkFile);
      const scale = (cfg.watermarkSize / 100) * info.width / (src.ow || src.w) * 100;
      const m = 0.04, P = { tr: [1 - m, m], tl: [m, m], br: [1 - m, 1 - m], bl: [m, 1 - m], c: [0.5, 0.5] }[typeof pos === 'string' ? pos : cfg.watermarkPos];
      const wFrac = cfg.watermarkSize / 100, hFrac = wFrac * ((src.oh || src.h) / (src.ow || src.w)) * (info.width / info.height);
      const px = P[0] + (P[0] < 0.5 ? wFrac / 2 : P[0] > 0.5 ? -wFrac / 2 : 0), py = P[1] + (P[1] < 0.5 ? hFrac / 2 : P[1] > 0.5 ? -hFrac / 2 : 0);
      const r = await call('TL_placeImage', JSON.stringify({ path: cfg.watermarkFile, start: 0, duration: info.duration || 10, scale, posX: px, posY: py, opacity: cfg.watermarkOpacity, name: 'Watermark' }));
      done('Watermark placed on V' + (r.track + 1) + '.', r.warnings);
    },
    async chapters() {
      const r = await call('TL_markers');
      if (!r.markers.length) throw new Error('No sequence markers found.');
      const lines = r.markers.map(m => fmtTc(m.start) + ' ' + (m.name || 'Chapter'));
      if (r.markers[0].start > 0.5) lines.unshift('0:00 Intro');
      const txt = lines.join('\n');
      try { CS.clipboardWrite(txt); }
      catch (e) { const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      done(lines.length + ' chapters copied to the clipboard.');
    },
    async stills() {
      const r = await call('TL_markers');
      if (!r.markers.length) throw new Error('No sequence markers found.');
      const dir = (await toolsDir('stills')).replace(/\\/g, '/');
      const res = await call('TL_exportStills', JSON.stringify({ times: r.markers.map(m => m.start), dir, prefix: (r.name || 'still').replace(/[^a-z0-9_-]+/gi, '_') }));
      done(res.exported + ' stills saved to ' + dir, res.warnings);
    },
    async countdown(from) {
      const info = await call('AS_range');
      const cues = []; let t = info.playhead;
      for (let n = typeof from === 'number' ? from : cfg.countdownFrom; n >= 1; n--) { cues.push({ s: t, e: t + 0.98, text: String(n) }); t += 1; }
      await call('TL_captionsFromSRT', writeSRT(cues, CS.path.join(await toolsDir('captions'), 'countdown_' + Date.now().toString(36) + '.srt')), 0);
      done('Countdown added at the playhead.');
    },
    async lowerthird() {
      const v = prompt('Lower third text ("Name | Title")', ''); if (!v) return;
      const [name, title] = v.split('|').map(s => s.trim());
      const info = await call('AS_range');
      await call('TL_captionsFromSRT', writeSRT([{ s: info.playhead, e: info.playhead + 4, text: name + (title ? '\n' + title : '') }], CS.path.join(await toolsDir('captions'), 'lowerthird_' + Date.now().toString(36) + '.srt')), 0);
      done('Lower third added.');
    },
    async tts() {
      const t = prompt('Voice-over text', ''); if (!t) return;
      need();
      const out = CS.path.join(await toolsDir('voiceover'), 'vo_' + Date.now().toString(36) + '.wav');
      const txtFile = out.replace(/\.wav$/, '.txt'); CS.fs.writeFileSync(txtFile, t, 'utf8');
      await ps("Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SetOutputToWaveFile('" + out.replace(/'/g, "''") + "'); $s.Speak([IO.File]::ReadAllText('" + txtFile.replace(/'/g, "''") + "')); $s.Dispose()");
      const info = await call('AS_range');
      const r = await call('TL_placeAudio', out, info.playhead, 'Voice-over');
      done('Voice-over (' + r.duration.toFixed(1) + ' s) placed on A' + (r.track + 1) + '.');
    }
  };

  let busy = false;
  async function run(id, arg) {
    try { Usage.tick('sidebar:' + id); } catch (e) {}
    if (busy) return; busy = true;
    hidePop();
    const b = document.querySelector('#sidebar [data-tool="' + id + '"]'); if (b) b.classList.add('busy');
    let ok = false;
    try { await actions[id](arg); ok = true; } catch (e) { toast(e.message || String(e), 'err'); }
    finally { busy = false; if (b) b.classList.remove('busy'); }
    if (ok && id !== 'mask') maybeTryPro();
  }
  /*  The one card against the biggest leak: most free users only ever run the toolbar and never open a
      tool with a paywall behind it, so they never see a reason to pay. After the fifth toolbar job on a
      free account, once, the two tools people buy for, a click away. Never for Pro, never twice.      */
  const TRYPRO = 'os.trypro', TRYPRO_N = 'os.trypro.n';
  function maybeTryPro() {
    try {
      if (localStorage.getItem(TRYPRO)) return;
      if (typeof License !== 'undefined' && License.isPro()) return;
      const n = (parseInt(localStorage.getItem(TRYPRO_N) || '0', 10) || 0) + 1;
      localStorage.setItem(TRYPRO_N, String(n));
      if (n < 5) return;
      const other = document.querySelector('.update.show'); if (other) return;   /* another card is up: next time */
      localStorage.setItem(TRYPRO, '1');
    } catch (e) { return; }
    const m = h('div', 'update trypro'); m.id = 'trypro-modal';
    m.innerHTML = '<div class="ubox"><div class="ueyebrow">Five jobs in</div><h2>The toolbar is the small part.</h2>' +
      '<p class="small">The tools people buy Outflow Studio for are on the home screen. Two to try on the clips you have selected - three free goes each, no card, nothing to set up:</p>' +
      '<div class="trypro-row">' +
        '<button class="trypro-btn" data-go="transitions">' + icon('transitions', 22) + '<b>Transitions</b><span>79 keyframed transitions on a motion curve. Pick one, it lands between your clips.</span></button>' +
        '<button class="trypro-btn" data-go="carousel">' + icon('carousel', 22) + '<b>3D Carousel</b><span>A 3D card carousel from your images or clips, 74 templates.</span></button>' +
      '</div>' +
      '<div class="ubtns"><button class="ghost" id="trypro-later">Not now</button></div></div>';
    document.body.appendChild(m);
    const close = () => m.remove();
    $('#trypro-later').addEventListener('click', () => { close(); try { Usage.tick('trypro:later'); } catch (e) {} });
    m.querySelectorAll('[data-go]').forEach((btn) => btn.addEventListener('click', () => { const id = btn.dataset.go; close(); try { Usage.tick('trypro:' + id); } catch (e) {} try { Hub.show(id); } catch (e) { toast('Open it from the home screen.', ''); } }));
    m.classList.add('show');
    try { Usage.tick('trypro:shown'); } catch (e) {}
  }
  /* hover popover: name, description and quick options */
  let pop = null, popTimer = null, popFor = null;
  function hidePop() { if (pop) { pop.remove(); pop = null; popFor = null; } clearTimeout(popTimer); }
  /*  In toolbar mode (the panel too thin for anything but the strip) there is no room beside a button, and a
      popover over the strip sits on the very icons you are about to click. There, the button's own title
      does the job - a native tooltip the mouse can never be under.                                        */
  const toolbarMode = () => window.innerWidth <= 150;
  /*  In toolbar mode (the panel docked as a thin strip) the panel cannot draw outside its own edges, so
      the full card would be cut off. A tool that has choices gets a compact card instead: the icons
      stacked, the switch as an icon, the width of the strip; a plain tool shows nothing there.       */
  function showPop(btn, t, force) {
    hidePop();
    const compact = toolbarMode();
    const togs = t.toggles || (t.toggle ? [t.toggle] : []);
    if (compact && !force && !(t.opts || togs.length)) return;
    pop = h('div', 'spop' + (compact ? ' compact' : ''));
    pop.innerHTML = compact ? '' : '<b>' + t.name + '</b><span>' + t.desc + '</span>';
    if (t.opts) { const row = h('div', 'spop-opts'); for (const [label, val] of t.opts) { const o = h('button', '', (t.optIcons && t.optIcons[val] ? icon(t.optIcons[val], compact ? 16 : 13) : '') + (compact && t.optIcons && t.optIcons[val] ? '' : label)); o.title = label; o.addEventListener('click', (e) => { e.stopPropagation(); run(t.id, val); }); row.appendChild(o); } pop.appendChild(row); }
    /* a switch inside the popover (the Mask button: mask on a new layer) */
    for (const tog of togs) { const tg = h('div', 'spop-toggle'); const sw = h('button', 'switch' + (tog.get() ? ' on' : '')); sw.title = tog.label + (tog.hint ? ' · ' + tog.hint : ''); sw.addEventListener('click', (e) => { e.stopPropagation(); const v = !tog.get(); tog.set(v); sw.classList.toggle('on', v); }); tg.innerHTML = compact ? '<span title="' + tog.label + '">' + icon(tog.icon || 'newlayer', 14) + '</span>' : '<span><b>' + tog.label + '</b>' + (tog.hint ? '<i>' + tog.hint + '</i>' : '') + '</span>'; tg.appendChild(sw); pop.appendChild(tg); }
    document.body.appendChild(pop);
    const r = btn.getBoundingClientRect(), pw = pop.offsetWidth, ph = pop.offsetHeight;
    let top = Math.max(6, Math.min(window.innerHeight - ph - 6, r.top + r.height / 2 - ph / 2));
    pop.style.top = top + 'px';
    /* beside the button, but never off the edge: in toolbar mode there is no "beside", so it sits over the strip */
    const want = compact ? 2 : (cfg.side === 'right' ? r.left - pw - 8 : r.right + 8);
    pop.style.left = Math.max(2, Math.min(want, innerWidth - pw - 2)) + 'px';
    /*  The compact card: its first choice carries the same icon as the button, and it is placed so that
        icon sits exactly over the button - the card opens under the mouse like Premiere's own flyout. */
    if (compact) {
      const first = pop.querySelector('.spop-opts button');
      if (first) {
        const fr = first.getBoundingClientRect(), pr = pop.getBoundingClientRect();
        let left = r.left + (r.width - fr.width) / 2 - (fr.left - pr.left), top2 = r.top + (r.height - fr.height) / 2 - (fr.top - pr.top);
        top2 = Math.max(2, Math.min(window.innerHeight - ph - 2, top2));
        pop.style.left = Math.max(0, left) + 'px'; pop.style.top = top2 + 'px';
      }
    }
    pop.addEventListener('mouseenter', () => clearTimeout(popTimer));
    pop.addEventListener('mouseleave', () => { popTimer = setTimeout(hidePop, 150); });
    popFor = t.id;
  }
  function render() {
    let sb = $('#sidebar');
    if (!sb) { sb = h('div'); sb.id = 'sidebar'; document.body.appendChild(sb); }
    sb.innerHTML = '';
    sb.className = 'side-' + cfg.side + (cfg.size === 'small' ? ' small' : '');
    sb.style.display = cfg.enabled ? '' : 'none';
    const makeBtn = (t, cls) => {
      const b = h('button', cls, icon(t.icon, cfg.size === 'small' ? 16 : 19));
      b.dataset.tool = t.id; b.title = t.name;
      /* the Mask button: hold it to pick the mask type, like Premiere's own tool flyout; a plain click uses the last pick */
      if (t.opts && t.id === 'mask') {
        let holdT = null, held = false;
        b.addEventListener('mousedown', () => { held = false; clearTimeout(holdT); holdT = setTimeout(() => { held = true; showPop(b, t, true); }, 380); });
        b.addEventListener('mouseup', () => clearTimeout(holdT));
        b.addEventListener('mouseleave', () => clearTimeout(holdT));
        b.addEventListener('click', () => { if (held) { held = false; return; } run(t.id); });
      } else b.addEventListener('click', () => run(t.id));
      b.addEventListener('mouseenter', () => { clearTimeout(popTimer); popTimer = setTimeout(() => showPop(b, t), 220); });
      b.addEventListener('mouseleave', () => { clearTimeout(popTimer); popTimer = setTimeout(hidePop, 200); });
      return b;
    };
    for (const t of TOOLS) { if (!cfg.show[t.id] || t.id === 'mask') continue; sb.appendChild(makeBtn(t, 'sbtn')); }
    /* the panel's own tools, pinned by the user, under a line so the two kinds never look like one list */
    const pinned = panelTools().filter((t) => cfg.panel[t.id]);
    /* Mask is one of the panel's own tools (Pro, three free goes): under the line, above the pinned ones, in their blue */
    const maskT = cfg.show.mask ? TOOLS.find((t) => t.id === 'mask') : null;
    if (pinned.length || maskT) {
      sb.appendChild(h('div', 'ssep'));
      if (maskT) sb.appendChild(makeBtn(maskT, 'sbtn panel'));
      for (const t of pinned) {
        const b = h('button', 'sbtn panel', icon(t.icon, cfg.size === 'small' ? 16 : 19));
        b.dataset.tool = t.id; b.title = t.name;
        b.addEventListener('click', () => {
          /* a pinned shortcut must not walk past the lock the home screen puts on a Pro tool */
          try {
            if (typeof License !== 'undefined' && !License.can(t.id)) { License.promptUnlock(t.id); return; }
            t.go();
          } catch (e) { toast(e.message || String(e), 'err'); }
        });
        b.addEventListener('mouseenter', () => { clearTimeout(popTimer); popTimer = setTimeout(() => showPop(b, { id: t.id, name: t.name, desc: t.desc }), 220); });
        b.addEventListener('mouseleave', () => { clearTimeout(popTimer); popTimer = setTimeout(hidePop, 200); });
        sb.appendChild(b);
      }
    }

    /* right under the tools: configure this sidebar. At the very bottom: the wheel and the panel's main Settings */
    const conf = h('button', 'sbtn conf', icon('toolbox', cfg.size === 'small' ? 15 : 17)); conf.title = 'Configure the sidebar';
    conf.addEventListener('click', () => Toolbox.openMenu());
    const wheel = h('button', 'sbtn wheel', '✦'); wheel.title = 'Quick FX wheel (' + 'Ctrl+Alt+X' + ')';
    wheel.addEventListener('click', () => QuickFX.toggle());
    const gear = h('button', 'sbtn gear', icon('settings', 17)); gear.title = 'Settings';
    gear.addEventListener('click', () => { if (typeof Hub !== 'undefined') Hub.show('settings'); });
    const bug = h('button', 'sbtn bug', '<span style="font-weight:800;font-size:15px;line-height:1">!</span>'); bug.title = 'Report a problem';
    bug.addEventListener('click', () => { if (typeof BugReport !== 'undefined') BugReport.open(); });
    sb.append(conf, wheel, bug, gear);
    document.body.classList.toggle('has-sidebar-right', cfg.enabled && cfg.side === 'right');
    document.body.classList.toggle('has-sidebar-left', cfg.enabled && cfg.side === 'left');
    const fab = $('#qfx-fab'); if (fab) fab.style.display = cfg.enabled ? 'none' : '';
  }
  /*  Once, after the update that brought the new default: whoever already had a sidebar sees theirs next to
      the new set and chooses. Nothing changes unless they pick the new one. New installs are never asked. */
  const ASKED = 'os.sidebar.def2';
  const same = () => TOOLS.every((t) => !!cfg.show[t.id] === !!DEF.show[t.id]) && panelTools().every((t) => !!cfg.panel[t.id] === !!DEF.panel[t.id]);
  function maybeAskDefault() {
    try {
      if (localStorage.getItem(ASKED)) return;
      if (!hadSaved || same()) { localStorage.setItem(ASKED, '1'); return; }
    } catch (e) { return; }
    const other = $('#update-modal'); if (other && other.classList.contains('show')) { setTimeout(maybeAskDefault, 4000); return; }
    const list = (show, panel) => {
      const a = TOOLS.filter((t) => show[t.id]).map((t) => '<div class="ti">' + icon(t.icon, 15) + '<span>' + t.name + '</span></div>');
      const b = panelTools().filter((t) => panel[t.id]).map((t) => '<div class="ti">' + icon(t.icon, 15) + '<span>' + t.name + '</span></div>');
      return a.join('') + (b.length ? '<div class="tsep"></div>' + b.join('') : '') || '<div class="ti muted">Nothing</div>';
    };
    const m = h('div', 'update tbdef'); m.id = 'tbdef-modal';
    m.innerHTML = '<div class="ubox"><div class="ueyebrow">Outflow Studio</div><h2>A new default toolbar</h2>' +
      '<p class="small">This version comes with a new default set of toolbar buttons. Keep the toolbar you have, or switch to the new one. You can change any of it later with the toolbox button at the foot of the toolbar.</p>' +
      '<div class="cols"><div class="tbcol"><h4>Yours now</h4>' + list(cfg.show, cfg.panel) + '</div><div class="tbcol new"><h4>New default</h4>' + list(DEF.show, DEF.panel) + '</div></div>' +
      '<div class="ubtns"><button class="primary" id="tbdef-new">Use the new default</button><button class="ghost" id="tbdef-keep">Keep mine</button></div></div>';
    document.body.appendChild(m);
    const close = () => { try { localStorage.setItem(ASKED, '1'); } catch (e) {} m.remove(); };
    $('#tbdef-keep').addEventListener('click', close);
    $('#tbdef-new').addEventListener('click', () => { cfg.show = Object.assign({}, DEF.show); cfg.panel = Object.assign({}, DEF.panel); save(); render(); close(); toast('Toolbar set to the new default.', 'ok'); });
    m.classList.add('show');
    try { Usage.tick('set:sidebar:askdefault'); } catch (e) {}
  }
  return { TOOLS, panelTools, cfg: () => cfg, save, render, run, actions, DEF, maybeAskDefault, maskIntro, maskTrackIntro, keycap };
})();
