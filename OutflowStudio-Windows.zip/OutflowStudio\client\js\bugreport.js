/*  Report a problem, from inside the panel, in three clicks.

    The form asks the three things that make a report usable - which tool, what kind of wrong, and a few
    words - and fills in everything else itself: the panel version, the computer, the last three hundred
    lines of the diagnostic log (the same file Log writes; it holds every host call and every error, never
    file names or content), and the account email when there is one. It works logged out too: someone who
    cannot log in is exactly the person who needs it. Sent to the bugreport function.                      */
const BugReport = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const KINDS = [['error', 'It gave an error'], ['nothing', 'Nothing happened'], ['wrong', 'The result was wrong'], ['crash', 'Premiere froze or crashed'], ['other', 'Something else']];
  const TOOLS = [['autoedit', 'Auto Edit'], ['captions', 'Word Captions'], ['carousel', '3D Carousel'], ['transitions', 'Transitions'], ['curves', 'Motion Curves'], ['montage', 'Zoom Montage'], ['audioai', 'Audio edit'], ['relight', 'Relight'], ['social', 'Download media'], ['stock', 'Stock media'], ['tools', 'Timeline tools / sidebar'], ['quickfx', 'Quick FX wheel'], ['login', 'Login or account'], ['update', 'Updating the panel'], ['other', 'Something else']];
  /* what the current screen is called in the list above; the form opens on it */
  const guessTool = () => {
    let cur = 'other'; try { cur = Hub.current(); } catch (e) {}
    const map = { home: 'other', settings: 'other', assist: 'autoedit', social: 'social', stock: 'stock', curves: 'curves', montage: 'montage', transitions: 'transitions', audioai: 'audioai', relight: 'relight', matte: 'other', gallery: 'carousel', editor: 'carousel', quickfx: 'quickfx', tools: 'tools', login: 'login' };
    return map[cur] || (TOOLS.some(t => t[0] === cur) ? cur : 'other');
  };
  let modal = null, state = { kind: '', error: '' };

  function build() {
    modal = h('div', 'update bug'); modal.id = 'bug-modal';
    modal.innerHTML = '<div class="ubox"><div class="ueyebrow">Report a problem</div><h2>What went wrong?</h2>' +
      '<p class="small">Three quick things and it is on its way. The panel adds its own log, so you do not have to explain the technical part.</p>' +
      '<div class="srow"><label>Which tool</label><select id="bug-tool">' + TOOLS.map(([v, n]) => '<option value="' + v + '">' + n + '</option>').join('') + '</select></div>' +
      '<div class="srow"><label>What happened</label><div class="bug-kinds" id="bug-kinds">' + KINDS.map(([v, n]) => '<button type="button" class="chip" data-kind="' + v + '">' + n + '</button>').join('') + '</div></div>' +
      '<div class="srow"><label>In your words <span class="hint">what you did, what you expected</span></label><textarea id="bug-text" rows="4" placeholder="I pressed Run Auto Edit on a 10-minute clip and…"></textarea></div>' +
      '<div class="srow" id="bug-err-row" style="display:none"><label>Error shown</label><div class="kbd" id="bug-err"></div></div>' +
      '<div class="srow"><label class="inline"><button type="button" class="switch on" id="bug-log"></button> Include the panel log (recommended - no file names or content)</label></div>' +
      '<div class="srow"><label class="inline"><button type="button" class="switch on" id="bug-mail"></button> <span id="bug-mail-txt">Include my email so we can reply</span></label></div>' +
      '<div class="small" id="bug-status"></div>' +
      '<div class="ubtns"><button class="primary" id="bug-send">Send report</button><button class="ghost" id="bug-cancel">Cancel</button></div></div>';
    document.body.appendChild(modal);
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    $('#bug-cancel').addEventListener('click', close);
    $('#bug-kinds').addEventListener('click', (e) => { const b = e.target.closest('[data-kind]'); if (!b) return; state.kind = b.dataset.kind; modal.querySelectorAll('[data-kind]').forEach(x => x.classList.toggle('on', x === b)); });
    for (const id of ['bug-log', 'bug-mail']) $('#' + id).addEventListener('click', () => $('#' + id).classList.toggle('on'));
    $('#bug-send').addEventListener('click', send);
  }
  function close() { if (modal) modal.classList.remove('show'); }

  /* open(tool?, error?) - an error toast's Report button passes the message it showed */
  function open(tool, error) {
    if (!modal) build();
    state = { kind: error ? 'error' : '', error: error || '' };
    $('#bug-tool').value = tool && TOOLS.some(t => t[0] === tool) ? tool : guessTool();
    modal.querySelectorAll('[data-kind]').forEach(x => x.classList.toggle('on', x.dataset.kind === state.kind));
    $('#bug-text').value = '';
    $('#bug-err-row').style.display = error ? '' : 'none'; $('#bug-err').textContent = error || '';
    $('#bug-status').textContent = '';
    let email = ''; try { email = (License.info() || {}).email || ''; } catch (e) {}
    $('#bug-mail-txt').textContent = email ? 'Include my email (' + email + ') so we can reply' : 'Not logged in - add your email in the text if you want a reply';
    $('#bug-mail').style.display = email ? '' : 'none';
    $('#bug-send').disabled = false; $('#bug-send').textContent = 'Send report';
    modal.classList.add('show');
    setTimeout(() => { try { $('#bug-text').focus(); } catch (e) {} }, 50);
  }

  async function send() {
    const text = $('#bug-text').value.trim(), status = $('#bug-status');
    if (!state.kind) { status.textContent = 'Pick what happened first.'; return; }
    if (!text && !state.error) { status.textContent = 'A few words help - what did you do, what did you expect?'; return; }
    const btn = $('#bug-send'); btn.disabled = true; btn.textContent = 'Sending…'; status.textContent = '';
    let email = ''; try { email = (License.info() || {}).email || ''; } catch (e) {}
    const body = {
      tool: $('#bug-tool').value, kind: state.kind, text, error: state.error,
      version: (window.OUTFLOW || {}).version || '',
      device: (() => { try { return Usage.device() || null; } catch (e) { return null; } })(),
      email: $('#bug-mail').classList.contains('on') ? email : '',
      log: $('#bug-log').classList.contains('on') ? (() => { try { return Log.tail(300).join('\n'); } catch (e) { return ''; } })() : '',
    };
    try {
      const r = await License.api('/bugreport', { method: 'POST', body });
      if (!r.ok) throw new Error(r.error || 'not sent');
      try { Usage.tick('set:bugreport:' + state.kind); } catch (e) {}
      btn.textContent = 'Sent, thank you';
      setTimeout(close, 1200);
      Hub.toast('Report sent. Thank you - it is read by the person who makes the panel.', 'ok');
    } catch (e) {
      btn.disabled = false; btn.textContent = 'Send report';
      status.textContent = 'Could not send (' + e.message + '). You can also email support@outflowstudio.com' + (Log.file() ? ' and attach ' + Log.file() : '') + '.';
    }
  }
  return { open, close };
})();
