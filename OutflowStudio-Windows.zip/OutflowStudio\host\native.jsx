/*  Outflow Studio - host script part 2 (ExtendScript, ES3)
    Selection helpers + native keyframe mode. Requires index.jsx.               */

function C3D_itemPath(item) { try { return item.getMediaPath(); } catch (e) { return ""; } }

function C3D_getProjectSelection() {
    try {
        var items = null;
        try { items = app.getCurrentProjectViewSelection(); } catch (e1) {}
        if ((!items || !items.length) && app.project.getSelection) { try { items = app.project.getSelection(); } catch (e2) {} }
        var out = [];
        if (items) {
            for (var i = 0; i < items.length; i++) {
                var it = items[i];
                if (!it || it.type === ProjectItemType.BIN) continue;
                var p = C3D_itemPath(it);
                if (p) out.push({ path: p, name: it.name });
            }
        }
        return C3D_json({ ok: true, items: out });
    } catch (e) { return C3D_err(e); }
}

function C3D_getSelectedClips() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var out = [];
        for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j];
                var sel = false;
                try { sel = c.isSelected(); } catch (e1) {}
                if (!sel) continue;
                var ip = 0, op = 0; try { ip = c.inPoint.seconds; op = c.outPoint.seconds; } catch (eIO) {}
                out.push({ name: c.name, path: c.projectItem ? C3D_itemPath(c.projectItem) : "", start: c.start.seconds, end: c.end.seconds, track: t, inPoint: ip, outPoint: op });
            }
        }
        return C3D_json({ ok: true, clips: out });
    } catch (e) { return C3D_err(e); }
}

function C3D_removeClipsByPrefix(prefix) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var minStart = 1e9, minTrack = 999, count = 0;
        for (var t = seq.videoTracks.numTracks - 1; t >= 0; t--) {
            var tr = seq.videoTracks[t];
            for (var j = tr.clips.numItems - 1; j >= 0; j--) {
                var c = tr.clips[j];
                if (String(c.name).indexOf(prefix) !== 0) continue;
                if (c.start.seconds < minStart) minStart = c.start.seconds;
                if (t < minTrack) minTrack = t;
                try { c.remove(false, false); count++; } catch (e1) {}
            }
        }
        return C3D_json({ ok: true, count: count, start: count ? minStart : -1, track: count ? minTrack : -1 });
    } catch (e) { return C3D_err(e); }
}

function C3D_setPlayhead(sec) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        seq.setPlayerPosition(String(Math.round(sec * C3D_TICKS_PER_SECOND)));
        return C3D_json({ ok: true });
    } catch (e) { return C3D_err(e); }
}


/* ========================================================================
   Payload transport: evalScript truncates long strings, so big payloads are
   written to a file by the panel and read here. Small ones arrive inline.
   ======================================================================== */
function C3D_parseJSON(s) {
    var i = 0, n = s.length;
    function ws() { while (i < n) { var c = s.charAt(i); if (c === " " || c === "\n" || c === "\r" || c === "\t") i++; else break; } }
    function str() {
        i++; var out = "";
        while (i < n) {
            var c = s.charAt(i++);
            if (c === '"') return out;
            if (c === "\\") {
                var e = s.charAt(i++);
                if (e === "n") out += "\n"; else if (e === "t") out += "\t"; else if (e === "r") out += "\r";
                else if (e === "u") { out += String.fromCharCode(parseInt(s.substr(i, 4), 16)); i += 4; }
                else out += e;
            } else out += c;
        }
        return out;
    }
    function val() {
        ws();
        var c = s.charAt(i);
        if (c === "{") {
            i++; var o = {}; ws();
            if (s.charAt(i) === "}") { i++; return o; }
            while (true) { ws(); var k = str(); ws(); i++; o[k] = val(); ws(); var d = s.charAt(i++); if (d === "}") return o; if (d !== ",") throw new Error("JSON: expected , at " + i); }
        }
        if (c === "[") {
            i++; var a = []; ws();
            if (s.charAt(i) === "]") { i++; return a; }
            while (true) { a.push(val()); ws(); var d2 = s.charAt(i++); if (d2 === "]") return a; if (d2 !== ",") throw new Error("JSON: expected , at " + i); }
        }
        if (c === '"') return str();
        if (s.substr(i, 4) === "true") { i += 4; return true; }
        if (s.substr(i, 5) === "false") { i += 5; return false; }
        if (s.substr(i, 4) === "null") { i += 4; return null; }
        var m = /^-?\d+(\.\d+)?([eE][+-]?\d+)?/.exec(s.substr(i, 40));
        if (!m) throw new Error("JSON: unexpected '" + c + "' at " + i);
        i += m[0].length;
        return parseFloat(m[0]);
    }
    return val();
}

function C3D_loadPayload(arg) {
    var text = String(arg);
    if (text.charAt(0) !== "{" && text.charAt(0) !== "[") {
        var f = new File(text);
        if (!f.exists) throw new Error("payload file missing: " + text);
        f.encoding = "UTF-8";
        if (!f.open("r")) throw new Error("cannot open payload: " + text);
        text = f.read();
        f.close();
    }
    try { return eval("(" + text + ")"); }
    catch (e) { return C3D_parseJSON(text); }
}

/* ========================================================================
   Native keyframe mode
   ======================================================================== */
function C3D_ensureTracks(needed) {
    var guard = 0;
    while (app.project.activeSequence.videoTracks.numTracks < needed && guard < 16) {
        if (!C3D_addVideoTrack(app.project.activeSequence)) return false;
        guard++;
    }
    return app.project.activeSequence.videoTracks.numTracks >= needed;
}

function C3D_importPath(path, bin) {
    var root = app.project.rootItem;
    var item = C3D_findItemByPath(root, path, 0);
    if (item) return item;
    app.project.importFiles([path], true, bin, false);
    item = C3D_findItemByPath(bin, path, 0);
    if (!item) item = C3D_findItemByPath(root, path, 0);
    return item;
}

function C3D_findClipAt(track, startSec) {
    var best = null, bd = 1e9;
    for (var j = 0; j < track.clips.numItems; j++) {
        var c = track.clips[j];
        var d = Math.abs(c.start.seconds - startSec);
        if (d < bd) { bd = d; best = c; }
    }
    return bd < 0.03 ? best : null;
}

function C3D_qeSecs(tobj) {
    try {
        if (tobj === undefined || tobj === null) return null;
        if (typeof tobj === "number") return tobj;
        if (tobj.secs !== undefined) return tobj.secs;
        if (tobj.seconds !== undefined) return tobj.seconds;
        if (tobj.ticks !== undefined) return parseFloat(tobj.ticks) / C3D_TICKS_PER_SECOND;
    } catch (e) {}
    return null;
}

function C3D_qeClipAt(qeSeq, trackIdx, startSec) {
    var tr = null;
    try { tr = qeSeq.getVideoTrackAt(trackIdx); } catch (e) {}
    if (!tr) return null;
    for (var k = 0; k < tr.numItems; k++) {
        var it = null;
        try { it = tr.getItemAt(k); } catch (e1) {}
        if (!it) continue;
        var ty = "";
        try { ty = String(it.type).toLowerCase(); } catch (e2) {}
        if (ty === "empty") continue;
        var s = C3D_qeSecs(it.start);
        if (s !== null && Math.abs(s - startSec) < 0.03) return it;
    }
    return null;
}

function C3D_qeAddEffect(qeClip, name) {
    var fx = null;
    try { fx = qe.project.getVideoEffectByName(name); } catch (e) {}
    if (!fx) return false;
    try { qeClip.addVideoEffect(fx); return true; } catch (e2) { return false; }
}

/* components are matched by display name (their order after QE is not reliable) */
function C3D_componentByName(clip, name) {
    for (var i = 0; i < clip.components.numItems; i++) {
        var n = "";
        try { n = String(clip.components[i].displayName); } catch (e) {}
        if (n === name) return clip.components[i];
    }
    return null;
}

function C3D_findComponents(clip) {
    var r = { motion: C3D_componentByName(clip, "Motion"), opacity: C3D_componentByName(clip, "Opacity") };
    for (var j = 0; j < clip.components.numItems && (!r.motion || !r.opacity); j++) {
        var cj = clip.components[j];
        if (cj === r.motion || cj === r.opacity) continue;
        var np = 0; try { np = cj.properties.numItems; } catch (e1) {}
        var v = null; try { v = cj.properties[0].getValue(); } catch (e2) {}
        if (!r.motion && np >= 5 && v && v.length === 2) { r.motion = cj; continue; }
        if (!r.opacity && np >= 1 && np <= 3 && typeof v === "number") { r.opacity = cj; continue; }
    }
    return r;
}

var C3D_KEYS_WRITTEN = 0;
/*  Keyframes: times are converted to whole ticks so addKey and setValueAtKey
    address exactly the same keyframe; updateUI is true (values do not stick
    otherwise in some builds); the keys are read back and counted.            */
function C3D_setKeys(param, keys, tOff, conv, warnings, label) {
    if (!param || !keys || !keys.length) return 0;
    try {
        if (keys.length === 1) { param.setValue(conv(keys[0]), true); return 0; }
        param.setTimeVarying(true);
        var n = 0;
        for (var i = 0; i < keys.length; i++) {
            var t = new Time();
            t.ticks = String(Math.round((keys[i][0] + tOff) * C3D_TICKS_PER_SECOND));
            try { param.addKey(t); } catch (e1) {}
            param.setValueAtKey(t, conv(keys[i]), true);
            n++;
        }
        var got = -1;
        try { var ks = param.getKeys(); got = ks ? ks.length : -1; } catch (e2) {}
        if (got === 0) { warnings.push(label + ": Premiere kept no keyframes (still media?)"); return 0; }
        var real = true;
        try { if (param.isTimeVarying && param.isTimeVarying() === false) real = false; } catch (e3) {}
        /* still media keeps the key list but never animates: compare the evaluated values at the first and last key */
        if (real && param.getValueAtTime) {
            try {
                var ea = String(conv(keys[0])), eb = String(conv(keys[keys.length - 1]));
                if (ea !== eb) {
                    var ta = new Time(); ta.ticks = String(Math.round((keys[0][0] + tOff) * C3D_TICKS_PER_SECOND));
                    var tb = new Time(); tb.ticks = String(Math.round((keys[keys.length - 1][0] + tOff) * C3D_TICKS_PER_SECOND));
                    var va = String(param.getValueAtTime(ta)), vb = String(param.getValueAtTime(tb));
                    if (va === vb) real = false;
                }
            } catch (e4) {}
        }
        if (!real) { warnings.push(label + ": keyframes ignored by Premiere (still media)"); return 0; }
        C3D_KEYS_WRITTEN += n;
        return n;
    } catch (e) { warnings.push(label + ": " + e); return 0; }
}

function C3D_isNormalized(posParam) {
    try { var v = posParam.getValue(); return (v && v.length === 2 && Math.abs(v[0]) <= 1.0001 && Math.abs(v[1]) <= 1.0001); } catch (e) {}
    return true;
}

/* Corner Pin points: detect whether the API wants pixels or 0..1 from the
   default Lower Right value ((w,h) in pixels or (1,1) normalised). */
function C3D_pinNormalized(pinComp) {
    try { var v = pinComp.properties[3].getValue(); return (v && v.length === 2 && v[0] <= 1.0001 && v[1] <= 1.0001); } catch (e) {}
    return true;
}

function C3D_seqById(id) {
    for (var i = 0; i < app.project.sequences.numSequences; i++) {
        var s = app.project.sequences[i];
        if (s.sequenceID === id) return s;
    }
    return null;
}

function C3D_clearSequence(seq) {
    var t, j;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        var vt = seq.videoTracks[t];
        for (j = vt.clips.numItems - 1; j >= 0; j--) { try { vt.clips[j].remove(false, false); } catch (e1) {} }
    }
    for (t = 0; t < seq.audioTracks.numTracks; t++) {
        var at = seq.audioTracks[t];
        for (j = at.clips.numItems - 1; j >= 0; j--) { try { at.clips[j].remove(false, false); } catch (e2) {} }
    }
}

/*  o = { duration, tracks, binName, track, nest, name }
    nest: build everything inside a fresh sequence (a cleared clone of the active
    one, so frame size / fps match) which C3D_nativeFinish drops on the timeline.  */
function C3D_nativeBegin(json) {
    try {
        C3D_NEST_CACHE = {};
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var root = app.project.rootItem;
        var bin = C3D_toolBin(o.binName);
        var start = seq.getPlayerPosition().seconds;
        var origId = seq.sequenceID;
        var warnings = [];
        if (o.nest) {
            var before = {}, i;
            for (i = 0; i < app.project.sequences.numSequences; i++) before[app.project.sequences[i].sequenceID] = true;
            var cloned = false;
            try { seq.clone(); cloned = true; } catch (e0) {}
            if (!cloned) {
                try { app.project.createNewSequence(o.name, "outflow_" + (new Date()).getTime()); warnings.push("Nested sequence uses your default sequence preset (Sequence.clone is not available)."); }
                catch (e1) { return C3D_err("Could not create the nested sequence: " + e1); }
            }
            var nested = null;
            for (i = 0; i < app.project.sequences.numSequences; i++) {
                var s = app.project.sequences[i];
                if (!before[s.sequenceID]) nested = s;
            }
            if (!nested) return C3D_err("Could not find the new nested sequence.");
            try { nested.name = o.name; } catch (e2) {}
            C3D_clearSequence(nested);
            app.project.openSequence(nested.sequenceID);
            if (!C3D_ensureTracks(o.tracks)) return C3D_err("Could not add enough video tracks in the nested sequence.");
            return C3D_json({ ok: true, base: 0, start: 0, seqId: nested.sequenceID, origId: origId, playhead: start, warnings: warnings });
        }
        var base = (o.track >= 0) ? o.track : C3D_findFreeTrack(seq, start, start + o.duration);
        if (!C3D_ensureTracks(base + o.tracks)) return C3D_err("Could not add enough video tracks (" + (base + o.tracks) + " needed).");
        return C3D_json({ ok: true, base: base, start: start, seqId: origId, origId: origId, playhead: start, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/*  o = { origId, seqId, start, track, duration }: reopen the original sequence and
    place the nested sequence at the playhead position recorded at begin.        */
function C3D_nativeFinish(json) {
    try {
        var o = C3D_loadPayload(json);
        var nested = C3D_seqById(o.seqId);
        if (!nested) return C3D_err("Nested sequence not found.");
        app.project.openSequence(o.origId);
        var seq = app.project.activeSequence;
        if (!seq || seq.sequenceID !== o.origId) { seq = C3D_seqById(o.origId); }
        if (!seq) return C3D_err("Original sequence not found.");
        var item = null;
        try { item = nested.projectItem; } catch (e0) {}
        if (!item) {
            var root = app.project.rootItem;
            for (var i = 0; i < root.children.numItems; i++) {
                var c = root.children[i];
                var isSeq = false; try { isSeq = c.isSequence(); } catch (e1) {}
                if (isSeq && c.name === nested.name) { item = c; break; }
            }
        }
        if (!item) return C3D_err("Project item of the nested sequence not found.");
        var dur = o.duration;
        try { var endTicks = parseFloat(nested.end); if (endTicks > 0) dur = endTicks / C3D_TICKS_PER_SECOND; } catch (e2) {}
        var start = o.start;
        var idx = (o.track >= 0) ? o.track : C3D_findFreeTrack(seq, start, start + dur);
        var guard = 0;
        while (idx >= app.project.activeSequence.videoTracks.numTracks && guard < 4) {
            if (!C3D_addVideoTrack(app.project.activeSequence)) return C3D_err("No empty video track above your footage. Add one and try again.");
            guard++;
        }
        seq = app.project.activeSequence;
        var track = seq.videoTracks[idx];
        var placed = false;
        try { placed = track.overwriteClip(item, start); } catch (e3) {}
        if (!placed) { try { var tm = new Time(); tm.seconds = start; placed = track.overwriteClip(item, tm); } catch (e4) {} }
        if (!placed) return C3D_err("Could not place the nested sequence on V" + (idx + 1));
        try { seq.setPlayerPosition(String(Math.round(start * C3D_TICKS_PER_SECOND))); } catch (e5) {}
        return C3D_json({ ok: true, track: idx, start: start });
    } catch (e) { return C3D_err(e); }
}

/*  o = { path, name, isVideo, binName, base, start, width, height, crop,
          fx: { basic3d, blur, brightKeys, bright, sat }, pieces: [...] }          */
var C3D_NEST_CACHE = {};
function C3D_nativeCard(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var root = app.project.rootItem;
        var bin = C3D_toolBin(o.binName) || root;
        var item = C3D_importPath(o.path, bin);
        if (!item) return C3D_err("Could not import " + o.path);
        var warnings = [], placed = 0;
        /* Premiere ignores scripted keyframes on stills: image cards go into a nested sequence
           (one per image, reused for every piece) so the placed clip is video-type */
        if (!o.isVideo) {
            var maxE = 0;
            for (var q = 0; q < o.pieces.length; q++) if (o.pieces[q].e > maxE) maxE = o.pieces[q].e;
            var cached = C3D_NEST_CACHE[o.path];
            var cachedOk = false; try { cachedOk = cached && cached.name !== undefined; } catch (ec) {}
            if (!cachedOk) {
                cached = TL_nestStill(seq, item, maxE + 1, (o.name || "Card") + " still");
                if (cached) { try { cached.moveBin(bin); } catch (em) {} C3D_NEST_CACHE[o.path] = cached; }
                else warnings.push("could not nest the still; keyframes may be ignored");
                seq = app.project.activeSequence;
            }
            if (cached) item = cached;
        }
        var qeSeq = null;
        try { app.enableQE(); qeSeq = qe.project.getActiveSequence(); } catch (e0) {}

        for (var k = 0; k < o.pieces.length; k++) {
            var p = o.pieces[k];
            var tIdx = o.base + p.track;
            seq = app.project.activeSequence;
            if (tIdx >= seq.videoTracks.numTracks) { warnings.push("track V" + (tIdx + 1) + " missing"); continue; }
            var track = seq.videoTracks[tIdx];
            var s = o.start + p.s, e = o.start + p.e;
            var ok = false;
            try { ok = track.overwriteClip(item, s); } catch (e1) {}
            if (!ok) { try { var tm = new Time(); tm.seconds = s; ok = track.overwriteClip(item, tm); } catch (e2) {} }
            if (!ok) { warnings.push("piece " + k + " not placed on V" + (tIdx + 1)); continue; }
            var clip = C3D_findClipAt(track, s);
            if (!clip) { warnings.push("piece " + k + " placed but not found"); continue; }
            try { clip.name = o.name; } catch (e3) {}
            /* trim to the piece */
            try {
                if (o.isVideo) {
                    var ip = new Time(); ip.seconds = p.mediaIn;
                    var op = new Time(); op.seconds = p.mediaIn + (e - s);
                    clip.inPoint = ip; clip.outPoint = op;
                    var st = new Time(); st.seconds = s; clip.start = st;
                }
                var en = new Time(); en.seconds = e; clip.end = en;
                if (Math.abs(clip.end.seconds - e) > 0.05) warnings.push("piece " + k + " length could not be set (" + clip.end.seconds.toFixed(2) + " vs " + e.toFixed(2) + ")");
            } catch (e4) { warnings.push("trim: " + e4); }
            /* effects through QE, then matched back by display name */
            var qeClip = qeSeq ? C3D_qeClipAt(qeSeq, tIdx, s) : null;
            var want = [];
            if (o.fx.basic3d) want.push("Basic 3D");
            if (o.fx.cornerpin) want.push("Corner Pin");
            if (o.fx.blur) want.push("Gaussian Blur");
            if (o.crop) want.push("Crop");
            if (o.fx.brightKeys || o.fx.bright !== undefined) want.push("Brightness & Contrast");
            if (o.fx.sat !== undefined) want.push("Color Balance (HLS)");
            if (qeClip) {
                for (var w = 0; w < want.length; w++) {
                    if (!C3D_qeAddEffect(qeClip, want[w])) warnings.push(want[w] + " effect not found");
                }
            } else if (k === 0) warnings.push("QE clip lookup failed: effects skipped");
            clip = C3D_findClipAt(app.project.activeSequence.videoTracks[tIdx], s) || clip;
            var comps = C3D_findComponents(clip);
            var tOff = -p.s + (o.isVideo ? p.mediaIn : 0);
            var num = function (kk) { return kk[1]; };
            if (comps.motion) {
                var pos = comps.motion.properties[0];
                var norm = C3D_isNormalized(pos);
                var W = o.width, H = o.height;
                C3D_setKeys(pos, p.keys.pos, tOff, function (kk) { return norm ? [kk[1] / W, kk[2] / H] : [kk[1], kk[2]]; }, warnings, "position");
                C3D_setKeys(comps.motion.properties[1], p.keys.scale, tOff, num, warnings, "scale");
                C3D_setKeys(comps.motion.properties[4], p.keys.rot, tOff, num, warnings, "rotation");
                if (o.fx.scale2d && p.keys.scaleW) {
                    try { comps.motion.properties[3].setValue(false, true); } catch (e9) { warnings.push("uniform scale: " + e9); }
                    C3D_setKeys(comps.motion.properties[2], p.keys.scaleW, tOff, num, warnings, "scale width");
                }
            } else if (k === 0) warnings.push("Motion component not found");
            var cpin = o.fx.cornerpin ? C3D_componentByName(clip, "Corner Pin") : null;
            if (cpin && p.keys.pin) {
                var pn = C3D_pinNormalized(cpin);
                var sw = o.srcW, shh = o.srcH;
                var mkConv = function (ix) { return function (kk) { var x = kk[1 + ix * 2], y = kk[2 + ix * 2]; return pn ? [x / sw, y / shh] : [x, y]; }; };
                for (var ci = 0; ci < 4; ci++) C3D_setKeys(cpin.properties[ci], p.keys.pin, tOff, mkConv(ci), warnings, "corner pin");
            }
            if (comps.opacity) C3D_setKeys(comps.opacity.properties[0], p.keys.opac, tOff, num, warnings, "opacity");
            var c3 = o.fx.basic3d ? C3D_componentByName(clip, "Basic 3D") : null;
            if (c3) {
                C3D_setKeys(c3.properties[0], p.keys.swivel, tOff, num, warnings, "swivel");
                C3D_setKeys(c3.properties[1], p.keys.tilt, tOff, num, warnings, "tilt");
            }
            var cb = o.fx.blur ? C3D_componentByName(clip, "Gaussian Blur") : null;
            if (cb) {
                C3D_setKeys(cb.properties[0], p.keys.blur, tOff, num, warnings, "blur");
                try { cb.properties[2].setValue(true, true); } catch (e5) {}
            }
            var cc = o.crop ? C3D_componentByName(clip, "Crop") : null;
            if (cc) {
                try { cc.properties[0].setValue(o.crop.l, true); cc.properties[1].setValue(o.crop.t, true); cc.properties[2].setValue(o.crop.r, true); cc.properties[3].setValue(o.crop.b, true); } catch (e6) { warnings.push("crop: " + e6); }
            }
            var bc = (o.fx.brightKeys || o.fx.bright !== undefined) ? C3D_componentByName(clip, "Brightness & Contrast") : null;
            if (bc) {
                if (o.fx.brightKeys) C3D_setKeys(bc.properties[0], p.keys.bright, tOff, num, warnings, "brightness");
                else { try { bc.properties[0].setValue(o.fx.bright, true); } catch (e7) { warnings.push("brightness: " + e7); } }
            }
            var cs = (o.fx.sat !== undefined) ? C3D_componentByName(clip, "Color Balance (HLS)") : null;
            if (cs) { try { cs.properties[2].setValue(o.fx.sat, true); } catch (e8) { warnings.push("saturation: " + e8); } }
            placed++;
        }
        return C3D_json({ ok: true, placed: placed, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}


/*  o = { track, start, end }: switches off the video of the clip(s) on that track inside the range. Linked audio stays. */
function MT_disableVideo(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var tr = seq.videoTracks[o.track];
        if (!tr) return C3D_err("Track V" + (o.track + 1) + " not found.");
        var n = 0, eps = 0.5 / AS_fps(seq);
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j];
            if (c.start.seconds < o.end - eps && c.end.seconds > o.start + eps) { try { c.disabled = true; n++; } catch (e1) {} }
        }
        return C3D_json({ ok: true, disabled: n });
    } catch (e) { return C3D_err(e); }
}
