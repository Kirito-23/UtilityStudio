/* Word Captions: transcript (SRT / VTT / Whisper API) -> animated captions rendered
   as transparent PNG clips, one clip per phrase. */
const Captions = (() => {
  const tc = (s) => { const m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(s); if (!m) return null; return (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / Math.pow(10, m[4].length); };

  function parseSubtitles(text) {
    const cues = [];
    const blocks = text.replace(/\r/g, '').split(/\n\n+/);
    for (const b of blocks) {
      const lines = b.split('\n').filter(l => l.trim());
      const ti = lines.findIndex(l => /-->/.test(l));
      if (ti < 0) continue;
      const [a, bb] = lines[ti].split('-->');
      const s = tc(a.trim()), e = tc(bb.trim().split(' ')[0]);
      if (s === null || e === null) continue;
      const txt = lines.slice(ti + 1).join(' ').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
      if (txt) cues.push({ s, e, text: txt });
    }
    return cues;
  }

  /* spread word timings across each cue by character weight */
  function cuesToWords(cues) {
    const words = [];
    for (const c of cues) {
      const ws = c.text.split(' ').filter(Boolean);
      const total = ws.reduce((a, w) => a + w.length + 1, 0);
      let t = c.s;
      ws.forEach((w, i) => {
        const d = (c.e - c.s) * (w.length + 1) / total;
        words.push({ s: t, e: t + d, w, brk: i === ws.length - 1 });
        t += d;
      });
    }
    return words;
  }

  /* OpenAI Whisper with word timestamps. wavBuf: 16 kHz mono WAV Buffer. */
  function whisper(wavBuf, key, language) {
    const nodeReq = (window.cep_node && window.cep_node.require) || window.require;
    const https = nodeReq('https');
    const Buf = window.Buffer || window.cep_node.Buffer;
    const boundary = '----OutflowStudio' + Date.now().toString(36);
    const field = (n, v) => Buf.from('--' + boundary + '\r\nContent-Disposition: form-data; name="' + n + '"\r\n\r\n' + v + '\r\n');
    const parts = [field('model', 'whisper-1'), field('response_format', 'verbose_json'), field('timestamp_granularities[]', 'word')];
    if (language) parts.push(field('language', language));
    parts.push(Buf.from('--' + boundary + '\r\nContent-Disposition: form-data; name="file"; filename="audio.wav"\r\nContent-Type: audio/wav\r\n\r\n'), wavBuf, Buf.from('\r\n--' + boundary + '--\r\n'));
    const body = Buf.concat(parts);
    return new Promise((resolve, reject) => {
      const req = https.request({ hostname: 'api.openai.com', path: '/v1/audio/transcriptions', method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'multipart/form-data; boundary=' + boundary, 'Content-Length': body.length } }, (res) => {
        const chunks = []; res.on('data', c => chunks.push(c));
        res.on('end', () => {
          const txt = Buf.concat(chunks).toString('utf8');
          if (res.statusCode >= 400) return reject(new Error('Whisper: HTTP ' + res.statusCode + ' ' + txt.slice(0, 200)));
          try {
            const d = JSON.parse(txt);
            const words = (d.words || []).map(w => ({ s: w.start, e: w.end, w: w.word.trim() })).filter(w => w.w);
            resolve({ words, text: d.text || '' });
          } catch (e) { reject(new Error('Whisper: bad response')); }
        });
      });
      req.on('error', reject);
      req.setTimeout(600000, () => req.destroy(new Error('Whisper request timed out')));
      req.write(body); req.end();
    });
  }

  function groupWords(words, maxWords, maxGap) {
    const phrases = [];
    let cur = null;
    for (const w of words) {
      const punct = /[.!?]$/.test(w.w);
      if (!cur || cur.words.length >= maxWords || w.s - cur.e > maxGap) { cur = { s: w.s, e: w.e, words: [] }; phrases.push(cur); }
      cur.words.push(w); cur.e = w.e;
      if ((punct && cur.words.length >= 2) || w.brk) cur = null;
    }
    for (let i = 0; i < phrases.length; i++) {
      const p = phrases[i], next = phrases[i + 1];
      /*  How long a caption stays up after its last word. Word ends used to run on to the next word, so
          this was always the 0.05 floor and captions swapped instantly. Now that the ends are real, a
          short pause has to be held through or the screen blinks empty between every caption; a long
          silence still clears it.                                                                     */
      p.hold = next ? Math.min(1.2, Math.max(0.05, next.s - p.e)) : 0.6;
    }
    return phrases;
  }

  const STYLES = {
    pop:     { name: 'Pop in', desc: 'each word pops in' },
    karaoke: { name: 'Karaoke', desc: 'active word changes colour' },
    box:     { name: 'Highlight box', desc: 'box behind the active word' },
    slide:   { name: 'Slide up', desc: 'words slide in from below' },
    type:    { name: 'Typewriter', desc: 'letters appear one by one' },
    bounce:  { name: 'Bounce', desc: 'active word bounces' },
    fade:    { name: 'Fade', desc: 'whole phrase fades' },
    glow:    { name: 'Glow', desc: 'active word glows' },
    scaleUp: { name: 'Scale word', desc: 'active word grows' },
    blur:    { name: 'Blur in', desc: 'words sharpen as spoken' },
    flip:    { name: 'Flip in', desc: 'words flip in vertically' },
    wave:    { name: 'Wave', desc: 'gentle wave across the phrase' }
  };
  /*  The look from short-form: the phrase sits small and white, and the one word that carries it goes
      large, coloured and glowing on its own line. A preset is only a bundle of the settings below -
      pick one, then change anything you like. `hero` is what turns the big word on.                  */
  const PRESETS = [
    { id: 'gold',   name: 'Gold',         set: { hi: '#ffc42e', glowSize: 0,    glowStrength: 0,   stroke: 0.5,  italic: 0, upper: 0, heroUpper: 1, style: 'pop' } },
    { id: 'orange', name: 'Orange',       set: { hi: '#ff7a1a', glowSize: 0.22, glowStrength: 0.7, stroke: 0.45, italic: 0, upper: 0, heroUpper: 1, style: 'pop' } },
    { id: 'neon',   name: 'Neon green',   set: { hi: '#4dff5e', glowSize: 0.55, glowStrength: 1.5, stroke: 0.22, italic: 0, upper: 0, heroUpper: 1, style: 'scaleUp' } },
    { id: 'white',  name: 'White',        set: { hi: '#ffffff', glowSize: 0,    glowStrength: 0,   stroke: 0.55, italic: 0, upper: 0, heroUpper: 0, style: 'pop' } },
    { id: 'red',    name: 'Red',          set: { hi: '#ff2323', glowSize: 0.42, glowStrength: 1.1, stroke: 0.3,  italic: 0, upper: 0, heroUpper: 0, style: 'bounce' } },
    { id: 'pink',   name: 'Magenta',      set: { hi: '#ff2fd0', glowSize: 0.48, glowStrength: 1.3, stroke: 0.25, italic: 0, upper: 0, heroUpper: 0, style: 'pop' } },
    { id: 'cyan',   name: 'Cyan',         set: { hi: '#22e0ff', glowSize: 0.3,  glowStrength: 0.9, stroke: 0.3,  italic: 0, upper: 1, heroUpper: 1, style: 'slide' } },
    { id: 'yellow', name: 'Yellow slant', set: { hi: '#ffd400', glowSize: 0.26, glowStrength: 0.8, stroke: 0.35, italic: 1, upper: 0, heroUpper: 0, style: 'pop' } }
  ];
  /* everything a preset shares: the big word itself, the heavy outline and the tight stack */
  const PRESET_BASE = { output: 'png', hero: 1, heroScale: 1.8, color: '#ffffff', font: 'Arial Black', weight: 900,
                        size: 6.0, strokeColor: '#000000', shadow: 0.85, y: 62, maxWords: 5, gap: 0.7,
                        anim: 0.16, lineBg: 0 };
  const applyPreset = (st, id) => {
    const pr = PRESETS.find((x) => x.id === id);
    if (pr) Object.assign(st, PRESET_BASE, pr.set, { preset: id });
    return st;
  };

  /*  Which word carries the phrase. Money and numbers win ("$10M"), then the longest word that is not
      one of the small joining words - those are never the point of the sentence.                      */
  const SMALL_WORDS = { the: 1, a: 1, an: 1, and: 1, or: 1, but: 1, if: 1, of: 1, to: 1, in: 1, on: 1, at: 1, as: 1,
                        is: 1, it: 1, be: 1, for: 1, you: 1, your: 1, my: 1, me: 1, we: 1, i: 1, so: 1, do: 1,
                        not: 1, with: 1, was: 1, are: 1, that: 1, they: 1, from: 1, have: 1, has: 1 };
  function heroIndex(words) {
    let best = -1, score = -Infinity;
    for (let i = 0; i < words.length; i++) {
      const raw = String(words[i].w || '');
      const t = raw.replace(/[^A-Za-z0-9$%]/g, '');
      if (!t) continue;
      let sc = t.length;
      if (/[0-9]/.test(t)) sc += 6;
      if (/^[$]/.test(raw)) sc += 4;
      if (/[!?]$/.test(raw)) sc += 2;
      if (SMALL_WORDS[t.toLowerCase()]) sc -= 6;
      if (sc > score) { score = sc; best = i; }
    }
    return best;
  }

  const DEFAULT_STYLE = { style: 'pop', font: 'Arial Black', size: 6.5, weight: 900, color: '#ffffff', hi: '#ffd166', stroke: 0.35, strokeColor: '#000000', shadow: 0.5, upper: true, y: 78, maxWords: 4, gap: 0.8, boxColor: '#ff3b6b', lineBg: 0, lineBgColor: '#000000', anim: 0.18,
    /* the big-word look, off unless a preset turns it on */
    hero: 0, heroScale: 1.8, heroUpper: 1, glowSize: 0.45, glowStrength: 1, italic: 0, preset: '' };

  const easeOutBack = (x) => 1 + 2.70158 * Math.pow(x - 1, 3) + 1.70158 * Math.pow(x - 1, 2);
  const clamp01 = (x) => Math.max(0, Math.min(1, x));

  /*  Draws one frame (time t, absolute seconds) of a phrase into ctx (W x H).
      Every word carries its own size, so the hero word can be far bigger than the rest of the line. */
  function drawFrame(g, W, H, phrase, t, st) {
    g.clearRect(0, 0, W, H);
    const basePx = H * st.size / 100;
    const italic = st.italic ? 'italic ' : '';
    const setFont = (px) => { g.font = italic + st.weight + ' ' + px + 'px "' + st.font + '", Arial, sans-serif'; };
    g.textBaseline = 'middle'; g.textAlign = 'left';
    /* worked out once per phrase and kept: it must not flicker between frames */
    const hero = st.hero ? (phrase.hero === undefined ? (phrase.hero = heroIndex(phrase.words)) : phrase.hero) : -1;
    const words = phrase.words.map((w, i) => {
      const isHero = i === hero;
      let txt = w.w;
      if (st.upper || (isHero && st.heroUpper)) txt = txt.toUpperCase();
      return { w: txt, s: w.s, e: w.e, hero: isHero, px: basePx * (isHero ? st.heroScale : 1) };
    });
    /*  A word stays the "active" one until the NEXT word starts, not until its own end. Word ends are
        real now (they used to run on to the next word), so keying the highlight off them would make it
        blink for a third of a second and drop back mid-sentence.                                     */
    words.forEach((w, i) => { w.until = i + 1 < words.length ? words[i + 1].s : Math.max(w.e, phrase.e) + 0.25; });
    const space = basePx * 0.28;
    const maxW = W * 0.86;
    for (const w of words) { setFont(w.px); w.width = g.measureText(w.w).width; }
    /* the hero word takes a line of its own; the rest wrap as they always did */
    const lines = []; let cur = [];
    const flush = () => { if (cur.length) { lines.push(cur); cur = []; } };
    for (const w of words) {
      if (w.hero) { flush(); lines.push([w]); continue; }
      const lw = cur.reduce((a, x) => a + x.width + space, 0);
      if (cur.length && lw + w.width > maxW) flush();
      cur.push(w);
    }
    flush();
    if (!lines.length) return;
    /*  Wrapping only ever breaks BETWEEN words, and the big word has a line to itself - so a long one
        ("BOOKKEEPER" at 1.8x on a vertical frame) simply ran off both edges. Any line wider than the
        frame is scaled down until it fits, which is also why the reference look has a huge short word
        and a smaller long one.                                                                       */
    for (const line of lines) {
      const total = line.reduce((a, w) => a + w.width, 0) + space * (line.length - 1);
      if (total > maxW) {
        const k = maxW / total;
        for (const w of line) { w.px *= k; w.width *= k; }
        line.space = space * k;
      }
    }
    const heights = lines.map((line) => Math.max.apply(null, line.map((w) => w.px)) * 1.12);
    const totalH = heights.reduce((a, b) => a + b, 0);
    const phraseIn = clamp01((t - phrase.s) / st.anim), phraseOut = clamp01((phrase.e + phrase.hold - t) / 0.15);
    const globalA = (st.style === 'fade') ? Math.min(phraseIn, phraseOut) : phraseOut;
    if (globalA <= 0) return;
    g.globalAlpha = globalA;
    let y = H * st.y / 100 - totalH / 2 + heights[0] / 2;
    lines.forEach((line, li) => {
      const sp = line.space || space;
      const total = line.reduce((a, w) => a + w.width, 0) + sp * (line.length - 1);
      let x = (W - total) / 2;
      if (st.lineBg > 0) {
        g.save(); g.globalAlpha = globalA * st.lineBg; g.fillStyle = st.lineBgColor;
        rr(g, x - basePx * 0.35, y - heights[li] * 0.55, total + basePx * 0.7, heights[li] * 1.1, basePx * 0.25); g.fill(); g.restore();
      }
      for (const w of line) {
        const p = clamp01((t - w.s) / st.anim);
        const active = t >= w.s && t < w.until;
        const spoken = t >= w.s;
        const fontPx = w.px;
        let sc = 1, dy = 0, dx = 0, alpha = 1, color = st.color, blurPx = 0, visibleChars = w.w.length, sy = 1;
        /* in the big-word presets the colour is decided by which word it is, not by which is being said */
        if (st.hero) color = w.hero ? st.hi : st.color;
        switch (st.style) {
          case 'pop': sc = spoken ? easeOutBack(p) : 0; alpha = spoken ? Math.min(1, p * 2) : 0; if (active && !st.hero) color = st.hi; break;
          case 'karaoke': if (!st.hero) color = spoken ? st.hi : st.color; if (!spoken) alpha = 0.85; break;
          case 'box': if (!st.hero) color = active ? '#ffffff' : st.color; break;
          case 'slide': dy = spoken ? (1 - easeOutBack(p)) * fontPx * 0.8 : fontPx; alpha = spoken ? Math.min(1, p * 2) : 0; if (active && !st.hero) color = st.hi; break;
          case 'type': visibleChars = spoken ? Math.ceil(p * w.w.length) : 0; if (active && !st.hero) color = st.hi; break;
          case 'bounce': dy = active ? -Math.abs(Math.sin(Math.min(1, (t - w.s) / 0.35) * Math.PI)) * fontPx * 0.25 : 0; if (active && !st.hero) color = st.hi; break;
          case 'fade': if (active && !st.hero) color = st.hi; break;
          case 'glow': if (active && !st.hero) color = st.hi; break;
          case 'scaleUp': sc = active ? 1 + 0.18 * Math.sin(Math.min(1, (t - w.s) / 0.3) * Math.PI) : 1; if (active && !st.hero) color = st.hi; break;
          case 'blur': blurPx = spoken ? (1 - p) * fontPx * 0.25 : fontPx * 0.25; alpha = spoken ? 0.4 + 0.6 * p : 0.4; if (active && !st.hero) color = st.hi; break;
          case 'flip': sy = spoken ? Math.max(0.02, easeOutBack(p)) : 0.02; alpha = spoken ? 1 : 0; if (active && !st.hero) color = st.hi; break;
          case 'wave': dy = Math.sin(t * 5 + x * 0.02) * fontPx * 0.06; if (active && !st.hero) color = st.hi; break;
        }
        if (alpha > 0 && sc > 0 && visibleChars > 0) {
          g.save();
          g.globalAlpha = globalA * alpha;
          g.translate(x + dx + w.width / 2, y + dy);
          g.scale(sc, sy);
          setFont(fontPx);
          if (blurPx > 0.3) g.filter = 'blur(' + blurPx + 'px)';
          if (st.style === 'box' && active && !st.hero) { g.fillStyle = st.boxColor; rr(g, -w.width / 2 - fontPx * 0.18, -fontPx * 0.62, w.width + fontPx * 0.36, fontPx * 1.24, fontPx * 0.18); g.fill(); }
          const txt = w.w.slice(0, visibleChars);
          /*  The halo first, underneath everything. Several passes at growing radius read as light coming
              off the letter; one pass at a big radius reads as a smudge. The letter, its outline and its
              drop shadow then go on top, so the edge stays crisp however strong the glow is.            */
          if (w.hero && st.glowSize > 0 && st.glowStrength > 0) {
            g.save();
            g.fillStyle = color; g.shadowColor = color; g.shadowOffsetX = 0; g.shadowOffsetY = 0;
            const passes = Math.max(1, Math.min(4, Math.round(st.glowStrength * 2)));
            for (let i = 1; i <= passes; i++) {
              g.globalAlpha = globalA * alpha * Math.min(1, 0.3 + 0.35 * st.glowStrength);
              g.shadowBlur = fontPx * st.glowSize * (i / passes);
              g.fillText(txt, -w.width / 2, 0);
            }
            g.restore();
          }
          if (st.shadow > 0) { g.shadowColor = 'rgba(0,0,0,' + (0.9 * st.shadow) + ')'; g.shadowBlur = fontPx * 0.25 * st.shadow; g.shadowOffsetY = fontPx * 0.06 * st.shadow; }
          if (st.style === 'glow' && active && !st.hero) { g.shadowColor = st.hi; g.shadowBlur = fontPx * 0.6; }
          if (st.stroke > 0) { g.lineJoin = 'round'; g.lineWidth = fontPx * 0.12 * st.stroke; g.strokeStyle = st.strokeColor; g.strokeText(txt, -w.width / 2, 0); }
          g.shadowColor = 'transparent';
          g.fillStyle = color;
          g.fillText(txt, -w.width / 2, 0);
          g.restore();
        }
        x += w.width + sp;
      }
      y += heights[li];
    });
    g.globalAlpha = 1;
  }
  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  /* renders every phrase to its own PNG sequence and places it on one captions track */
  async function render(phrases, st, info, ui, onCancel) {
    const W = info.width, H = info.height, fps = info.fps;
    const paths = await CS.call('OS_getPaths');
    const base = (paths.ok && (paths.projectDir || paths.documents)) || CS.os.homedir();
    const dir = CS.path.join(base, 'OutflowStudio', 'captions', 'cap_' + Date.now().toString(36));
    CS.mkdirp(dir);
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const g = cv.getContext('2d');
    let track = -1, placed = 0, drift = 0, rateWarn = false;
    for (let i = 0; i < phrases.length; i++) {
      if (onCancel && onCancel()) throw new Error('Cancelled');
      const ph = phrases[i];
      const f0 = Math.floor(ph.s * fps), f1 = Math.ceil((ph.e + ph.hold) * fps);
      const sub = CS.path.join(dir, 'p' + String(i + 1).padStart(4, '0'));
      CS.mkdirp(sub);
      let first = null;
      const pending = [];
      for (let f = f0; f <= f1; f++) {
        drawFrame(g, W, H, ph, f / fps, st);
        const file = CS.path.join(sub, 'c_' + String(f - f0).padStart(5, '0') + '.png');
        if (!first) first = file;
        const img = g.getImageData(0, 0, W, H);
        pending.push(Exporter.writePNGStraight(file, img.data, W, H));
        if (pending.length >= 4) await pending.shift();
      }
      await Promise.all(pending);
      ui.title('Captions ' + (i + 1) + ' / ' + phrases.length); ui.progress((i + 1) / phrases.length, ph.words.map(w => w.w).join(' '));
      const want = f0 / fps;
      const r = await CS.call('AS_placeAt', JSON.stringify({ firstFile: first, fps, par: info.par || 1, duration: (f1 - f0 + 1) / fps, track, start: want, name: 'Caption ' + (i + 1) + ' ' + ph.words.map(w => w.w).join(' ').slice(0, 30), bin: 'Outflow Captions' }));
      if (!r.ok) throw new Error(r.error);
      /* say so rather than letting it slide: half a frame is invisible, anything more is not */
      if (r.start !== undefined && Math.abs(r.start - want) > 0.6 / fps) drift = Math.max(drift, Math.abs(r.start - want));
      if (r.rate === false) rateWarn = true;
      track = r.track; placed++;
    }
    return { placed, track, dir, drift, rateWarn };
  }

  return { parseSubtitles, cuesToWords, whisper, groupWords, STYLES, PRESETS, PRESET_BASE, applyPreset, heroIndex, DEFAULT_STYLE, drawFrame, render };
})();
