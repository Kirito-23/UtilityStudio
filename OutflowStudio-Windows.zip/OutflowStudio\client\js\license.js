/* Licensing: login through the website, entitlements from the API, encrypted cache,
   offline grace, tool gating with the gold "Unlock" badge, free export counters.
   The API contract lives in docs/LICENSING.md; tools/license-dev-server.js fakes it. */
const License = (() => {
  const $ = (s) => document.querySelector(s);
  const CFG = () => window.OUTFLOW || {};
  const API = () => (CFG().api || '').replace(/\/$/, '');
  const GRACE_MS = 7 * 86400e3, POLL_MS = 3000, POLL_MAX_MS = 10 * 60e3;
  /* which tools need Pro; everything else is free (with export counters on carousel / transitions) */
  const PRO_TOOLS = { assist: 'Auto Edit', audioai: 'Audio edit', relight: 'Relight', matte: 'Remove background' };
  /*  The tools above are locked outright; the carousel, transitions, Motion Curves, Zoom Montage and
      Download media are Pro but hand out FREE_EXPORTS free ones first - three per account, for ever, not
      per month. The count that decides lives on the server (see the /trial function): the copy below is a
      mirror so the panel still works offline, and it is a file on the user's own machine.                 */
  const FREE_EXPORTS = 3;
  const TRIAL_TOOLS = ['carousel', 'transitions', 'curves', 'montage', 'social', 'mask'];
  /* what one of them is called, where "export" would read oddly */
  const TRIAL_WORD = { social: 'download', mask: 'mask' };
  let trialSync = null;
  let lic = null;      /* { token, email, plan, status, features, seats, portalUrl, pricingUrl, affiliate, exp, checkedAt } */
  let polling = null;

  const store = () => { try { return Hub.keys(); } catch (e) { return {}; } };
  const save = () => { try { store().license = lic; Hub.saveKeys(); } catch (e) {} };
  const load = () => { try { lic = store().license || null; } catch (e) { lic = null; } };

  function deviceId() {
    const k = store();
    if (k.deviceId) return k.deviceId;
    let seed = '';
    try { const os = (window.cep_node && window.cep_node.require ? window.cep_node.require('os') : (typeof require === 'function' ? require('os') : null)); if (os) seed = os.hostname() + '|' + (os.userInfo().username || ''); } catch (e) {}
    if (!seed) seed = navigator.userAgent + '|' + Math.random();
    let h = 2166136261; for (let i = 0; i < seed.length; i++) { h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    k.deviceId = 'dev_' + h.toString(16) + '_' + Math.random().toString(36).slice(2, 8);
    try { Hub.saveKeys(); } catch (e) {}
    return k.deviceId;
  }
  async function api(path, opt) {
    if (!API()) throw new Error('No licence server configured.');
    const headers = Object.assign({ 'Content-Type': 'application/json' }, (opt && opt.headers) || {});
    if (lic && lic.token && !(opt && opt.noAuth)) headers.Authorization = 'Bearer ' + lic.token;
    const r = await fetch(API() + path, { method: (opt && opt.method) || 'GET', headers, body: opt && opt.body ? JSON.stringify(opt.body) : undefined });
    const text = await r.text();
    let j = {}; try { j = JSON.parse(text || '{}'); } catch (e) { j = { error: text.slice(0, 200) }; }
    if (!r.ok) { const err = new Error(j.error || ('HTTP ' + r.status)); err.status = r.status; throw err; }
    return j;
  }

  /* ---- state ---- */
  const isPro = () => !!(lic && lic.token && lic.status === 'active' && lic.features && lic.features.includes('all') && fresh());
  const fresh = () => !!(lic && lic.checkedAt && Date.now() - lic.checkedAt < GRACE_MS);
  const plan = () => (lic && lic.token) ? (isPro() ? lic.plan : 'free') : 'free';
  const loggedIn = () => !!(lic && lic.token && lic.email);
  const hasTool = (tool) => isPro() || !!(lic && lic.token && fresh() && lic.features && lic.features.includes(tool));
  const can = (tool) => !PRO_TOOLS[tool] || isPro();
  const pricingUrl = (tool) => { const base = (lic && lic.pricingUrl) || (CFG().site || '') + (CFG().pricing || '/pricing'); const ref = lic && lic.affiliate && lic.affiliate.code ? '&ref=' + encodeURIComponent(lic.affiliate.code) : ''; return base + (base.includes('?') ? '&' : '?') + 'utm_source=panel&utm_medium=unlock' + (tool ? '&tool=' + encodeURIComponent(tool) : '') + ref; };

  /* ---- login through the browser: the site confirms the code, the panel polls ---- */
  async function login(onStatus) {
    const note = (t) => { if (onStatus) onStatus(t); };
    const start = await api('/link-start', { method: 'POST', noAuth: true, body: { device: { id: deviceId(), name: (() => { try { return window.cep_node.require('os').hostname(); } catch (e) { return 'this computer'; } })(), app: 'premiere', version: CFG().version || '1.0' } } });
    CS.openURL(start.url);
    note('Waiting for you to log in in the browser…');
    Log.info('license', 'link started', { code: start.code });
    const t0 = Date.now();
    return new Promise((resolve, reject) => {
      const tick = async () => {
        if (Date.now() - t0 > POLL_MAX_MS) { polling = null; reject(new Error('The login timed out. Try again.')); return; }
        try {
          const r = await api('/link-poll?code=' + encodeURIComponent(start.code), { noAuth: true });
          if (r.status === 'ok' && r.token) { polling = null; lic = { token: r.token, checkedAt: 0 }; await refresh(); resolve(lic); return; }
          if (r.status === 'expired') { polling = null; reject(new Error('The login code expired. Try again.')); return; }
        } catch (e) { Log.warn('license', 'poll failed', e.message); }
        polling = setTimeout(tick, POLL_MS);
      };
      polling = setTimeout(tick, POLL_MS);
    });
  }
  function cancelLogin() { if (polling) { clearTimeout(polling); polling = null; } }
  /* ---- entitlements: refresh on launch, keep the cache while offline ---- */
  async function refresh() {
    if (!lic || !lic.token) return null;
    try {
      const me = await api('/me');
      const before = lic.celebrated || '';
      lic = Object.assign({ token: lic.token }, me, { checkedAt: Date.now(), celebrated: before });
      save();
      /* a purchase or a grant since we last looked: throw the party once */
      const level = (m) => (m.features || []).includes('all') ? 2 : (m.tools && m.tools.length ? 1 : 0);
      const key = level(me) + ':' + (me.plan || '') + ':' + (me.tools || []).slice().sort().join(',');
      if (me.status !== 'past_due' && level(me) > 0 && key !== before) {
        const prevLevel = parseInt(before.split(':')[0] || '0', 10) || 0;
        if (level(me) >= prevLevel && typeof Celebrate !== 'undefined') { try { Celebrate.plan(me); } catch (e) {} }
        lic.celebrated = key; save();
      } else if (level(me) === 0 && before) { lic.celebrated = ''; save(); }
      Log.info('license', 'entitlements', { email: me.email, plan: me.plan, status: me.status });
    } catch (e) {
      if (e.status === 401 || e.status === 403) { Log.warn('license', 'token rejected, logging out'); lic = null; save(); }
      else Log.warn('license', 'refresh failed (offline?), keeping cache', e.message);
    }
    try { await syncTrials(); } catch (e) {}
    document.dispatchEvent(new CustomEvent('licensechange'));
    return lic;
  }
  async function logout() {
    try { if (lic && lic.token) await api('/logout', { method: 'POST' }); } catch (e) {}
    lic = null; save();
    document.dispatchEvent(new CustomEvent('licensechange'));
  }

  /*  ---- free exports: three a tool, per account, once ----
      The server keeps the real count. This mirror lets the panel answer instantly and keep working with no
      connection; claims made offline queue up and go through on the next sync, so a week on a plane is not
      a week of free exports.                                                                              */
  function exportsUsed(tool) { const t = store().trials || {}; return t[tool] || 0; }
  function setUsed(tool, n) { const k = store(); k.trials = k.trials || {}; k.trials[tool] = Math.max(k.trials[tool] || 0, n | 0); try { Hub.saveKeys(); } catch (e) {} }
  const exportsLeft = (tool) => hasTool(tool) ? Infinity : Math.max(0, FREE_EXPORTS - exportsUsed(tool));
  /* the old per-month buckets become one total: whatever was used in any month still counts */
  function migrateCounts() {
    const k = store(); if (!k.exports) return;
    k.trials = k.trials || {};
    for (const month of Object.keys(k.exports)) { const m = k.exports[month] || {}; for (const tool of Object.keys(m)) k.trials[tool] = Math.max(k.trials[tool] || 0, m[tool] | 0); }
    delete k.exports; try { Hub.saveKeys(); } catch (e) {}
  }
  /* one sync at a time: two tools clicked together must not both post the same queued claims */
  function syncTrials() { return trialSync || (trialSync = doSync().then((r) => { trialSync = null; return r; }, (e) => { trialSync = null; throw e; })); }
  async function doSync() {
    if (!loggedIn()) return false;
    const k = store(), q = k.trialQ || {};
    /* anything claimed while we were offline goes up first, or the read below would undo it */
    for (const tool of Object.keys(q)) {
      const n = q[tool] | 0;
      if (n <= 0) { delete q[tool]; continue; }
      try { const r = await api('/trial', { method: 'POST', body: { tool, n } }); delete q[tool]; setUsed(tool, r.used); }
      catch (e) { return; }
    }
    try {
      const r = await api('/trial'), used = r.used || {};
      k.trials = k.trials || {};
      for (const tool of Object.keys(used)) k.trials[tool] = Math.max(k.trials[tool] || 0, used[tool] | 0);
      /* and the server can give exports back (a refund, a gift): it decides in both directions */
      for (const tool of TRIAL_TOOLS) if (!(tool in used)) k.trials[tool] = 0;
      try { Hub.saveKeys(); } catch (e) {}
      return true;
    } catch (e) { Log.warn('license', 'trial sync failed (offline?)', e.message); }
    try { Hub.saveKeys(); } catch (e) {}
    return false;
  }
  /* returns true when the export may go ahead; otherwise explains and opens the pricing page */
  async function guardExport(tool, label) {
    if (hasTool(tool)) return true;
    /* the free exports belong to an account, not to an install - otherwise the count is a file you can delete */
    if (!loggedIn()) {
      toast('Log in to use your ' + FREE_EXPORTS + ' free ' + label + 's. An account is free.', 'err');
      try { Hub.show('login'); } catch (e) {}
      return false;
    }
    /*  ask every single time. Caching the answer for even a minute is enough to let someone empty the
        mirror between two exports and start again - the count has to come from the server at the moment
        the export is asked for. When the server cannot be reached the mirror is all we have.            */
    await syncTrials();
    const used = exportsUsed(tool);
    if (used < FREE_EXPORTS) {
      /*  where they stand is said before every one, not just the last, so the lock is never a surprise:
          "1 of 3, after this one 2 left", and the third is called what it is                            */
      const left = FREE_EXPORTS - used - 1;
      toast(left ? 'Free ' + label + ' ' + (used + 1) + ' of ' + FREE_EXPORTS + '. After this one, ' + left + ' left - then Pro.'
                 : 'Your last free ' + label + '. Pro makes this tool unlimited.', 'ok');
      return true;
    }
    try { Usage.tick('limit:' + tool); } catch (e) {}
    limitCard(tool, label);
    return false;
  }
  /* one export happened: count it here, then have the server count it too (queued if it cannot be reached) */
  async function noteExport(tool) {
    if (hasTool(tool)) return;
    const k = store();
    k.trials = k.trials || {}; k.trials[tool] = (k.trials[tool] || 0) + 1;
    try { Hub.saveKeys(); } catch (e) {}
    if (!loggedIn()) return;
    try { const r = await api('/trial', { method: 'POST', body: { tool } }); setUsed(tool, r.used); }
    catch (e) { k.trialQ = k.trialQ || {}; k.trialQ[tool] = (k.trialQ[tool] || 0) + 1; try { Hub.saveKeys(); } catch (e2) {} }
  }

  /* ---- gating UI ---- */
  /*  The moment someone is out of free exports is the one moment they are certainly interested. It used to
      be a red toast and a pricing tab opening behind Premiere; now it is a card in the panel that says what
      Pro is and costs, with one button. The pricing page still opens from that button, logged in or not.   */
  const NAMES = { carousel: '3D Carousel', transitions: 'Transitions', curves: 'Motion Curves', montage: 'Zoom Montage', social: 'Download media', mask: 'Mask' };
  function limitCard(tool, label) {
    let m = $('#limit-modal');
    if (!m) {
      m = document.createElement('div'); m.className = 'update'; m.id = 'limit-modal';
      m.innerHTML = '<div class="ubox"><div class="ueyebrow">Outflow Studio Pro</div><h2 id="lim-title"></h2><p class="small" id="lim-sub"></p>' +
        '<ul class="ulist"><li>' + Object.values(NAMES).join(', ') + ': unlimited</li><li>Auto Edit, Word Captions, Relight and Remove music</li><li>$19 a month, or $149 for the first year (four months free). Cancel any time, 14-day refund.</li></ul>' +
        '<div class="ubtns"><button class="primary gold" id="lim-go">Get Pro</button><button class="ghost" id="lim-later">Not now</button></div></div>';
      document.body.appendChild(m);
      $('#lim-later').addEventListener('click', () => m.classList.remove('show'));
      m.addEventListener('click', (e) => { if (e.target === m) m.classList.remove('show'); });
    }
    const name = NAMES[tool] || 'This tool';
    $('#lim-title').textContent = 'Your ' + FREE_EXPORTS + ' free ' + label + 's are used';
    $('#lim-sub').textContent = name + ' is part of Pro. Pro makes it unlimited, with every other tool:';
    const go = $('#lim-go'); const fresh = go.cloneNode(true); go.parentNode.replaceChild(fresh, go);
    fresh.addEventListener('click', () => { CS.openURL(pricingUrl(tool)); m.classList.remove('show'); });
    m.classList.add('show');
  }
  function lock(el, tool) {
    if (!el || can(tool)) { if (el) { el.classList.remove('locked'); const b = el.querySelector('.unlock'); if (b) b.remove(); } return false; }
    el.classList.add('locked');
    if (!el.querySelector('.unlock')) { const b = document.createElement('span'); b.className = 'unlock'; b.textContent = 'Unlock'; el.appendChild(b); }
    return true;
  }
  function promptUnlock(tool) {
    toast((PRO_TOOLS[tool] || 'This tool') + ' is part of Pro.', 'err');
    CS.openURL(pricingUrl(tool));
  }

  /* ---- login screen (first open) ---- */
  function showLogin() {
    const s = $('#screen-login'); if (!s) return;
    Hub.show('login');
    const status = $('#lg-status'); status.textContent = '';
    $('#lg-login').disabled = false;
  }
  /* keep the entitlements fresh: every five minutes and whenever the panel comes back into view */
  setInterval(() => { refresh(); }, 5 * 60 * 1000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && lic && lic.checkedAt && Date.now() - lic.checkedAt > 60 * 1000) refresh(); });
  function init() {
    load();
    migrateCounts();
    const btn = $('#lg-login'), skip = $('#lg-skip'), status = $('#lg-status');
    if (btn) btn.addEventListener('click', async () => {
      btn.disabled = true;
      try { await login((t) => { status.textContent = t; }); status.textContent = ''; toast('Logged in as ' + (lic.email || 'you') + (isPro() ? ' · Pro' : ' · Free'), 'ok'); try { store().loginSeen = true; Hub.saveKeys(); } catch (e) {} Hub.show('home'); }
      catch (e) { status.textContent = e.message; btn.disabled = false; }
    });
    if (skip) skip.addEventListener('click', () => { cancelLogin(); try { store().loginSeen = true; Hub.saveKeys(); } catch (e) {} Hub.show('home'); });
    const cancel = $('#lg-cancel'); if (cancel) cancel.addEventListener('click', () => { cancelLogin(); if (btn) btn.disabled = false; status.textContent = ''; });
    document.addEventListener('screenchange', (e) => { if (e.detail !== 'login') cancelLogin(); });
    /* refresh in the background; the home screen re-renders when it lands */
    if (lic && lic.token) refresh();
    return { firstOpen: !store().loginSeen && !loggedIn() };
  }
  return { api, init, showLogin, login, logout, refresh, isPro, hasTool, plan, loggedIn, can, lock, promptUnlock, guardExport, noteExport, exportsUsed, exportsLeft, syncTrials, pricingUrl, info: () => lic, PRO_TOOLS, FREE_EXPORTS, TRIAL_TOOLS, TRIAL_WORD };
})();
