Outflow Studio for Premiere Pro (Windows) · version 1.14.4

1. Close Premiere Pro.
2. Double-click install.bat (no admin needed). The installer at outflowstudio.com/account does the same with a window.
3. Start Premiere Pro, open Window > Extensions > Outflow Studio.
4. Log in with the same email you used on outflowstudio.com.

By hand instead: copy the OutflowStudio folder into %APPDATA%AdobeCEPextensions, then double-click
Enable-Extensions.reg and answer Yes. Same result as install.bat.

Updates: the panel tells you when a new version is ready and installs it with one click.
