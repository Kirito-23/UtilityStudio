/*  Guide: a working mock-up of Instagram, TikTok or YouTube drawn over your sequence, so you can see what the app
    covers while you edit rather than after you upload.

    The same draw() fills both the preview in the panel and the full-size PNG that goes on a track above your
    footage, so what you see is what lands. The layer is named "disable before export": it is a guide, not a
    graphic.

    The furniture is drawn here as real paths rather than copied: hearts, speech bubbles, paper planes and spinning
    discs are ordinary shapes, and the layout, sizes and typography are what make it read as the real thing. The
    platforms' own wordmarks and logos are deliberately not reproduced - this ships inside a product that is sold,
    and those are trademarks. Your own logo goes in the profile spot, which is the part that should be yours.

    Zones came from safe-zone guides current in September 2026 and are generous on purpose: every app moves its
    buttons, and they sit differently on a tall phone than on a short one.                                        */
const Guide = (() => {
  const $ = (s) => document.querySelector(s);
  const KEY = 'os.guide';

  /* every measurement is a fraction of the frame, so this works at 1080x1920 or anything else */
  const PLATFORMS = {
    reels:  { name: 'Instagram Reels', top: 0.062, bottom: 0.224, rail: { w: 0.176, from: 0.44, to: 0.87 }, mock: 'reels' },
    tiktok: { name: 'TikTok',          top: 0.058, bottom: 0.200, rail: { w: 0.155, from: 0.42, to: 0.86 }, mock: 'tiktok' },
    shorts: { name: 'YouTube Shorts',  top: 0.058, bottom: 0.156, rail: { w: 0.130, from: 0.46, to: 0.88 }, mock: 'shorts' },
    story:  { name: 'Instagram Story', top: 0.085, bottom: 0.130, rail: null, mock: 'story' },
    all:    { name: 'Safe for all of them', top: 0.135, bottom: 0.135, side: 0.083, rail: null, mock: null }
  };

  const st = {
    platform: 'reels', opacity: 100, mock: true, dim: true, safebox: true,
    handle: 'outflowstudio', caption: 'Frame every shot perfectly.', avatar: '', last: null
  };
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ platform: st.platform, opacity: st.opacity, mock: st.mock, dim: st.dim, safebox: st.safebox, handle: st.handle, caption: st.caption, avatar: st.avatar })); } catch (e) {} };
  (() => { try { Object.assign(st, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) {} st.last = null; })();

  const P = () => PLATFORMS[st.platform] || PLATFORMS.reels;

  /* the profile picture: whatever the user picked, else the panel's own logo */
  let avatarImg = null, avatarFor = null;
  function avatarURL() { return st.avatar ? (CS.inCEP ? CS.fileURL(st.avatar) : st.avatar) : 'img/logo.png'; }
  function loadAvatar() {
    const url = avatarURL();
    if (avatarFor === url && avatarImg) return Promise.resolve(avatarImg);
    return new Promise((res) => {
      const im = new Image();
      im.onload = () => { avatarImg = im; avatarFor = url; res(im); };
      im.onerror = () => { avatarImg = null; res(null); };
      im.src = url;
    });
  }

  /* ---------------------------------------------------------------- icons, drawn rather than borrowed */
  const ICON = {
    heart(g, x, y, s) {
      /* the classic two-lobe heart: start at the point, up and over the left lobe, back down from the right */
      const t = s * 0.5;
      g.beginPath();
      g.moveTo(x, y + t * 0.78);
      g.bezierCurveTo(x - t * 1.45, y - t * 0.30, x - t * 0.58, y - t * 1.18, x, y - t * 0.32);
      g.bezierCurveTo(x + t * 0.58, y - t * 1.18, x + t * 1.45, y - t * 0.30, x, y + t * 0.78);
      g.closePath(); g.fill();
    },
    bubble(g, x, y, s) {
      const w = s * 1.05, h = s * 0.92, r = h * 0.32;
      g.beginPath();
      g.moveTo(x - w / 2 + r, y - h / 2);
      g.arcTo(x + w / 2, y - h / 2, x + w / 2, y + h / 2, r);
      g.arcTo(x + w / 2, y + h / 2, x - w / 2, y + h / 2, r);
      g.lineTo(x - w * 0.18, y + h / 2);
      g.lineTo(x - w * 0.34, y + h * 0.86);
      g.lineTo(x - w * 0.30, y + h / 2);
      g.arcTo(x - w / 2, y + h / 2, x - w / 2, y - h / 2, r);
      g.arcTo(x - w / 2, y - h / 2, x + w / 2, y - h / 2, r);
      g.closePath(); g.fill();
    },
    plane(g, x, y, s) {
      g.beginPath();
      g.moveTo(x - s * 0.55, y - s * 0.12);
      g.lineTo(x + s * 0.55, y - s * 0.52);
      g.lineTo(x + s * 0.08, y + s * 0.52);
      g.lineTo(x - s * 0.02, y + s * 0.10);
      g.closePath(); g.fill();
    },
    dots(g, x, y, s) {
      const r = s * 0.09;
      for (let i = -1; i <= 1; i++) { g.beginPath(); g.arc(x + i * s * 0.28, y, r, 0, Math.PI * 2); g.fill(); }
    },
    bookmark(g, x, y, s) {
      g.beginPath();
      g.moveTo(x - s * 0.34, y - s * 0.5);
      g.lineTo(x + s * 0.34, y - s * 0.5);
      g.lineTo(x + s * 0.34, y + s * 0.5);
      g.lineTo(x, y + s * 0.16);
      g.lineTo(x - s * 0.34, y + s * 0.5);
      g.closePath(); g.fill();
    },
    thumb(g, x, y, s, down) {
      g.save(); g.translate(x, y); if (down) g.rotate(Math.PI);
      g.beginPath();
      g.moveTo(-s * 0.42, s * 0.06); g.lineTo(-s * 0.16, s * 0.06);
      g.lineTo(-s * 0.16, s * 0.5); g.lineTo(-s * 0.42, s * 0.5); g.closePath(); g.fill();
      g.beginPath();
      g.moveTo(-s * 0.06, s * 0.06);
      g.lineTo(s * 0.06, -s * 0.5); g.lineTo(s * 0.2, -s * 0.42); g.lineTo(s * 0.12, -s * 0.06);
      g.lineTo(s * 0.44, -s * 0.06); g.lineTo(s * 0.36, s * 0.5); g.lineTo(-s * 0.06, s * 0.5);
      g.closePath(); g.fill();
      g.restore();
    },
    note(g, x, y, s) {
      g.beginPath(); g.arc(x - s * 0.18, y + s * 0.28, s * 0.17, 0, Math.PI * 2); g.fill();
      g.fillRect(x - s * 0.03, y - s * 0.42, s * 0.07, s * 0.72);
      g.beginPath();
      g.moveTo(x + s * 0.04, y - s * 0.42);
      g.quadraticCurveTo(x + s * 0.38, y - s * 0.34, x + s * 0.30, y - s * 0.02);
      g.quadraticCurveTo(x + s * 0.30, y - s * 0.24, x + s * 0.04, y - s * 0.24);
      g.closePath(); g.fill();
    },
    camera(g, x, y, s) {
      g.beginPath();
      const w = s * 1.0, h = s * 0.72, r = h * 0.26;
      g.moveTo(x - w / 2 + r, y - h / 2);
      g.arcTo(x + w / 2, y - h / 2, x + w / 2, y + h / 2, r);
      g.arcTo(x + w / 2, y + h / 2, x - w / 2, y + h / 2, r);
      g.arcTo(x - w / 2, y + h / 2, x - w / 2, y - h / 2, r);
      g.arcTo(x - w / 2, y - h / 2, x + w / 2, y - h / 2, r);
      g.closePath(); g.fill();
      g.save(); g.globalCompositeOperation = 'destination-out';
      g.beginPath(); g.arc(x, y, s * 0.2, 0, Math.PI * 2); g.fill(); g.restore();
    },
    search(g, x, y, s) {
      g.lineWidth = s * 0.12; g.strokeStyle = g.fillStyle;
      g.beginPath(); g.arc(x - s * 0.08, y - s * 0.08, s * 0.28, 0, Math.PI * 2); g.stroke();
      g.beginPath(); g.moveTo(x + s * 0.12, y + s * 0.12); g.lineTo(x + s * 0.36, y + s * 0.36); g.stroke();
    },
    tick(g, x, y, s) {   /* the verified badge: a starburst with a check in it */
      g.beginPath();
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * Math.PI * 2, r = i % 2 ? s * 0.38 : s * 0.5;
        const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
        i ? g.lineTo(px, py) : g.moveTo(px, py);
      }
      g.closePath(); g.fill();
      g.save(); g.globalCompositeOperation = 'destination-out';
      g.lineWidth = s * 0.14; g.lineCap = 'round'; g.strokeStyle = '#000';
      g.beginPath(); g.moveTo(x - s * 0.18, y); g.lineTo(x - s * 0.04, y + s * 0.15); g.lineTo(x + s * 0.2, y - s * 0.16); g.stroke();
      g.restore();
    }
  };

  const roundRect = (g, x, y, w, h, r) => {
    g.beginPath();
    if (g.roundRect) g.roundRect(x, y, w, h, r); else {
      g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
      g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
    }
  };
  function circleImage(g, im, x, y, r) {
    g.save(); g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.clip();
    if (im) g.drawImage(im, x - r, y - r, r * 2, r * 2);
    else { g.fillStyle = '#4f8dff'; g.fillRect(x - r, y - r, r * 2, r * 2); }
    g.restore();
  }

  /* ---------------------------------------------------------------- the drawing */
  function draw(g, W, H, opts) {
    const p = P(), a = (opts && opts.alpha != null ? opts.alpha : st.opacity / 100);
    const u = W / 1080;
    g.clearRect(0, 0, W, H);
    g.globalAlpha = 1;

    const side = p.side || 0.056;
    const safe = { x: W * side, y: H * p.top, w: W * (1 - side * 2), h: H * (1 - p.top - p.bottom) };
    if (p.rail) safe.w -= W * p.rail.w - W * side;

    if (st.dim) {
      g.fillStyle = 'rgba(0,0,0,' + (0.42 * a).toFixed(3) + ')';
      g.fillRect(0, 0, W, H * p.top);
      g.fillRect(0, H * (1 - p.bottom), W, H * p.bottom);
      if (p.rail) g.fillRect(W * (1 - p.rail.w), H * p.rail.from, W * p.rail.w, H * (p.rail.to - p.rail.from));
      if (p.side) { g.fillRect(0, H * p.top, W * p.side, H * (1 - p.top - p.bottom)); g.fillRect(W * (1 - p.side), H * p.top, W * p.side, H * (1 - p.top - p.bottom)); }
    }

    if (st.mock && p.mock) {
      g.globalAlpha = a;
      /* the apps all darken the top and bottom so their white text stays readable */
      const top = g.createLinearGradient(0, 0, 0, H * 0.16);
      top.addColorStop(0, 'rgba(0,0,0,.45)'); top.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = top; g.fillRect(0, 0, W, H * 0.16);
      const bot = g.createLinearGradient(0, H * (1 - p.bottom - 0.12), 0, H);
      bot.addColorStop(0, 'rgba(0,0,0,0)'); bot.addColorStop(1, 'rgba(0,0,0,.62)');
      g.fillStyle = bot; g.fillRect(0, H * (1 - p.bottom - 0.12), W, H * (p.bottom + 0.12));
      MOCK[p.mock](g, W, H, p, u);
      g.globalAlpha = 1;
    }

    if (st.safebox) {
      g.strokeStyle = 'rgba(120,225,145,' + (0.9 * a).toFixed(3) + ')';
      g.lineWidth = Math.max(2, 3 * u); g.setLineDash([]);
      g.strokeRect(safe.x, safe.y, safe.w, safe.h);
      /* the label sits inside the box: above it, it lands in the app's own header */
      g.fillStyle = 'rgba(120,225,145,' + (0.9 * a).toFixed(3) + ')';
      g.font = '700 ' + Math.round(20 * u) + 'px Inter, system-ui, sans-serif';
      g.textBaseline = 'top'; g.textAlign = 'left';
      g.fillText('KEEP IT IN HERE', safe.x + 10 * u, safe.y + 10 * u);
      g.textBaseline = 'alphabetic';
    }
  }

  const F = (u) => (w, size) => (w === 700 ? '700 ' : w === 600 ? '600 ' : '') + Math.round(size * u) + 'px Inter, "Segoe UI", system-ui, sans-serif';

  const MOCK = {
    /* ------------------------------------------------------------ Instagram Reels */
    reels(g, W, H, p, u) {
      const f = F(u);
      g.fillStyle = '#fff'; g.textBaseline = 'middle';

      /* header */
      g.font = f(700, 34); g.textAlign = 'center';
      g.fillText('Reels', W * 0.5, H * 0.032);
      g.beginPath(); g.moveTo(W * 0.5 + 44 * u, H * 0.032 - 3 * u); g.lineTo(W * 0.5 + 58 * u, H * 0.032 + 7 * u); g.lineTo(W * 0.5 + 72 * u, H * 0.032 - 3 * u);
      g.lineWidth = 4 * u; g.strokeStyle = '#fff'; g.stroke();
      g.textAlign = 'left';
      ICON.plane(g, W * 0.93, H * 0.032, 40 * u);
      ICON.camera(g, W * 0.07, H * 0.032, 44 * u);

      /* the rail */
      const cx = W * (1 - p.rail.w / 2);
      const rail = [['heart', '253K'], ['bubble', '1.139'], ['plane', '29'], ['dots', '']];
      const y0 = H * p.rail.from;
      rail.forEach((it, i) => {
        const y = y0 + i * H * 0.093;
        g.fillStyle = '#fff';
        ICON[it[0]](g, cx, y, 48 * u);
        if (it[1]) { g.font = f(600, 24); g.textAlign = 'center'; g.fillText(it[1], cx, y + 44 * u); g.textAlign = 'left'; }
      });
      /* the spinning album disc */
      const dy = y0 + 3.5 * H * 0.093;
      g.fillStyle = 'rgba(255,255,255,.9)'; g.beginPath(); g.arc(cx, dy, 30 * u, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#1c1c22'; g.beginPath(); g.arc(cx, dy, 22 * u, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#fff'; ICON.note(g, cx, dy, 26 * u);

      /* the caption block */
      const bx = W * 0.05; let by = H * (1 - p.bottom) + H * 0.035;
      circleImage(g, avatarImg, bx + 26 * u, by, 26 * u);
      g.fillStyle = '#fff'; g.font = f(600, 28);
      const hw = g.measureText(st.handle).width;
      g.fillText(st.handle, bx + 64 * u, by);
      g.fillStyle = '#4f9dff'; ICON.tick(g, bx + 64 * u + hw + 20 * u, by, 26 * u);
      g.strokeStyle = 'rgba(255,255,255,.75)'; g.lineWidth = 2 * u;
      roundRect(g, bx + 64 * u + hw + 44 * u, by - 20 * u, 118 * u, 40 * u, 8 * u); g.stroke();
      g.fillStyle = '#fff'; g.font = f(600, 24); g.textAlign = 'center';
      g.fillText('Follow', bx + 64 * u + hw + 103 * u, by); g.textAlign = 'left';

      by += 54 * u;
      g.font = f(400, 27); g.fillStyle = 'rgba(255,255,255,.95)';
      g.fillText(st.caption, bx, by);
      by += 44 * u;
      g.font = f(400, 24); g.fillStyle = 'rgba(255,255,255,.85)';
      g.fillText('Liked by your friend and 25.517 others', bx, by);
      by += 44 * u;
      g.fillStyle = '#fff'; ICON.note(g, bx + 12 * u, by, 24 * u);
      g.font = f(400, 24); g.fillStyle = 'rgba(255,255,255,.9)';
      g.fillText('Title · Original audio', bx + 34 * u, by);
    },

    /* ------------------------------------------------------------ TikTok */
    tiktok(g, W, H, p, u) {
      const f = F(u);
      g.fillStyle = '#fff'; g.textBaseline = 'middle'; g.textAlign = 'center';
      g.font = f(600, 28); g.fillStyle = 'rgba(255,255,255,.65)';
      g.fillText('Following', W * 0.38, H * 0.03);
      g.fillStyle = '#fff'; g.font = f(700, 28);
      g.fillText('For You', W * 0.62, H * 0.03);
      g.fillRect(W * 0.585, H * 0.03 + 24 * u, W * 0.07, 4 * u);
      g.textAlign = 'left';
      g.fillStyle = '#fff'; ICON.search(g, W * 0.93, H * 0.03, 44 * u);

      const cx = W * (1 - p.rail.w / 2), y0 = H * p.rail.from;
      /* the avatar with its plus badge */
      circleImage(g, avatarImg, cx, y0, 32 * u);
      g.strokeStyle = '#fff'; g.lineWidth = 3 * u; g.beginPath(); g.arc(cx, y0, 32 * u, 0, Math.PI * 2); g.stroke();
      g.fillStyle = '#fe2c55'; g.beginPath(); g.arc(cx, y0 + 38 * u, 15 * u, 0, Math.PI * 2); g.fill();
      g.strokeStyle = '#fff'; g.lineWidth = 3 * u;
      g.beginPath(); g.moveTo(cx - 7 * u, y0 + 38 * u); g.lineTo(cx + 7 * u, y0 + 38 * u);
      g.moveTo(cx, y0 + 31 * u); g.lineTo(cx, y0 + 45 * u); g.stroke();

      const rail = [['heart', '328.4K'], ['bubble', '2.180'], ['bookmark', '9.941'], ['plane', '4.517']];
      rail.forEach((it, i) => {
        const y = y0 + H * 0.082 + i * H * 0.086;
        g.fillStyle = '#fff'; ICON[it[0]](g, cx, y, 48 * u);
        g.font = f(600, 23); g.textAlign = 'center'; g.fillText(it[1], cx, y + 44 * u); g.textAlign = 'left';
      });
      const dy = y0 + H * 0.082 + 4 * H * 0.086;
      g.fillStyle = '#2a2a2a'; g.beginPath(); g.arc(cx, dy, 32 * u, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#fff'; ICON.note(g, cx, dy, 30 * u);

      const bx = W * 0.05; let by = H * (1 - p.bottom) + H * 0.03;
      g.fillStyle = '#fff'; g.font = f(700, 30);
      g.fillText('@' + st.handle, bx, by);
      by += 48 * u;
      g.font = f(400, 27); g.fillStyle = 'rgba(255,255,255,.95)';
      g.fillText(st.caption, bx, by);
      by += 46 * u;
      g.fillStyle = '#fff'; ICON.note(g, bx + 12 * u, by, 26 * u);
      g.font = f(400, 25); g.fillText('original sound · ' + st.handle, bx + 36 * u, by);
    },

    /* ------------------------------------------------------------ YouTube Shorts */
    shorts(g, W, H, p, u) {
      const f = F(u);
      g.fillStyle = '#fff'; g.textBaseline = 'middle';
      g.font = f(700, 30); g.fillText('Shorts', W * 0.05, H * 0.03);
      ICON.search(g, W * 0.86, H * 0.03, 44 * u);
      ICON.dots(g, W * 0.94, H * 0.03, 44 * u);

      const cx = W * (1 - p.rail.w / 2), y0 = H * p.rail.from;
      const rail = [['thumb', '12K', 0], ['thumb', 'Dislike', 1], ['bubble', '431', 0], ['plane', 'Share', 0]];
      rail.forEach((it, i) => {
        const y = y0 + i * H * 0.095;
        g.fillStyle = '#fff';
        if (it[0] === 'thumb') ICON.thumb(g, cx, y, 46 * u, !!it[2]); else ICON[it[0]](g, cx, y, 46 * u);
        g.font = f(600, 22); g.textAlign = 'center'; g.fillText(it[1], cx, y + 42 * u); g.textAlign = 'left';
      });
      const dy = y0 + 4 * H * 0.095;
      circleImage(g, avatarImg, cx, dy, 26 * u);

      const bx = W * 0.05; let by = H * (1 - p.bottom) + H * 0.028;
      circleImage(g, avatarImg, bx + 24 * u, by, 24 * u);
      g.fillStyle = '#fff'; g.font = f(600, 26);
      const nw = g.measureText('@' + st.handle).width;
      g.fillText('@' + st.handle, bx + 60 * u, by);
      g.fillStyle = '#fff';
      roundRect(g, bx + 60 * u + nw + 22 * u, by - 20 * u, 140 * u, 40 * u, 20 * u); g.fill();
      g.fillStyle = '#0f0f0f'; g.font = f(700, 24); g.textAlign = 'center';
      g.fillText('Subscribe', bx + 60 * u + nw + 92 * u, by); g.textAlign = 'left';
      by += 50 * u;
      g.fillStyle = '#fff'; g.font = f(400, 27);
      g.fillText(st.caption, bx, by);
      /* the scrubber along the very bottom */
      g.fillStyle = 'rgba(255,255,255,.3)'; g.fillRect(0, H - 6 * u, W, 4 * u);
      g.fillStyle = '#fff'; g.fillRect(0, H - 6 * u, W * 0.42, 4 * u);
    },

    /* ------------------------------------------------------------ Instagram Story */
    story(g, W, H, p, u) {
      const f = F(u);
      const n = 5, gap = 6 * u, tw = (W * 0.9 - gap * (n - 1)) / n;
      for (let i = 0; i < n; i++) {
        g.fillStyle = i < 2 ? '#fff' : 'rgba(255,255,255,.4)';
        roundRect(g, W * 0.05 + i * (tw + gap), H * 0.018, tw, 5 * u, 3 * u); g.fill();
      }
      const by = H * 0.05;
      circleImage(g, avatarImg, W * 0.05 + 26 * u, by, 26 * u);
      g.fillStyle = '#fff'; g.textBaseline = 'middle'; g.font = f(600, 27);
      g.fillText(st.handle, W * 0.05 + 64 * u, by);
      const w2 = g.measureText(st.handle).width;
      g.fillStyle = 'rgba(255,255,255,.7)'; g.font = f(400, 24);
      g.fillText('4h', W * 0.05 + 78 * u + w2, by);
      g.fillStyle = '#fff'; ICON.dots(g, W * 0.88, by, 40 * u);
      g.lineWidth = 4 * u; g.strokeStyle = '#fff';
      g.beginPath(); g.moveTo(W * 0.94 - 12 * u, by - 12 * u); g.lineTo(W * 0.94 + 12 * u, by + 12 * u);
      g.moveTo(W * 0.94 + 12 * u, by - 12 * u); g.lineTo(W * 0.94 - 12 * u, by + 12 * u); g.stroke();

      const ry = H * (1 - p.bottom) + H * 0.045;
      g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 2.5 * u;
      roundRect(g, W * 0.05, ry - 30 * u, W * 0.6, 60 * u, 30 * u); g.stroke();
      g.fillStyle = 'rgba(255,255,255,.85)'; g.font = f(400, 25); g.textBaseline = 'middle';
      g.fillText('Send message', W * 0.09, ry);
      g.fillStyle = '#fff';
      ICON.heart(g, W * 0.75, ry, 46 * u);
      ICON.plane(g, W * 0.88, ry, 46 * u);
    }
  };

  /* ---------------------------------------------------------------- the preview */
  async function paint() {
    const cv = $('#gd-cv'); if (!cv) return;
    await loadAvatar();
    const H = 380, W = Math.round(H * 9 / 16);
    const dpr = window.devicePixelRatio || 1;
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const grd = g.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, '#55606f'); grd.addColorStop(1, '#2b313c');
    g.fillStyle = grd; g.fillRect(0, 0, W, H);
    draw(g, W, H, { alpha: 1 });
  }

  /* ---------------------------------------------------------------- on the timeline */
  async function apply() {
    if (!CS.inCEP) { toast('This works inside Premiere Pro only.', 'err'); return; }
    const btn = $('#gd-apply'); btn.classList.add('loading');
    try {
      const info = await CS.call('AS_range');
      if (!info || !info.ok) throw new Error((info && info.error) || 'Open a sequence first.');
      await loadAvatar();
      const W = info.width, H = info.height;
      const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      draw(cv.getContext('2d'), W, H, { alpha: st.opacity / 100 });

      const dir = CS.path.join(CS.os.homedir(), 'AppData', 'Roaming', 'OutflowStudio', 'guides');
      CS.mkdirp(dir);
      const file = CS.path.join(dir, 'guide_' + st.platform + '_' + W + 'x' + H + '_' + Date.now().toString(36) + '.png');
      await Exporter.writePNGStraight(file, cv.getContext('2d').getImageData(0, 0, W, H).data, W, H);

      const r = await CS.call('TL_placeImage', JSON.stringify({
        path: file, start: 0, duration: info.duration || 10, scale: 100,
        name: P().name + ' guide (disable before export)'
      }));
      if (!r.ok) throw new Error(r.error);
      st.last = { track: r.track, start: 0 };
      toast(P().name + ' guide on V' + (r.track + 1) + '. Switch that track off before you export.', 'ok');
      try { Usage.tick('guide'); Usage.tick('set:guide:' + st.platform); } catch (e) {}
      render();
    } catch (e) {
      toast(e.message || String(e), 'err');
      try { Usage.fail('guide', 'apply', e.message); } catch (e2) {}
    }
    btn.classList.remove('loading');
  }

  async function removeGuide() {
    if (!st.last) return;
    try {
      const r = await CS.call('MG_revert', JSON.stringify({ track: st.last.track, starts: [st.last.start], layers: [] }));
      if (!r.ok) throw new Error(r.error);
      st.last = null; render();
      toast('Guide removed.', 'ok');
    } catch (e) { toast(e.message || String(e), 'err'); }
  }

  /* ---------------------------------------------------------------- wiring */
  let wired = false;
  function wire() {
    if (wired) return; wired = true;
    const sel = $('#gd-platform');
    sel.innerHTML = Object.keys(PLATFORMS).map((k) => '<option value="' + k + '">' + PLATFORMS[k].name + '</option>').join('');
    sel.value = st.platform;
    sel.addEventListener('change', () => { st.platform = sel.value; save(); paint(); });

    const hd = $('#gd-handle'); hd.value = st.handle;
    hd.addEventListener('input', () => { st.handle = hd.value.replace(/^@/, '').slice(0, 30); save(); paint(); });
    const cp = $('#gd-caption'); cp.value = st.caption;
    cp.addEventListener('input', () => { st.caption = cp.value.slice(0, 70); save(); paint(); });

    const av = $('#gd-avatar');
    const avName = () => st.avatar ? String(st.avatar).split(/[\\/]/).pop() : 'Outflow Studio logo';
    av.textContent = avName();
    av.addEventListener('click', () => {
      if (!CS.inCEP) { toast('Picking a file works inside Premiere Pro only.'); return; }
      const p = CS.pickFiles();
      if (p && p[0]) { st.avatar = p[0]; avatarFor = null; av.textContent = avName(); save(); paint(); }
    });
    const avClear = $('#gd-avatar-clear');
    avClear.addEventListener('click', () => { st.avatar = ''; avatarFor = null; av.textContent = avName(); save(); paint(); });

    const op = $('#gd-opacity'), opv = $('#gd-opacity-v');
    op.value = String(st.opacity); opv.textContent = st.opacity + '%';
    op.addEventListener('input', () => { st.opacity = +op.value; opv.textContent = st.opacity + '%'; save(); paint(); });

    const t = (id, key) => {
      const b = $(id); if (!b) return;
      b.classList.toggle('on', !!st[key]);
      b.onclick = () => { st[key] = !b.classList.contains('on'); b.classList.toggle('on', st[key]); save(); paint(); };
    };
    t('#gd-mock', 'mock'); t('#gd-dim', 'dim'); t('#gd-safebox', 'safebox');

    $('#gd-apply').addEventListener('click', apply);
    $('#gd-remove').addEventListener('click', removeGuide);
  }

  function render() {
    const rm = $('#gd-remove'); if (rm) rm.style.display = st.last ? '' : 'none';
    paint();
  }

  function open() { Hub.show('guide'); wire(); render(); }
  return { open, render, PLATFORMS };
})();
window.Guide = Guide;
