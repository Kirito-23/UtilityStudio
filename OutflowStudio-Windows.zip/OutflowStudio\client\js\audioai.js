/* Audio AI: free, local audio processing.
   - Voice clean-up (Extract Voice): DeepFilterNet's deep-filter binary (MIT/Apache, Rikorose/DeepFilterNet),
     a single ~27 MB exe downloaded on first use, model built in.
   - Remove Vocals / Extract Vocals / Remove Instrumentals: the UVR MDX-Net ONNX models, run by our own
     Node script (js/mdx/separate.js) with onnxruntime-node (DirectML on the GPU). The runtime is a signed
     node.exe from nodejs.org plus the onnxruntime-node package from the npm registry, about 150 MB once,
     no Python. It reproduces python-audio-separator's MDX path bit for bit (verified 2026-09-04).
   - Remove Echo and the HQ (BS-RoFormer) quality still use python-audio-separator on the official
     python.org embeddable Python 3.11 (about 1.5 GB, optional, installed only when one of those is used).
   The selected clips (or the in/out range, or the whole sequence) are exported to WAV,
   processed, and the result is placed on a free audio track at the same position. */
const AudioAI = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const cp = nodeReq ? nodeReq('child_process') : null;
  const proc = (window.cep_node && window.cep_node.process) || (typeof process !== 'undefined' ? process : null);
  const DF_URL = () => CS.mac ? 'https://github.com/Rikorose/DeepFilterNet/releases/download/v0.5.6/deep-filter-0.5.6-' + (CS.arch() === 'arm64' ? 'aarch64' : 'x86_64') + '-apple-darwin' : 'https://github.com/Rikorose/DeepFilterNet/releases/download/v0.5.6/deep-filter-0.5.6-x86_64-pc-windows-msvc.exe';
  const PY_URL = 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip';
  const GETPIP_URL = 'https://bootstrap.pypa.io/get-pip.py';
  /* the Python-free separation runtime: node.exe (only that file is taken from the zip) and onnxruntime-node */
  const NODE_VER = 'v22.19.0';
  const nodePkg = () => CS.mac ? 'node-' + NODE_VER + '-darwin-' + CS.arch() : 'node-' + NODE_VER + '-win-x64';
  const NODE_URL = () => 'https://nodejs.org/dist/' + NODE_VER + '/' + nodePkg() + (CS.mac ? '.tar.gz' : '.zip');
  const ORT_VER = '1.29.0';
  const ORT_URL = 'https://registry.npmjs.org/onnxruntime-node/-/onnxruntime-node-' + ORT_VER + '.tgz';
  const ORT_COMMON_URL = 'https://registry.npmjs.org/onnxruntime-common/-/onnxruntime-common-' + ORT_VER + '.tgz';
  const MODEL_URL = 'https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/';
  /* per-model settings from UVR's mdx_model_data.json */
  const MDX = {
    'UVR-MDX-NET-Inst_HQ_3.onnx': { nfft: 6144, dimf: 3072, dimt: 256, compensate: 1.022, primary: 'instrumental' },
    'UVR-MDX-NET-Voc_FT.onnx': { nfft: 7680, dimf: 3072, dimt: 256, compensate: 1.021, primary: 'vocals' }
  };
  /* MDX-Net (ONNX) runs in seconds and on the GPU through DirectML; BS-RoFormer sounds a bit better but is
     PyTorch-on-CPU and takes tens of minutes for a song */
  const SEP_MODEL_VOCALS = (q) => q === 'hq' ? 'model_bs_roformer_ep_317_sdr_12.9755.ckpt' : 'UVR-MDX-NET-Inst_HQ_3.onnx';
  const SEP_MODEL_ECHO = 'UVR-DeEcho-DeReverb.pth';

  const TASKS = [
    { id: 'novocals', name: 'Remove Vocals', icon: 'audioai', desc: 'Creates a backing track by removing the vocal part.', engine: 'mdx', model: SEP_MODEL_VOCALS, stem: 'instrumental', pick: /\(Instrumental\)/i },
    { id: 'vocals', name: 'Extract Vocals', icon: 'audioai', desc: 'Isolates clear vocals by removing the backing track.', engine: 'mdx', model: SEP_MODEL_VOCALS, stem: 'vocals', pick: /\(Vocals\)/i },
    { id: 'nomusic', name: 'Remove Instrumentals', icon: 'silence', desc: 'Keeps every voice (speech and singing) and strips the instrumental music.', engine: 'mdx', model: 'UVR-MDX-NET-Voc_FT.onnx', stem: 'vocals', pick: /\(Vocals\)/i },
    { id: 'voice', name: 'Extract Voice', icon: 'speaker', desc: 'Isolates voice from all background sounds.', engine: 'df' },
    { id: 'echo', name: 'Remove Echo', icon: 'audio', desc: 'Eliminates echo and reverb from voice and vocals.', engine: 'sep', model: SEP_MODEL_ECHO, pick: /No (Echo|Reverb)/i }
  ];
  const st = { source: 'selection', mute: false, quality: 'fast', gpu: true };
  try { Object.assign(st, JSON.parse(localStorage.getItem('os.audioai') || '{}')); } catch (e) {}
  const save = () => { try { localStorage.setItem('os.audioai', JSON.stringify(st)); } catch (e) {} };

  function home() { return CS.dataDir('audioai'); }
  const exists = (p) => { try { return !!(CS.fs && p && CS.fs.existsSync(p)); } catch (e) { return false; } };
  const ok = () => !!(CS.fs && CS.path);
  const dfExe = () => { if (!ok()) return null; const p = CS.path.join(home(), CS.bin('deep-filter')); return exists(p) ? p : null; };
  const pyDir = () => CS.path.join(home(), 'py311');
  const pyExe = () => { if (!ok()) return null; const p = CS.path.join(pyDir(), 'python.exe'); return exists(p) ? p : null; };
  const sepReady = () => ok() && !!pyExe() && exists(CS.path.join(pyDir(), 'Lib', 'site-packages', 'audio_separator', 'utils', 'cli.py'));
  const dmlReady = () => { try { return ok() && CS.fs.readdirSync(CS.path.join(pyDir(), 'Lib', 'site-packages')).some(f => /^onnxruntime_directml-/i.test(f)); } catch (e) { return false; } };
  function pyEnv() {
    const env = Object.assign({}, proc ? proc.env : {});
    env.PYTHONIOENCODING = 'utf-8'; env.PYTHONUNBUFFERED = '1'; env.PYTHONUTF8 = '1';
    return env;
  }

  /* ---- the Python-free runtime ---- */
  const nodeExe = () => { if (!ok()) return null; const p = CS.path.join(home(), 'node', CS.bin('node')); return exists(p) ? p : null; };
  const ortDir = () => CS.path.join(home(), 'ort');
  const ortBin = () => CS.mac ? CS.path.join(ortDir(), 'node_modules', 'onnxruntime-node', 'bin', 'napi-v6', 'darwin', CS.arch()) : CS.path.join(ortDir(), 'node_modules', 'onnxruntime-node', 'bin', 'napi-v6', 'win32', 'x64', 'onnxruntime.dll');
  const ortReady = () => ok() && exists(ortBin()) && exists(CS.path.join(ortDir(), 'node_modules', 'onnxruntime-common', 'package.json'));
  const mdxReady = () => !!nodeExe() && ortReady();
  const tarExe = () => CS.tar();
  const separateJs = () => CS.path.join(CS.extensionDir(), 'client', 'js', 'mdx', 'separate.js');
  async function ensureNode(onProgress) {
    if (nodeExe()) return nodeExe();
    const zip = CS.path.join(home(), CS.mac ? 'node.tar.gz' : 'node.zip'), dir = CS.path.join(home(), 'node'); CS.mkdirp(dir);
    await Net.download(NODE_URL(), zip, (p) => onProgress(p * 0.3, 'Downloading the audio engine 1/2 (35 MB, once)' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    /* only the one program is taken out of the archive: bin/node on a Mac, node.exe at the top on Windows */
    if (CS.mac) await run(tarExe(), ['-xzf', zip, '-C', dir, '--strip-components=2', nodePkg() + '/bin/node']);
    else await run(tarExe(), ['-xf', zip, '-C', dir, '--strip-components=1', nodePkg() + '/node.exe']);
    try { CS.fs.unlinkSync(zip); } catch (e) {}
    if (nodeExe()) CS.chmodX(nodeExe());
    if (!nodeExe()) throw new Error(CS.bin('node') + ' was not found after unpacking (antivirus?).');
    return nodeExe();
  }
  async function ensureOrt(onProgress) {
    if (ortReady()) return;
    const base = ortDir(), nm = CS.path.join(base, 'node_modules');
    const dNode = CS.path.join(nm, 'onnxruntime-node'), dCommon = CS.path.join(nm, 'onnxruntime-common'); CS.mkdirp(dNode); CS.mkdirp(dCommon);
    const tgz = CS.path.join(base, 'ort.tgz'), tgz2 = CS.path.join(base, 'common.tgz');
    await Net.download(ORT_URL, tgz, (p) => onProgress(0.3 + p * 0.6, 'Downloading the audio engine 2/2 (110 MB, once)' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    await Net.download(ORT_COMMON_URL, tgz2, () => {});
    onProgress(0.92, 'Unpacking the runtime');
    /* the runtime for this platform only: the package carries every OS and both CPU kinds */
    const skip = CS.mac ? ['package/bin/napi-v6/win32', 'package/bin/napi-v6/linux', 'package/bin/napi-v6/darwin/' + (CS.arch() === 'arm64' ? 'x64' : 'arm64')] : ['package/bin/napi-v6/darwin', 'package/bin/napi-v6/linux', 'package/bin/napi-v6/win32/arm64'];
    await run(tarExe(), ['-xzf', tgz, '-C', dNode, '--strip-components=1'].concat(skip.reduce((a, x) => a.concat(['--exclude', x]), []), ['--exclude', 'package/script']));
    await run(tarExe(), ['-xzf', tgz2, '-C', dCommon, '--strip-components=1']);
    try { CS.fs.unlinkSync(tgz); CS.fs.unlinkSync(tgz2); } catch (e) {}
    if (!ortReady()) throw new Error('The audio engine was not found after unpacking (antivirus?).');
  }
  async function ensureModel(name, onProgress) {
    const dir = CS.path.join(home(), 'models'); CS.mkdirp(dir);
    const p = CS.path.join(dir, name);
    if (exists(p) && CS.fs.statSync(p).size > 1e6) return p;
    await Net.download(MODEL_URL + name, p, (q) => onProgress(q, 'Downloading the audio model (67 MB, once)' + (q >= 0 ? ' · ' + Math.round(q * 100) + '%' : '')));
    return p;
  }
  async function ensureFfmpegExe(onProgress) {
    if (Social.ffmpeg()) return Social.ffmpeg();
    await Social.installFfmpeg(onProgress);
    return Social.ffmpeg();
  }

  let current = null, cancelled = false;
  function run(cmd, args, onLine, env) {
    return new Promise((resolve, reject) => {
      if (cancelled) { reject(new Error('Cancelled.')); return; }
      const p = CS.track(cp.spawn(cmd, args, { windowsHide: true, env: env || (proc ? proc.env : undefined) }));
      current = p;
      let out = '', err = '';
      p.stdout.on('data', d => { const s = String(d); out += s; if (onLine) s.split(/[\r\n]+/).forEach(l => l.trim() && onLine(l.trim())); });
      p.stderr.on('data', d => { const s = String(d); err += s; if (onLine) s.split(/[\r\n]+/).forEach(l => l.trim() && onLine(l.trim())); });
      p.on('error', (e) => { current = null; reject(e); });
      p.on('close', code => { current = null; if (cancelled) { reject(new Error('Cancelled.')); return; } code === 0 ? resolve(out) : reject(new Error((err || out).trim().split('\n').filter(l => /error|failed|no such|not found/i.test(l)).slice(-2).join(' ').slice(0, 320) || (err || out).trim().split('\n').slice(-2).join(' ').slice(0, 320) || (CS.path.basename(cmd) + ' exited with code ' + code))); });
    });
  }
  function cancel() {
    cancelled = true;
    if (current) { CS.killTree(current.pid); try { current.kill(); } catch (e2) {} }
  }
  async function ensureDeepFilter(onProgress) {
    if (dfExe()) return dfExe();
    const dest = CS.path.join(home(), CS.bin('deep-filter'));
    await Net.download(DF_URL(), dest, (p) => onProgress(p * 0.95, 'Downloading the voice engine (27 MB, once)' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    CS.chmodX(dest);
    if (!dfExe()) throw new Error(CS.bin('deep-filter') + ' disappeared after the download. An antivirus (AVG?) may have quarantined it; add ' + home() + ' to its exclusions.');
    return dest;
  }
  async function ensurePython(onProgress) {
    if (pyExe()) return pyExe();
    if (CS.mac) throw new Error('Remove Echo and Best quality are Windows only for now. Every other audio tool works on the Mac.');
    const zip = CS.path.join(home(), 'py311.zip');
    await Net.download(PY_URL, zip, (p) => onProgress(p * 0.1, 'Downloading the extra engine 1/2 (11 MB, once)' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    await CS.unzip(zip, pyDir());
    try { CS.fs.unlinkSync(zip); } catch (e) {}
    if (!pyExe()) throw new Error('python.exe was not found after unzipping (antivirus?).');
    /* the embeddable build ignores site-packages unless the ._pth file says so */
    CS.fs.writeFileSync(CS.path.join(pyDir(), 'python311._pth'), 'python311.zip\r\n.\r\nLib\\site-packages\r\nimport site\r\n');
    const gp = CS.path.join(pyDir(), 'get-pip.py');
    await Net.download(GETPIP_URL, gp, (p) => onProgress(0.1 + p * 0.03, 'Downloading pip'));
    onProgress(0.14, 'Installing pip');
    await run(pyExe(), [gp, '--no-warn-script-location'], null, pyEnv());
    return pyExe();
  }
  async function installSeparator(onProgress) {
    await ensurePython(onProgress);
    onProgress(-1, 'Installing the extra engine 2/2 (about 1.5 GB, one time)…');
    let n = 0;
    await run(pyExe(), ['-m', 'pip', 'install', '--no-warn-script-location', '--upgrade', 'audio-separator[cpu]'], (l) => { n++; onProgress(Math.min(0.9, 0.15 + n / 120), l.slice(0, 100)); }, pyEnv());
    if (!sepReady()) throw new Error('pip finished but audio_separator is missing in ' + pyDir());
    await ensureDml(onProgress);
  }
  /* GPU through DirectML (NVIDIA, AMD and Intel): swap the CPU onnxruntime for the DirectML build */
  async function ensureDml(onProgress) {
    if (dmlReady()) return;
    onProgress(0.92, 'Adding GPU acceleration…');
    try {
      await run(pyExe(), ['-m', 'pip', 'uninstall', '-y', 'onnxruntime'], null, pyEnv());
      await run(pyExe(), ['-m', 'pip', 'install', '--no-warn-script-location', 'onnxruntime-directml'], null, pyEnv());
    } catch (e) { try { await run(pyExe(), ['-m', 'pip', 'install', '--no-warn-script-location', 'onnxruntime'], null, pyEnv()); } catch (e2) {} }
  }

  /* ---- processing ---- */
  async function range() {
    const info = await CS.call('AS_range');
    if (!info.ok) throw new Error(info.error);
    const sel = info.selection || [];
    if (st.source === 'selection' && sel.length) return { start: Math.min(...sel.map(s => s.start)), end: Math.max(...sel.map(s => s.end)), info };
    if (st.source !== 'whole' && info.hasInOut) return { start: info.inPoint, end: info.outPoint, info };
    if (st.source === 'selection' && !sel.length) throw new Error('Select the clips to process first (or choose another source).');
    return { start: 0, end: info.duration, info };
  }
  async function exportWav(r, onProgress) {
    const preset = AudioTool.findWavPreset();
    if (!preset) throw new Error('No WAV export preset found in the Premiere install.');
    const dir = await outDir();
    const out = CS.path.join(dir, 'src_' + Date.now().toString(36) + '.wav');
    onProgress(0.05, 'Exporting audio from the sequence…');
    const e = await CS.call('AS_exportAudio', JSON.stringify({ out, preset, start: r.start, end: r.end, solo: null }));
    if (!e.ok) throw new Error(e.error || 'Audio export failed');
    if (!exists(out)) throw new Error('Premiere did not write the WAV file.');
    return out;
  }
  let paths = null;
  async function outDir() {
    if (!paths) { const p = await CS.call('OS_getPaths'); paths = p.ok ? p : {}; }
    const base = Hub.keys().downloadDir || CS.path.join(paths.projectDir || paths.documents || CS.os.homedir(), 'OutflowStudio');
    const d = CS.path.join(base, 'audioai'); CS.mkdirp(d); return d;
  }
  async function process(task, wav, onProgress) {
    const dir = CS.path.join(CS.path.dirname(wav), 'out_' + Date.now().toString(36)); CS.mkdirp(dir);
    if (task.engine === 'mdx' && st.quality === 'hq' && typeof task.model === 'function') task = Object.assign({}, task, { engine: 'sep' });   /* BS-RoFormer lives in the Python path */
    if (task.engine === 'df') {
      const exe = await ensureDeepFilter(onProgress);
      onProgress(-1, 'Cleaning the voice…');
      await run(exe, ['-o', dir, wav], (l) => onProgress(-1, l.slice(0, 100)));
      const f = CS.path.join(dir, CS.path.basename(wav));
      if (!exists(f)) throw new Error('The voice engine produced no file.');
      return f;
    }
    const model = typeof task.model === 'function' ? task.model(st.quality) : task.model;
    if (task.engine === 'mdx' && MDX[model]) {
      const cfg = MDX[model];
      await ensureNode(onProgress); await ensureOrt(onProgress);
      const ffmpeg = await ensureFfmpegExe(onProgress);
      const modelPath = await ensureModel(model, onProgress);
      const primary = CS.path.join(dir, 'primary.wav'), secondary = CS.path.join(dir, 'secondary.wav');
      onProgress(0.02, 'Separating' + (st.gpu ? ' on the GPU' : ' on the CPU') + '…');
      await run(nodeExe(), [separateJs(), '--model', modelPath, '--in', wav, '--primary', primary, '--secondary', secondary, '--ffmpeg', ffmpeg, '--ort', ortDir(),
        '--nfft', String(cfg.nfft), '--dimf', String(cfg.dimf), '--dimt', String(cfg.dimt), '--compensate', String(cfg.compensate)].concat(st.gpu ? [] : ['--cpu']),
        (l) => { const m = /^progress ([\d.]+)/.exec(l); if (m) onProgress(0.05 + (+m[1]) * 0.9, 'Separating · ' + Math.round(+m[1] * 100) + '%'); else if (/^backend/.test(l)) onProgress(-1, 'Running on ' + (l.includes('dml') ? 'the GPU' : 'the CPU')); });
      const out = task.stem === cfg.primary ? primary : secondary;
      if (!exists(out)) throw new Error('The separator produced no file.');
      return out;
    }
    if (!sepReady()) await installSeparator(onProgress);
    if (st.gpu && !dmlReady()) await ensureDml(onProgress);
    const modelDir = CS.path.join(home(), 'models'); CS.mkdirp(modelDir);
    const useGpu = st.gpu && dmlReady() && /\.onnx$/i.test(model);
    onProgress(-1, 'Separating' + (useGpu ? ' on the GPU' : '') + ' (the first run downloads the model)…');
    /* cli.py has no __main__ guard, so call main() directly */
    await run(pyExe(), ['-c', 'from audio_separator.utils.cli import main; main()', wav, '--model_filename', model, '--model_file_dir', modelDir, '--output_dir', dir, '--output_format', 'WAV', '--log_level', 'INFO'].concat(useGpu ? ['--use_directml'] : []),
      (l) => { const m = /(\d{1,3})%/.exec(l); onProgress(m ? +m[1] / 100 : -1, l.replace(/^\S+\s+\S+\s+-\s+\w+\s+-\s+\S+\s+-\s+/, '').slice(0, 100)); }, pyEnv());
    const files = CS.fs.readdirSync(dir).filter(f => /\.wav$/i.test(f)).map(f => CS.path.join(dir, f));
    const pick = files.find(f => task.pick.test(CS.path.basename(f)));
    if (!pick) throw new Error('No matching output in ' + dir + ' (' + files.map(f => CS.path.basename(f)).join(', ') + ')');
    return pick;
  }
  const prog = {
    show(t) { cancelled = false; $('#progress').classList.add('show'); $('#prog-title').textContent = t; $('#prog-bar').style.width = '0%'; $('#prog-text').textContent = ''; const c = $('#prog-cancel'); if (c) { c.style.display = ''; c.dataset.audioai = '1'; } },
    set(p, txt) { if (p >= 0) $('#prog-bar').style.width = Math.round(p * 100) + '%'; if (txt) $('#prog-text').textContent = txt; },
    hide() { $('#progress').classList.remove('show'); const c = $('#prog-cancel'); if (c) { c.style.display = ''; delete c.dataset.audioai; } }
  };
  let running = false;
  async function runTask(task) {
    if (!CS.inCEP || !cp) { toast('Audio AI runs inside Premiere Pro.'); return; }
    if (running) { toast('Please wait for the current task.'); return; }
    running = true; prog.show(task.name);
    try {
      const r = await range();
      if (r.end - r.start < 0.2) throw new Error('The range is too short.');
      const wav = await exportWav(r, prog.set);
      const out = await process(task, wav, prog.set);
      prog.set(0.98, 'Placing the result on the timeline');
      const pl = await CS.call('TL_placeAudio', out, r.start, task.name);
      if (!pl.ok) throw new Error(pl.error);
      toast(task.name + ' done · placed on A' + (pl.track + 1) + '.', 'ok');
      try { Usage.tick('audio:' + task.id); } catch (e) {}
      renderStatus();
    } catch (e) { toast(cancelled ? 'Cancelled.' : (e.message || String(e)), cancelled ? '' : 'err'); }
    finally { running = false; prog.hide(); }
  }

  /* ---- UI ---- */
  function renderStatus() {
    const s = $('#aa-status'); if (!s) return;
    s.innerHTML = (mdxReady() ? icon('check', 12) + ' Separation engine ready' + (st.gpu ? ' · GPU' : ' · CPU') : 'Separation engine (150 MB) downloads on first use')
      + ' · ' + (dfExe() ? icon('check', 12) + ' Voice engine ready' : 'Voice engine (27 MB) downloads on first use')
      + ' · ' + (sepReady() ? icon('check', 12) + ' Extra engine ready (Remove Echo, Best quality)' : CS.mac ? 'Remove Echo and Best quality are Windows only for now' : 'Remove Echo and Best quality add a larger engine (about 1.5 GB) on first use');
  }
  function open() {
    Hub.show('audioai');
    const box = $('#aa-tiles'); box.innerHTML = '';
    for (const t of TASKS) {
      const b = h('button', 'tile');
      b.innerHTML = '<div class="ico">' + icon(t.icon, 26) + '</div><div class="nm">' + t.name + '</div><div class="ds">' + t.desc + '</div>';
      b.addEventListener('click', () => runTask(t));
      box.appendChild(b);
    }
    const src = $('#aa-source'); src.value = st.source; src.onchange = () => { st.source = src.value; save(); };
    const q = $('#aa-quality'); if (q) { q.value = st.quality; q.onchange = () => { st.quality = q.value; save(); }; }
    const g = $('#aa-gpu'); if (g) { g.classList.toggle('on', !!st.gpu); g.onclick = () => { st.gpu = !st.gpu; g.classList.toggle('on', st.gpu); save(); }; }
    renderStatus();
  }
  function init() {
    const c = $('#prog-cancel'); if (c) c.addEventListener('click', () => { if (c.dataset.audioai) cancel(); });
    const up = $('#aa-install'); if (up) up.addEventListener('click', () => Hub.showEngines());
  }
  const safe = (fn) => { try { return !!fn(); } catch (e) { return false; } };
  const engines = () => [
    { id: 'audio-rt', name: 'Audio engine', size: '145 MB', uses: 'Remove Vocals, Extract Vocals, Remove Instrumentals', ready: safe(mdxReady), install: async (p) => { await ensureNode(p); await ensureOrt(p); } },
    { id: 'model-inst', name: 'Audio model · vocals', size: '67 MB', uses: 'Remove Vocals, Extract Vocals', ready: safe(() => exists(CS.path.join(home(), 'models', 'UVR-MDX-NET-Inst_HQ_3.onnx'))), install: (p) => ensureModel('UVR-MDX-NET-Inst_HQ_3.onnx', p) },
    { id: 'model-voc', name: 'Audio model · instrumentals', size: '67 MB', uses: 'Remove Instrumentals', ready: safe(() => exists(CS.path.join(home(), 'models', 'UVR-MDX-NET-Voc_FT.onnx'))), install: (p) => ensureModel('UVR-MDX-NET-Voc_FT.onnx', p) },
    { id: 'voice', name: 'Voice engine', size: '27 MB', uses: 'Extract Voice', ready: safe(dfExe), install: ensureDeepFilter },
    { id: 'extra', name: 'Extra engine', size: '1.5 GB', uses: 'Remove Echo, Best quality', ready: safe(sepReady), install: installSeparator, optional: true }
  ];
  return { open, init, tasks: TASKS, engines, ensureNode, ensureOrt, nodeExe, ortDir, mdxReady };
})();
