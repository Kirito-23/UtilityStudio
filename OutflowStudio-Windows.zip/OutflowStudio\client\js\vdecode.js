/* Video cards for the export, decoded with WebCodecs (hardware when the machine has it): the MP4 is read once,
   its samples are fed to a VideoDecoder, and next(f) hands back the VideoFrame that belongs to export frame f.
   The video loops when it is shorter than the carousel, like the old <video> seek did. Returns null when the
   browser or the file cannot do it, and the caller uses the ffmpeg path instead. */
const VideoFeed = (() => {
  async function open(bytes, fps, count, name) {
    if (typeof VideoDecoder === 'undefined' || typeof EncodedVideoChunk === 'undefined') return null;
    let info;
    try { info = Mp4.parse(bytes); } catch (e) { try { Log.info('export', 'mp4 reader skipped ' + (name || '') + ': ' + e.message); } catch (e2) {} return null; }
    const config = { codec: info.codec, description: info.description, optimizeForLatency: false };
    try { const sup = await VideoDecoder.isConfigSupported(config); if (!sup || !sup.supported) return null; } catch (e) { return null; }
    const samples = info.samples, ts = info.timescale;
    const periodUs = Math.round(info.duration * 1e6) || Math.round((samples[samples.length - 1].pts / ts + 1 / 25) * 1e6);
    const queue = [];             /* decoded frames, presentation order */
    let waiter = null, error = null, decoder = null, nextSample = 0, loopBase = 0, flushing = null, done = false;
    const wake = () => { if (waiter) { const w = waiter; waiter = null; w(); } };
    const make = () => {
      decoder = new VideoDecoder({ output: (fr) => { queue.push(fr); wake(); }, error: (e) => { error = e; wake(); } });
      decoder.configure(config);
    };
    make();
    /* keep the decoder busy but not flooded */
    const feed = () => {
      if (error || flushing) return;
      while (nextSample < samples.length && decoder.decodeQueueSize < 12) {
        const s = samples[nextSample++];
        decoder.decode(new EncodedVideoChunk({ type: s.key ? 'key' : 'delta', timestamp: Math.round(s.pts / ts * 1e6) + loopBase, data: bytes.subarray(s.offset, s.offset + s.size) }));
      }
      if (nextSample >= samples.length) {
        /* end of the file: drain, then start over with the timestamps moved by one period */
        flushing = decoder.flush().then(() => { loopBase += periodUs; nextSample = 0; flushing = null; wake(); }, (e) => { error = e; wake(); });
      }
    };
    let current = null;
    return {
      w: info.width, h: info.height, mode: 'webcodecs',
      async next(f) {
        const tUs = Math.round(f / fps * 1e6) + 500;   /* half a millisecond of slack */
        for (;;) {
          if (error) throw new Error('Could not decode ' + (name || 'a video card') + ': ' + (error.message || error));
          /* advance to the last frame that is not later than t */
          while (queue.length && queue[0].timestamp <= tUs) { if (current) current.close(); current = queue.shift(); }
          if (queue.length && queue[0].timestamp > tUs) { if (!current) current = queue.shift(); return current; }   /* the next one is later: current is right (or the video starts after t) */
          if (done) return current;
          feed();
          if (queue.length && queue[0].timestamp > tUs) { if (!current) current = queue.shift(); return current; }
          await new Promise((res) => { waiter = res; });
        }
      },
      prefetch() {},
      stop() {
        done = true;
        try { for (const fr of queue) fr.close(); } catch (e) {}
        queue.length = 0;
        try { if (current) current.close(); } catch (e) {}
        current = null;
        try { if (decoder && decoder.state !== 'closed') decoder.close(); } catch (e) {}
      }
    };
  }
  return { open };
})();
window.VideoFeed = VideoFeed;
