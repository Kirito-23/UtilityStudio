/* Minimal MP4 (ISO BMFF) reader for the export: finds the first H.264 / HEVC video track, plain or fragmented
   (moof/mdat), and lists its samples with byte offsets, presentation times and keyframe flags, plus the codec string
   and the avcC / hvcC description WebCodecs needs. Anything unusual throws, and the caller falls back to ffmpeg. */
const Mp4 = (() => {
  function parse(buf) {
    /* works on any Uint8Array (Node Buffer included): no Buffer methods, so the same code runs in a plain browser */
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    const u32 = (o) => dv.getUint32(o), i32 = (o) => dv.getInt32(o), u64 = (o) => Number(dv.getBigUint64(o)), u16 = (o) => dv.getUint16(o);
    const str = (a, b) => String.fromCharCode.apply(null, buf.subarray(a, b));
    const boxes = (start, end) => { const out = []; let o = start; while (o + 8 <= end) { let size = u32(o); const type = str(o + 4, o + 8); let hdr = 8; if (size === 1) { size = u64(o + 8); hdr = 16; } else if (size === 0) size = end - o; if (size < hdr) break; out.push({ type, start: o + hdr, end: o + size, box: o }); o += size; } return out; };
    const find = (list, type) => list.find((b) => b.type === type);
    const top = boxes(0, buf.length);
    const moov = find(top, 'moov'); if (!moov) throw new Error('no moov');
    const mb = boxes(moov.start, moov.end);

    /* the video track: id, timescale, duration, codec */
    let track = null;
    for (const trak of mb.filter((b) => b.type === 'trak')) {
      const tb = boxes(trak.start, trak.end);
      const mdia = find(tb, 'mdia'); if (!mdia) continue;
      const db = boxes(mdia.start, mdia.end);
      const hdlr = find(db, 'hdlr'); if (!hdlr || str(hdlr.start + 8, hdlr.start + 12) !== 'vide') continue;
      const tkhd = find(tb, 'tkhd'); const trackId = tkhd ? (buf[tkhd.start] === 1 ? u32(tkhd.start + 20) : u32(tkhd.start + 12)) : 1;
      const mdhd = find(db, 'mdhd'); const mv = buf[mdhd.start];
      const timescale = mv === 1 ? u32(mdhd.start + 20) : u32(mdhd.start + 12);
      const duration = mv === 1 ? u64(mdhd.start + 24) : u32(mdhd.start + 16);
      const minf = find(db, 'minf'), stbl = find(boxes(minf.start, minf.end), 'stbl');
      const sb = boxes(stbl.start, stbl.end);
      const stsd = find(sb, 'stsd'); const e0 = boxes(stsd.start + 8, stsd.end)[0];
      if (!e0) throw new Error('no sample entry');
      const width = u16(e0.start + 24), height = u16(e0.start + 26);
      const inner = boxes(e0.start + 78, e0.end);
      let codec, description;
      if (e0.type === 'avc1' || e0.type === 'avc3') {
        const avcC = find(inner, 'avcC'); if (!avcC) throw new Error('no avcC');
        description = buf.subarray(avcC.start, avcC.end);
        codec = 'avc1.' + [description[1], description[2], description[3]].map((x) => x.toString(16).padStart(2, '0')).join('');
      } else if (e0.type === 'hvc1' || e0.type === 'hev1') {
        const hvcC = find(inner, 'hvcC'); if (!hvcC) throw new Error('no hvcC');
        description = buf.subarray(hvcC.start, hvcC.end);
        codec = 'hvc1.1.6.L120.B0';
      } else throw new Error('codec ' + e0.type + ' not supported');
      track = { trackId, timescale, duration, codec, description, width, height, sb };
      break;
    }
    if (!track) throw new Error('no video track');
    const { timescale, sb } = track;
    const samples = [];

    if (find(top, 'moof')) {
      /* fragmented: defaults from trex, then every moof/traf/trun of this track */
      let defDur = 0, defSize = 0, defFlags = 0;
      const mvex = find(mb, 'mvex');
      if (mvex) for (const x of boxes(mvex.start, mvex.end)) if (x.type === 'trex' && u32(x.start + 4) === track.trackId) { defDur = u32(x.start + 12); defSize = u32(x.start + 16); defFlags = u32(x.start + 20); }
      for (const moof of top.filter((b) => b.type === 'moof')) {
        for (const traf of boxes(moof.start, moof.end).filter((b) => b.type === 'traf')) {
          const fb = boxes(traf.start, traf.end);
          const tfhd = find(fb, 'tfhd'); if (!tfhd || u32(tfhd.start + 4) !== track.trackId) continue;
          const tf = u32(tfhd.start) & 0xffffff;
          let p = tfhd.start + 8, base = moof.box;
          if (tf & 0x1) { base = u64(p); p += 8; }
          if (tf & 0x2) p += 4;
          let fDur = defDur, fSize = defSize, fFlags = defFlags;
          if (tf & 0x8) { fDur = u32(p); p += 4; }
          if (tf & 0x10) { fSize = u32(p); p += 4; }
          if (tf & 0x20) { fFlags = u32(p); p += 4; }
          const tfdt = find(fb, 'tfdt');
          let dts = tfdt ? (buf[tfdt.start] === 1 ? u64(tfdt.start + 4) : u32(tfdt.start + 4)) : (samples.length ? samples[samples.length - 1].dts + fDur : 0);
          let offset = base;
          for (const trun of fb.filter((b) => b.type === 'trun')) {
            const ver = buf[trun.start], fl = u32(trun.start) & 0xffffff, n = u32(trun.start + 4);
            let q = trun.start + 8;
            if (fl & 0x1) { offset = base + i32(q); q += 4; }
            let first = null; if (fl & 0x4) { first = u32(q); q += 4; }
            for (let i = 0; i < n; i++) {
              let dur = fDur, size = fSize, flags = fFlags, cto = 0;
              if (fl & 0x100) { dur = u32(q); q += 4; }
              if (fl & 0x200) { size = u32(q); q += 4; }
              if (fl & 0x400) { flags = u32(q); q += 4; }
              if (fl & 0x800) { cto = ver === 0 ? u32(q) : i32(q); q += 4; }
              if (i === 0 && first !== null) flags = first;
              samples.push({ offset, size, dts, pts: dts + cto, key: !((flags >> 16) & 1) });
              offset += size; dts += dur;
            }
          }
        }
      }
      if (!samples.length) throw new Error('no fragments for the video track');
    } else {
      /* plain: the sample tables */
      const stts = find(sb, 'stts'), stsz = find(sb, 'stsz'), stsc = find(sb, 'stsc'), stco = find(sb, 'stco') || find(sb, 'co64'), stss = find(sb, 'stss'), ctts = find(sb, 'ctts');
      if (!stts || !stsz || !stsc || !stco) throw new Error('sample tables missing');
      const sizes = []; { const n = u32(stsz.start + 8), fixed = u32(stsz.start + 4); for (let i = 0; i < n; i++) sizes.push(fixed || u32(stsz.start + 12 + i * 4)); }
      const count = sizes.length;
      const dts = new Float64Array(count); { let t = 0, i = 0; const n = u32(stts.start + 4); for (let k = 0; k < n; k++) { const c = u32(stts.start + 8 + k * 8), d = u32(stts.start + 12 + k * 8); for (let j = 0; j < c && i < count; j++) { dts[i++] = t; t += d; } } }
      const cto = new Float64Array(count); if (ctts) { let i = 0; const n = u32(ctts.start + 4); const v = buf[ctts.start]; for (let k = 0; k < n; k++) { const c = u32(ctts.start + 8 + k * 8); let off = u32(ctts.start + 12 + k * 8); if (v === 1 || off > 0x7fffffff) off = off | 0; for (let j = 0; j < c && i < count; j++) cto[i++] = off; } }
      const key = new Uint8Array(count); if (stss) { const n = u32(stss.start + 4); for (let k = 0; k < n; k++) { const s = u32(stss.start + 8 + k * 4) - 1; if (s >= 0 && s < count) key[s] = 1; } } else key.fill(1);
      const offsets = new Float64Array(count); {
        const co64 = stco.type === 'co64', nChunks = u32(stco.start + 4);
        const chunkOff = (i) => co64 ? u64(stco.start + 8 + i * 8) : u32(stco.start + 8 + i * 4);
        const nsc = u32(stsc.start + 4); const runs = []; for (let k = 0; k < nsc; k++) runs.push({ first: u32(stsc.start + 8 + k * 12) - 1, per: u32(stsc.start + 12 + k * 12) });
        let s = 0;
        for (let c = 0; c < nChunks && s < count; c++) {
          let per = runs[0].per; for (const r of runs) if (c >= r.first) per = r.per;
          let o = chunkOff(c);
          for (let j = 0; j < per && s < count; j++) { offsets[s] = o; o += sizes[s]; s++; }
        }
      }
      for (let i = 0; i < count; i++) samples.push({ offset: offsets[i], size: sizes[i], dts: dts[i], pts: dts[i] + cto[i], key: !!key[i] });
    }
    if (!samples[0].key) throw new Error('does not start with a keyframe');
    /* duration: the header when it has one, else the end of the last sample */
    let duration = track.duration / timescale;
    if (!duration) { const last = samples[samples.length - 1]; const step = samples.length > 1 ? (last.dts - samples[samples.length - 2].dts) : timescale / 25; duration = (Math.max.apply(null, samples.slice(-4).map((s) => s.pts)) + step) / timescale; }
    return { codec: track.codec, description: track.description, width: track.width, height: track.height, timescale, duration, samples };
  }
  return { parse };
})();
window.Mp4 = Mp4;
