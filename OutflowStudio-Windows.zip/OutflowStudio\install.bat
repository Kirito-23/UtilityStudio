@echo off
setlocal
REM Installs (or updates) the 3D Carousel panel for Premiere Pro. No admin needed.
REM 1) enables unsigned (developer) extensions for CEP 9-12 (current user)
REM 2) copies this folder to %APPDATA%\Adobe\CEP\extensions\OutflowStudio
REM Run it again after editing files to push the changes into Premiere.

set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
set "DST=%APPDATA%\Adobe\CEP\extensions\OutflowStudio"

for %%V in (9 10 11 12) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
)

if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
robocopy "%SRC%" "%DST%" /MIR /XD .claude site backend tools docs node_modules .git /R:1 /W:1 /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo Copy failed. Close Premiere Pro and try again.
  pause
  exit /b 1
)

echo.
echo Installed to: %DST%
if exist "%APPDATA%\Adobe\CEP\extensions\ThriveToday_3DCarousel" rmdir /s /q "%APPDATA%\Adobe\CEP\extensions\ThriveToday_3DCarousel"
echo Restart Premiere Pro, then open  Window ^> Extensions ^> Outflow Studio
echo.
pause
