/*  Motion Curves: read the keyframed properties of a clip, and write eased ("baked") keyframes back.
    Premiere's scripting API can set a keyframe to Bezier but not its handles, so a curve is written as a row of
    linear keyframes that follow it (one per frame or every few frames). The panel computes the values; this side
    finds the clip, lists what is keyframed, removes the old keys in a range and writes the new ones. It can also
    move Motion / Opacity keyframes onto a Transform effect (motion blur), on the clip or on an adjustment layer.
    Requires index.jsx, native.jsx, quickfx.jsx, transitions.jsx and assist.jsx helpers. */

/* kind -> Transform parameter name and default value. Lookup tables, not nested ternaries: ExtendScript groups
   a ? b : c ? d : e from the left, which made every kind resolve to "Rotation". */
var MC_PARAM = { pos: "Position", scale: "Scale Height", rot: "Rotation", op: "Opacity" };
function MC_default(kind, norm, W, H) {
    if (kind === "pos") { if (norm) return [0.5, 0.5]; return [W / 2, H / 2]; }
    if (kind === "rot") return 0;
    return 100;
}
function MC_time(sec) { var t = new Time(); t.ticks = String(Math.round(sec * C3D_TICKS_PER_SECOND)); return t; }

/* a value from Premiere -> number | [numbers]; null when it is not numeric (colours, booleans, text) */
function MC_num(v) {
    if (typeof v === "number") return isFinite(v) ? v : null;
    if (v instanceof Array) {
        var out = [];
        for (var i = 0; i < v.length; i++) { if (typeof v[i] !== "number" || !isFinite(v[i])) return null; out.push(v[i]); }
        return out.length ? out : null;
    }
    return null;
}

function MC_clip(o) {
    var seq = app.project.activeSequence;
    if (!seq) throw new Error("Open a sequence first.");
    var tr = seq.videoTracks[o.track];
    if (!tr) throw new Error("Track V" + (o.track + 1) + " not found.");
    var clip = C3D_findClipAt(tr, o.start);
    if (!clip) throw new Error("The clip moved; select it again.");
    return clip;
}

/* the clip at (track, start) with every time-varying numeric property and its keys */
function MC_listProps(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var clip = MC_clip(o);
        var fps = C3D_TICKS_PER_SECOND / parseFloat(seq.timebase);
        var props = [];
        var comps = clip.components;
        for (var ci = 0; ci < comps.numItems; ci++) {
            var comp = comps[ci];
            var params = comp.properties;
            for (var pi = 0; pi < params.numItems; pi++) {
                var p = params[pi];
                var varying = false;
                try { varying = p.isTimeVarying(); } catch (e1) { continue; }
                if (!varying) continue;
                var keys = null;
                try { keys = p.getKeys(); } catch (e2) { continue; }
                if (!keys || keys.length < 2) continue;
                var list = [], ok = true, dims = 1;
                for (var k = 0; k < keys.length; k++) {
                    var t = keys[k], sec = t.seconds;
                    var v = null;
                    try { v = MC_num(p.getValueAtKey(t)); } catch (e3) { v = null; }
                    if (v === null) { ok = false; break; }
                    if (v instanceof Array) dims = v.length;
                    list.push([sec, v]);
                }
                if (!ok || list.length < 2) continue;
                props.push({ comp: ci, param: pi, compName: String(comp.displayName), name: String(p.displayName), dims: dims, keys: list });
            }
        }
        var ip = 0; try { ip = clip.inPoint.seconds; } catch (eIP) {}
        return C3D_json({ ok: true, name: clip.name, start: clip.start.seconds, end: clip.end.seconds, inPoint: ip, fps: fps, width: seq.frameSizeHorizontal, height: seq.frameSizeVertical, props: props });
    } catch (e) { return C3D_err(e); }
}

function MC_clearKeys(p, from, to, warnings, label) {
    try { p.removeKeyRange(MC_time(from), MC_time(to), true); } catch (e1) {
        try { var ks = p.getKeys(); for (var k = ks.length - 1; k >= 0; k--) { var sec = ks[k].seconds; if (sec >= from && sec <= to) p.removeKey(ks[k]); } } catch (e2) { warnings.push(label + ": could not clear old keys (" + e2 + ")"); }
    }
}

/* write keys on one clip: props = [{ comp, param, keys: [[sec, value], ...] }]. The keys between the first and last
   given time are removed first, then every key is added linear, so a baked curve replaces whatever easing the
   original keys had. */
function MC_writeProps(clip, props, warnings) {
    var written = 0;
    for (var i = 0; i < props.length; i++) {
        var pr = props[i];
        var comp = clip.components[pr.comp]; if (!comp) { warnings.push("component " + pr.comp + " missing"); continue; }
        var p = comp.properties[pr.param]; if (!p) { warnings.push("property " + pr.param + " missing"); continue; }
        var keys = pr.keys; if (!keys || keys.length < 2) continue;
        /* 0 is linear, which a baked curve needs because its shape is already in the keys. A caller that sent only
           the endpoints asks for 1 and lets Premiere do the easing between them. */
        var it = (pr.interp === undefined || pr.interp === null) ? 0 : pr.interp;
        var first = keys[0][0], last = keys[keys.length - 1][0];
        MC_clearKeys(p, first - 0.002, last + 0.002, warnings, pr.name || ("property " + pr.param));
        try { p.setTimeVarying(true); } catch (e3) {}
        var n = 0;
        for (var k2 = 0; k2 < keys.length; k2++) {
            var t = MC_time(keys[k2][0]);
            try { p.addKey(t); } catch (e4) {}
            try { p.setValueAtKey(t, keys[k2][1], true); n++; } catch (e5) { warnings.push((pr.name || "key") + " at " + keys[k2][0].toFixed(3) + " failed (" + e5 + ")"); }
            try { p.setInterpolationTypeAtKey(t, it, true); } catch (e6) {}
        }
        written += n;
    }
    return written;
}

/* { track, start, props: [{ comp, param, keys }] } */
function MC_writeKeys(json) {
    try {
        var o = C3D_loadPayload(json), warnings = [];
        var written = MC_writeProps(MC_clip(o), o.props, warnings);
        return C3D_json({ ok: true, written: written, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/* a new adjustment layer directly above the clip, spanning it. null (with a warning) when none can be made. */
function MC_layerAbove(clip, template, name, warnings) {
    var seq = app.project.activeSequence;
    var adj = TR_findVideoAL(app.project.rootItem, 0), layer = adj ? "outflow" : "";
    if (!adj) { adj = TR_importAdjustmentTemplate(template); layer = adj ? "outflow-new" : ""; }
    if (!adj) { adj = QF_findAdjustmentItem(app.project.rootItem, 0); layer = adj ? "project" : ""; }
    if (!adj) { warnings.push("no adjustment layer could be made"); return null; }
    var s = clip.start.seconds, e = clip.end.seconds, eps = 0.5 / AS_fps(seq);
    var tIdx = TR_trackAbove(seq, s, s, e, eps);
    while (tIdx >= app.project.activeSequence.videoTracks.numTracks) { if (!C3D_addVideoTrack(app.project.activeSequence)) { warnings.push("could not add a track"); return null; } }
    seq = app.project.activeSequence;
    var track = seq.videoTracks[tIdx], ok = false;
    try { ok = track.overwriteClip(adj, s); } catch (e3) {}
    if (!ok) { warnings.push("could not place the adjustment layer"); return null; }
    var target = C3D_findClipAt(track, s);
    if (!target) { warnings.push("adjustment layer not found after placing it"); return null; }
    try { var en = new Time(); en.seconds = e; target.end = en; } catch (e4) { warnings.push("length: " + e4); }
    try { target.name = name || "Motion Curves"; } catch (e5) {}
    return { target: target, tIdx: tIdx, start: s, layer: layer };
}
function MC_propIndex(comp, prop) {
    var want = ""; try { want = String(prop.displayName); } catch (e) {}
    for (var i = 0; i < comp.properties.numItems; i++) { var n = ""; try { n = String(comp.properties[i].displayName); } catch (e2) {} if (n === want) return i; }
    return -1;
}
function MC_compIndex(clip, comp) {
    var want = ""; try { want = String(comp.displayName); } catch (e) {}
    for (var i = clip.components.numItems - 1; i >= 0; i--) { var n = ""; try { n = String(clip.components[i].displayName); } catch (e2) {} if (n === want) return i; }
    return -1;
}

/* effects on a clip (the Transform effect is added when missing; an existing one is reused so in + out share it).
   effects = [{ name, params: [{ name, alias, point, rel, keys: [[secFromClipStart, value]], orig }] }]
   Returns { target, map: { "Effect/Param": { comp, param, layerKeys } } } so the panel can address the keys later. */
function MC_applyEffects(target, tIdx, qeStart, effects, warnings) {
    var seq = app.project.activeSequence, W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
    var tOff = 0; try { tOff = target.inPoint.seconds; } catch (e6) {}
    var qeSeq = null;
    try { app.enableQE(); qeSeq = qe.project.getActiveSequence(); } catch (e0) {}
    if (!qeSeq) throw new Error("QE DOM not available.");
    var map = {};
    for (var f = 0; f < effects.length; f++) {
        var fx = effects[f], comp = null;
        if (fx.name === "Motion" || fx.name === "Opacity") comp = C3D_componentByName(target, fx.name);
        else {
            comp = QF_lastComponentByName(target, fx.name);
            if (!comp) {
                var qc = C3D_qeClipAt(qeSeq, tIdx, qeStart);
                if (!qc) { warnings.push("QE clip not found"); continue; }
                if (!C3D_qeAddEffect(qc, fx.name)) { warnings.push("effect not found: " + fx.name); continue; }
                target = C3D_findClipAt(app.project.activeSequence.videoTracks[tIdx], qeStart) || target;
                comp = QF_lastComponentByName(target, fx.name);
            }
        }
        if (!comp) { warnings.push(fx.name + " component missing"); continue; }
        for (var p = 0; p < fx.params.length; p++) {
            var pa = fx.params[p], prop = TR_propByName(comp, pa.name, pa.alias);
            if (!prop) { if (!pa.optional) warnings.push(fx.name + ": no parameter '" + pa.name + "' (has: " + TR_propNames(comp) + ")"); continue; }
            var conv;
            if (pa.point) {
                var norm = C3D_isNormalized(prop), base = [0.5, 0.5];
                try { var dv = prop.getValue(); if (dv && dv.length === 2) base = dv; } catch (e2) {}
                conv = (function (pa, norm, base) { return function (kk) {
                    if (pa.rel) return norm ? [base[0] + kk[1][0], base[1] + kk[1][1]] : [base[0] + kk[1][0] * W, base[1] + kk[1][1] * H];
                    return norm ? [kk[1][0], kk[1][1]] : [kk[1][0] * W, kk[1][1] * H];
                }; })(pa, norm, base);
            } else conv = function (kk) { return kk[1]; };
            var before = C3D_KEYS_WRITTEN;
            if (pa.keys.length > 1) MC_clearKeys(prop, pa.keys[0][0] + tOff - 0.002, pa.keys[pa.keys.length - 1][0] + tOff + 0.002, warnings, pa.name);
            C3D_setKeys(prop, pa.keys, tOff, conv, warnings, fx.name + "/" + pa.name);
            if (pa.keys.length > 1 && C3D_KEYS_WRITTEN > before) {
                /* 0 is linear, which is right for a baked curve: the shape is already in the keyframes. A caller
                   that only wrote a start and an end asks for 1 (Bezier) and lets Premiere do the easing. */
                var it = (pa.interp === undefined || pa.interp === null) ? 0 : pa.interp;
                for (var k = 0; k < pa.keys.length; k++) { try { prop.setInterpolationTypeAtKey(MC_time(pa.keys[k][0] + tOff), it, true); } catch (e7) {} }
            }
            /* where the keys ended up, in the target's own time and value space (for re-curving from the panel) */
            var lk = []; if (pa.orig) for (var q = 0; q < pa.orig.length; q++) lk.push([pa.orig[q][0] + tOff, conv(pa.orig[q])]);
            map[fx.name + "/" + pa.name] = { comp: MC_compIndex(target, comp), param: MC_propIndex(comp, prop), layerKeys: lk };
        }
    }
    return { target: target, map: map };
}

/* Animate a clip: { track, start, mode: "transform" | "motion" | "adjustment", template, name, effects }
   Key times count from the clip's start. */
function MC_animate(json) {
    try {
        var o = C3D_loadPayload(json), warnings = [], mode = o.mode || "transform";
        var clip = MC_clip(o), target = clip, tIdx = o.track, qeStart = clip.start.seconds, layer = null;
        if (mode === "adjustment") {
            var L = MC_layerAbove(clip, o.template, o.name, warnings);
            if (L) { target = L.target; tIdx = L.tIdx; qeStart = L.start; layer = { track: L.tIdx, start: L.start, kind: L.layer }; }
            else { mode = "transform"; warnings.push("keyframed the clip itself"); }
        }
        C3D_KEYS_WRITTEN = 0;
        var r = MC_applyEffects(target, tIdx, qeStart, o.effects, warnings);
        return C3D_json({ ok: true, keyframes: C3D_KEYS_WRITTEN, mode: mode, track: tIdx, layer: layer, map: r.map, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/* Move keyframes off a clip's Motion / Opacity onto a Transform effect, on the clip itself or on a new adjustment
   layer above it. The clip's own property goes back to its default (no motion left on it).
   { track, start, mode: "transform" | "adjustment", template, name, shutter,
     props: [{ comp, param, kind: "pos" | "scale" | "rot" | "op", keys (baked, media time), orig (the unbaked keys) }] } */
function MC_moveKeys(json) {
    try {
        var o = C3D_loadPayload(json), warnings = [], mode = o.mode || "adjustment";
        var seq = app.project.activeSequence, W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
        var clip = MC_clip(o), ip = 0; try { ip = clip.inPoint.seconds; } catch (eI) {}
        var params = [], hasScale = false, kinds = {};
        for (var i = 0; i < o.props.length; i++) {
            var pr = o.props[i], comp = clip.components[pr.comp]; if (!comp) { warnings.push("component " + pr.comp + " missing"); continue; }
            var p = comp.properties[pr.param]; if (!p) { warnings.push("property " + pr.param + " missing"); continue; }
            var norm = pr.kind === "pos" ? C3D_isNormalized(p) : false;
            var name = MC_PARAM[pr.kind] || "Opacity";
            var rel = function (keys) {
                var out = [];
                for (var k = 0; k < keys.length; k++) {
                    var v = keys[k][1];
                    if (pr.kind === "pos") v = norm ? [v[0], v[1]] : [v[0] / W, v[1] / H];
                    out.push([keys[k][0] - ip, v]);
                }
                return out;
            };
            params.push({ name: name, alias: pr.kind === "scale" ? ["Scale"] : null, point: pr.kind === "pos", rel: false, keys: rel(pr.keys), orig: rel(pr.orig || pr.keys), interp: o.interp });
            if (pr.kind === "scale") hasScale = true;
            kinds[pr.kind] = true;
            /* the clip itself: keys off, value back to default */
            MC_clearKeys(p, -1, 100000, warnings, name);
            try { p.setTimeVarying(false); } catch (e2) {}
            var def = MC_default(pr.kind, norm, W, H);
            try { p.setValue(def, true); } catch (e3) { warnings.push(name + ": reset failed (" + e3 + ")"); }
        }
        if (!params.length) return C3D_err("Nothing to move.");
        if (hasScale) params.unshift({ name: "Uniform Scale", keys: [[0, true]] });
        params.push({ name: "Use Composition's Shutter Angle", keys: [[0, false]], optional: true }, { name: "Shutter Angle", keys: [[0, o.shutter || 180]], optional: true });
        var target = clip, tIdx = o.track, qeStart = clip.start.seconds, layer = null;
        if (mode === "adjustment") {
            var L = MC_layerAbove(clip, o.template, o.name, warnings);
            if (L) { target = L.target; tIdx = L.tIdx; qeStart = L.start; layer = { track: L.tIdx, start: L.start, kind: L.layer }; }
            else { mode = "transform"; warnings.push("keyframed the clip itself"); }
        }
        C3D_KEYS_WRITTEN = 0;
        var r = MC_applyEffects(target, tIdx, qeStart, [{ name: "Transform", params: params }], warnings);
        var out = [];
        for (var kd in kinds) {
            var key = "Transform/" + (MC_PARAM[kd] || "Opacity");
            if (r.map[key]) out.push({ kind: kd, comp: r.map[key].comp, param: r.map[key].param, layerKeys: r.map[key].layerKeys });
        }
        return C3D_json({ ok: true, keyframes: C3D_KEYS_WRITTEN, mode: mode, target: { track: tIdx, start: qeStart }, layer: layer, props: out, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/* Undo a move: the clip gets its keys back; the adjustment layer is removed, or the Transform keys are cleared.
   { track, start, props: [{ comp, param, keys }], layer: { track, start } | null, target: { track, start }, tparams: [{ comp, param, kind }] } */
function MC_undoMove(json) {
    try {
        var o = C3D_loadPayload(json), warnings = [];
        var clip = MC_clip(o);
        var written = MC_writeProps(clip, o.props, warnings);
        if (o.layer) {
            try { var lc = MC_clip(o.layer); lc.remove(false, false); } catch (e1) { warnings.push("layer not removed: " + e1); }
        } else if (o.target && o.tparams) {
            try {
                var tc = MC_clip(o.target), seq = app.project.activeSequence;
                for (var i = 0; i < o.tparams.length; i++) {
                    var tp = o.tparams[i], comp = tc.components[tp.comp]; if (!comp) continue;
                    var p = comp.properties[tp.param]; if (!p) continue;
                    MC_clearKeys(p, -1, 100000, warnings, "Transform");
                    try { p.setTimeVarying(false); } catch (e2) {}
                    var def = MC_default(tp.kind, tp.kind === "pos" && C3D_isNormalized(p), seq.frameSizeHorizontal, seq.frameSizeVertical);
                    try { p.setValue(def, true); } catch (e3) {}
                }
            } catch (e4) { warnings.push("Transform not cleared: " + e4); }
        }
        return C3D_json({ ok: true, written: written, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}
