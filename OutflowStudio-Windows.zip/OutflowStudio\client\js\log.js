/* Diagnostic log, written to %APPDATA%\OutflowStudio\logs\outflow-YYYY-MM-DD.log (7 days kept).
   Not shown in the panel. Every host call, every assistant step and every error lands here so a
   misbehaving run can be reconstructed. The host script appends to the same file (C3D_log). */
const Log = (() => {
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const fs = nodeReq ? nodeReq('fs') : null, pathM = nodeReq ? nodeReq('path') : null;
  const proc = (window.cep_node && window.cep_node.process) || (typeof process !== 'undefined' ? process : null);
  const buffer = [];
  let file = null, dir = null;
  function init() {
    try {
      if (!fs || !pathM) return;
      const osm = nodeReq('os');
      const base = osm.platform() === 'darwin' ? pathM.join(osm.homedir(), 'Library', 'Application Support') : ((proc && proc.env && proc.env.APPDATA) || osm.homedir());
      dir = pathM.join(base, 'OutflowStudio', 'logs');
      fs.mkdirSync(dir, { recursive: true });
      const d = new Date(), day = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      file = pathM.join(dir, 'outflow-' + day + '.log');
      for (const f of fs.readdirSync(dir)) { try { const p = pathM.join(dir, f); if (Date.now() - fs.statSync(p).mtimeMs > 7 * 86400e3) fs.unlinkSync(p); } catch (e) {} }
      write('INFO', 'panel', 'session start', { ua: navigator.userAgent, url: location.href });
    } catch (e) { file = null; }
  }
  const safe = (v, max) => { let s; try { s = typeof v === 'string' ? v : JSON.stringify(v, (k, x) => (x instanceof Float32Array || x instanceof Int16Array || x instanceof Uint8Array) ? ('[' + x.constructor.name + ' ' + x.length + ']') : x); } catch (e) { s = String(v); } if (s === undefined) s = ''; return s.length > (max || 1500) ? s.slice(0, max || 1500) + '…(' + s.length + ')' : s; };
  function write(level, tag, msg, data) {
    const t = new Date().toISOString().replace('T', ' ').slice(0, 23);
    const line = t + ' ' + level.padEnd(5) + ' [' + tag + '] ' + msg + (data !== undefined ? ' ' + safe(data) : '');
    buffer.push(line); if (buffer.length > 4000) buffer.shift();
    if (file) { try { fs.appendFileSync(file, line + '\n'); } catch (e) {} }
  }
  const info = (tag, msg, data) => write('INFO', tag, msg, data);
  const warn = (tag, msg, data) => write('WARN', tag, msg, data);
  const error = (tag, msg, data) => write('ERROR', tag, msg, data);
  const debug = (tag, msg, data) => write('DEBUG', tag, msg, data);
  const section = (name) => write('INFO', 'section', '════════ ' + name + ' ════════');
  /* summarise a host result for the log without dumping huge payloads */
  function summary(r) {
    if (!r || typeof r !== 'object') return safe(r, 300);
    const o = {};
    for (const k of Object.keys(r)) { const v = r[k]; if (Array.isArray(v)) o[k] = '[' + v.length + ']' + (v.length && v.length <= 6 ? ' ' + safe(v, 400) : ''); else if (v && typeof v === 'object') o[k] = safe(v, 200); else o[k] = v; }
    return safe(o, 900);
  }
  window.addEventListener('error', (e) => error('window', 'uncaught: ' + (e.message || e), { file: e.filename, line: e.lineno, stack: e.error && e.error.stack ? String(e.error.stack).slice(0, 800) : '' }));
  window.addEventListener('unhandledrejection', (e) => error('window', 'unhandled rejection: ' + (e.reason && e.reason.message ? e.reason.message : safe(e.reason, 300)), { stack: e.reason && e.reason.stack ? String(e.reason.stack).slice(0, 800) : '' }));
  const origErr = console.error.bind(console); console.error = (...a) => { try { error('console', a.map(x => safe(x, 300)).join(' ')); } catch (e) {} origErr(...a); };
  init();
  return { info, warn, error, debug, section, summary, file: () => file, dir: () => dir, tail: (n) => buffer.slice(-(n || 200)) };
})();

window.Log = Log;
