/* WebGL quad renderer: textured / solid rounded rectangles with per-quad blur,
   border, glow, tint, gradient alpha. Output is premultiplied alpha so PNG
   export from the canvas has a clean straight-alpha transparency. */
const PX_PER_UNIT = 200;

const VERT_SRC = `
attribute vec2 a_pos;
uniform mat4 u_mvp;
uniform vec2 u_quad;
varying vec2 v_uv;
void main() {
  v_uv = a_pos + 0.5;
  gl_Position = u_mvp * vec4(a_pos * u_quad, 0.0, 1.0);
}`;

const FRAG_SRC = `
#ifdef GL_OES_standard_derivatives
#extension GL_OES_standard_derivatives : enable
#endif
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 v_uv;
uniform sampler2D u_tex;
uniform float u_solid;
uniform vec4 u_color;
uniform vec2 u_sizePx;
uniform float u_padPx;
uniform float u_radius;
uniform float u_blur;
uniform float u_lod;
uniform float u_opacity;
uniform vec2 u_uvScale;
uniform vec2 u_uvOff;
uniform vec3 u_tint;
uniform float u_tintAmt;
uniform float u_gray;
uniform float u_bright;
uniform float u_border;
uniform vec4 u_borderColor;
uniform float u_gradTop;
uniform float u_gradBot;
uniform float u_vignette;
uniform float u_glow;
uniform vec4 u_glowColor;
uniform vec2 u_taps[16];

float sdRR(vec2 p, vec2 b, float r) {
  vec2 q = abs(p) - b + r;
  return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

vec4 card(vec2 c, float aa) {
  float d = sdRR(c, u_sizePx * 0.5, u_radius);
  float m = 1.0 - smoothstep(-aa, aa, d);
  vec4 col = vec4(0.0);
  if (m > 0.0) {
    vec2 uv = c / u_sizePx + 0.5;
    if (u_solid > 0.5) col = u_color;
    else col = texture2D(u_tex, uv * u_uvScale + u_uvOff, u_lod);
    if (u_vignette > 0.0) {
      float vg = 1.0 - u_vignette * smoothstep(0.35, 1.25, length((uv - 0.5) * 2.0));
      col.rgb *= vg;
    }
    if (u_border > 0.0) {
      float bd = smoothstep(-u_border - aa, -u_border + aa, d);
      col = mix(col, u_borderColor, bd);
    }
    col.a *= m;
  }
  if (u_glow > 0.0) {
    float g = exp(-max(d, 0.0) / u_glow) * u_glowColor.a;
    col = vec4(mix(u_glowColor.rgb, col.rgb, m), col.a + g * (1.0 - m));
  }
  return col;
}

void main() {
  vec2 full = u_sizePx + 2.0 * u_padPx;
  vec2 c = (v_uv - 0.5) * full;
  float aa = 0.75;
#ifdef GL_OES_standard_derivatives
  aa = max(0.6, fwidth(c.x) * 0.7);
#endif
  vec4 acc = vec4(0.0);
  if (u_blur < 0.5) {
    vec4 s = card(c, aa);
    acc = vec4(s.rgb * s.a, s.a);
  } else {
    float aa2 = aa + u_blur * 0.2;
    vec4 s0 = card(c, aa2);
    acc += vec4(s0.rgb * s0.a, s0.a);
    for (int k = 0; k < 16; k++) {
      vec4 s = card(c + u_taps[k] * u_blur, aa2);
      acc += vec4(s.rgb * s.a, s.a);
    }
    for (int k = 0; k < 8; k++) {
      vec4 s = card(c + u_taps[k] * u_blur * 0.45, aa2);
      acc += vec4(s.rgb * s.a, s.a);
    }
    acc /= 25.0;
  }
  float a = acc.a;
  vec3 rgb = acc.rgb;
  float l = dot(rgb, vec3(0.299, 0.587, 0.114));
  rgb = mix(rgb, vec3(l), u_gray);
  rgb = mix(rgb, u_tint * a, u_tintAmt);
  rgb *= u_bright;
  float grad = mix(u_gradBot, u_gradTop, v_uv.y) * u_opacity;
  gl_FragColor = vec4(rgb, a) * grad;
}`;

const POISSON = [
  -0.94201624, -0.39906216,  0.94558609, -0.76890725, -0.09418410, -0.92938870,  0.34495938,  0.29387760,
  -0.91588581,  0.45771432, -0.81544232, -0.87912464, -0.38277543,  0.27676845,  0.97484398,  0.75648379,
   0.44323325, -0.97511554,  0.53742981, -0.47373420, -0.26496911, -0.41893023,  0.79197514,  0.19090188,
  -0.24188840,  0.99706507, -0.81409955,  0.91437590,  0.19984126,  0.78641367,  0.14383161, -0.14100790
];

function hexToRgb(hex) {
  const h = (hex || '#ffffff').replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: true, depth: false, stencil: false, powerPreference: 'high-performance' });
    if (!gl) throw new Error('WebGL is not available in this panel.');
    this.gl = gl;
    gl.getExtension('OES_standard_derivatives');
    this.prog = this._program(VERT_SRC, FRAG_SRC);
    gl.useProgram(this.prog);
    const names = ['u_mvp', 'u_quad', 'u_tex', 'u_solid', 'u_color', 'u_sizePx', 'u_padPx', 'u_radius', 'u_blur', 'u_lod', 'u_opacity', 'u_uvScale', 'u_uvOff', 'u_tint', 'u_tintAmt', 'u_gray', 'u_bright', 'u_border', 'u_borderColor', 'u_gradTop', 'u_gradBot', 'u_vignette', 'u_glow', 'u_glowColor', 'u_taps'];
    this.u = {};
    for (const n of names) this.u[n] = gl.getUniformLocation(this.prog, n);
    gl.uniform2fv(this.u.u_taps, new Float32Array(POISSON));
    gl.uniform1i(this.u.u_tex, 0);
    this.buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-0.5, -0.5, 0.5, -0.5, -0.5, 0.5, 0.5, 0.5]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(this.prog, 'a_pos');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    this.tex = new Map();
    this.white = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.white);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
  }
  _program(vs, fs) {
    const gl = this.gl;
    const mk = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Shader: ' + gl.getShaderInfoLog(s));
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, mk(gl.VERTEX_SHADER, vs));
    gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Program: ' + gl.getProgramInfoLog(p));
    return p;
  }
  setSize(w, h) {
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    this.gl.viewport(0, 0, w, h);
  }
  /* upload / refresh texture for a media source ({id, type, el, w, h}) */
  texture(src) {
    const gl = this.gl;
    let e = this.tex.get(src.id);
    if (!e) {
      e = { tex: gl.createTexture(), uploaded: false, lastTime: -1, mips: false };
      this.tex.set(src.id, e);
    }
    gl.bindTexture(gl.TEXTURE_2D, e.tex);
    if (src.type === 'image') {
      if (!e.uploaded) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src.el);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        if (src.pot) {
          gl.generateMipmap(gl.TEXTURE_2D);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
          e.mips = true;
        } else {
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        }
        e.uploaded = true;
      }
    } else if (src.frame) {
      /* export: raw RGBA from the streaming decoder */
      const fr = src.frame;
      if (e.lastFrame !== fr.seq) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, fr.bitmap);
        if (!e.uploaded) {
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        }
        e.uploaded = true; e.lastFrame = fr.seq; e.lastTime = -1;
      }
    } else {
      const v = src.el;
      if (v.readyState >= 2 && (!e.uploaded || e.lastTime !== v.currentTime)) {
        try {
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, v);
          if (!e.uploaded) {
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
          }
          e.uploaded = true; e.lastTime = v.currentTime;
        } catch (err) { /* frame not ready yet */ }
      }
      if (!e.uploaded) { gl.bindTexture(gl.TEXTURE_2D, this.white); return { tex: this.white, mips: false }; }
    }
    return e;
  }
  dispose(id) {
    const e = this.tex.get(id);
    if (e) { this.gl.deleteTexture(e.tex); this.tex.delete(id); }
  }
  render(scene) {
    const gl = this.gl, u = this.u;
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.useProgram(this.prog);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.activeTexture(gl.TEXTURE0);
    for (const q of scene.quads) {
      let mips = false;
      if (q.src) {
        const e = this.texture(q.src);
        mips = e.mips;
        gl.bindTexture(gl.TEXTURE_2D, e.tex);
        gl.uniform1f(u.u_solid, 0);
      } else {
        gl.bindTexture(gl.TEXTURE_2D, this.white);
        gl.uniform1f(u.u_solid, 1);
        gl.uniform4fv(u.u_color, q.color);
      }
      gl.uniformMatrix4fv(u.u_mvp, false, q.mvp);
      gl.uniform2f(u.u_quad, q.quad[0], q.quad[1]);
      gl.uniform2f(u.u_sizePx, q.sizePx[0], q.sizePx[1]);
      gl.uniform1f(u.u_padPx, q.padPx);
      gl.uniform1f(u.u_radius, q.radius);
      gl.uniform1f(u.u_blur, q.blur);
      /*  The third argument of texture2D in a fragment shader is a mip BIAS, added to the level the GPU
          already picked for the card's size on screen. This used to hand it up to 9: on a small preview
          the base level is already high, so the sum reached the 1x1 mip and every blurred card became a
          flat dark blob - on some GPUs (drivers differ in how far they honour a bias), which is why it
          looked fine on one machine and broken on the next. The 25 Poisson taps do the visible blur; the
          bias only takes the shimmer out of a heavy one, and two levels is plenty for that.           */
      let lod = 0;
      if (mips && q.blur > 2 && q.src) lod = Math.max(0, Math.min(2, Math.log2(q.blur * 0.25)));
      gl.uniform1f(u.u_lod, lod);
      gl.uniform1f(u.u_opacity, q.opacity);
      gl.uniform2f(u.u_uvScale, q.uvScale[0], q.uvScale[1]);
      gl.uniform2f(u.u_uvOff, q.uvOff[0], q.uvOff[1]);
      gl.uniform3fv(u.u_tint, q.tint);
      gl.uniform1f(u.u_tintAmt, q.tintAmt);
      gl.uniform1f(u.u_gray, q.gray);
      gl.uniform1f(u.u_bright, q.bright);
      gl.uniform1f(u.u_border, q.border);
      gl.uniform4fv(u.u_borderColor, q.borderColor);
      gl.uniform1f(u.u_gradTop, q.gradTop);
      gl.uniform1f(u.u_gradBot, q.gradBot);
      gl.uniform1f(u.u_vignette, q.vignette);
      gl.uniform1f(u.u_glow, q.glow);
      gl.uniform4fv(u.u_glowColor, q.glowColor);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
  }
}
