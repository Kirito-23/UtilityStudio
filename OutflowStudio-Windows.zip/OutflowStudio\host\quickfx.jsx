/*  Outflow Studio - Quick FX wheel (ExtendScript, ES3). Requires index.jsx + native.jsx. */

function QF_selectedVideoClips(seq) {
    var out = [];
    for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var tr = seq.videoTracks[t];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j], sel = false;
            try { sel = c.isSelected(); } catch (e) {}
            if (sel) out.push({ clip: c, track: t });
        }
    }
    return out;
}

/* components + parameter values of the first selected clip (to save as a preset) */
function QF_readSelection() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = QF_selectedVideoClips(seq);
        if (!sel.length) return C3D_err("Select a clip that has the effects you want to save.");
        var clip = sel[0].clip, comps = [];
        for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i], props = [];
            for (var k = 0; k < comp.properties.numItems; k++) {
                var pr = comp.properties[k], v = null, ok = true;
                try { v = pr.getValue(); } catch (e1) { ok = false; }
                var type = (v === null || v === undefined) ? "null" : (v instanceof Array ? "array" : typeof v);
                if (type === "object" || type === "function") ok = false;
                props.push({ i: k, name: String(pr.displayName), value: ok ? v : null, ok: ok });
            }
            comps.push({ name: String(comp.displayName), props: props });
        }
        return C3D_json({ ok: true, clip: clip.name, components: comps });
    } catch (e) { return C3D_err(e); }
}

function QF_lastComponentByName(clip, name) {
    for (var i = clip.components.numItems - 1; i >= 0; i--) {
        var n = ""; try { n = String(clip.components[i].displayName); } catch (e) {}
        if (n === name) return clip.components[i];
    }
    return null;
}

function QF_findAdjustmentItem(parent, depth) {
    for (var i = 0; i < parent.children.numItems; i++) {
        var c = parent.children[i];
        if (c.type === ProjectItemType.BIN) { if (depth < 5) { var r = QF_findAdjustmentItem(c, depth + 1); if (r) return r; } continue; }
        var isSeq = false; try { isSeq = c.isSequence(); } catch (e) {}
        if (isSeq) continue;
        if (/adjustment|aanpassing|einstellungs|calque d.effets|capa de ajuste/i.test(String(c.name))) return c;
    }
    return null;
}

/*  Where an adjustment layer over [s, e] goes: above the highest ordinary clip in that range (an adjustment
    layer only affects what is below it), on the first track there that is empty over the range. Clips made
    from the adjustment item itself are skipped when working out "highest" - they are the previous clicks.  */
function QF_trackForAdjustment(seq, s, e, adjItem) {
    var adjId = null; try { adjId = adjItem ? adjItem.nodeId : null; } catch (e0) {}
    var minIdx = 0, n = seq.videoTracks.numTracks;
    for (var i = 0; i < n; i++) {
        var tr = seq.videoTracks[i];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j];
            if (!(c.start.seconds < e && c.end.seconds > s)) continue;
            var isAdj = false; try { isAdj = !!(adjId && c.projectItem && c.projectItem.nodeId === adjId); } catch (e1) {}
            if (!isAdj) minIdx = i + 1;
        }
    }
    for (var k = minIdx; k < n; k++) {
        var busy = false, t2 = seq.videoTracks[k];
        for (var m = 0; m < t2.clips.numItems; m++) { var c2 = t2.clips[m]; if (c2.start.seconds < e && c2.end.seconds > s) { busy = true; break; } }
        if (!busy) return k;
    }
    return n;
}

/*  Set one effect parameter, trying every way Premiere has accepted over the years. The plain DOM call
    (setValue(v, true)) is refused with "Invalid parameter" on some effects in Premiere 25/26 - Gaussian
    Blur's Blurriness among them - so the fallbacks go through the QE side of the same clip. Whatever
    worked is reported, and when nothing did, what the parameter looks like is put in the warning so the
    next bug report says more than "invalid".                                                             */
function QF_setParam(prop, value, qeClip, fxName, paramName, comp) {
    var err = "";
    try { prop.setValue(value, true); return { ok: true, via: "dom" }; } catch (e1) { err = String(e1); }
    try { prop.setValue(value); return { ok: true, via: "dom-1arg" }; } catch (e2) {}
    try { prop.setTimeVarying(false); prop.setValue(value, true); return { ok: true, via: "dom-untimed" }; } catch (e3) {}
    if (typeof value === "number") { try { prop.setValue([value], true); return { ok: true, via: "dom-array" }; } catch (e4) {} }
    /* QE: the same clip's components, matched by name, then the parameter by name */
    try {
        if (qeClip && paramName) {
            for (var ci = 0; ci < qeClip.numComponents; ci++) {
                var qc = qeClip.getComponentAt(ci);
                if (!qc || String(qc.name) !== String(fxName)) continue;
                for (var qi = 0; qi < qc.numProperties; qi++) {
                    var qp = qc.getPropertyAt(qi);
                    if (!qp || String(qp.name) !== String(paramName)) continue;
                    try { qp.setValue(value); return { ok: true, via: "qe" }; } catch (e5) {}
                    try { qp.setValue(String(value)); return { ok: true, via: "qe-string" }; } catch (e6) {}
                }
            }
        }
    } catch (e7) {}
    var diag = "";
    try { diag = "type " + (typeof prop.getValue()) + " value " + String(prop.getValue()).slice(0, 30) + " timeVarying " + prop.isTimeVarying(); } catch (e8) { diag = "no read (" + e8 + ")"; }
    try { if (comp) { var names = []; for (var di = 0; di < comp.properties.numItems && di < 12; di++) { var dv = null; try { dv = comp.properties[di].getValue(); } catch (eD) {} names.push(di + ":" + String(comp.properties[di].displayName) + "=" + (typeof dv) + ":" + String(dv).slice(0, 12)); } diag += " · params " + names.join(", "); } } catch (e9) {}
    return { ok: false, error: err, diag: diag };
}
/* "Blurriness" and "blurriness " are the same parameter */
function QF_sameName(a, b) { return String(a || "").replace(/\s+/g, "").toLowerCase() === String(b || "").replace(/\s+/g, "").toLowerCase() && String(b || "") !== ""; }

/*  o = { name, target: "selected" | "adjustment", effects: [{ name, params: [{ i, value }] }], duration }  */
function QF_apply(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var warnings = [], targets = [];
        var sel = QF_selectedVideoClips(seq);
        if (o.target === "adjustment") {
            var adj = QF_findAdjustmentItem(app.project.rootItem, 0);
            if (!adj && typeof TR_createAdjustmentLayer === "function") adj = TR_createAdjustmentLayer(seq, o.template);
            if (!adj) {
                if (!o.effects.length) return C3D_err("The adjustment layer template could not be imported.");
                if (!sel.length) return C3D_err("Select the clips first (no adjustment layer could be created).");
                warnings.push("adjustment layer unavailable, applied to the clips");
                o.target = "selected";
            }
        }
        if (o.target === "adjustment") {
            var adj2 = QF_findAdjustmentItem(app.project.rootItem, 0);
            adj = adj2;
            var s, e;
            if (sel.length && !o.ignoreSelection) {
                s = 1e9; e = 0;
                for (var i = 0; i < sel.length; i++) { s = Math.min(s, sel[i].clip.start.seconds); e = Math.max(e, sel[i].clip.end.seconds); }
            } else { s = seq.getPlayerPosition().seconds; e = s + (o.duration || 5); }
            /*  The lowest empty track above the clips it is meant to affect. Other adjustment layers in the
                range do not count as something to sit above - or every click would go one track higher.
                A new track only when every existing one is taken over that stretch.                      */
            var ti = QF_trackForAdjustment(seq, s, e, adj);
            if (ti >= seq.videoTracks.numTracks) {
                if (!C3D_addVideoTrack(seq)) return C3D_err("Could not add a track for the adjustment layer.");
                seq = app.project.activeSequence;
                ti = seq.videoTracks.numTracks - 1;
            }
            var track = seq.videoTracks[ti];
            var ok = false;
            try { ok = track.overwriteClip(adj, s); } catch (e1) {}
            if (!ok) return C3D_err("Could not place the adjustment layer.");
            var ac = C3D_findClipAt(track, s);
            if (!ac) return C3D_err("Adjustment layer placed but not found.");
            try { var en = new Time(); en.seconds = e; ac.end = en; } catch (e2) { warnings.push("length: " + e2); }
            try { ac.name = o.name || "Quick FX"; } catch (e3) {}
            targets.push({ clip: ac, track: ti });
        } else {
            if (!sel.length) return C3D_err("Select one or more clips first.");
            targets = sel;
        }
        var qeSeq = null;
        try { app.enableQE(); qeSeq = qe.project.getActiveSequence(); } catch (e4) {}
        var applied = 0;
        for (var t = 0; t < targets.length; t++) {
            var clip = targets[t].clip, tIdx = targets[t].track;
            var qeClip = qeSeq ? C3D_qeClipAt(qeSeq, tIdx, clip.start.seconds) : null;
            for (var f = 0; f < o.effects.length; f++) {
                var fx = o.effects[f], comp = null;
                if (fx.name === "Motion" || fx.name === "Opacity" || fx.name === "Time Remapping") comp = C3D_componentByName(clip, fx.name);
                else {
                    if (!qeClip) { warnings.push("QE clip not found for " + clip.name); continue; }
                    if (!C3D_qeAddEffect(qeClip, fx.name)) { warnings.push("effect not found: " + fx.name); continue; }
                    clip = C3D_findClipAt(app.project.activeSequence.videoTracks[tIdx], clip.start.seconds) || clip;
                    comp = QF_lastComponentByName(clip, fx.name);
                }
                if (!comp) { warnings.push(fx.name + " component missing"); continue; }
                for (var p = 0; p < fx.params.length; p++) {
                    var pa = fx.params[p], prop = null;
                    /*  by name first: a preset saved as "Blurriness = 30" must not land on whatever sits at
                        that position in this Premiere - the order of an effect's parameters moved between
                        versions, which is where "Invalid parameter" on Gaussian Blur came from.         */
                    if (pa.name) { try { for (var pi = 0; pi < comp.properties.numItems; pi++) { if (QF_sameName(comp.properties[pi].displayName, pa.name)) { prop = comp.properties[pi]; break; } } } catch (eN) {} }
                    /*  Premiere 26 reports no usable names on some effects (Gaussian Blur's came back as a
                        boolean at position 0): then the first parameter of the value's own type, which for
                        a single slider like Blurriness is the one that exists.                           */
                    if (!prop) { try { for (var pt = 0; pt < comp.properties.numItems; pt++) { var pv = null; try { pv = comp.properties[pt].getValue(); } catch (eV) {} if (typeof pv === typeof pa.value && (typeof pv !== "number" || pt >= 0)) { prop = comp.properties[pt]; break; } } } catch (eT) {} }
                    if (!prop) { try { prop = comp.properties[pa.i]; } catch (eI) {} }
                    if (!prop) { warnings.push(fx.name + " / " + (pa.name || pa.i) + ": no such parameter"); continue; }
                    var how = QF_setParam(prop, pa.value, qeClip, fx.name, pa.name, comp);
                    if (how.ok) { if (how.via !== "dom") C3D_log("QF_apply", fx.name + " / " + pa.name + " set via " + how.via); }
                    else warnings.push(fx.name + " / " + (pa.name || pa.i) + ": " + how.error + " [" + how.diag + "]");
                }
            }
            applied++;
        }
        return C3D_json({ ok: true, applied: applied, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}
