/* Relight: virtual lights on a clip. Surface direction from a model, lights you place on the preview, plus a ground
   shadow, dappled light and colour correction. The render runs in the panel's Node runtime (js/relight/relight.js),
   the preview in WebGL (relight-preview.js). */
const Relight = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const cp = nodeReq ? nodeReq('child_process') : null;
  const proc = (window.cep_node && window.cep_node.process) || (typeof process !== 'undefined' ? process : null);
  const MODEL_URL = 'https://huggingface.co/Ruicheng/moge-2-vits-normal-onnx/resolve/main/model.onnx', MODEL_NAME = 'moge-2-vits-normal.onnx';
  const TOKENS = { fast: 350, good: 350, best: 800 }, EVERY = { fast: 2, good: 1, best: 1 };   /* Fast reads the shapes on every other frame */
  const PRESETS = {
    key: { name: 'Key light', ambient: 0.3, lights: [{ x: 0.3, y: 0.25, z: 0.6, color: 'ffe6c8', intensity: 1.0, radius: 0.9 }] },
    rim: { name: 'Key + rim', ambient: 0.3, lights: [{ x: 0.3, y: 0.25, z: 0.6, color: 'ffe6c8', intensity: 0.9, radius: 0.9 }, { x: 0.85, y: 0.3, z: 0.35, color: '9ec8ff', intensity: 0.8, radius: 0.6 }] },
    golden: { name: 'Golden hour', ambient: 0.25, lights: [{ x: 0.85, y: 0.35, z: 0.35, color: 'ffb060', intensity: 1.3, radius: 0.8 }] },
    back: { name: 'Backlight', ambient: 0.15, lights: [{ x: 0.6, y: 0.3, z: -0.4, color: 'ffd6a0', intensity: 1.8, radius: 0.5 }] },
    spot: { name: 'Spotlight', ambient: 0.12, lights: [{ type: 'spot', x: 0.5, y: -0.1, z: 0.7, ax: 0.5, ay: 0.4, cone: 36, soft: 0.5, color: 'fff2dc', intensity: 1.6, radius: 1.2 }] },
    neon: { name: 'Neon', ambient: 0.2, lights: [{ x: 0.1, y: 0.5, z: 0.4, color: 'ff3ec8', intensity: 1.0, radius: 0.8 }, { x: 0.9, y: 0.5, z: 0.4, color: '2fd0ff', intensity: 1.0, radius: 0.8 }] },
    top: { name: 'Overhead', ambient: 0.3, lights: [{ x: 0.5, y: -0.1, z: 0.5, color: 'ffffff', intensity: 1.1, radius: 1.0 }] }
  };
  const DEF = () => ({
    ambient: 0.3, ambientColor: 'ffffff', wrap: 0.25, specular: 0.12, shininess: 24, relief: 0.5, even: 0, gpu: true,
    lights: JSON.parse(JSON.stringify(PRESETS.rim.lights)), sel: 0, view: 0, quality: 'good', bgImage: null, bgThumb: null, showBg: false,
    shadow: { on: false, light: 0, opacity: 0.6, soft: 0.5, length: 1 },
    gobo: { on: false, amount: 0.5, size: 4, speed: 1, soft: 0.5 },
    color: { exposure: 0, contrast: 0, saturation: 1, temp: 0, tint: 0, shadows: 0, mids: 0, highs: 0 },
    tab: 'lights', sideBig: false, v: 2
  });
  const st = DEF();
  let evenFit = null, previewAt = 0;   /* the light the preview frame already has, and where in the clip the preview sits */
  try {
    const saved = JSON.parse(localStorage.getItem('os.relight') || '{}');
    if (saved.v !== 2) { delete saved.ambient; delete saved.specular; delete saved.lights; }
    for (const k of ['shadow', 'gobo', 'color']) if (saved[k]) saved[k] = Object.assign(DEF()[k], saved[k]);
    Object.assign(st, saved, { v: 2 });
  } catch (e) {}
  const save = () => { try { localStorage.setItem('os.relight', JSON.stringify(st)); } catch (e) {} redraw(); };
  const exists = (p) => { try { return !!(CS.fs && p && CS.fs.existsSync(p)); } catch (e) { return false; } };
  const ok = () => !!(CS.fs && CS.path);
  function home() { return CS.dataDir('relight'); }
  const modelPath = () => ok() ? CS.path.join(home(), MODEL_NAME) : null;
  const modelReady = () => ok() && exists(modelPath()) && CS.fs.statSync(modelPath()).size > 5e7;
  const scriptJs = () => CS.path.join(CS.extensionDir(), 'client', 'js', 'relight', 'relight.js');
  async function ensureModel(onProgress) { if (modelReady()) return modelPath(); await Net.download(MODEL_URL, modelPath(), (q) => onProgress(q, 'Downloading the geometry model (140 MB, once)' + (q >= 0 ? ' · ' + Math.round(q * 100) + '%' : ''))); return modelPath(); }
  async function ensureAll(onProgress) {
    await AudioAI.ensureNode(onProgress); await AudioAI.ensureOrt(onProgress);
    const ffmpeg = Social.ffmpeg() || (await Social.installFfmpeg(onProgress), Social.ffmpeg());
    if (!ffmpeg) throw new Error('The video engine is missing.');
    return { ffmpeg, model: await ensureModel(onProgress) };
  }
  const safe = (fn) => { try { return !!fn(); } catch (e) { return false; } };
  const engineReady = () => safe(AudioAI.mdxReady) && modelReady() && !!(typeof Social !== 'undefined' && Social.ffmpeg && Social.ffmpeg());
  let cancelled = false; const live = new Set();
  function runOne(cmd, args, onLine) {
    return new Promise((resolve, reject) => {
      if (cancelled) { reject(new Error('Cancelled.')); return; }
      const p = CS.track(cp.spawn(cmd, args, { windowsHide: true, env: proc ? proc.env : undefined })); live.add(p);
      let out = '', err = '';
      p.stdout.on('data', (d) => { const s = String(d); out += s; if (onLine) s.split(/[\r\n]+/).forEach((l) => l.trim() && onLine(l.trim())); });
      p.stderr.on('data', (d) => { err += String(d); });
      p.on('error', (e) => { live.delete(p); reject(e); });
      p.on('close', (code) => { live.delete(p); if (cancelled) { reject(new Error('Cancelled.')); return; } code === 0 ? resolve(out) : reject(new Error((err + out).trim().split('\n').filter((l) => /error/i.test(l)).slice(-1)[0] || ('The relight engine stopped (' + code + ')'))); });
    });
  }
  function cancel() { cancelled = true; for (const p of Array.from(live)) { CS.killTree(p.pid); try { p.kill(); } catch (e2) {} } }
  const prog = {
    show(t) { cancelled = false; $('#progress').classList.add('show'); $('#prog-title').textContent = t; $('#prog-bar').style.width = '0%'; $('#prog-text').textContent = ''; const c = $('#prog-cancel'); if (c) { c.style.display = ''; c.dataset.relight = '1'; } },
    set(p, txt) { if (p >= 0) $('#prog-bar').style.width = Math.round(p * 100) + '%'; if (txt) $('#prog-text').textContent = txt; },
    hide() { $('#progress').classList.remove('show'); const c = $('#prog-cancel'); if (c) delete c.dataset.relight; }
  };
  async function selectedClip() {
    const r = await CS.call('C3D_getSelectedClips'); if (!r.ok) throw new Error(r.error);
    const clips = (r.clips || []).filter((c) => c.path && /\.(mp4|mov|m4v|mkv|webm|avi|mts|m2ts|mxf)$/i.test(c.path));
    if (!clips.length) throw new Error('Select a video clip in the timeline first.');
    return clips[0];
  }
  const rig = () => ({ ambient: st.ambient, ambientColor: st.ambientColor, wrap: st.wrap, specular: st.specular, shininess: st.shininess, relief: st.relief, even: st.even, evenFit, lights: st.lights, shadow: st.shadow, gobo: st.gobo, color: st.color, mode: st.view, time: previewAt });

  /* ---- preview, light handles, the top view ---- */
  let running = false;
  function redraw() { if (typeof RelightPreview !== 'undefined' && RelightPreview.has()) RelightPreview.render(rig()); drawHandles(); }
  const SUN = (c) => '<svg viewBox="0 0 32 32"><g fill="none" stroke="' + c + '" stroke-width="2.4" stroke-linecap="round"><path d="M16 2v5M16 25v5M2 16h5M25 16h5M6 6l3.5 3.5M22.5 22.5L26 26M26 6l-3.5 3.5M9.5 22.5L6 26"/></g><circle cx="16" cy="16" r="6.5" fill="' + c + '" stroke="#fff" stroke-width="2"/></svg>';
  const SPOT = (c) => '<svg viewBox="0 0 32 32"><path d="M9 4h14l4 16H5z" fill="' + c + '" stroke="#fff" stroke-width="2" stroke-linejoin="round"/><path d="M8 24h16M11 28h10" fill="none" stroke="' + c + '" stroke-width="2.4" stroke-linecap="round"/></svg>';
  const clampP = (v) => Math.max(-0.3, Math.min(1.3, v));
  function drawHandles() {
    const box = $('#rl-box'); if (!box) return;
    box.querySelectorAll('.rl-handle, .rl-aim, .rl-lines').forEach((e) => e.remove());
    const lines = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); lines.setAttribute('class', 'rl-lines'); lines.setAttribute('viewBox', '0 0 100 100'); lines.setAttribute('preserveAspectRatio', 'none'); box.appendChild(lines);
    st.lights.forEach((l, i) => {
      const c = '#' + (l.color || 'ffffff');
      const e = h('div', 'rl-handle' + (i === st.sel ? ' on' : '') + (l.z < 0 ? ' behind' : ''));
      e.innerHTML = (l.type === 'spot' ? SPOT(c) : SUN(c)) + '<b>' + (i + 1) + '</b>';
      e.style.left = (l.x * 100) + '%'; e.style.top = (l.y * 100) + '%'; e.title = 'Light ' + (i + 1) + (l.z < 0 ? ' (behind the picture)' : '') + ' · drag to move';
      e.dataset.i = i; box.appendChild(e);
      if (l.type === 'spot') {
        const a = h('div', 'rl-aim' + (i === st.sel ? ' on' : '')); a.style.left = ((l.ax == null ? 0.5 : l.ax) * 100) + '%'; a.style.top = ((l.ay == null ? 0.5 : l.ay) * 100) + '%'; a.style.borderColor = c; a.title = 'Where light ' + (i + 1) + ' points · drag'; a.dataset.i = i; box.appendChild(a);
        const ln = document.createElementNS('http://www.w3.org/2000/svg', 'line'); ln.setAttribute('x1', l.x * 100); ln.setAttribute('y1', l.y * 100); ln.setAttribute('x2', (l.ax == null ? 0.5 : l.ax) * 100); ln.setAttribute('y2', (l.ay == null ? 0.5 : l.ay) * 100); ln.setAttribute('stroke', c); lines.appendChild(ln);
      }
    });
    drawSide();
  }
  /* the top view: camera at the bottom, the picture as a line, the subject's depth bulging towards the camera.
     Lights below the line are in front of the subject, lights above it are behind. z runs -1 (top) .. 2 (bottom). */
  const ZMIN = -1, ZMAX = 2, zToPct = (z) => (Math.max(ZMIN, Math.min(ZMAX, z)) - ZMIN) / (ZMAX - ZMIN) * 100, pctToZ = (p) => ZMIN + Math.max(0, Math.min(1, p)) * (ZMAX - ZMIN);
  let profileCache = null;
  function drawSide() {
    const side = $('#rl-side'); if (!side) return;
    side.classList.toggle('big', !!st.sideBig);
    let svg = side.querySelector('svg.rl-top');
    if (!svg) {
      side.innerHTML = '<span class="rl-side-label">Top view · camera at the bottom · lights under the line are in front of the subject, above it behind</span><button class="rl-expand" title="Bigger / smaller">⤢</button>';
      svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'rl-top'); svg.setAttribute('viewBox', '0 0 100 100'); svg.setAttribute('preserveAspectRatio', 'none'); side.appendChild(svg);
      side.querySelector('.rl-expand').onclick = (e) => { e.stopPropagation(); st.sideBig = !st.sideBig; save(); };
    }
    const planeY = zToPct(0);
    if (!profileCache && typeof RelightPreview !== 'undefined' && RelightPreview.has()) profileCache = RelightPreview.profile(96);
    let poly = '';
    if (profileCache) { const n = profileCache.length; poly = '0,' + planeY.toFixed(2); for (let i = 0; i < n; i++) poly += ' ' + ((i + 0.5) / n * 100).toFixed(2) + ',' + zToPct(profileCache[i] * 0.5).toFixed(2); poly += ' 100,' + planeY.toFixed(2); }
    svg.innerHTML = '<rect x="0" y="0" width="100" height="' + planeY.toFixed(2) + '" fill="rgba(255,255,255,.03)"/>' + (poly ? '<polygon points="' + poly + '" fill="rgba(79,141,255,.28)" stroke="rgba(79,141,255,.9)" stroke-width="0.6" vector-effect="non-scaling-stroke"/>' : '') + '<line x1="0" y1="' + planeY + '" x2="100" y2="' + planeY + '" stroke="var(--accent)" stroke-width="1.2" vector-effect="non-scaling-stroke" opacity=".8"/>' + '<text x="1.5" y="' + (planeY - 2) + '" font-size="4" fill="#8b93a7">behind</text><text x="1.5" y="97" font-size="4" fill="#8b93a7">camera</text><text x="98.5" y="' + (planeY - 2) + '" font-size="4" fill="#8b93a7" text-anchor="end">picture</text>';
    side.querySelectorAll('.rl-handle').forEach((e) => e.remove());
    st.lights.forEach((l, i) => {
      const c = '#' + (l.color || 'ffffff');
      const e = h('div', 'rl-handle mini' + (i === st.sel ? ' on' : ''));
      e.innerHTML = (l.type === 'spot' ? SPOT(c) : SUN(c)) + '<b>' + (i + 1) + '</b>';
      e.style.left = (clampP(l.x) * 100) + '%'; e.style.top = zToPct(l.z == null ? 0.6 : +l.z) + '%';
      e.title = 'Light ' + (i + 1) + ' · distance ' + (+l.z).toFixed(2) + (l.z < 0 ? ' (behind)' : ' (in front)') + ' · drag'; e.dataset.i = i; side.appendChild(e);
    });
  }
  function wireHandles() {
    const box = $('#rl-box'); if (!box || box.dataset.wired) return; box.dataset.wired = '1';
    let drag = null;
    box.addEventListener('pointerdown', (e) => {
      const hd = e.target.closest('.rl-handle'), am = e.target.closest('.rl-aim');
      if (hd) { st.sel = +hd.dataset.i; drag = { i: st.sel, aim: false }; box.setPointerCapture(e.pointerId); renderLightPanel(); drawHandles(); }
      else if (am) { st.sel = +am.dataset.i; drag = { i: st.sel, aim: true }; box.setPointerCapture(e.pointerId); renderLightPanel(); drawHandles(); }
    });
    box.addEventListener('pointermove', (e) => {
      if (!drag) return; const r = box.getBoundingClientRect(); const l = st.lights[drag.i]; if (!l) return;
      const x = clampP((e.clientX - r.left) / r.width), y = clampP((e.clientY - r.top) / r.height);
      if (drag.aim) { l.ax = x; l.ay = y; } else { l.x = x; l.y = y; }
      redraw();
    });
    const up = () => { if (drag) { drag = null; save(); } };
    box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
    box.addEventListener('dblclick', (e) => { if (e.target.closest('.rl-handle, .rl-aim')) return; const r = box.getBoundingClientRect(); addLight((e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height); });
    const side = $('#rl-side'); if (!side || side.dataset.wired) return; side.dataset.wired = '1';
    let sdrag = null;
    side.addEventListener('pointerdown', (e) => { const hd = e.target.closest('.rl-handle'); if (!hd) return; st.sel = +hd.dataset.i; sdrag = st.sel; side.setPointerCapture(e.pointerId); renderLightPanel(); drawHandles(); });
    side.addEventListener('pointermove', (e) => { if (sdrag == null) return; const r = side.getBoundingClientRect(); const l = st.lights[sdrag]; if (!l) return; l.x = clampP((e.clientX - r.left) / r.width); l.z = +pctToZ((e.clientY - r.top) / r.height).toFixed(2); redraw(); renderLightPanel(); });
    const sup = () => { if (sdrag != null) { sdrag = null; save(); } };
    side.addEventListener('pointerup', sup); side.addEventListener('pointercancel', sup);
  }
  /* the picture never grows taller than 42% of the panel, so the settings stay reachable under the sticky preview */
  function layoutBox() {
    const box = $('#rl-box'), stage = $('#rl-stage'); if (!box || !stage || typeof RelightPreview === 'undefined' || !RelightPreview.has()) return;
    const sz = RelightPreview.size(), panel = stage.parentElement.parentElement, avail = Math.max(120, panel.clientWidth - 24);
    let hgt = avail * sz.H / sz.W; const maxH = Math.max(140, window.innerHeight * 0.42); if (hgt > maxH) hgt = maxH;
    const w = Math.min(avail, hgt * sz.W / sz.H);
    stage.style.width = Math.round(w) + 'px'; box.style.height = Math.round(hgt) + 'px'; box.style.aspectRatio = '';
  }
  function addLight(x, y) {
    if (st.lights.length >= 6) { toast('Six lights is the maximum.'); return; }
    st.lights.push({ x: x == null ? 0.5 : x, y: y == null ? 0.2 : y, z: 0.5, color: 'ffffff', intensity: 1, radius: 0.8 });
    st.sel = st.lights.length - 1; renderLightPanel(); save();
  }

  /* ---- background image: shown behind a cutout in the preview, and its light can be read into the rig ---- */
  const IMG_EXT = ['png', 'jpg', 'jpeg', 'webp', 'bmp', 'tif', 'tiff'], VID_EXT = ['mp4', 'mov', 'mkv', 'webm', 'm4v'];
  const isImage = (f) => IMG_EXT.includes(String(f).split('.').pop().toLowerCase());
  async function chooseBg() {
    if (!CS.inCEP || !cp) { toast('Relight runs inside Premiere Pro.'); return; }
    const file = await CS.pickFile('Background image or video', IMG_EXT.concat(VID_EXT), 'Images and video');
    if (!file) return;
    st.bgImage = file; st.bgThumb = null;
    if (!isImage(file)) {
      try { const eng = engineReady() ? await ensureAll(() => {}) : null; if (eng) { const out = CS.path.join(home(), 'bg_thumb.png'); const r = cp.spawnSync(eng.ffmpeg, ['-y', '-hide_banner', '-loglevel', 'error', '-i', file, '-frames:v', '1', '-vf', 'scale=960:-2', out], { windowsHide: true }); if (r.status === 0) st.bgThumb = out; } } catch (e) {}
    }
    save(); renderBg(); applyBg();
  }
  function bgThumbURL() { const f = st.bgThumb || (st.bgImage && isImage(st.bgImage) ? st.bgImage : null); return f ? CS.fileURL(f) + '?t=' + Date.now() : null; }
  function renderBg() {
    const b = $('#rl-bg'); if (!b) return;
    const url = bgThumbURL();
    if (!st.bgImage) { b.className = 'rl-thumb empty'; b.innerHTML = 'Choose image…'; b.title = 'Pick a background image or video'; }
    else { b.className = 'rl-thumb'; b.innerHTML = (url ? '<img src="' + url + '" alt="">' : '<span class="rl-thumb-name">' + CS.path.basename(st.bgImage) + '</span>') + '<span class="rl-thumb-over">Replace</span>'; b.title = st.bgImage; }
    const m = $('#rl-match'); if (m) m.disabled = !st.bgImage;
    const c = $('#rl-bg-clear'); if (c) c.style.display = st.bgImage ? '' : 'none';
    const sw = $('#rl-showbg'); if (sw) sw.classList.toggle('on', !!st.showBg);
  }
  function applyBg() {
    const box = $('#rl-box'); if (!box) return;
    const url = st.showBg ? bgThumbURL() : null;
    box.style.backgroundImage = url ? 'url("' + url + '")' : ''; box.style.backgroundSize = 'cover'; box.style.backgroundPosition = 'center';
  }
  async function matchImage() {
    if (!CS.inCEP || !cp) { toast('Relight runs inside Premiere Pro.'); return; }
    const file = st.bgImage; if (!file) { toast('Choose a background image first.'); return; }
    if (running) { toast('Please wait for the current job.'); return; }
    running = true; prog.show('Matching the light');
    try {
      const eng = await ensureAll(prog.set);
      const out = CS.path.join(home(), 'match_' + Date.now().toString(36) + '.json');
      prog.set(0.4, 'Reading the light of ' + CS.path.basename(file) + '…');
      await runOne(AudioAI.nodeExe(), [scriptJs(), '--match', file, '--matchout', out, '--model', eng.model, '--ffmpeg', eng.ffmpeg, '--ort', AudioAI.ortDir(), '--tokens', String(TOKENS[st.quality] || 350)].concat(st.gpu ? [] : ['--cpu']), () => {});
      const r = JSON.parse(CS.fs.readFileSync(out, 'utf8')); try { CS.fs.unlinkSync(out); } catch (e) {}
      st.lights = r.lights; st.ambient = r.ambient; st.sel = 0;
      syncScene(); renderLightPanel(); save();
      $('#rl-match-note').textContent = 'Matched ' + CS.path.basename(file) + ': ' + r.lights.length + ' light(s), base light ' + Math.round(st.ambient * 100) + '%' + (r.fit && r.fit.main < 0.25 ? ' · the picture gave little to go on, adjust by eye' : '') + '.';
    } catch (e) { toast(cancelled ? 'Cancelled.' : (e.message || String(e)), cancelled ? '' : 'err'); }
    finally { running = false; prog.hide(); }
  }

  /* ---- the light panel: one light, or all of them at once ---- */
  const row = (label, ctl, hint) => { const r = h('div', 'row'); const lb = h('label', '', label + (hint ? ' <span class="hint">' + hint + '</span>' : '')); r.append(lb, ctl); return r; };
  function renderLightPanel() {
    const box = $('#rl-light'); if (!box) return; box.innerHTML = '';
    const tabs = h('div', 'rl-tabs');
    const add = h('button', 'ghost small', '+ Add light'); add.onclick = () => addLight(); tabs.appendChild(add);
    const allB = h('button', 'ghost small' + (st.sel === -1 ? ' on' : ''), 'All'); allB.title = 'Change every light at once'; allB.onclick = () => { st.sel = -1; renderLightPanel(); drawHandles(); }; tabs.appendChild(allB);
    st.lights.forEach((x, i) => { const b = h('button', 'ghost small' + (i === st.sel ? ' on' : ''), 'Light ' + (i + 1)); b.style.borderColor = '#' + (x.color || 'ffffff'); b.onclick = () => { st.sel = i; renderLightPanel(); drawHandles(); }; tabs.appendChild(b); });
    if (st.sel >= 0 && st.lights[st.sel]) { const del = h('button', 'ghost small', 'Remove'); del.onclick = () => { st.lights.splice(st.sel, 1); st.sel = Math.max(0, st.sel - 1); renderLightPanel(); save(); refreshShadowLights(); }; tabs.appendChild(del); }
    box.appendChild(tabs);
    refreshShadowLights();
    if (!st.lights.length) { box.appendChild(h('div', 'kbd', 'No lights. Double-click the picture to add one, or pick a preset.')); return; }
    if (st.sel === -1) { renderAllLights(box); return; }
    const l = st.lights[st.sel]; if (!l) { st.sel = 0; return renderLightPanel(); }
    const range = (key, min, max, step, fmt) => { const wrap = h('div', 'rl-range'); const inp = h('input'); inp.type = 'range'; inp.min = min; inp.max = max; inp.step = step; inp.value = l[key]; const val = h('span', 'hint', fmt(l[key])); inp.oninput = () => { l[key] = +inp.value; val.textContent = fmt(l[key]); redraw(); }; inp.onchange = () => save(); wrap.append(inp, val); return wrap; };
    const col = h('input'); col.type = 'color'; col.value = '#' + (l.color || 'ffffff'); col.oninput = () => { l.color = col.value.replace('#', ''); redraw(); }; col.onchange = () => { save(); renderLightPanel(); };
    const type = h('select', 'sel'); type.innerHTML = '<option value="point">Point</option><option value="spot">Spot</option>'; type.value = l.type === 'spot' ? 'spot' : 'point';
    type.onchange = () => { l.type = type.value; if (l.type === 'spot') { if (l.ax == null) { l.ax = 0.5; l.ay = 0.5; } if (l.cone == null) l.cone = 40; if (l.soft == null) l.soft = 0.5; } renderLightPanel(); save(); };
    box.append(row('Type', type, l.type === 'spot' ? 'a cone aimed at the small target on the picture' : 'shines in every direction'), row('Colour', col), row('Intensity', range('intensity', 0, 3, 0.05, (v) => Math.round(v * 100) + '%')), row('Distance', range('z', -1, 2, 0.05, (v) => (+v).toFixed(2)), 'from the picture: in front (+) lights the face, behind (−) makes a rim'), row('Reach', range('radius', 0.1, 3, 0.05, (v) => (+v).toFixed(2)), 'how far the light carries'));
    if (l.type === 'spot') box.append(row('Cone', range('cone', 6, 140, 1, (v) => Math.round(v) + '°'), 'how wide the beam is'), row('Edge', range('soft', 0.02, 1, 0.02, (v) => Math.round(v * 100) + '%'), 'soft or hard edge of the beam'));
  }
  /* "All": the sliders start at the average and move every light together (ratios for intensity and reach, offsets for distance) */
  function renderAllLights(box) {
    const base = st.lights.map((l) => Object.assign({}, l));
    const mean = (k) => base.reduce((a, l) => a + (+l[k] || 0), 0) / base.length;
    const rel = (key, min, max, step, fmt, mode) => {
      const m0 = mean(key); const wrap = h('div', 'rl-range'); const inp = h('input'); inp.type = 'range'; inp.min = min; inp.max = max; inp.step = step; inp.value = m0; const val = h('span', 'hint', fmt(m0));
      inp.oninput = () => { const v = +inp.value; st.lights.forEach((l, i) => { const b = +base[i][key] || 0; l[key] = mode === 'ratio' ? (m0 > 0.001 ? b * v / m0 : v) : b + (v - m0); l[key] = Math.max(min, Math.min(max, +l[key].toFixed(3))); }); val.textContent = fmt(v); redraw(); };
      inp.onchange = () => save(); wrap.append(inp, val); return wrap;
    };
    const col = h('input'); col.type = 'color'; col.value = '#' + (base[0].color || 'ffffff'); col.oninput = () => { st.lights.forEach((l) => { l.color = col.value.replace('#', ''); }); redraw(); }; col.onchange = () => { save(); renderLightPanel(); };
    box.append(h('div', 'kbd', 'Every light at once. Intensity and reach scale together, distance shifts together.'), row('Colour', col, 'sets all lights'), row('Intensity', rel('intensity', 0, 3, 0.05, (v) => Math.round(v * 100) + '%', 'ratio')), row('Distance', rel('z', -1, 2, 0.05, (v) => (+v).toFixed(2), 'offset')), row('Reach', rel('radius', 0.1, 3, 0.05, (v) => (+v).toFixed(2), 'ratio')));
  }
  function refreshShadowLights() {
    const sel = $('#rl-sh-light'); if (!sel) return;
    sel.innerHTML = st.lights.map((l, i) => '<option value="' + i + '">Light ' + (i + 1) + (l.type === 'spot' ? ' (spot)' : '') + '</option>').join('') || '<option value="0">No lights</option>';
    sel.value = String(Math.max(0, Math.min(st.lights.length - 1, +st.shadow.light || 0)));
  }
  function syncScene() { const a = $('#rl-ambient'); if (a) { a.value = st.ambient; $('#rl-ambient-val').textContent = Math.round(st.ambient * 100) + '%'; } }

  /* ---- preview frame and render ---- */
  async function preview(auto) {
    if (!CS.inCEP || !cp) { if (!auto) toast('Relight runs inside Premiere Pro.'); return; }
    if (running) return;
    let clip;
    try { clip = await selectedClip(); } catch (e) { $('#rl-note').textContent = 'Select a video clip in the timeline, then come back here or press Preview one frame.'; if (!auto) toast(e.message, 'err'); return; }
    if (auto && !engineReady()) { $('#rl-note').textContent = 'Press Preview one frame: the first run downloads the engine and the geometry model (140 MB).'; return; }
    running = true; prog.show('Preview');
    try {
      const eng = await ensureAll(prog.set);
      const dir = CS.path.join(home(), 'preview'); CS.mkdirp(dir);
      const frac = Math.max(0, Math.min(1, (+$('#rl-at').value || 50) / 100));
      const at = (clip.inPoint || 0) + Math.max(0, clip.end - clip.start) * frac; previewAt = at;
      prog.set(0.3, 'Reading the shapes of one frame' + (st.gpu ? ' on the GPU' : '') + '…');
      await runOne(AudioAI.nodeExe(), [scriptJs(), '--in', clip.path, '--model', eng.model, '--ffmpeg', eng.ffmpeg, '--ort', AudioAI.ortDir(), '--tokens', String(TOKENS[st.quality] || 350), '--preview', dir, '--at', String(at)].concat(st.gpu ? [] : ['--cpu']), () => {});
      const t = '?t=' + Date.now();
      await RelightPreview.set({ original: CS.fileURL(CS.path.join(dir, 'original.png')) + t, depth: CS.fileURL(CS.path.join(dir, 'depth.png')) + t, normal: CS.fileURL(CS.path.join(dir, 'normal.png')) + t }, $('#rl-preview'));
      $('#rl-wrap').style.display = '';
      evenFit = null; try { evenFit = JSON.parse(CS.fs.readFileSync(CS.path.join(dir, 'light.json'), 'utf8')); } catch (e) {}
      profileCache = null; layoutBox(); applyBg(); noteShadow();
      wireHandles(); renderLightPanel(); redraw();
      $('#rl-note').textContent = clip.name + ' at ' + Math.round(frac * 100) + '%. Drag the lights, double-click to add one. Everything below redraws live.';
    } catch (e) { toast(cancelled ? 'Cancelled.' : (e.message || String(e)), cancelled ? '' : 'err'); }
    finally { running = false; prog.hide(); }
  }
  function noteShadow() { const n = $('#rl-sh-note'); if (!n) return; const s = RelightPreview.has() ? RelightPreview.silhouette() : null; n.textContent = !s ? 'Needs a preview frame.' : !s.hasAlpha ? 'The ground shadow needs a clip with transparency (a Remove background result). This clip has none, so it is skipped.' : 'The shadow falls away from the chosen light and is written into the clip\'s transparency, so it lands on whatever is on the track below.'; }
  async function outDir() { const k = Hub.keys(); let base = k.downloadDir; if (!base) { const r = await CS.call('OS_getPaths'); base = (r.ok && (r.projectDir || r.documents)) || (CS.os ? CS.os.homedir() : ''); base = CS.path.join(base, 'OutflowStudio'); } return base; }
  async function process() {
    if (!CS.inCEP || !cp) { toast('Relight runs inside Premiere Pro.'); return; }
    if (running) { toast('Please wait for the current job.'); return; }
    if (!st.lights.length) { toast('Add at least one light.', 'err'); return; }
    if (typeof License !== 'undefined' && !License.can('relight')) { License.promptUnlock('relight'); return; }
    running = true; prog.show('Relight');
    try {
      const clip = await selectedClip();
      const eng = await ensureAll(prog.set);
      const dir = CS.path.join(await outDir(), 'relight'); CS.mkdirp(dir);
      const out = CS.path.join(dir, CS.path.basename(clip.path).replace(/\.[^.]+$/, '') + '_relit_' + Date.now().toString(36) + '.mov');
      const rigFile = out.replace(/\.mov$/, '_lights.json'); CS.fs.writeFileSync(rigFile, JSON.stringify(rig()), 'utf8');
      const start = clip.inPoint || 0, duration = Math.max(0.05, clip.end - clip.start), t0 = Date.now();
      let fps = 30; try { const pr = cp.spawnSync(CS.path.join(CS.path.dirname(eng.ffmpeg), CS.bin('ffprobe')), ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=r_frame_rate', '-of', 'default=nw=1:nk=1', clip.path], { encoding: 'utf8', windowsHide: true }); const [fa, fb] = String(pr.stdout || '').trim().split('/').map(Number); if (fa > 0) fps = fb ? fa / fb : fa; } catch (e) {}
      let cores = 8; try { cores = nodeReq('os').cpus().length; } catch (e) {}
      const segments = duration < 4 || !st.gpu ? 1 : Math.max(1, Math.min(4, Math.floor(cores / 4)));
      prog.set(0.02, 'Relighting' + (st.gpu ? ' on the GPU' : ' on the CPU') + (segments > 1 ? ' · ' + segments + ' parts at once' : '') + '…');
      const totalFrames = Math.max(1, Math.round(duration * fps)), leadFrames = Math.round(0.5 * fps), parts = [], progressOf = new Array(segments).fill(0);
      const report = () => { const p = progressOf.reduce((a, b) => a + b, 0) / segments; const el = (Date.now() - t0) / 1000; const eta = p > 0.05 ? Math.round(el / p - el) : 0; prog.set(0.03 + p * 0.92, Math.round(p * 100) + '%' + (eta > 0 ? ' · about ' + (eta >= 60 ? Math.round(eta / 60) + ' min' : eta + ' s') + ' left' : '')); };
      const jobs = [];
      for (let k = 0; k < segments; k++) {
        const f0 = Math.round(totalFrames * k / segments), f1 = Math.round(totalFrames * (k + 1) / segments), frames = f1 - f0;
        const skip = k > 0 ? Math.min(leadFrames, f0) : 0, segStart = start + (f0 - skip) / fps, segLen = (frames + skip) / fps + 0.25;
        const file = segments > 1 ? out.replace(/\.mov$/, '_part' + k + '.mov') : out; parts.push(file);
        jobs.push(runOne(AudioAI.nodeExe(), [scriptJs(), '--in', clip.path, '--out', file, '--model', eng.model, '--ffmpeg', eng.ffmpeg, '--ort', AudioAI.ortDir(), '--lights', rigFile, '--tokens', String(TOKENS[st.quality] || 350), '--every', String(EVERY[st.quality] || 1), '--start', String(segStart), '--duration', String(segLen), '--frames', String(frames), '--skipframes', String(skip)].concat(st.gpu ? [] : ['--cpu']), (l) => { const mm = /^progress ([\d.]+)/.exec(l); if (mm) { progressOf[k] = +mm[1]; report(); } }));
      }
      await Promise.all(jobs);
      if (segments > 1) {
        prog.set(0.96, 'Joining the parts');
        const list = out.replace(/\.mov$/, '_parts.txt'); CS.fs.writeFileSync(list, parts.map((p) => "file '" + p.replace(/'/g, "'\\''") + "'").join('\n'), 'utf8');
        await runOne(eng.ffmpeg, ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', out], null);
        for (const p of parts) { try { CS.fs.unlinkSync(p); } catch (e) {} } try { CS.fs.unlinkSync(list); } catch (e) {}
      }
      try { CS.fs.unlinkSync(rigFile); } catch (e) {}
      if (!exists(out)) throw new Error('The relight engine produced no file.');
      prog.set(0.98, 'Placing the clip');
      const r = await CS.call('C3D_importAndInsert', out, 0, duration, -1, 'Outflow Relight', clip.name + ' · relit', clip.start, clip.track + 1);
      if (!r.ok) throw new Error(r.error);
      let off = null; try { off = await CS.call('MT_disableVideo', JSON.stringify({ track: clip.track, start: clip.start, end: clip.end })); } catch (e) {}
      toast('Relit · placed on V' + (r.track + 1) + (off && off.ok && off.disabled ? ' · original video switched off, audio kept' : '') + '.', 'ok');
      try { Log.info('relight', 'done', { clip: clip.name, seconds: +((Date.now() - t0) / 1000).toFixed(1), duration, lights: st.lights.length, segments, quality: st.quality, shadow: !!st.shadow.on, gobo: !!st.gobo.on }); } catch (e) {}
      try { Usage.tick('relight', 1, { seconds: (Date.now() - t0) / 1000, clip: duration }); Usage.tick('set:relight:quality:' + st.quality); Usage.tick('set:relight:gpu:' + (st.gpu ? 'on' : 'off')); if (st.shadow.on) Usage.tick('set:relight:shadow'); if (st.gobo.on) Usage.tick('set:relight:dapples'); } catch (e) {}
    } catch (e) { toast(cancelled ? 'Cancelled.' : (e.message || String(e)), cancelled ? '' : 'err'); }
    finally { running = false; prog.hide(); }
  }
  function renderStatus() { const s = $('#rl-status'); if (!s) return; s.innerHTML = (safe(AudioAI.mdxReady) ? icon('check', 12) + ' Engine ready' + (st.gpu ? ' · GPU' : ' · CPU') : 'The engine (150 MB, shared with Remove music) downloads on first use') + ' · ' + (modelReady() ? icon('check', 12) + ' Geometry model ready' : 'Geometry model (140 MB) downloads on first use'); }

  /* ---- screen ---- */
  function showTab(name) {
    st.tab = name;
    document.querySelectorAll('#rl-tabbar button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    document.querySelectorAll('.rl-tab').forEach((t) => { t.style.display = t.dataset.tab === name ? '' : 'none'; });
    try { localStorage.setItem('os.relight', JSON.stringify(st)); } catch (e) {}
  }
  function open() {
    Hub.show('relight');
    /* sliders bound to st[key] or st[group][key] */
    const bind = (id, path, fmt) => {
      const el = $('#' + id), lab = $('#' + id + '-val'); if (!el) return;
      const get = () => path.length === 1 ? st[path[0]] : st[path[0]][path[1]], set = (v) => { if (path.length === 1) st[path[0]] = v; else st[path[0]][path[1]] = v; };
      el.value = get(); if (lab) lab.textContent = fmt(get());
      el.oninput = () => { set(+el.value); if (lab) lab.textContent = fmt(get()); redraw(); }; el.onchange = () => save();
    };
    const pct = (v) => Math.round(v * 100) + '%', signed = (v) => (v > 0 ? '+' : '') + Math.round(v * 100), fix = (v) => (+v).toFixed(2);
    bind('rl-ambient', ['ambient'], pct); bind('rl-wrap', ['wrap'], pct); bind('rl-specular', ['specular'], pct); bind('rl-shininess', ['shininess'], (v) => Math.round(v)); bind('rl-relief', ['relief'], pct); bind('rl-even', ['even'], pct);
    bind('rl-sh-opacity', ['shadow', 'opacity'], pct); bind('rl-sh-soft', ['shadow', 'soft'], pct); bind('rl-sh-length', ['shadow', 'length'], fix);
    bind('rl-go-amount', ['gobo', 'amount'], pct); bind('rl-go-size', ['gobo', 'size'], (v) => (+v).toFixed(1)); bind('rl-go-speed', ['gobo', 'speed'], fix); bind('rl-go-soft', ['gobo', 'soft'], pct);
    bind('rl-c-exposure', ['color', 'exposure'], (v) => (v > 0 ? '+' : '') + (+v).toFixed(2)); bind('rl-c-contrast', ['color', 'contrast'], signed); bind('rl-c-saturation', ['color', 'saturation'], pct); bind('rl-c-temp', ['color', 'temp'], signed); bind('rl-c-tint', ['color', 'tint'], signed); bind('rl-c-shadows', ['color', 'shadows'], signed); bind('rl-c-mids', ['color', 'mids'], signed); bind('rl-c-highs', ['color', 'highs'], signed);
    const acol = $('#rl-ambcolor'); if (acol) { acol.value = '#' + (st.ambientColor || 'ffffff'); acol.oninput = () => { st.ambientColor = acol.value.replace('#', ''); redraw(); }; acol.onchange = () => save(); }
    const sw = (id, group, key, after) => { const b = $('#' + id); if (!b) return; const cur = () => group ? st[group][key] : st[key]; b.classList.toggle('on', !!cur()); b.onclick = () => { if (group) st[group][key] = !st[group][key]; else st[key] = !st[key]; b.classList.toggle('on', !!cur()); save(); if (after) after(); }; };
    sw('rl-sh-on', 'shadow', 'on'); sw('rl-go-on', 'gobo', 'on'); sw('rl-gpu', null, 'gpu', renderStatus);
    const shl = $('#rl-sh-light'); if (shl) shl.onchange = () => { st.shadow.light = +shl.value; save(); };
    const q = $('#rl-quality'); if (q) { q.value = st.quality; q.onchange = () => { st.quality = q.value; save(); }; }
    const bg = $('#rl-bg'); if (bg) bg.onclick = chooseBg;
    const bc = $('#rl-bg-clear'); if (bc) bc.onclick = () => { st.bgImage = null; st.bgThumb = null; st.showBg = false; save(); renderBg(); applyBg(); };
    const sb = $('#rl-showbg'); if (sb) sb.onclick = () => { st.showBg = !st.showBg; save(); renderBg(); applyBg(); };
    const cr = $('#rl-c-reset'); if (cr) cr.onclick = () => { st.color = DEF().color; save(); open(); };
    renderBg(); applyBg();
    const pre = $('#rl-preset'); pre.innerHTML = '<option value="">Presets…</option>' + Object.entries(PRESETS).map(([k, p]) => '<option value="' + k + '">' + p.name + '</option>').join(''); pre.onchange = () => { const P = PRESETS[pre.value]; if (P) { try { Usage.tick('set:relight:preset:' + pre.value); } catch (e) {} st.lights = JSON.parse(JSON.stringify(P.lights)); st.sel = 0; if (P.ambient != null) { st.ambient = P.ambient; syncScene(); } renderLightPanel(); save(); } pre.value = ''; };
    document.querySelectorAll('#rl-view button').forEach((b) => { b.classList.toggle('on', +b.dataset.view === st.view); b.onclick = () => { st.view = +b.dataset.view; document.querySelectorAll('#rl-view button').forEach((x) => x.classList.toggle('on', x === b)); redraw(); }; });
    document.querySelectorAll('#rl-tabbar button').forEach((b) => { b.onclick = () => showTab(b.dataset.tab); });
    showTab(st.tab || 'lights');
    const mb = $('#rl-match'); if (mb) mb.onclick = matchImage;
    renderLightPanel(); renderStatus(); wireHandles(); noteShadow(); layoutBox(); drawSide();
    if (!RelightPreview.has()) $('#rl-note').textContent = 'Getting a preview frame…';
    setTimeout(() => preview(true), 50);
  }
  function init() {
    const c = $('#prog-cancel'); if (c) c.addEventListener('click', () => { if (c.dataset.relight) cancel(); });
    const p = $('#rl-preview-btn'); if (p) p.addEventListener('click', () => preview(false));
    const r = $('#rl-run'); if (r) r.addEventListener('click', process);
    const i = $('#rl-install'); if (i) i.addEventListener('click', () => Hub.showEngines());
    const at = $('#rl-at'); if (at) at.addEventListener('change', () => { if (RelightPreview.has()) preview(false); });
    window.addEventListener('resize', () => { if ($('#screen-relight') && $('#screen-relight').classList.contains('active')) layoutBox(); });
  }
  const engines = () => [{ id: 'geo-model', name: 'Geometry model', size: '140 MB', uses: 'Relight', ready: safe(modelReady), install: ensureModel }];
  return { open, init, engines };
})();
