/* Output pipelines:
   - render : transparent PNG sequences (fast GPU readback + Node zlib), imported
              and placed on the timeline (background / back / front layers).
   - native : every card becomes its own clip with Motion, Opacity, Basic 3D and
              Gaussian Blur keyframes. No rendering, fully editable in Premiere. */
const Exporter = (() => {
  let cancelled = false;
  const join = (...a) => (CS.path ? CS.path.join(...a) : a.join('/'));
  const BIN = '3D Carousel';

  /* ---------------------------------------------------------- fast PNG */
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(buf) { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
  function pngChunk(type, data) {
    const Buf = CS.fs ? (window.Buffer || window.cep_node.Buffer) : null;
    const len = Buf.alloc(4); len.writeUInt32BE(data.length, 0);
    const td = Buf.concat([Buf.from(type, 'ascii'), data]);
    const crc = Buf.alloc(4); crc.writeUInt32BE(crc32(td), 0);
    return Buf.concat([len, td, crc]);
  }
  /* pixels: premultiplied RGBA from gl.readPixels (bottom-up). Returns Promise<Buffer>. */
  function encodePNG(pixels, w, h) {
    const Buf = window.Buffer || window.cep_node.Buffer;
    const zlib = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('zlib');
    const stride = w * 4, raw = Buf.allocUnsafe((stride + 1) * h);
    for (let y = 0; y < h; y++) {
      const srcRow = (h - 1 - y) * stride, dst = y * (stride + 1);
      raw[dst] = 0;
      for (let x = 0; x < stride; x += 4) {
        const a = pixels[srcRow + x + 3];
        const o = dst + 1 + x;
        if (a === 0) { raw[o] = 0; raw[o + 1] = 0; raw[o + 2] = 0; raw[o + 3] = 0; }
        else if (a === 255) { raw[o] = pixels[srcRow + x]; raw[o + 1] = pixels[srcRow + x + 1]; raw[o + 2] = pixels[srcRow + x + 2]; raw[o + 3] = 255; }
        else {
          const f = 255 / a;
          raw[o] = Math.min(255, (pixels[srcRow + x] * f + 0.5) | 0);
          raw[o + 1] = Math.min(255, (pixels[srcRow + x + 1] * f + 0.5) | 0);
          raw[o + 2] = Math.min(255, (pixels[srcRow + x + 2] * f + 0.5) | 0);
          raw[o + 3] = a;
        }
      }
    }
    return new Promise((resolve, reject) => {
      zlib.deflate(raw, { level: 1 }, (err, comp) => {
        if (err) return reject(err);
        const ihdr = Buf.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
        resolve(Buf.concat([Buf.from([137, 80, 78, 71, 13, 10, 26, 10]), pngChunk('IHDR', ihdr), pngChunk('IDAT', comp), pngChunk('IEND', Buf.alloc(0))]));
      });
    });
  }
  const writeFileAsync = (file, buf) => new Promise((res, rej) => CS.fs.writeFile(file, buf, (e) => e ? rej(e) : res()));
  /* straight-alpha, top-down RGBA (canvas ImageData) -> PNG file */
  /*  An overlay that is already on the timeline is held open by Premiere: writing over it fails with
      EBUSY (two reports on 2026-09-15, safe margins). This writes to the name asked for, and when that
      one is locked, to the next free name - and returns the name it used.                            */
  async function writePNGFree(file, data, w, h) {
    let target = file;
    for (let n = 1; n <= 40; n++) {
      try { await writePNGStraight(target, data, w, h); return target; }
      catch (e) {
        if (!/EBUSY|EPERM|EACCES/i.test(String((e && e.message) || e))) throw e;
        target = file.replace(/\.png$/i, '') + '_' + (n + 1) + '.png';
      }
    }
    throw new Error('Could not write the overlay: every copy of it is in use by Premiere.');
  }
  function writePNGStraight(file, data, w, h) {
    const Buf = window.Buffer || window.cep_node.Buffer;
    const zlib = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require)('zlib');
    const stride = w * 4, raw = Buf.allocUnsafe((stride + 1) * h);
    for (let y = 0; y < h; y++) { raw[y * (stride + 1)] = 0; raw.set(data.subarray(y * stride, (y + 1) * stride), y * (stride + 1) + 1); }
    return new Promise((resolve, reject) => {
      zlib.deflate(raw, { level: 1 }, (err, comp) => {
        if (err) return reject(err);
        const ihdr = Buf.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
        const png = Buf.concat([Buf.from([137, 80, 78, 71, 13, 10, 26, 10]), pngChunk('IHDR', ihdr), pngChunk('IDAT', comp), pngChunk('IEND', Buf.alloc(0))]);
        writeFileAsync(file, png).then(resolve, reject);
      });
    });
  }

  /* How big does each video card ever get on screen? Sampled over the animation from the projected quad corners, so
     the decoder only produces what the frame can show (a Coverflow card is a few hundred pixels, not 4K). */
  function neededTexSize(o, sources, frames) {
    const need = new Map();
    const N = Math.min(frames, 48);
    for (let i = 0; i < N; i++) {
      const t = N <= 1 ? 0 : (i / (N - 1)) * (frames - 1) / o.fps;
      const sc = buildScene(o.state, sources, t, o.width, o.height, { layer: 'all' });
      for (const q of sc.quads || []) {
        if (!q.src || q.src.type !== 'video' || !q.mvp || !q.quad) continue;
        const m = q.mvp, pts = [];
        for (const [sx, sy] of [[-0.5, -0.5], [0.5, -0.5], [0.5, 0.5], [-0.5, 0.5]]) {
          const x = sx * q.quad[0], y = sy * q.quad[1];
          const cx = m[0] * x + m[4] * y + m[12], cy = m[1] * x + m[5] * y + m[13], cw = m[3] * x + m[7] * y + m[15];
          if (cw <= 1e-4) { pts.length = 0; break; }
          pts.push([(cx / cw + 1) / 2 * o.width, (cy / cw + 1) / 2 * o.height]);
        }
        let w, h;
        if (pts.length === 4) { const d = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]); w = Math.max(d(pts[0], pts[1]), d(pts[3], pts[2])); h = Math.max(d(pts[1], pts[2]), d(pts[0], pts[3])); }
        else { w = q.src.w; h = q.src.h; }   /* crosses the camera plane: play safe with the full source */
        const us = Math.max(0.05, Math.abs((q.uvScale || [1, 1])[0])), vs = Math.max(0.05, Math.abs((q.uvScale || [1, 1])[1]));
        let tw = w / us, th = h / vs;
        /* the background layer is a zoomed, heavily blurred copy of the card: a third of the frame is more than the blur can show */
        if (q.bgQuad) { tw = o.width * 0.35; th = o.height * 0.35; }
        const cur = need.get(q.src.id) || [0, 0];
        need.set(q.src.id, [Math.max(cur[0], tw), Math.max(cur[1], th)]);
      }
    }
    return need;
  }

  /* Seeking a <video> element to every frame costs 100-300 ms (H.264 keyframe re-sync). For the export each video card
     gets its own ffmpeg that writes one PNG per frame at the export rate and the size the card needs; the panel decodes
     them off the main thread with createImageBitmap and uploads that. Pipes were tried: inside the panel Node's event
     loop only moves ~45 MB/s, files with a synchronous read do not depend on it. */
  function frameFeeder(ffmpegExe, cp, Buf, src, fps, w, h, dir, idx, count) {
    const pattern = join(dir, 'card' + idx + '_%05d.png');
    const fileOf = (f) => join(dir, 'card' + idx + '_' + String(f).padStart(5, '0') + '.png');
    const at = +src['in'] || 0;
    const args = ['-hide_banner', '-loglevel', 'error', '-stream_loop', '-1'].concat(at > 0.001 ? ['-ss', at.toFixed(3)] : []).concat(['-i', src.path, '-an', '-sn', '-vf', 'fps=' + fps + ',scale=' + w + ':' + h + ':flags=bicubic,format=rgba', '-frames:v', String(count), '-f', 'image2', '-c:v', 'png', '-compression_level', '1', '-pix_fmt', 'rgba', '-start_number', '0', '-threads', '0', pattern]);
    const p = CS.track(cp.spawn(ffmpegExe, args, { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] }));
    let err = '', ended = false, code = null;
    p.stderr.on('data', (d) => { err += d; });
    p.on('close', (c) => { ended = true; code = c; });
    p.on('error', (er) => { err += er.message; ended = true; code = -1; });
    const exists = (file) => { try { return CS.fs.existsSync(file); } catch (e) { return false; } };
    async function load(f) {
      const file = fileOf(f);
      for (let tries = 0; ; tries++) {
        /* complete when the next frame's file has appeared (image2 finishes one file before opening the next) or ffmpeg is done */
        if (exists(file) && (ended || f + 1 >= count || exists(fileOf(f + 1)))) break;
        if (ended) throw new Error('The video engine could not decode ' + (src.name || 'a video card') + (err ? ': ' + err.slice(-200) : (code ? ' (exit ' + code + ')' : '')));
        await new Promise((res) => setTimeout(res, tries < 20 ? 4 : 15));
      }
      const buf = CS.fs.readFileSync(file);
      try { CS.fs.unlinkSync(file); } catch (e) {}
      return createImageBitmap(new Blob([buf], { type: 'image/png' }), { premultiplyAlpha: 'none', colorSpaceConversion: 'none' });
    }
    let pre = null, preIdx = -1;
    return {
      w, h,
      next(f) { const pr = (pre && preIdx === f) ? pre : load(f); pre = null; return pr; },
      prefetch(f) { if (f < count) { preIdx = f; pre = load(f); pre.catch(() => {}); } },
      stop() {
        try { if (!ended) p.kill(); } catch (e2) {}
        try { for (const n of CS.fs.readdirSync(dir)) if (n.startsWith('card' + idx + '_') && n.endsWith('.png')) CS.fs.unlinkSync(join(dir, n)); } catch (e3) {}
      }
    };
  }

  /* ------------------------------------------------------ frame render */
  async function renderFrames(o) {
    const sources = o.sourceIds.map(id => Sources.get(id)).filter(Boolean);
    const canvas = document.createElement('canvas');
    canvas.width = o.width; canvas.height = o.height;
    const r = new Renderer(canvas);
    const gl = r.gl;
    const frames = Math.max(1, Math.round(o.state.duration * o.fps));
    CS.mkdirp(o.outDir);
    const fast = CS.hasNode;
    const pixels = fast ? new Uint8Array(o.width * o.height * 4) : null;
    const pending = [];
    let first = null, done = 0;
    const tick = () => { done++; if (o.onProgress) o.onProgress(done / frames, done, frames); };
    /* video engine present: one ProRes 4444 clip with alpha, no PNG encoding, no 120 files */
    /* PNG sequences also go through ffmpeg when it is there: its PNG encoder runs on every core, ours ran on one */
    const ffmpegExe = (fast && typeof Social !== 'undefined' && Social.ffmpeg) ? Social.ffmpeg() : null;
    const wantPng = o.format === 'png';
    if (ffmpegExe) {
      const req = (window.cep_node && window.cep_node.require ? window.cep_node.require : window.require);
      const cp = req('child_process'), Buf = window.Buffer || window.cep_node.Buffer;
      /* video cards stream through their own decoders; the texture never needs to be bigger than 1.5x the frame */
      const feeders = new Map();
      const need = neededTexSize(o, sources, frames);
      for (const s of sources) {
        if (s.type !== 'video' || !s.path) continue;
        /* first choice: WebCodecs straight from the file (GPU decode, no files); otherwise ffmpeg PNG frames */
        let fd = null;
        try { const bytes = CS.fs.statSync(s.path).size <= 400e6 ? CS.fs.readFileSync(s.path) : null; if (bytes && typeof VideoFeed !== 'undefined') fd = await VideoFeed.open(bytes, o.fps, frames, s.name); } catch (e8) { try { Log.warn('export', 'webcodecs unavailable for ' + s.name + ': ' + e8.message); } catch (e9) {} fd = null; }
        if (!fd) {
          const nd = need.get(s.id) || [s.w, s.h];
          const sc = Math.min(1, Math.max(nd[0] * 1.25 / s.w, nd[1] * 1.25 / s.h, 0.05));
          const fw = Math.max(2, Math.round(s.w * sc / 2) * 2), fh = Math.max(2, Math.round(s.h * sc / 2) * 2);
          fd = frameFeeder(ffmpegExe, cp, Buf, s, o.fps, fw, fh, o.outDir, feeders.size, frames); fd.mode = 'png';
        }
        feeders.set(s, fd);
      }
      for (const fd of feeders.values()) fd.prefetch(0);
      const T = { decode: 0, render: 0, read: 0, write: 0 }, t0 = performance.now();
      const now = () => performance.now();
      const out = wantPng ? join(o.outDir, (o.prefix || 'frame') + '_%05d.png') : join(o.outDir, (o.prefix || 'frame') + '.mov');
      const args = ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', o.width + 'x' + o.height, '-r', String(o.fps), '-i', 'pipe:0',
        '-vf', 'vflip,unpremultiply=inplace=1', ...(wantPng ? ['-c:v', 'png', '-compression_level', '1', '-pix_fmt', 'rgba', '-start_number', '0', '-f', 'image2'] : ['-c:v', 'prores_aw', '-profile:v', '4', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0']), '-threads', '0', out];
      const proc = CS.track(cp.spawn(ffmpegExe, args, { windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] }));
      let errText = '';
      proc.stderr.on('data', (d) => { errText += d; });
      let exitErr = null;
      const exit = new Promise((res) => { proc.on('error', (err) => { exitErr = err; res(); }); proc.on('close', (code) => { if (code !== 0 && !exitErr) exitErr = new Error('The video engine stopped (' + code + '): ' + errText.slice(-300)); res(); }); });
      const write = (buf) => new Promise((res, rej) => { if (proc.stdin.destroyed || exitErr) return rej(exitErr || new Error('The video engine closed early')); const ok = proc.stdin.write(buf, (err) => { if (err) rej(err); }); if (ok) res(); else proc.stdin.once('drain', res); });
      try {
        for (let f = 0; f < frames; f++) {
          if (cancelled) throw new Error('Export cancelled');
          const t = f / o.fps;
          let a = now();
          for (const s of sources) {
            if (s.type !== 'video') continue;
            const fd = feeders.get(s);
            if (fd) { const bitmap = await fd.next(f); if (s.frame && s.frame.bitmap) { try { s.frame.bitmap.close(); } catch (e6) {} } s.frame = { bitmap, w: fd.w, h: fd.h, seq: f + 1 }; fd.prefetch(f + 1); }
            else await Sources.seekVideo(s.el, t + (s['in'] || 0));
          }
          T.decode += now() - a; a = now();
          r.render(buildScene(o.state, sources, t, o.width, o.height, { layer: o.layer || 'all' }));
          T.render += now() - a; a = now();
          gl.readPixels(0, 0, o.width, o.height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
          T.read += now() - a; a = now();
          await write(Buf.from(pixels.slice().buffer));
          T.write += now() - a;
          tick();
          if (f % 6 === 0) await new Promise(res => setTimeout(res, 0));
        }
        proc.stdin.end();
        a = now(); await exit; T.write += now() - a;
        if (exitErr) throw exitErr;
        const total = (now() - t0) / 1000;
        try { Log.info('export', 'pass ' + (o.layer || 'all') + ' done', { cards: Array.from(feeders.values()).map((x) => x.w + 'x' + x.h + ':' + x.mode).join(' '), frames, seconds: +total.toFixed(2), fps: +(frames / total).toFixed(1), msPerFrame: +((total * 1000) / frames).toFixed(1), decodeMs: Math.round(T.decode), renderMs: Math.round(T.render), readMs: Math.round(T.read), encodeWaitMs: Math.round(T.write), videoCards: feeders.size, size: o.width + 'x' + o.height, format: wantPng ? 'png' : 'prores' }); } catch (e5) {}
      } catch (err) {
        try { proc.kill(); } catch (e2) {}
        try { if (!wantPng && CS.fs.existsSync(out)) CS.fs.unlinkSync(out); } catch (e3) {}
        throw err;
      } finally {
        for (const [s, fd] of feeders) { fd.stop(); if (s.frame && s.frame.bitmap) { try { s.frame.bitmap.close(); } catch (e7) {} } delete s.frame; }
        try { const ext = gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext(); } catch (e4) {}
      }
      return { first: wantPng ? join(o.outDir, (o.prefix || 'frame') + '_00000.png') : out, count: frames, video: !wantPng };
    }
    for (let f = 0; f < frames; f++) {
      if (cancelled) { await Promise.allSettled(pending); throw new Error('Export cancelled'); }
      const t = f / o.fps;
      for (const s of sources) if (s.type === 'video') await Sources.seekVideo(s.el, t + (s['in'] || 0));
      r.render(buildScene(o.state, sources, t, o.width, o.height, { layer: o.layer || 'all' }));
      const file = join(o.outDir, (o.prefix || 'frame') + '_' + String(f).padStart(5, '0') + '.png');
      if (!first) first = file;
      if (fast) {
        gl.readPixels(0, 0, o.width, o.height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
        const copy = pixels.slice();
        const p = encodePNG(copy, o.width, o.height).then(buf => writeFileAsync(file, buf)).then(tick);
        pending.push(p);
        if (pending.length >= 4) { await pending.shift(); }
      } else {
        const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
        if (!blob) throw new Error('Could not encode frame ' + f);
        CS.writeFile(file, await blob.arrayBuffer());
        tick();
      }
      if (f % 3 === 0) await new Promise(res => setTimeout(res, 0));
    }
    await Promise.all(pending);
    try { const ext = gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext(); } catch (e) {}
    return { first, count: frames };
  }

  /* --------------------------------------------------------- helpers */
  function stamp() {
    const d = new Date(), p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
  }
  function safeName(s) { return String(s).replace(/[^a-z0-9_\-]+/gi, '_').slice(0, 40); }
  async function sequenceInfo() {
    if (!CS.inCEP) throw new Error('Open this panel inside Premiere Pro (Window > Extensions > 3D Carousel) to add clips to the timeline.');
    if (!CS.hasNode) throw new Error('Node.js is disabled in this panel, files cannot be written.');
    const info = await CS.call('C3D_getSequenceInfo');
    if (!info.ok) throw new Error(info.error || 'No active sequence');
    return info;
  }
  function carouselDir(info, name) {
    const base = info.projectDir || info.documents || (CS.os ? CS.os.homedir() : '');
    return join(base, 'OutflowStudio', 'carousel', name);
  }
  /* make sure every source has a file on disk (dropped blobs get copied) */
  async function materialize(sourceIds, dir) {
    const out = [];
    for (const id of sourceIds) {
      const s = Sources.get(id); if (!s) continue;
      if (!s.path) {
        if (!s.file) throw new Error(s.name + ' has no file path; add it through the file dialog or the Project panel.');
        CS.mkdirp(join(dir, 'assets'));
        const p = join(dir, 'assets', safeName(s.name.replace(/\.[^.]+$/, '')) + '_' + id + (s.name.match(/\.[^.]+$/) || [''])[0]);
        CS.writeFile(p, await s.file.arrayBuffer());
        s.path = p;
      }
      out.push(s);
    }
    return out;
  }
  function writeSettings(dir, state, sources, name) {
    CS.mkdirp(dir);
    const data = { version: 2, name, state, sources: sources.map(s => ({ path: s.path, name: s.name, type: s.type })) };
    CS.fs.writeFileSync(join(dir, 'settings.json'), JSON.stringify(data, null, 1));
  }
  function readSettings(dir) {
    const p = join(dir, 'settings.json');
    if (!CS.fs.existsSync(p)) return null;
    try { return JSON.parse(CS.fs.readFileSync(p, 'utf8')); } catch (e) { return null; }
  }

  /* ------------------------------------------------------ render mode */
  /* frame rate for rendering / keyframe sampling: the sequence's, or a fixed one from the Output section */
  function renderFps(state, info) { const f = parseFloat(state.fps); return f > 0 ? f : info.fps; }
  async function addRendered(state, sourceIds, ui, info, name, dir, trackHint) {
    const sources = await materialize(sourceIds, dir);
    const fps = renderFps(state, info);
    writeSettings(dir, state, sources, name);
    const passes = [];
    if (state.bg && state.bg.enabled) passes.push(['bg', 'background']);
    if (state.split) { passes.push(['back', 'back']); passes.push(['front', 'front']); } else passes.push(['all', 'carousel']);
    let track = trackHint === undefined ? -1 : trackHint;
    const results = [];
    for (let i = 0; i < passes.length; i++) {
      const [layer, sub] = passes[i];
      ui.title('Rendering ' + sub + ' (' + (i + 1) + '/' + passes.length + ')');
      const res = await renderFrames({
        state, sourceIds, width: info.width, height: info.height, fps, outDir: join(dir, sub), prefix: 'frame', layer,
        onProgress: (p, f, n) => ui.progress(p, f + ' / ' + n + ' frames  ·  ' + info.width + '×' + info.height + ' @ ' + fps.toFixed(2) + ' fps')
      });
      ui.title('Placing ' + sub + ' on the timeline');
      const host = await CS.call('C3D_importAndInsert', res.first, fps, state.duration, track, BIN, name + ' (' + sub + ')');
      if (!host.ok) throw new Error(host.error || 'Premiere could not place the clip');
      track = host.track + 1;
      results.push(Object.assign({ layer: sub }, host));
    }
    return { dir, info, results, name, mode: 'render' };
  }

  /* ------------------------------------------------------ native mode */
  /* homography mapping 4 src points to 4 dst points (DLT, 8x8 solve) */
  function homography(src, dst) {
    const A = [], b = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i], [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
    }
    const n = 8, M = A.map((r, i) => r.concat([b[i]]));
    for (let c = 0; c < n; c++) {
      let piv = c;
      for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
      [M[c], M[piv]] = [M[piv], M[c]];
      const d = M[c][c] || 1e-12;
      for (let r = 0; r < n; r++) {
        if (r === c) continue;
        const f = M[r][c] / d;
        if (!f) continue;
        for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
      }
    }
    const h = M.map((r, i) => r[n] / (r[i] || 1e-12));
    return [h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1];
  }
  const applyH = (H, p) => { const w = H[6] * p[0] + H[7] * p[1] + 1 || 1e-9; return [(H[0] * p[0] + H[1] * p[1] + H[2]) / w, (H[3] * p[0] + H[4] * p[1] + H[5]) / w]; };

  /* bakes cover-crop, rounded corners and border into a PNG for native mode */
  async function bakeImage(src, aspect, cornerFrac, borderFrac, borderColor, file) {
    const ow = src.ow || src.w, oh = src.oh || src.h;
    let cw = ow, ch = oh, cx = 0, cy = 0;
    if (ow / oh > aspect) { cw = oh * aspect; cx = (ow - cw) / 2; } else { ch = ow / aspect; cy = (oh - ch) / 2; }
    const sc = Math.min(1, 2048 / Math.max(cw, ch));
    const bw = Math.max(8, Math.round(cw * sc)), bh = Math.max(8, Math.round(ch * sc));
    const c = document.createElement('canvas'); c.width = bw; c.height = bh;
    const g = c.getContext('2d');
    const r = Math.min(cornerFrac * bw, bw / 2, bh / 2);
    const rr = (x, y, w, h, rad) => { g.beginPath(); g.moveTo(x + rad, y); g.arcTo(x + w, y, x + w, y + h, rad); g.arcTo(x + w, y + h, x, y + h, rad); g.arcTo(x, y + h, x, y, rad); g.arcTo(x, y, x + w, y, rad); g.closePath(); };
    g.save(); rr(0, 0, bw, bh, r); g.clip();
    const el = src.el, kx = el.width / ow, ky = el.height / oh;
    g.imageSmoothingQuality = 'high';
    g.drawImage(el, cx * kx, cy * ky, cw * kx, ch * ky, 0, 0, bw, bh);
    g.restore();
    const bpx = borderFrac * bw;
    if (bpx > 0.5) { g.save(); rr(bpx / 2, bpx / 2, bw - bpx, bh - bpx, Math.max(0, r - bpx / 2)); g.lineWidth = bpx; g.strokeStyle = borderColor; g.stroke(); g.restore(); }
    const blob = await new Promise(res => c.toBlob(res, 'image/png'));
    CS.writeFile(file, await blob.arrayBuffer());
    return { path: file, ow: bw, oh: bh, aspect: bw / bh };
  }

  function reduceKeys(frames, getter, eps, fps) {
    const keys = [];
    let lastKept = null, lastSeen = null;
    const same = (a, b) => { for (let i = 0; i < a.length; i++) if (Math.abs(a[i] - b[i]) > eps) return false; return true; };
    const rnd = (v) => v.map(x => Math.round(x * 1000) / 1000);
    for (const fr of frames) {
      const v = getter(fr.s), t = fr.f / fps;
      if (!lastKept) { keys.push([t].concat(rnd(v))); lastKept = { t, v }; }
      else if (!same(v, lastKept.v)) {
        if (lastSeen && lastSeen.t !== lastKept.t) keys.push([lastSeen.t].concat(rnd(lastSeen.v)));
        keys.push([t].concat(rnd(v))); lastKept = { t, v };
      }
      lastSeen = { t, v };
    }
    return keys;
  }
  /* kind: 'bg' | 'card'; m: { method, W, H, ow, oh, crop } for cards */
  function piecesToPayload(pieces, fps, isVideo, kind, m) {
    return pieces.map(pc => {
      const fr = pc.frames;
      /* Premiere's Gaussian Blur is stronger than our shader blur per unit */
      const blurK = kind === 'card' ? 0.45 : 0.7;
      const keys = {
        opac: reduceKeys(fr, s => [Math.max(0, Math.min(100, s.opacity))], 0.05, fps)
      };
      if (kind === 'card' && m.method === 'cornerpin') {
        /* Motion stays static (source scaled to cover the frame); the 4 pin points do the 3D */
        const S = 100 * Math.max(m.W / m.ow, m.H / m.oh);
        const toSrc = (P) => [m.ow / 2 + (P[0] - m.W / 2) * 100 / S, m.oh / 2 + (P[1] - m.H / 2) * 100 / S];
        const cr = m.crop;
        const hasCrop = cr && (cr.l > 0.05 || cr.r > 0.05 || cr.t > 0.05 || cr.b > 0.05);
        const L = hasCrop ? cr.l / 100 * m.ow : 0, R = hasCrop ? m.ow - cr.r / 100 * m.ow : m.ow;
        const T = hasCrop ? cr.t / 100 * m.oh : 0, B = hasCrop ? m.oh - cr.b / 100 * m.oh : m.oh;
        const layer = [[0, 0], [m.ow, 0], [0, m.oh], [m.ow, m.oh]];
        const pins = (s) => {
          const card = s.corners.map(toSrc);
          if (!hasCrop) return card;
          const Hm = homography([[L, T], [R, T], [L, B], [R, B]], card);
          return layer.map(p => applyH(Hm, p));
        };
        keys.pin = reduceKeys(fr, s => pins(s).flat(), 0.05, fps);
        keys.pos = [[0, m.W / 2, m.H / 2]];
        keys.scale = [[0, S]];
        keys.rot = [[0, 0]];
        keys.blur = reduceKeys(fr, s => [s.blur * blurK * 100 / S], 0.05, fps);
      } else {
        keys.pos = reduceKeys(fr, s => [s.x, s.y], 0.05, fps);
        keys.scale = reduceKeys(fr, s => [s.scale], 0.01, fps);
        keys.rot = reduceKeys(fr, s => [s.rot], 0.01, fps);
        keys.blur = reduceKeys(fr, s => [s.blur * blurK], 0.05, fps);
        if (kind === 'card' && m.method === 'basic3d') {
          keys.swivel = reduceKeys(fr, s => [s.swivel], 0.01, fps);
          keys.tilt = reduceKeys(fr, s => [s.tilt], 0.01, fps);
        }
        if (kind === 'card' && m.method === 'scale') {
          keys.scale = reduceKeys(fr, s => [s.scale * Math.max(0.02, Math.abs(Math.cos(s.tilt * DEG)))], 0.01, fps);
          keys.scaleW = reduceKeys(fr, s => [s.scale * Math.max(0.02, Math.abs(Math.cos(s.swivel * DEG)))], 0.01, fps);
        }
      }
      if (kind === 'card') keys.bright = reduceKeys(fr, s => [Math.max(-100, Math.min(100, ((s.bright === undefined ? 1 : s.bright) - 1) * 100))], 0.2, fps);
      const s = pc.f0 / fps, e = (pc.f1 + 1) / fps;
      return { track: pc.track, s, e, mediaIn: isVideo ? s : 0, keys };
    });
  }
  async function addNative(state, sourceIds, ui, info, name, dir, trackHint) {
    const sources = await materialize(sourceIds, dir);
    writeSettings(dir, state, sources, name);
    const n = sources.length, fps = renderFps(state, info), W = info.width, H = info.height;
    const frames = Math.max(1, Math.round(state.duration * fps));
    const nat = state.native || DEFAULTS.native;
    const method = nat.method || 'cornerpin';
    /* bake crop / rounded corners / border into image cards (videos keep the Crop effect) */
    let cardSrcs = sources;
    if (nat.bake !== false) {
      ui.title('Preparing card images');
      const S0 = solveScene(state, sources, 0, W, H);
      const cornerFrac = state.card.corner / (S0.w * PX_PER_UNIT), borderFrac = state.card.border / (S0.w * PX_PER_UNIT);
      CS.mkdirp(join(dir, 'cards'));
      cardSrcs = [];
      for (let i = 0; i < n; i++) {
        const s = sources[i];
        if (s.type !== 'image') { cardSrcs.push(s); continue; }
        const aspect = state.card.fit === 'contain' ? (s.aspect || S0.ca) : S0.ca;
        const tag = [aspect.toFixed(4), cornerFrac.toFixed(4), borderFrac.toFixed(4), state.card.borderColor].join('_');
        const file = join(dir, 'cards', 'card' + String(i + 1).padStart(2, '0') + '.png');
        const baked = await bakeImage(s, aspect, cornerFrac, borderFrac, state.card.borderColor, file);
        cardSrcs.push(Object.assign({}, s, baked, { bakedTag: tag }));
        ui.progress((i + 1) / n, s.name);
      }
    }
    ui.title('Solving animation');
    const samples = [];
    for (let f = 0; f < frames; f++) {
      if (cancelled) throw new Error('Export cancelled');
      samples.push(sampleNative(state, cardSrcs, f / fps, W, H, { bgSources: sources }));
      if (f % 20 === 0) { ui.progress(f / frames, f + ' / ' + frames + ' frames'); await new Promise(r => setTimeout(r, 0)); }
    }
    /* card pieces: a piece lives on one track (its depth rank) for a run of frames */
    const bgOn = state.bg && state.bg.enabled;
    const bgTracks = bgOn ? 2 : 0;
    const cardPieces = sources.map(() => []);
    const open = new Array(n).fill(null);
    for (let f = 0; f < frames; f++) {
      const ranks = new Array(n).fill(-1);
      samples[f].cards.forEach((c, r) => { ranks[c.i] = r; });
      for (let i = 0; i < n; i++) {
        const r = ranks[i];
        const smp = r >= 0 ? samples[f].cards[r] : null;
        if (smp && open[i] && open[i].track === r) { open[i].f1 = f; open[i].frames.push({ f, s: smp }); continue; }
        if (open[i]) { cardPieces[i].push(open[i]); open[i] = null; }
        if (smp) open[i] = { track: r, f0: f, f1: f, frames: [{ f, s: smp }] };
      }
    }
    for (let i = 0; i < n; i++) if (open[i]) cardPieces[i].push(open[i]);
    /* background pieces on two alternating tracks */
    const bgPieces = sources.map(() => []);
    const bgOpen = new Array(n).fill(null);
    if (bgOn) {
      for (let f = 0; f < frames; f++) {
        const seen = new Set();
        for (const b of samples[f].bg) {
          seen.add(b.i);
          if (bgOpen[b.i]) { bgOpen[b.i].f1 = f; bgOpen[b.i].frames.push({ f, s: b }); continue; }
          const used = bgOpen.filter(Boolean).map(p => p.track);
          bgOpen[b.i] = { track: used.includes(0) ? 1 : 0, f0: f, f1: f, frames: [{ f, s: b }], crop: b.crop, bright: b.bright };
        }
        for (let i = 0; i < n; i++) if (bgOpen[i] && !seen.has(i)) { bgPieces[i].push(bgOpen[i]); bgOpen[i] = null; }
      }
      for (let i = 0; i < n; i++) if (bgOpen[i]) bgPieces[i].push(bgOpen[i]);
    }
    ui.title('Preparing nested sequence');
    const begin = await CS.call('C3D_nativeBegin', JSON.stringify({ duration: state.duration, tracks: bgTracks + n, binName: BIN, track: -1, nest: true, name }));
    if (!begin.ok) throw new Error(begin.error);
    const warnings = [].concat(begin.warnings || []);
    /* evalScript truncates long strings: hand the host a file instead */
    const tmpDir = join(dir, 'tmp');
    CS.mkdirp(tmpDir);
    const viaFile = (tag, payload) => { const f = join(tmpDir, tag + '.json'); CS.fs.writeFileSync(f, JSON.stringify(payload)); return f; };
    let placed = 0, step = 0, total = n * (bgOn ? 2 : 1);
    if (bgOn) {
      for (let i = 0; i < n; i++) {
        if (!bgPieces[i].length) { step++; continue; }
        ui.title('Background ' + (i + 1) + ' / ' + n); ui.progress(step++ / total, 'writing keyframes');
        const first = bgPieces[i][0];
        const res = await CS.call('C3D_nativeCard', viaFile('bg' + i, {
          path: sources[i].path, name: name + ' bg' + String(i + 1).padStart(2, '0'), isVideo: sources[i].type === 'video', binName: BIN,
          base: begin.base, start: begin.start, width: W, height: H, crop: first.crop,
          fx: { basic3d: false, blur: true, bright: (first.bright - 1) * 100, sat: -(1 - state.bg.sat) * 100 },
          pieces: piecesToPayload(bgPieces[i], fps, sources[i].type === 'video', 'bg', {})
        }));
        if (!res.ok) throw new Error(res.error);
        placed += res.placed; warnings.push(...(res.warnings || []));
      }
    }
    for (let i = 0; i < n; i++) {
      if (cancelled) throw new Error('Export cancelled');
      if (!cardPieces[i].length) { step++; continue; }
      ui.title('Card ' + (i + 1) + ' / ' + n); ui.progress(step++ / total, 'writing keyframes');
      const all = cardPieces[i].flatMap(p => p.frames.map(x => x.s));
      const cs = cardSrcs[i];
      const needs3d = all.some(s => Math.abs(s.swivel) > 0.5 || Math.abs(s.tilt) > 0.5);
      const needsBlur = all.some(s => s.blur > 0.3);
      const crop = all[0].crop;
      const needsCrop = crop.l > 0.05 || crop.r > 0.05 || crop.t > 0.05 || crop.b > 0.05;
      const needsDim = all.some(s => s.bright !== undefined && Math.abs(s.bright - 1) > 0.02);
      const ow = cs.ow || cs.w, oh = cs.oh || cs.h;
      const pieces = piecesToPayload(cardPieces[i], fps, cs.type === 'video', 'card', { method, W, H, ow, oh, crop: needsCrop ? crop : null }).map(p => { p.track += bgTracks; return p; });
      const res = await CS.call('C3D_nativeCard', viaFile('card' + i, {
        path: cs.path, name: name + ' card' + String(i + 1).padStart(2, '0'), isVideo: cs.type === 'video', binName: BIN,
        base: begin.base, start: begin.start, width: W, height: H, srcW: ow, srcH: oh,
        crop: (needsCrop && method !== 'cornerpin') ? crop : null,
        fx: { basic3d: method === 'basic3d' && needs3d, cornerpin: method === 'cornerpin', scale2d: method === 'scale', blur: needsBlur, brightKeys: needsDim }, pieces
      }));
      if (!res.ok) throw new Error(res.error);
      placed += res.placed; warnings.push(...(res.warnings || []));
    }
    ui.title('Placing nested sequence'); ui.progress(1, '');
    const fin = await CS.call('C3D_nativeFinish', JSON.stringify({ origId: begin.origId, seqId: begin.seqId, start: begin.playhead, track: trackHint === undefined ? -1 : trackHint, duration: state.duration }));
    if (!fin.ok) throw new Error(fin.error);
    const uniq = Array.from(new Set(warnings));
    return { dir, info, name, mode: 'native', nested: true, placed, warnings: uniq, base: fin.track, tracks: 1 };
  }

  /* ---------------------------------------------------------- public */
  async function addToTimeline(state, sourceIds, ui, opts) {
    cancelled = false;
    opts = opts || {};
    const info = await sequenceInfo();
    const tpl = (TEMPLATES.find(t => t.id === state.template) || {}).name || state.layout;
    const name = opts.name || ('Carousel_' + safeName(tpl) + '_' + stamp());
    const dir = carouselDir(info, name);
    if (state.output === 'native') return addNative(state, sourceIds, ui, info, name, dir, opts.track);
    return addRendered(state, sourceIds, ui, info, name, dir, opts.track);
  }

  async function exportToFolder(state, sourceIds, ui, width, height, fps) {
    cancelled = false;
    if (!CS.hasNode) throw new Error('Exporting frames needs the panel to run inside Premiere Pro.');
    const folder = CS.pickFolder('Choose a folder for the PNG sequence');
    if (!folder) return null;
    const outDir = join(folder, 'Carousel_' + stamp());
    const passes = [];
    if (state.bg && state.bg.enabled) passes.push(['bg', 'background']);
    if (state.split) { passes.push(['back', 'back']); passes.push(['front', 'front']); } else passes.push(['all', 'carousel']);
    for (const [layer, sub] of passes) {
      ui.title('Rendering ' + sub);
      await renderFrames({ state, sourceIds, width, height, fps, outDir: join(outDir, sub), prefix: 'frame', layer, format: 'png',
        onProgress: (p, f, n) => ui.progress(p, f + ' / ' + n + ' frames') });
    }
    return outDir;
  }

  /* find the carousel a selected timeline clip belongs to and load its settings */
  async function loadFromSelection() {
    const info = await sequenceInfo();
    const sel = await CS.call('C3D_getSelectedClips');
    if (!sel.ok) throw new Error(sel.error);
    if (!sel.clips.length) throw new Error('Select a carousel clip in the timeline first.');
    for (const c of sel.clips) {
      const prefix = String(c.name).split(' ')[0];
      const candidates = [];
      if (c.path) { const m = c.path.replace(/\\/g, '/').match(/^(.*\/(?:Carousel3D|OutflowStudio\/carousel)\/[^/]+)\//); if (m) candidates.push(m[1]); }
      candidates.push(carouselDir(info, prefix));
      candidates.push(join(info.projectDir || info.documents || '', 'Carousel3D', prefix));
      for (const dir of candidates) {
        const s = readSettings(dir);
        if (s) return { settings: s, prefix, start: Math.min(...sel.clips.map(x => x.start)), track: Math.min(...sel.clips.map(x => x.track)), dir };
      }
    }
    throw new Error('No carousel settings found for the selected clip.');
  }
  async function removeCarousel(prefix) {
    const r = await CS.call('C3D_removeClipsByPrefix', prefix);
    if (!r.ok) throw new Error(r.error);
    return r;
  }
  async function setPlayhead(sec) { return CS.call('C3D_setPlayhead', sec); }
  async function projectSelection() {
    const r = await CS.call('C3D_getProjectSelection');
    if (!r.ok) throw new Error(r.error);
    return r.items;
  }
  async function timelineSelection() {
    const r = await CS.call('C3D_getSelectedClips');
    if (!r.ok) throw new Error(r.error);
    return r.clips.filter(c => c.path);
  }

  return { addToTimeline, exportToFolder, loadFromSelection, removeCarousel, setPlayhead, projectSelection, timelineSelection, writePNGFree, writePNGStraight, cancel() { cancelled = true; } };
})();
