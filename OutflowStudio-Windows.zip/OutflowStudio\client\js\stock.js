/* Stock media browser: Pexels (photos, videos), Openverse (audio), Giphy / Tenor (GIFs). */

/* ---------------------------------------------------------------- network */
const Net = (() => {
  let nodeReq = null;
  try { nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null); } catch (e) {}
  const https = nodeReq ? nodeReq('https') : null, http = nodeReq ? nodeReq('http') : null, crypto = nodeReq ? nodeReq('crypto') : null;
  const MIRROR = 'https://outflowstudio.com/engines/';
  const UA = 'OutflowStudio/1.0 (Premiere Pro panel)';

  function nodeGet(url, headers, redirects) {
    return new Promise((resolve, reject) => {
      const mod = url.startsWith('http:') ? http : https;
      const req = mod.get(url, { headers: Object.assign({ 'User-Agent': UA, 'Accept': '*/*' }, headers || {}) }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) {
          res.resume();
          const next = new URL(res.headers.location, url).toString();
          nodeGet(next, headers, redirects - 1).then(resolve, reject);
          return;
        }
        resolve(res);
      });
      req.on('error', reject);
      req.setTimeout(30000, () => { req.destroy(new Error('Request timed out')); });
    });
  }
  async function getJSON(url, headers) {
    if (https) {
      const res = await nodeGet(url, headers, 5);
      const chunks = [];
      await new Promise((ok, bad) => { res.on('data', c => chunks.push(c)); res.on('end', ok); res.on('error', bad); });
      const text = Buffer.concat(chunks).toString('utf8');
      if (res.statusCode >= 400) throw new Error('HTTP ' + res.statusCode + ': ' + text.slice(0, 160));
      return JSON.parse(text);
    }
    const r = await fetch(url, { headers: headers || {} });
    if (!r.ok) throw new Error('HTTP ' + r.status + ': ' + (await r.text()).slice(0, 160));
    return r.json();
  }
  /*  Connection trouble is retried: three tries with a pause, since a GitHub mirror that times out once
      usually answers the next time. A 404 is not retried - the callers have their own fallbacks for that.
      The error people see names the host and says what to check, not "connect ETIMEDOUT 185.199...".  */
  const FLAKY = /ETIMEDOUT|ECONNRESET|ENOTFOUND|EAI_AGAIN|ECONNREFUSED|EPIPE|EHOSTUNREACH|ENETUNREACH|timed out|socket hang up|incomplete/i;
  function friendly(url, e) {
    let host = 'the download server'; try { host = new URL(url).hostname; } catch (x) {}
    const m = String((e && e.message) || e);
    if (/ENOTFOUND|EAI_AGAIN/i.test(m)) return 'Could not find ' + host + '. Is the internet connection up?';
    if (FLAKY.test(m)) { const code = (/(E[A-Z]{4,})/.exec(m) || [])[1]; return 'Could not reach ' + host + (code ? ' (' + code + ')' : '') + (/github/i.test(host) ? ' or outflowstudio.com' : '') + '. Check the connection - a VPN, firewall or the network itself may be blocking it - then try again.'; }
    return m;
  }
  async function download(url, file, onProgress) {
    let last = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try { return await downloadOnce(url, file, onProgress); }
      catch (e) {
        last = e;
        const m = String((e && e.message) || e);
        if (!(FLAKY.test(m) || /HTTP 5\d\d/.test(m)) || attempt === 3) break;
        if (onProgress) onProgress(-1, 'Connection trouble, trying again (' + (attempt + 1) + ' of 3)');
        await new Promise((r) => setTimeout(r, attempt * 2500));
      }
    }
    /*  GitHub's download servers are out of reach on some networks (timeouts from India and elsewhere,
        Sept 2026). Every engine the panel takes from GitHub is also on outflowstudio.com, in parts: try that
        before giving up. Only for GitHub links and only after a network failure - a 404 goes to the callers. */
    const lm = String((last && last.message) || last);
    if (/github(usercontent)?\.com/i.test(url) && (FLAKY.test(lm) || /HTTP 5\d\d/.test(lm))) {
      try { return await fromMirror(url, file, onProgress); }
      catch (e) { try { Log.warn('net', 'mirror failed too', { url, err: e.message }); } catch (x) {} }
    }
    throw new Error(friendly(url, last));
  }
  let manifest = null;
  async function fromMirror(url, file, onProgress) {
    const name = decodeURIComponent(String(url).split('?')[0].split('/').pop() || '');
    if (!manifest) manifest = await getJSON(MIRROR + 'manifest.json');
    const m = manifest && manifest[name];
    if (!m) throw new Error('not on the mirror: ' + name);
    try { Log.info('net', 'GitHub out of reach, taking the copy from outflowstudio.com', { name, parts: m.parts }); } catch (e) {}
    const parts = [];
    try {
      for (let i = 0; i < m.parts; i++) {
        const pf = file + '.mirror' + i;
        await downloadOnce(MIRROR + encodeURIComponent(name) + '.p' + i, pf, (p) => { if (onProgress) onProgress(p >= 0 ? (i + p) / m.parts : -1, 0, m.size); });
        parts.push(pf);
      }
      const tmp = file + '.joined';
      CS.fs.writeFileSync(tmp, Buffer.concat(parts.map((p) => CS.fs.readFileSync(p))));
      const sum = crypto ? crypto.createHash('sha256').update(CS.fs.readFileSync(tmp)).digest('hex') : m.sha256;
      if (sum !== m.sha256) { try { CS.fs.unlinkSync(tmp); } catch (e) {} throw new Error('the copy did not check out'); }
      try { CS.fs.unlinkSync(file); } catch (e) {}
      CS.fs.renameSync(tmp, file);
      return file;
    } finally { for (const p of parts) { try { CS.fs.unlinkSync(p); } catch (e) {} } }
  }
  async function downloadOnce(url, file, onProgress) {
    if (!https || !CS.fs) throw new Error('Downloads need the panel to run inside Premiere Pro.');
    const res = await nodeGet(url, {}, 5);
    if (res.statusCode >= 400) { res.resume(); throw new Error('Download failed: HTTP ' + res.statusCode); }
    const total = parseInt(res.headers['content-length'] || '0', 10);
    let got = 0;
    /* unique temp name: two downloads of the same item must never share a .part file */
    const tmp = file + '.' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6) + '.part';
    try {
      await new Promise((ok, bad) => {
        const ws = CS.fs.createWriteStream(tmp);
        res.on('data', (c) => { got += c.length; if (onProgress) onProgress(total ? got / total : -1, got, total); });
        res.on('error', bad); ws.on('error', bad);
        ws.on('finish', ok);
        res.pipe(ws);
      });
      const size = CS.fs.statSync(tmp).size;
      if (!size || (total && size < total)) throw new Error('Download incomplete (' + size + ' of ' + total + ' bytes).');
      if (CS.fs.existsSync(file) && CS.fs.statSync(file).size === size) CS.fs.unlinkSync(tmp);   /* someone else finished it first */
      else { try { CS.fs.unlinkSync(file); } catch (e) {} CS.fs.renameSync(tmp, file); }
    } catch (e) { try { CS.fs.unlinkSync(tmp); } catch (e2) {} throw e; }
    return file;
  }
  /* size of a file in bytes from a HEAD request, 0 when the server does not say */
  function head(url) {
    if (!https) return Promise.resolve(0);
    return new Promise((resolve) => {
      const go = (u, left) => {
        try {
          const mod = u.startsWith('http:') ? http : https;
          const req = mod.request(u, { method: 'HEAD', headers: { 'User-Agent': UA } }, (res) => {
            res.resume();
            if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && left > 0) return go(new URL(res.headers.location, u).toString(), left - 1);
            resolve(parseInt(res.headers['content-length'] || '0', 10) || 0);
          });
          req.on('error', () => resolve(0));
          req.setTimeout(8000, () => { req.destroy(); resolve(0); });
          req.end();
        } catch (e) { resolve(0); }
      };
      go(url, 5);
    });
  }
  return { getJSON, download, head, hasNode: !!https };
})();

/* -------------------------------------------------------------- providers */

const Providers = (() => {
  const enc = encodeURIComponent;
  const key = (k) => (Hub.keys()[k] || (window.BUILTIN_KEYS || {})[k] || '').trim();
  const PER = 24;
  return {
    photos: {
      name: 'Pexels', needsKey: 'pexels',
      async search(q, page, o) {
        const k = key('pexels'); if (!k) throw new Error('needkey');
        const url = q
          ? 'https://api.pexels.com/v1/search?query=' + enc(q) + '&per_page=' + PER + '&page=' + page + (o.orientation !== 'all' ? '&orientation=' + o.orientation : '')
          : 'https://api.pexels.com/v1/curated?per_page=' + PER + '&page=' + page;
        const d = await Net.getJSON(url, { Authorization: k });
        return {
          more: !!d.next_page,
          items: (d.photos || []).map(p => ({ id: 'pexels_' + p.id, kind: 'photo', w: p.width, h: p.height, thumb: p.src.medium, url: p.src.original, srcs: { original: p.src.original, large2x: p.src.large2x, large: p.src.large }, ext: 'jpg', author: p.photographer, link: p.url, title: p.alt || '' }))
        };
      }
    },
    videos: {
      name: 'Pexels', needsKey: 'pexels',
      async search(q, page, o) {
        const k = key('pexels'); if (!k) throw new Error('needkey');
        const url = q
          ? 'https://api.pexels.com/videos/search?query=' + enc(q) + '&per_page=' + PER + '&page=' + page + (o.orientation !== 'all' ? '&orientation=' + o.orientation : '')
          : 'https://api.pexels.com/videos/popular?per_page=' + PER + '&page=' + page;
        const d = await Net.getJSON(url, { Authorization: k });
        return {
          more: !!d.next_page,
          items: (d.videos || []).map(v => {
            const files = (v.video_files || []).filter(f => /mp4/i.test(f.file_type || 'mp4')).map(f => ({ w: f.width, h: f.height, link: f.link })).sort((a, b) => b.h - a.h);
            return { id: 'pexels_v' + v.id, kind: 'video', w: v.width, h: v.height, duration: v.duration, thumb: v.image, files, preview: files.length ? files[files.length - 1].link : null, ext: 'mp4', author: v.user ? v.user.name : '', link: v.url, title: '' };
          })
        };
      }
    },
    audio: {
      name: 'Openverse', needsKey: null,
      async search(q, page) {
        const url = 'https://api.openverse.org/v1/audio/?q=' + enc(q || 'music') + '&page_size=20&page=' + page;
        const d = await Net.getJSON(url, { Accept: 'application/json' });
        return {
          more: (d.page_count || 1) > page,
          items: (d.results || []).map(a => {
            const m = /\.([a-z0-9]{2,4})(\?|$)/i.exec(a.url || '');
            return { id: 'openverse_' + a.id, kind: 'audio', thumb: a.thumbnail || null, url: a.url, ext: (a.filetype || (m ? m[1] : 'mp3')).toLowerCase(), title: a.title || 'Untitled', author: a.creator || '', duration: (a.duration || 0) / 1000, license: (a.license || '').toUpperCase() + (a.license_version ? ' ' + a.license_version : ''), link: a.foreign_landing_url };
          })
        };
      }
    },
    sfx: {
      name: 'Freesound', needsKey: 'freesound',
      async search(q, page) {
        const k = key('freesound'); if (!k) throw new Error('needkey:freesound');
        const url = 'https://freesound.org/apiv2/search/text/?query=' + enc(q || 'whoosh') + '&page=' + page + '&page_size=' + PER + '&fields=id,name,previews,duration,username,license,url,tags&token=' + enc(k);
        const d = await Net.getJSON(url);
        return {
          more: !!d.next,
          items: (d.results || []).map(s => ({ id: 'freesound_' + s.id, kind: 'audio', thumb: null, url: (s.previews || {})['preview-hq-mp3'] || (s.previews || {})['preview-lq-mp3'], ext: 'mp3', title: s.name, author: s.username, duration: s.duration, license: String(s.license || '').replace(/^https?:\/\/creativecommons.org\/(licenses|publicdomain)\//, '').replace(/\/$/, '').toUpperCase(), link: s.url }))
        };
      }
    },
    gifs: {
      name: 'Giphy', needsKey: null,
      async search(q, page, o) {
        if (o.gifSource === 'tenor') {
          const k = key('tenor'); if (!k) throw new Error('needkey:tenor');
          const base = q ? 'https://tenor.googleapis.com/v2/search?q=' + enc(q) : 'https://tenor.googleapis.com/v2/featured?';
          const url = base + '&key=' + enc(k) + '&limit=' + PER + '&media_filter=tinygif,gif,mp4' + (o.pos ? '&pos=' + enc(o.pos) : '');
          const d = await Net.getJSON(url);
          return {
            more: !!d.next, pos: d.next,
            items: (d.results || []).map(r => {
              const mf = r.media_formats || {};
              const best = mf.mp4 || mf.gif || mf.tinygif;
              return { id: 'tenor_' + r.id, kind: 'gif', thumb: (mf.tinygif || mf.gif || {}).url, url: best.url, ext: mf.mp4 ? 'mp4' : 'gif', w: best.dims ? best.dims[0] : 0, h: best.dims ? best.dims[1] : 0, title: r.content_description || '', author: '', link: r.itemurl };
            })
          };
        }
        const k = key('giphy'); if (!k) throw new Error('needkey:giphy');
        const base = q ? 'https://api.giphy.com/v1/gifs/search?q=' + enc(q) : 'https://api.giphy.com/v1/gifs/trending?';
        const url = base + '&api_key=' + enc(k) + '&limit=' + PER + '&offset=' + ((page - 1) * PER) + '&rating=pg-13';
        const d = await Net.getJSON(url);
        const total = d.pagination ? d.pagination.total_count : 0;
        return {
          more: total > page * PER,
          items: (d.data || []).map(g => {
            const im = g.images || {};
            const orig = im.original || {};
            return { id: 'giphy_' + g.id, kind: 'gif', thumb: (im.fixed_width || orig).url, url: orig.mp4 || orig.url, ext: orig.mp4 ? 'mp4' : 'gif', w: +orig.width || 0, h: +orig.height || 0, title: g.title || '', author: g.username || '', link: g.url };
          })
        };
      }
    }
  };
})();

/* --------------------------------------------------------------------- UI */
const Stock = (() => {
  const $ = (s) => document.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const st = { tab: 'photos', q: '', page: 1, items: [], more: false, pos: null, orientation: 'all', gifSource: 'giphy', loading: false };
  let stockMore = null;   /* set once the screen exists: loads the next batch when the end is already in view */
  let audio = null, audioBtn = null;
  const TABS = { photos: 'Photos', videos: 'Videos', audio: 'Music', sfx: 'SFX', gifs: 'GIFs', favs: '★ Favourites', recent: 'Recent' };
  const LOCAL = { favs: true, recent: true };   /* tabs that list what is stored here, not a provider */
  /*  Favourites and the recent list: the item objects as the providers hand them out (plain data - thumb,
      urls, title, author - nothing that cannot be stored), each tagged with the tab it came from and when.
      Newest first, capped so the file never grows without end.                                          */
  const store = {
    load(k) { try { return JSON.parse(localStorage.getItem('os.stock.' + k) || '[]'); } catch (e) { return []; } },
    save(k, list) { try { localStorage.setItem('os.stock.' + k, JSON.stringify(list)); } catch (e) {} },
    strip(it) { const o = {}; for (const k of Object.keys(it)) if (typeof it[k] !== 'function') o[k] = it[k]; return o; },
    isFav(it) { return store.load('favs').some(x => x.id === it.id); },
    toggleFav(it) {
      let list = store.load('favs');
      const was = list.some(x => x.id === it.id);
      list = was ? list.filter(x => x.id !== it.id) : [Object.assign(store.strip(it), { t: Date.now() })].concat(list).slice(0, 300);
      store.save('favs', list);
      return !was;
    },
    noteRecent(it) {
      const list = [Object.assign(store.strip(it), { t: Date.now() })].concat(store.load('recent').filter(x => x.id !== it.id)).slice(0, 60);
      store.save('recent', list);
    },
    clear(k) { store.save(k, []); }
  };


  function open(tab) {
    st.tab = tab || st.tab;
    Hub.show('stock');
    syncTabs();
    if (!st.items.length || st.lastTab !== st.tab) search(true);
  }
  function syncTabs() {
    document.querySelectorAll('#st-tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === st.tab));
    $('#st-orient').style.display = (st.tab === 'photos' || st.tab === 'videos') ? '' : 'none';
    $('#st-gifsrc').style.display = st.tab === 'gifs' ? '' : 'none';
    const clr = $('#st-clear'); if (clr) clr.style.display = st.tab === 'recent' ? '' : 'none';
    const res = $('#st-res');
    if (res) {
      res.style.display = (st.tab === 'photos' || st.tab === 'videos') ? '' : 'none';
      const k = Hub.keys();
      if (st.tab === 'videos') { res.innerHTML = '<option value="4k">Best available (up to 4K)</option><option value="hd">1080p</option><option value="sd">720p</option>'; res.value = k.videoQuality || 'hd'; }
      else { res.innerHTML = '<option value="original">Original size</option><option value="large2x">Large · 1880 px</option><option value="large">Web · 940 px</option>'; res.value = k.photoSize || 'original'; }
    }
    addedBar(false);
    $('#st-q').placeholder = { photos: 'Search photos…', videos: 'Search videos…', audio: 'Search music…', sfx: 'Search sound effects…', gifs: 'Search GIFs…', favs: 'Filter your favourites…', recent: 'Filter recent…' }[st.tab];
    $('#st-attrib').textContent = { favs: 'Your favourites, kept on this computer', recent: 'What you placed, imported or sent to the carousel, newest first', photos: 'Photos provided by Pexels', videos: 'Videos provided by Pexels', audio: 'Audio via Openverse (check each license)', sfx: 'Sounds via Freesound (check each license)', gifs: st.gifSource === 'tenor' ? 'Powered by Tenor' : 'Powered by GIPHY' }[st.tab];
  }
  function note(html, kind) {
    const n = $('#st-note'); n.innerHTML = html || ''; n.className = 'st-note' + (kind ? ' ' + kind : '') + (html ? ' show' : '');
  }
  function keyPrompt(which) {
    const names = { pexels: 'Pexels', giphy: 'Giphy', tenor: 'Tenor', freesound: 'Freesound' };
    note('<b>' + names[which] + ' needs a free API key.</b> Paste it in <a href="#" data-go="settings">Settings</a>, or put it in <code>client/js/config.js</code> so the panel ships with it.' +
      (which === 'giphy' ? ' Or switch the source to Tenor.' : '') + '<div class="inline" style="margin-top:6px"><input type="password" placeholder="paste ' + names[which] + ' key" spellcheck="false"><button class="ghost">Save & search</button></div>');
    const n = $('#st-note');
    n.querySelector('a').addEventListener('click', (e) => { e.preventDefault(); Hub.show('settings'); });
    n.querySelector('button').addEventListener('click', () => { const v = n.querySelector('input').value.trim(); if (!v) return; Hub.keys()[which] = v; Hub.saveKeys(); search(true); });
  }

  const aspectOk = (it) => {
    if (st.orientation === 'all' || !it.w || !it.h) return true;
    const r = it.w / it.h;
    return st.orientation === 'portrait' ? r < 0.95 : st.orientation === 'landscape' ? r > 1.05 : Math.abs(r - 1) <= 0.05;
  };
  async function search(reset) {
    if (st.loading) return;
    if (reset) { st.page = 1; st.pos = null; st.items = []; $('#st-grid').innerHTML = ''; }
    st.q = $('#st-q').value.trim();
    st.lastTab = st.tab;
    st.loading = true; note(''); $('#st-more').disabled = true; $('#st-go').disabled = true;
    if (LOCAL[st.tab]) {
      const q = st.q.toLowerCase();
      const all = store.load(st.tab).filter(it => !q || ((it.title || '') + ' ' + (it.author || '') + ' ' + (it.kind || '')).toLowerCase().includes(q));
      st.items = all; st.more = false; appendItems(all);
      if (!all.length) note(st.tab === 'favs' ? 'No favourites yet. The ★ on any photo, video or sound keeps it here.' : 'Nothing used yet. Whatever you place, import or send to the carousel shows up here.');
      st.loading = false; $('#st-go').disabled = false; $('#st-more').style.display = 'none';
      return;
    }
    try {
      /* curated/popular feeds have no orientation filter: filter client-side and keep loading until enough */
      const needFilter = !st.q && st.orientation !== 'all' && (st.tab === 'photos' || st.tab === 'videos');
      let added = 0, rounds = 0;
      do {
        const r = await Providers[st.tab].search(st.q, st.page, { orientation: st.orientation, gifSource: st.gifSource, pos: st.pos });
        st.more = r.more; st.pos = r.pos || null;
        const items = (needFilter ? r.items.filter(aspectOk) : r.items).map(it => Object.assign(it, { tab: st.tab }));
        st.items.push(...items); appendItems(items); added += items.length;
        st.page++; rounds++;
      } while (needFilter && added < 12 && st.more && rounds < 4);
      if (!st.items.length) note('No results' + (st.q ? ' for “' + st.q + '”' : '') + '.');
    } catch (e) {
      const m = /^needkey(?::(\w+))?(?::(\w+))?/.exec(e.message || '');
      if (m) keyPrompt(m[1] || Providers[st.tab].needsKey || 'pexels');
      else note('Search failed: ' + (e.message || e), 'err');
    } finally {
      st.loading = false; $('#st-go').disabled = false;
      $('#st-more').disabled = !st.more; $('#st-more').style.display = st.more ? '' : 'none';
      /* the new batch may not have filled the screen: check once more, so scrolling never stalls */
      if (stockMore) requestAnimationFrame(stockMore);
    }
  }

  function fmtDur(s) { s = Math.round(s || 0); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
  function appendItems(items) {
    const grid = $('#st-grid');
    for (const it of items) {
      const card = el('div', 'st-item ' + it.kind);
      const ratio = it.w && it.h ? clamp(it.h / it.w, 0.45, 1.8) : (it.kind === 'audio' ? 0.5 : 0.66);
      const media = el('div', 'st-media'); media.style.paddingTop = (ratio * 100).toFixed(1) + '%';
      if (it.kind === 'audio') {
        media.innerHTML = (it.thumb ? '<img loading="lazy" src="' + it.thumb + '">' : '') + '<div class="st-audio"><span>🎵</span></div>';
      } else media.innerHTML = '<img loading="lazy" src="' + it.thumb + '" alt="">';
      if (it.kind === 'video' && it.preview) {
        media.addEventListener('mouseenter', () => {
          if (media.querySelector('video')) return;
          const v = document.createElement('video'); v.src = it.preview; v.muted = true; v.loop = true; v.playsInline = true; v.autoplay = true;
          media.appendChild(v);
        });
        media.addEventListener('mouseleave', () => { const v = media.querySelector('video'); if (v) v.remove(); });
      }
      const meta = el('div', 'st-meta');
      card._item = it;
      metaFor(it, meta);
      const acts = el('div', 'st-actions');
      const mk = (label, title, fn) => { const b = el('button', '', label); b.title = title; b.addEventListener('click', (e) => { e.stopPropagation(); fn(b); }); acts.appendChild(b); return b; };
      if (it.kind === 'audio') mk('▶', 'Preview', (b) => togglePreview(it, b));
      mk('⏭', 'Add to the timeline at the playhead', () => acquire(it, true));
      mk('⬇', 'Import into the project only', () => acquire(it, false));
      if (it.kind !== 'audio') mk('🎠', 'Use in 3D Carousel', (b) => toCarousel(it, b));
      mk('↗', 'Open on ' + ((Providers[it.tab] || Providers[st.tab] || {}).name || 'the site'), () => CS.openURL(it.link));
      /* the star: kept in Favourites; in that tab, unstarring takes the card away */
      const fav = el('button', 'st-fav' + (store.isFav(it) ? ' on' : ''), store.isFav(it) ? '★' : '☆'); fav.title = 'Favourite';
      fav.addEventListener('click', (e) => {
        e.stopPropagation();
        const on = store.toggleFav(it);
        fav.textContent = on ? '★' : '☆'; fav.classList.toggle('on', on);
        if (!on && st.tab === 'favs') { card.remove(); if (!$('#st-grid').children.length) note('No favourites yet. The ★ on any photo, video or sound keeps it here.'); }
        toast(on ? 'Added to your favourites.' : 'Removed from your favourites.', 'ok');
        try { Usage.tick('set:stock:fav:' + (on ? 'add' : 'remove')); } catch (e2) {}
      });
      card.append(media, fav, meta, acts);
      grid.appendChild(card);
    }
  }
  function togglePreview(it, btn) {
    if (audio && audioBtn === btn) { audio.pause(); audio = null; btn.textContent = '▶'; audioBtn = null; return; }
    if (audio) { audio.pause(); if (audioBtn) audioBtn.textContent = '▶'; }
    const start = (src) => { audio = new Audio(src); audio.volume = 0.8; audio.play().catch(() => toast('Preview not available for this file.')); audio.onended = () => { btn.textContent = '▶'; audio = null; audioBtn = null; }; audioBtn = btn; btn.textContent = '⏸'; };
    if (it.resolve && !it.url) { btn.textContent = '…'; it.resolve('stream').then(start).catch(e => { btn.textContent = '▶'; toast(e.message, 'err'); }); return; }
    start(it.url);
  }

  /* --------------------------------------------------------- download */
  let paths = null;
  async function downloadDir(kind) {
    const k = Hub.keys();
    let base = k.downloadDir;
    if (!base) {
      if (!paths) { const r = await CS.call('OS_getPaths'); paths = r.ok ? r : {}; }
      base = paths.projectDir || paths.documents || (CS.os ? CS.os.homedir() : '');
      base = CS.path.join(base, 'OutflowStudio');
    }
    const dir = CS.path.join(base, kind);
    CS.mkdirp(dir);
    return dir;
  }
  /* the photo size setting: original, large2x (1880 px) or large (940 px) */
  function pickPhoto(it) {
    const q = Hub.keys().photoSize || 'original';
    const srcs = it.srcs || {};
    const url = q === 'large' ? (srcs.large || it.url) : q === 'large2x' ? (srcs.large2x || it.url) : it.url;
    const scale = q === 'large' ? Math.min(1, 940 / Math.max(1, it.w)) : q === 'large2x' ? Math.min(1, 1880 / Math.max(1, it.w)) : 1;
    return { url, w: Math.round(it.w * scale), h: Math.round(it.h * scale), tag: q === 'original' ? '' : q === 'large2x' ? '1880 px' : '940 px' };
  }
  /* what will be downloaded for an item with the current settings */
  function chosen(it) {
    if (it.kind === 'video') { const f = pickVideoFile(it); return { url: f.link, label: Math.min(f.w, f.h) + 'p' + (f.w < f.h ? ' vertical' : '') }; }
    if (it.kind === 'photo') { const p = pickPhoto(it); return { url: p.url, label: p.w + '×' + p.h }; }
    return { url: it.url, label: '' };
  }
  const sizeCache = new Map();
  let sizeQueue = [], sizeBusy = 0;
  function sizeOf(url, cb) {
    if (!url || !Net.hasNode) return;
    if (sizeCache.has(url)) { cb(sizeCache.get(url)); return; }
    sizeQueue.push([url, cb]);
    const pump = () => {
      while (sizeBusy < 4 && sizeQueue.length) {
        const [u, f] = sizeQueue.shift();
        if (sizeCache.has(u)) { f(sizeCache.get(u)); continue; }
        sizeBusy++;
        Net.head(u).then((n) => { sizeCache.set(u, n); f(n); }).catch(() => f(0)).finally(() => { sizeBusy--; pump(); });
      }
    };
    pump();
  }
  /* the meta line of a card: author · duration · resolution · MB (size fetched lazily) */
  function metaFor(it, meta) {
    const bits = [];
    if (it.kind === 'audio') bits.push(fmtDur(it.duration), it.license);
    if (it.kind === 'video') bits.push(fmtDur(it.duration));
    const c = chosen(it);
    if (c.label) bits.push(c.label);
    const base = [it.title && it.kind === 'audio' ? it.title : '', it.author, ...bits].filter(Boolean).join(' · ');
    meta.textContent = base; meta.title = base;
    if (it.kind === 'photo' || it.kind === 'video' || it.kind === 'gif') sizeOf(c.url, (n) => { if (n && meta.isConnected && meta.dataset.url === c.url) { meta.textContent = base + ' · ' + fmtMB(n); meta.title = meta.textContent; } });
    meta.dataset.url = c.url;
  }
  function refreshMetas() { document.querySelectorAll('#st-grid .st-item').forEach((card) => { if (card._item) metaFor(card._item, card.querySelector('.st-meta')); }); }
  function pickVideoFile(it) {
    const q = Hub.keys().videoQuality || 'hd';
    const max = q === 'sd' ? 720 : q === 'hd' ? 1080 : 100000;
    const ok = it.files.filter(f => Math.min(f.w, f.h) <= max);
    return (ok.length ? ok[0] : it.files[it.files.length - 1]);
  }
  /* one download at a time; a second click on the same item joins the running one */
  let inflight = null, inflightKey = '';
  const nodeReq2 = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const cp2 = nodeReq2 ? nodeReq2('child_process') : null, Buf2 = nodeReq2 ? nodeReq2('buffer').Buffer : null;
  /*  What the file really is, from its first bytes. Openverse hands out whatever the source has - OGG, FLAC,
      or a web page when the source wants a login - under the name the search promised, and Premiere then
      refused an "mp3" that was none. */
  function sniff(file) {
    try {
      const fd = CS.fs.openSync(file, 'r'); const b = Buf2.alloc(16); CS.fs.readSync(fd, b, 0, 16, 0); CS.fs.closeSync(fd);
      const s = b.toString('latin1');
      if (s.startsWith('ID3') || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) return 'mp3';
      if (s.startsWith('RIFF')) return 'wav';
      if (s.startsWith('OggS')) return 'ogg';
      if (s.startsWith('fLaC')) return 'flac';
      if (s.startsWith('FORM')) return 'aiff';
      if (s.slice(4, 8) === 'ftyp') return 'm4a';
      if (/^\s*[<{]/.test(s)) return 'page';
      return 'other';
    } catch (e) { return 'other'; }
  }
  async function playable(file) {
    const kind = sniff(file);
    if (kind === 'page') { try { CS.fs.unlinkSync(file); } catch (e) {} throw new Error('The source did not hand out this sound: its site wants a login for the file. Try another result.'); }
    if (['mp3', 'wav', 'm4a', 'aiff'].includes(kind)) return file;
    /* OGG, FLAC and the like: Premiere does not play them; the video engine turns them into MP3 */
    const ff = (window.Social && Social.ffmpeg) ? Social.ffmpeg() : null;
    if (!ff || !cp2) throw new Error('This sound is ' + kind.toUpperCase() + ', which Premiere cannot play. Install the video engine in Settings › Engines and the panel converts it for you.');
    const out = file.replace(/\.[a-z0-9]+$/i, '') + '.mp3';
    if (out !== file && CS.fs.existsSync(out) && CS.fs.statSync(out).size > 1000) return out;
    const tmp = file.replace(/\.[a-z0-9]+$/i, '') + '_conv.mp3';
    overlay.show('Converting to MP3'); overlay.set(-1, '');
    try {
      await new Promise((ok, bad) => { const p = CS.track(cp2.spawn(ff, ['-y', '-i', file, '-vn', '-c:a', 'libmp3lame', '-q:a', '2', tmp], { windowsHide: true })); let err = ''; p.stderr.on('data', (d) => { err += d; }); p.on('error', bad); p.on('close', (c) => c === 0 ? ok() : bad(new Error('Could not convert this sound: ' + err.trim().split('\n').pop().slice(0, 160)))); });
      if (out !== file) { try { CS.fs.unlinkSync(file); } catch (e) {} CS.fs.renameSync(tmp, out); return out; }
      return tmp;
    } finally { overlay.hide(); }
  }
  const fmtMB = (b) => (b / 1048576).toFixed(1) + ' MB';
  const overlay = {
    show(title) { const p = $('#progress'); if (!p) return; p.classList.add('show'); $('#prog-title').textContent = title; $('#prog-bar').style.width = '0%'; $('#prog-text').textContent = ''; const c = $('#prog-cancel'); if (c) c.style.display = 'none'; },
    set(p, text) { if (p >= 0) $('#prog-bar').style.width = Math.round(p * 100) + '%'; $('#prog-text').textContent = text || ''; },
    hide() { const p = $('#progress'); if (!p) return; p.classList.remove('show'); const c = $('#prog-cancel'); if (c) c.style.display = ''; }
  };
  async function fetchItem(it) {
    const key = it.kind + ':' + it.id;
    if (inflight) {
      if (inflightKey === key) return inflight;
      throw new Error('One download at a time. Wait for the current one to finish.');
    }
    inflightKey = key;
    inflight = fetchItemNow(it).finally(() => { inflight = null; inflightKey = ''; });
    return inflight;
  }
  async function fetchItemNow(it) {
    if (!Net.hasNode) throw new Error('Downloads work inside Premiere Pro only.');
    const dir = await downloadDir(it.kind === 'gif' ? 'gifs' : it.kind + 's');
    let url = it.url, name = it.id + '.' + it.ext;
    if (it.kind === 'video') { const f = pickVideoFile(it); url = f.link; name = it.id + '_' + f.h + 'p.mp4'; }
    if (it.kind === 'photo' && it.srcs) { const p = pickPhoto(it); url = p.url; if (p.tag) name = it.id + '_' + p.w + '.jpg'; }
    if (it.resolve) url = await it.resolve('download');
    const file = CS.path.join(dir, name);
    try { if (CS.fs.existsSync(file) && CS.fs.statSync(file).size > 0) return file; } catch (e) {}
    overlay.show('Downloading ' + (it.kind === 'video' ? 'video' : it.kind));
    overlay.set(-1, name);
    try {
      await Net.download(url, file, (p, got, total) => { overlay.set(p, name + (total ? ' · ' + fmtMB(got) + ' / ' + fmtMB(total) : ' · ' + fmtMB(got))); note('Downloading ' + name + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')); });
    } finally { overlay.hide(); note(''); }
    return file;
  }
  /* Premiere occasionally refuses a file it saw appear a moment ago; try again shortly */
  async function importWithRetry(file, bin, insert, kind) {
    let r = await CS.call('OS_importMedia', file, bin, insert, kind);
    if (!r.ok && /could not import/i.test(r.error || '')) { await new Promise(res => setTimeout(res, 800)); r = await CS.call('OS_importMedia', file, bin, insert, kind); }
    return r;
  }
  async function acquire(it, insert) {
    try {
      let file = await fetchItem(it);
      if (it.kind === 'audio') file = await playable(file);
      const r = await importWithRetry(file, 'Outflow Stock', insert, it.kind);
      if (!r.ok) throw new Error(r.error);
      store.noteRecent(it);
      if (r.placed) toast('Placed on ' + r.track + ' at the playhead.', 'ok');
      else toast(r.note || 'Imported into Outflow › Stock.', 'ok');
    } catch (e) { toast(e.message || String(e), 'err'); note(''); }
  }
  async function toCarousel(it, btn) {
    try {
      const file = await fetchItem(it);
      await window.CarouselTool.addPaths([file], { stay: true });
      store.noteRecent(it);
      if (btn) { btn.textContent = '✓'; btn.title = 'In the carousel'; btn.classList.add('done'); }
      addedBar(true);
    } catch (e) { toast(e.message || String(e), 'err'); note(''); }
  }
  /* the bar at the bottom of the stock screen: how many cards are in the carousel, and a way to get there */
  function carouselCount() { try { return window.CarouselTool && window.CarouselTool.count ? window.CarouselTool.count() : 0; } catch (e) { return 0; } }
  function openCarousel() { Hub.show('carousel'); window.CarouselTool.show('editor'); }
  function addedBar(justAdded) {
    const n = carouselCount();
    let bar = $('#st-added');
    if (!bar) {
      bar = el('div', 'st-added'); bar.id = 'st-added';
      bar.innerHTML = '<span class="txt"></span><button class="primary" data-open>Open the carousel editor</button><button class="ghost" data-close title="Hide">✕</button>';
      bar.querySelector('[data-open]').addEventListener('click', openCarousel);
      bar.querySelector('[data-close]').addEventListener('click', () => bar.classList.remove('show'));
      $('#screen-stock').appendChild(bar);
    }
    bar.querySelector('.txt').textContent = (justAdded ? 'Added to the carousel · ' : '') + n + ' card' + (n === 1 ? '' : 's') + ' in the carousel';
    bar.classList.toggle('show', n > 0 && (justAdded || bar.classList.contains('show')));
    const chip = $('#st-count');
    if (chip) { chip.textContent = '🎠 ' + n; chip.style.display = n ? '' : 'none'; }
  }

  function init() {
    const tabs = $('#st-tabs');
    for (const [k, v] of Object.entries(TABS)) { const b = el('button', '', v); b.dataset.tab = k; b.addEventListener('click', () => { st.tab = k; syncTabs(); search(true); }); tabs.appendChild(b); }
    $('#st-go').addEventListener('click', () => search(true));
    $('#st-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') search(true); });
    $('#st-more').addEventListener('click', () => search(false));
    /* scrolling to the end loads the next batch on its own; the button stays for anyone who would rather click */
    const panel = document.querySelector('#screen-stock .st-panel');
    if (panel) {
      const nearEnd = () => panel.scrollHeight - panel.scrollTop - panel.clientHeight < 700;
      panel.addEventListener('scroll', () => { if (st.more && !st.loading && nearEnd()) search(false); }, { passive: true });
      stockMore = () => { if (st.more && !st.loading && nearEnd()) setTimeout(() => search(false), 60); };
    }
    document.querySelectorAll('#st-orient button').forEach(b => b.addEventListener('click', () => { st.orientation = b.dataset.v; document.querySelectorAll('#st-orient button').forEach(x => x.classList.toggle('on', x === b)); search(true); }));
    $('#st-gifsrc').addEventListener('change', (e) => { st.gifSource = e.target.value; syncTabs(); search(true); });
    /* resolution: videos share the Settings quality, photos have their own size */
    const res = $('#st-res');
    res.addEventListener('change', () => { const k = Hub.keys(); if (st.tab === 'videos') k.videoQuality = res.value; else k.photoSize = res.value; Hub.saveKeys(); refreshMetas(); });
    /* thumbnail size: 2 to 6 columns, remembered */
    const size = $('#st-size');
    let cols = 3; try { cols = parseInt(localStorage.getItem('os.stockCols') || '3', 10) || 3; } catch (e) {}
    size.value = 8 - cols; $('#st-grid').style.columnCount = cols;
    size.addEventListener('input', () => { const c = 8 - parseInt(size.value, 10); $('#st-grid').style.columnCount = c; try { localStorage.setItem('os.stockCols', String(c)); } catch (e) {} });
    $('#st-count').addEventListener('click', openCarousel);
    const clr = $('#st-clear'); if (clr) clr.addEventListener('click', () => { store.clear('recent'); search(true); });
    document.addEventListener('screenchange', (e) => { if (e.detail !== 'stock' && audio) { audio.pause(); audio = null; if (audioBtn) audioBtn.textContent = '▶'; } });
  }
  return { open, init, search };
})();
