/* Updates: once a day (and on demand from Settings) the panel reads version.json from the website,
   compares it with its own version and, when there is a newer one, shows the "what is new" screen over a
   blurred panel. Update now downloads the zip, checks it, unpacks it over this extension folder with the
   Windows tar and asks for a Premiere restart. A minVersion in version.json makes the update mandatory.
   Channel: stable (downloads/version.json) or beta (downloads/beta/version.json). */
const Update = (() => {
  const $ = (s) => document.querySelector(s);
  const CFG = () => window.OUTFLOW || {};
  const KEY = 'os.update';
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const cp = nodeReq ? nodeReq('child_process') : null;
  const proc = (window.cep_node && window.cep_node.process) || (typeof process !== 'undefined' ? process : null);
  const st = { channel: 'stable', last: 0, dismissed: '', dismissedAt: 0, installed: '' };
  try { Object.assign(st, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} };
  const cmp = (a, b) => { const pa = String(a || '0').split('.').map((n) => parseInt(n, 10) || 0), pb = String(b || '0').split('.').map((n) => parseInt(n, 10) || 0); for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0); return 0; };
  const version = () => CFG().version || '0.0.0';
  /*  A note that starts with "Mac:" or "Windows:" is for that side only: shown there without the prefix,
      left out on the other. One changelog, one version, and nobody reads about a fix for a computer they
      do not have. */
  const OS_TAG = /^\s*(mac|macos|windows|win)\s*:\s*/i;
  function platformNotes(notes, mac) {
    const out = [];
    for (const n of notes) {
      const m = OS_TAG.exec(String(n));
      if (!m) { out.push(String(n)); continue; }
      const forMac = /^mac/i.test(m[1]);
      if (forMac === mac) out.push(String(n).slice(m[0].length));
    }
    return out;
  }
  const infoUrl = () => CFG().site + '/downloads/' + (st.channel === 'beta' ? 'beta/' : '') + 'version.json?t=' + Date.now();
  let pending = null;

  async function fetchInfo() {
    const r = await fetch(infoUrl(), { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    if (!j.version || !j.url) throw new Error('version.json is incomplete');
    return j;
  }
  /* returns the server's info; shows the screen when it is newer (always when force) */
  async function check(opts) {
    opts = opts || {};
    let info;
    try { info = await fetchInfo(); }
    catch (e) {
      if (opts.force) { if (st.channel === 'beta' && /HTTP 404/.test(e.message)) toast('No beta build is out right now. You have ' + version() + '.', ''); else toast('Could not check for updates: ' + e.message, 'err'); }
      return null;
    }
    st.last = Date.now(); save();
    const newer = cmp(info.version, version()) > 0;
    const forced = cmp(version(), info.minVersion || '0') < 0;
    if (!newer) { if (opts.force) toast('You have the latest version (' + version() + (st.channel === 'beta' ? ', beta channel' : '') + ').', 'ok'); return info; }
    /* Later buries the card for three days, not for good: a version dismissed on a busy day still arrives */
    if (!opts.force && st.dismissed === info.version && Date.now() - (st.dismissedAt || 0) < 3 * 86400e3 && !forced) return info;
    show(info, forced);
    return info;
  }
  function show(info, forced) {
    pending = info;
    const m = $('#update-modal'); if (!m) return;
    $('#upd-title').textContent = (forced ? 'Update required · ' : 'Update ready · ') + info.version;
    const rep0 = $('#upd-report'); if (rep0) rep0.style.display = 'none';
    $('#upd-sub').textContent = st.channel === 'beta' && info.channel === 'beta' ? 'Beta build of ' + (info.date || '') + '. New in this version:' : 'New in this version, free for you:';
    $('#upd-list').innerHTML = platformNotes(info.notes || [], !!CS.mac).map((n) => '<li>' + String(n).replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])) + '</li>').join('') || '<li>General improvements</li>';
    $('#upd-bar').parentElement.style.display = 'none'; $('#upd-text').textContent = info.size ? Math.round(info.size / 1024) + ' KB download · installs in a few seconds' : '';
    $('#upd-go').textContent = 'Update now'; $('#upd-go').disabled = false; $('#upd-go').style.display = '';
    $('#upd-later').style.display = forced ? 'none' : ''; $('#upd-later').textContent = 'Later';
    m.classList.add('show');
  }
  function hide() { const m = $('#update-modal'); if (m) m.classList.remove('show'); }
  const exec = (cmd, args) => new Promise((res, rej) => cp.execFile(cmd, args, { windowsHide: true, maxBuffer: 1 << 24 }, (e, so, se) => e ? rej(new Error((se || so || String(e)).trim().slice(0, 300))) : res(String(so))));
  async function install(info) {
    if (!CS.inCEP || !cp || !CS.fs) { toast('Updates install from inside Premiere Pro.', 'err'); return; }
    const go = $('#upd-go'), bar = $('#upd-bar'), txt = $('#upd-text');
    go.disabled = true; go.textContent = 'Updating…'; $('#upd-later').style.display = 'none'; bar.parentElement.style.display = '';
    try {
      const dir = CS.dataDir('updates');
      /* version.json carries a second package for the Mac (forward slashes in the zip, an Install.command inside) */
      const pkg = (CS.mac && info.mac && info.mac.url) ? info.mac : info;
      const zip = CS.path.join(dir, 'OutflowStudio-' + info.version + '.zip');
      await Net.download(pkg.url, zip, (p) => { if (p >= 0) bar.style.width = Math.round(p * 70) + '%'; txt.textContent = 'Downloading ' + info.version + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : ''); });
      const tar = CS.tar();
      txt.textContent = 'Checking the download'; bar.style.width = '75%';
      const list = await exec(tar, ['-tf', zip]);
      if (!/OutflowStudio\/CSXS\/manifest\.xml/.test(list.replace(/\\/g, '/'))) throw new Error('The download is not an Outflow Studio package.');
      if (pkg.sha256 && nodeReq) { const h = nodeReq('crypto').createHash('sha256').update(CS.fs.readFileSync(zip)).digest('hex'); if (h !== pkg.sha256) throw new Error('The download is damaged (checksum mismatch). Try again.'); }
      const dest = CS.extensionDir();
      if (!dest || !CS.fs.existsSync(CS.path.join(dest, 'CSXS', 'manifest.xml'))) throw new Error('Cannot find the extension folder to update (' + dest + ').');
      txt.textContent = 'Installing'; bar.style.width = '85%';
      await exec(tar, ['-xf', zip, '-C', dest, '--strip-components=1']);
      try { CS.fs.unlinkSync(zip); } catch (e) {}
      st.installed = info.version; st.dismissed = ''; save();
      bar.style.width = '100%';
      $('#upd-title').textContent = 'Updated to ' + info.version;
      $('#upd-sub').textContent = 'Restart Premiere Pro to start using it. Everything you had stays as it was.';
      $('#upd-list').innerHTML = ''; txt.textContent = '';
      go.style.display = 'none'; $('#upd-later').style.display = ''; $('#upd-later').textContent = 'Close';
    } catch (e) {
      const msg = e.message || String(e);
      txt.textContent = msg; bar.style.width = '0%';
      go.disabled = false; go.textContent = 'Try again'; $('#upd-later').style.display = '';
      /* the one error that never went through a toast: a Report button here too, with the message filled in */
      if (typeof BugReport !== 'undefined') {
        let rep = $('#upd-report');
        if (!rep) { rep = document.createElement('button'); rep.className = 'ghost'; rep.id = 'upd-report'; rep.textContent = 'Report'; $('#update-modal .ubtns').appendChild(rep); }
        rep.style.display = '';
        rep.onclick = () => { hide(); BugReport.open('update', 'Update to ' + info.version + ' failed: ' + msg); };
      }
    }
  }
  function setChannel(c) { st.channel = c === 'beta' ? 'beta' : 'stable'; st.dismissed = ''; save(); }
  function init() {
    const go = $('#upd-go'), later = $('#upd-later');
    if (go) go.addEventListener('click', () => { if (pending) install(pending); });
    if (later) later.addEventListener('click', () => { if (pending && later.textContent === 'Later') { st.dismissed = pending.version; st.dismissedAt = Date.now(); save(); } hide(); });
    /* after a restart the new version runs: clear the "restart needed" note; otherwise remind */
    if (st.installed) { if (cmp(st.installed, version()) <= 0) { st.installed = ''; save(); } else setTimeout(() => toast('Update ' + st.installed + ' is installed. Restart Premiere Pro to use it.', ''), 2500); }
    if (CS.inCEP && Date.now() - (st.last || 0) > 20 * 3600 * 1000) setTimeout(() => check(), 4000);
  }
  return { init, check, install, setChannel, channel: () => st.channel, version, cmp };
})();
