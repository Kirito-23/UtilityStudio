/*  Zoom Montage: pick clips from the Project panel, choose the piece of each one you want, and drop the lot on the
    timeline back to back with a zoom on every cut.

    The picker is a filmstrip of the whole source with a window over it. The window's width is the clip length, so
    there is one thing to drag instead of two handles, and changing the length resizes every window in place.
    Filmstrips come from one ffmpeg pass per source and are cached on disk: seeking a <video> per drag is far too
    slow on 4K footage (measured while building the exporter).                                                      */
const Montage = (() => {
  const $ = (s) => document.querySelector(s);
  const nodeReq = (typeof window !== 'undefined' && window.cep_node) ? window.cep_node.require : (typeof require === 'function' ? require : null);
  const cp = nodeReq ? nodeReq('child_process') : null;
  const KEY = 'os.montage';
  const TILES = 24;            /* frames in a filmstrip */
  const STRIP_H = 54;          /* their height in pixels */

  /* the curves on offer. Two control points each, the same shapes Motion Curves uses. */
  const CURVES = {
    quadInOut: { name: 'Smooth (ease in and out)', b: [0.45, 0, 0.55, 1], interp: 1 },
    expoOut: { name: 'Snappy (fast, then settles)', b: [0.16, 1, 0.3, 1] },
    backOut: { name: 'Overshoot', b: [0.34, 1.56, 0.64, 1] },
    cubicIn: { name: 'Slow start', b: [0.32, 0, 0.67, 0] },
    linear: { name: 'Linear', b: [0.25, 0.25, 0.75, 0.75], interp: 0 }
  };
  /* y for a given x on a cubic bezier from (0,0) to (1,1), by bisection: exact enough and short */
  const curveFn = (b) => {
    const cx = (t, a, c) => 3 * a * t * (1 - t) * (1 - t) + 3 * c * t * t * (1 - t) + t * t * t;
    return (x) => {
      if (x <= 0) return 0; if (x >= 1) return 1;
      let lo = 0, hi = 1, t = x;
      for (let i = 0; i < 24; i++) { const v = cx(t, b[0], b[2]); if (v < x) lo = t; else hi = t; t = (lo + hi) / 2; }
      return cx(t, b[1], b[3]);
    };
  };

  /* how much a moment must stand out, in plain terms rather than a number */
  const STRENGTH = {
    strong: { name: 'Only the strong beats', frac: 0.55, gap: 0.42 },
    normal: { name: 'Normal', frac: 0.42, gap: 0.26 },
    all: { name: 'Every little hit', frac: 0.08, gap: 0.15 }
  };

  const st = {
    rows: [],            /* { path, name, dur, fps, strip, in } */
    sel: 0,
    frames: 3,
    from: 200, to: 100,
    curve: 'quadInOut',
    shutter: 200,
    mode: 'transform',   /* transform = on the clip · adjustment = on a layer above */
    audio: true,
    hold: 0,             /* frames at the end that sit still, taken out of the clip's length */
    beat: false,         /* let the music decide where the cuts fall instead of a fixed length */
    btrack: -1,          /* which audio track to listen to, -1 = the whole mix, -2 = the selected audio clip only */
    strength: 'normal',   /* how much a moment has to stand out before it counts as a beat */
    every: 1,            /* use every beat, every 2nd, every 4th */
    repeat: false,       /* when the music outlasts the clips, start again at clip 1 */
    keepEnd: false,      /* clips taken off the timeline keep the length they had there */
    plan: null,          /* seconds per clip once the beats have been found */
    last: null           /* what the last Apply put on the timeline, so Revert can take it away */
  };
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ frames: st.frames, from: st.from, to: st.to, curve: st.curve, shutter: st.shutter, mode: st.mode, audio: st.audio, hold: st.hold, beat: st.beat, btrack: st.btrack, strength: st.strength, every: st.every, repeat: st.repeat, keepEnd: st.keepEnd })); } catch (e) {} };
  (() => { try { Object.assign(st, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) {} st.plan = null; })();

  const fpsOf = (r) => r.fps || st.seqFps || 25;        /* the source's own rate, for reading it */
  const seqFps = () => st.seqFps || 25;                 /* the sequence's rate, which is what a 'frame' means here */
  const lenSec = () => st.frames / seqFps();
  const exists = (p) => { try { return CS.fs.existsSync(p); } catch (e) { return false; } };
  const cacheDir = () => CS.dataDir('montage');
  const hash = (s) => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(36); };

  /* duration and frame rate, straight from ffprobe */
  function probe(file, ffmpeg) {
    const out = { dur: 0, fps: 25, w: 0, h: 0 };
    try {
      const pr = CS.path.join(CS.path.dirname(ffmpeg), CS.bin('ffprobe'));
      if (!exists(pr)) return out;
      const r = cp.spawnSync(pr, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,r_frame_rate,duration:format=duration', '-of', 'default=nw=1:nk=1', file], { encoding: 'utf8', windowsHide: true });
      const lines = String(r.stdout || '').trim().split(/\r?\n/);
      const plain = [];
      for (const l of lines) {
        if (/^\d+\/\d+$/.test(l)) { const [a, b] = l.split('/').map(Number); if (a > 0) out.fps = b ? a / b : a; }
        else { const v = parseFloat(l); if (!isNaN(v)) plain.push(v); }
      }
      /* width and height come first, then the durations */
      if (plain.length >= 2 && plain[0] >= 16 && plain[1] >= 16) { out.w = plain[0]; out.h = plain[1]; }
      for (const v of plain.slice(out.w ? 2 : 0)) if (v > 0 && !out.dur) out.dur = v;
    } catch (e) {}
    return out;
  }

  /* one filmstrip per source, made once and kept */
  function strip(file, dur, ffmpeg) {
    const f = CS.path.join(cacheDir(), hash(file + '|' + dur) + '.jpg');
    if (exists(f)) return f;
    try {
      const rate = TILES / Math.max(0.4, dur);
      cp.spawnSync(ffmpeg, ['-v', 'error', '-i', file, '-vf', 'fps=' + rate.toFixed(4) + ',scale=-1:' + STRIP_H + ',tile=' + TILES + 'x1', '-frames:v', '1', '-y', f], { windowsHide: true, timeout: 60000 });
    } catch (e) {}
    return exists(f) ? f : '';
  }

  async function ffmpegPath() {
    let ff = null;
    try { ff = Social.ffmpeg(); } catch (e) {}
    if (!ff) { try { await Social.installFfmpeg((q, m) => busy(m || 'Getting the video engine')); ff = Social.ffmpeg(); } catch (e) {} }
    if (!ff) throw new Error('The video engine is missing. Open Download media once to install it.');
    return ff;
  }

  const busy = (m) => { const el = $('#mg-note'); if (el) { el.textContent = m || ''; el.className = 'hint' + (m ? ' on' : ''); } };

  /* ---------- taking clips in ---------- */
  const probed = {};   /* path -> what ffprobe said, so ten pieces of one file are read once */
  async function add(specs) {
    specs = specs.map((s) => (typeof s === 'string' ? { path: s } : s));
    if (!specs.length) return;
    const ff = await ffmpegPath();
    let added = 0; const skipped = [];
    for (const sp of specs) {
      const p = sp.path;
      const isStill = /\.(jpg|jpeg|png|gif|bmp|tif|tiff|webp|psd|tga)$/i.test(p);
      if (!isStill && !/\.(mp4|mov|m4v|avi|mkv|mxf|webm|wmv|mpg|mpeg|mts|m2ts)$/i.test(p)) { skipped.push(CS.path.basename(p) + ' (not video or an image)'); continue; }
      if (isStill) {
        /* a still has no timeline of its own: nothing to scrub, it just holds for the chosen length */
        const sr = { path: p, name: CS.path.basename(p), dur: 0, fps: 0, strip: p, still: true, in: 0, w: 0, h: 0 };
        st.rows.push(sr); added++;
        /* a very large photo is exactly what makes Transform run out of buffer, so measure it */
        try {
          const im = new Image();
          im.onload = () => { sr.w = im.naturalWidth; sr.h = im.naturalHeight; };
          im.src = 'file:///' + String(p).replace(/\\/g, '/');
        } catch (e) {}
        continue;
      }
      let info = probed[p];
      if (!info) {
        busy('Reading ' + CS.path.basename(p));
        const pr = probe(p, ff);
        if (!pr.dur) { skipped.push(CS.path.basename(p) + ' (could not be read)'); continue; }
        info = probed[p] = { dur: pr.dur, fps: pr.fps, w: pr.w, h: pr.h, strip: strip(p, pr.dur, ff) };
      }
      const row = { path: p, name: CS.path.basename(p), dur: info.dur, fps: info.fps, w: info.w, h: info.h, strip: info.strip, still: false, in: 0, own: sp.own > 0.02 ? sp.own : 0 };
      const len = Math.min(lenSec(), row.dur);
      /* a clip taken off the timeline opens on the piece that was selected; anything else opens in the middle */
      const want = sp.at != null ? sp.at : row.dur / 2 - len / 2;
      row.in = Math.max(0, Math.min(Math.max(0, row.dur - len), want));
      st.rows.push(row); added++;
    }
    busy('');
    if (!added) { toast('Nothing usable in that selection' + (skipped.length ? ': ' + skipped[0] : '') + '.', 'err'); return; }
    dropPlan();
    if (skipped.length) toast('Added ' + added + ' · left out ' + skipped.length + ': ' + skipped.slice(0, 2).join(', ') + (skipped.length > 2 ? '…' : ''));
    st.sel = st.rows.length - 1;
    render();
  }
  async function fromProject() {
    try { const items = await Exporter.projectSelection(); if (!items.length) { toast('Select clips in the Project panel first, then click again.'); return; } await add(items.map((i) => i.path)); }
    catch (e) { busy(''); toast(e.message, 'err'); }
  }
  async function fromTimeline() {
    try {
      const clips = await Exporter.timelineSelection();
      if (!clips.length) { toast('Select clips in the timeline first, then click again.'); return; }
      const inOrder = clips.slice().sort((a, b) => (a.start || 0) - (b.start || 0));
      await add(inOrder.map((c) => ({ path: c.path, at: c.inPoint, own: Math.max(0, (c.outPoint || 0) - (c.inPoint || 0)) })));
    } catch (e) { busy(''); toast(e.message, 'err'); }
  }

  /* ---------- the strip of chosen clips ---------- */
  function renderThumbs() {
    const box = $('#mg-thumbs'); if (!box) return;
    box.innerHTML = '';
    st.rows.forEach((r, i) => {
      const t = document.createElement('div');
      t.className = 'thumb mg-th' + (i === st.sel ? ' on' : '');
      t.draggable = true; t.dataset.i = String(i); t.title = r.name;
      t.innerHTML = (r.strip ? '<img src="file:///' + r.strip.replace(/\\/g, '/') + '">' : '') +
        '<div class="num">' + String(i + 1).padStart(2, '0') + '</div><button class="x" title="Remove">✕</button>';
      t.addEventListener('click', () => { st.sel = i; render(); });
      t.querySelector('.x').addEventListener('click', (e) => { e.stopPropagation(); st.rows.splice(i, 1); if (st.sel >= st.rows.length) st.sel = st.rows.length - 1; dropPlan(); render(); });
      t.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', String(i)); t.classList.add('dragging'); });
      t.addEventListener('dragend', () => t.classList.remove('dragging'));
      t.addEventListener('dragover', (e) => e.preventDefault());
      t.addEventListener('drop', (e) => {
        e.preventDefault(); const from = +e.dataTransfer.getData('text/plain');
        if (isNaN(from) || from === i) return;
        const [m] = st.rows.splice(from, 1); st.rows.splice(i, 0, m); st.sel = i; render();
      });
      box.appendChild(t);
    });
  }

  /* ---------- the preview and the window over the filmstrip ---------- */
  /* The drag listeners live on window and are registered once: re-registering them per render leaked them and let an
     old closure keep dragging a clip the user had already moved on from. */
  let live = null;   /* { row, strip, win, place, video } for the picker currently on screen */
  let drag = null;   /* { x, in, w } while the mouse is down */
  /* Which row a placed clip uses. With repeat on, the clips cycle for as long as the beats last. */
  const rowAt = (i) => st.rows.length ? st.rows[st.repeat ? i % st.rows.length : i] : null;
  /* How many clips will land: the beat plan decides when there is one, otherwise one per row. */
  const placedCount = () => (st.plan ? st.plan.length : st.rows.length);
  /* How long clip i runs for. The beat plan wins; then the length it had on the timeline; then the fixed length. */
  const durFor = (i, r) => {
    r = r || rowAt(i);
    const p = st.plan && st.plan[i];
    if (p) return r && !r.still ? Math.min(p, r.dur) : p;
    if (st.keepEnd && r && r.own > 0) return r.still ? r.own : Math.min(r.own, r.dur);
    return r && !r.still ? Math.min(lenSec(), r.dur) : lenSec();
  };
  const winLen = (r, i) => r.still ? 0 : durFor(i == null ? st.sel : i, r);
  const dropPlan = () => { if (st.plan || st.wave) { try { stopWave(); } catch (e) {} st.plan = null; st.wave = null; st.cuts = null; st.view = null; st.planStart = null; st.planShift = 0; drawWave(); const s = $('#mg-beat-sum'); if (s) s.textContent = 'The clips changed \u2014 find the beats again.'; } };
  const onMove = (e) => {
    if (!drag || !live) return;
    const r = live.row, len = winLen(r, st.sel);
    const d = (e.clientX - drag.x) / drag.w * r.dur;
    r.in = Math.max(0, Math.min(Math.max(0, r.dur - len), drag.in + d));
    live.place();
    if (live.video) { try { live.video.currentTime = r.in; } catch (err) {} }   /* the preview follows the drag */
  };
  const onUp = () => { if (!drag) return; drag = null; if (live) live.win.classList.remove('dragging'); };
  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);

  /* keep the preview inside the chosen window while it plays */
  function loopGuard(v, r) {
    const stop = () => { const len = winLen(r, st.sel); if (v.currentTime >= r.in + len || v.currentTime < r.in - 0.05) { try { v.currentTime = r.in; } catch (e) {} } };
    v.addEventListener('timeupdate', () => { stop(); paint(); });
  }
  function paint() {
    if (!live || !live.video) return;
    const r = live.row, len = winLen(r, st.sel), v = live.video;
    const at = Math.max(0, Math.min(1, len ? (v.currentTime - r.in) / len : 0));
    const bar = $('#mg-prog-in'); if (bar) bar.style.width = (at * 100) + '%';
    const t = $('#mg-ptime'); if (t) t.textContent = fmt(Math.max(0, v.currentTime - r.in)) + ' / ' + fmt(len);
  }

  function renderPicker() {
    const wrap = $('#mg-picker'); if (!wrap) return;
    const r = st.rows[st.sel];
    live = null; drag = null;
    if (!r) { wrap.innerHTML = '<div class="kbd">Add clips above, then drag the window to pick the moment each one shows.</div>'; return; }
    const url = 'file:///' + String(r.path).replace(/\\/g, '/');
    const stripUrl = r.strip ? 'file:///' + String(r.strip).replace(/\\/g, '/') : '';

    wrap.innerHTML =
      '<div class="mg-prev">' +
        (r.still ? '<img src="' + url + '" alt="">'
                 : '<video id="mg-video" src="' + url + '" preload="metadata" muted playsinline></video>') +
      '</div>' +
      (r.still ? '' :
      '<div class="mg-prev-bar"><button class="ghost" id="mg-play" title="Play the selection">\u25b6</button>' +
        '<div class="mg-prog" id="mg-prog"><i id="mg-prog-in"></i></div><span id="mg-ptime"></span></div>') +
      (r.still ? '<div class="mg-strip-foot"><span>' + r.name + '</span><span>still \u00b7 holds for ' + st.frames + ' frames</span></div>'
               :
      '<div class="mg-strip" id="mg-strip">' +
        (stripUrl ? '<img src="' + stripUrl + '" draggable="false">' : '<div class="mg-nostrip">no preview</div>') +
        '<div class="mg-win" id="mg-win"><i class="l"></i><i class="r"></i></div>' +
      '</div>' +
      '<div class="mg-strip-foot"><span>' + r.name + '</span><span id="mg-at"></span></div>');

    /* the preview is only as wide as the media is tall: a vertical clip must not sit in a letterboxed 16:9 box */
    const shape = (ratio) => {
      const box = wrap.querySelector('.mg-prev'); if (!box || !ratio) return;
      const cap = 190, w = wrap.clientWidth || 320;
      const h = Math.min(cap, w / ratio);
      box.style.width = Math.round(h * ratio) + 'px';
      box.style.height = Math.round(h) + 'px';
    };
    if (r.still) {
      const im = wrap.querySelector('.mg-prev img');
      if (im) im.addEventListener('load', () => { if (im.naturalWidth) shape(im.naturalWidth / im.naturalHeight); });
      return;
    }

    const stripEl = $('#mg-strip'), win = $('#mg-win'), video = $('#mg-video');
    const place = () => {
      const w = stripEl.clientWidth || 1, len = winLen(r, st.sel);
      /* read the length every time, so dragging the Length slider resizes the window as it moves */
      win.style.width = Math.max(8, Math.min(1, len / r.dur) * w) + 'px';
      r.in = Math.max(0, Math.min(Math.max(0, r.dur - len), r.in));
      win.style.left = (r.in / r.dur) * w + 'px';
      const at = $('#mg-at');
      if (at) at.textContent = fmt(r.in) + ' \u2192 ' + fmt(r.in + len) + ' \u00b7 ' + st.frames + ' of ' + fmt(r.dur);
      paint();
    };
    live = { row: r, strip: stripEl, win: win, place: place, video: video };
    place();

    if (video) {
      video.addEventListener('loadedmetadata', () => {
        try { video.currentTime = r.in; } catch (e) {}
        if (video.videoWidth && video.videoHeight) shape(video.videoWidth / video.videoHeight);
        paint();
      });
      loopGuard(video, r);
      video.addEventListener('play', () => { const b = $('#mg-play'); if (b) b.textContent = '\u23f8'; });
      video.addEventListener('pause', () => { const b = $('#mg-play'); if (b) b.textContent = '\u25b6'; });
      $('#mg-play').addEventListener('click', () => {
        if (video.paused) { try { if (video.currentTime < r.in || video.currentTime > r.in + winLen(r, st.sel)) video.currentTime = r.in; } catch (e) {} video.play(); }
        else video.pause();
      });
      $('#mg-prog').addEventListener('click', (e) => {
        const box = e.currentTarget.getBoundingClientRect();
        try { video.currentTime = r.in + Math.max(0, Math.min(1, (e.clientX - box.left) / box.width)) * winLen(r, st.sel); } catch (err) {}
        paint();
      });
    }

    const grab = (e) => { drag = { x: e.clientX, in: r.in, w: stripEl.clientWidth || 1 }; win.classList.add('dragging'); e.preventDefault(); };
    win.addEventListener('mousedown', grab);
    stripEl.addEventListener('mousedown', (e) => {   /* click anywhere on the strip to bring the window there */
      if (e.target === win || win.contains(e.target)) return;
      const w = stripEl.clientWidth || 1, len = winLen(r, st.sel), x = e.clientX - stripEl.getBoundingClientRect().left;
      r.in = Math.max(0, Math.min(Math.max(0, r.dur - len), (x / w) * r.dur - len / 2));
      place(); if (video) { try { video.currentTime = r.in; } catch (err) {} }
      grab(e);
    });
  }
  const fmt = (s) => { const m = Math.floor(s / 60), x = s - m * 60; return (m ? m + ':' + (x < 10 ? '0' : '') : '') + x.toFixed(m ? 1 : 2) + (m ? '' : 's'); };

  function sum() {
    const n = placedCount();
    let total = 0;
    for (let i = 0; i < n; i++) total += durFor(i);
    const el = $('#mg-sum');
    if (el) el.textContent = st.rows.length ? n + ' clip' + (n === 1 ? '' : 's') + ' · ' + total.toFixed(2) + 's on the timeline' +
      (st.repeat && st.plan && n > st.rows.length ? ' (' + st.rows.length + ' repeated)' : '') : 'Nothing added yet';
    const go = $('#mg-apply'); if (go) go.disabled = !n;
    const rev = $('#mg-revert'); if (rev) rev.style.display = st.last ? '' : 'none';
  }
  function render() { renderThumbs(); renderPicker(); sum(); }

  /* ---------- letting the music decide ---------- */
  /* Same detection as Beat Markers: the loudness envelope, its rise from one window to the next, and the peaks of
     that above a threshold the sensitivity slider moves. It listens from the playhead forward, and only for as long
     as the montage could possibly need, so a five minute song is not exported to analyse a four second montage. */
  async function findBeats(quiet) {
    if (!CS.inCEP) throw new Error('Beat detection runs inside Premiere Pro.');
    if (!st.rows.length) throw new Error('Add some clips first.');
    const info = await CS.call('AS_range');
    if (!info || !info.ok) throw new Error((info && info.error) || 'Open a sequence first.');
    if (info.fps > 0) st.seqFps = info.fps;
    /* The music itself: the audio clip you selected, else whatever plays under the playhead. Listening to exactly
       that stretch is the point - a trimmed clip must not be analysed beyond where it actually plays, and with
       repeat on it is what tells the montage when to stop. */
    let music = null;
    try {
      const m = await CS.call('MG_musicRange', JSON.stringify({ track: st.btrack >= 0 ? st.btrack : -1, selectedOnly: st.btrack === -2 }));
      if (m && m.ok && m.found) music = m;
    } catch (e) {}
    if (st.btrack === -2 && !music) throw new Error('Select the music clip in the timeline first (Music track is set to "Selected clip").');
    st.music = music;

    /* A clip you went and selected is a clearer instruction than wherever the playhead happens to be sitting, so the
       montage starts where that clip starts. Only when the music was found by the playhead does the playhead lead. */
    const from = music && music.how === 'selection'
      ? music.start
      : Math.max(info.playhead || 0, music ? music.start : 0);
    const seqEnd = music ? music.end : (info.duration || 0);
    if (seqEnd - from < 0.5) throw new Error(music
      ? 'The playhead is past the end of that music clip.'
      : 'There is no audio after the playhead to listen to.');

    /* how much to listen to. Never past the end of the music. Without repeat we only need one beat per clip, so a few
       seconds each is plenty; with repeat the music decides when it ends, so take the lot. */
    const want = st.repeat ? (seqEnd - from) : Math.max(12, st.rows.length * lenSec() * 8);
    let span = Math.min(seqEnd - from, Math.min(240, want));
    let used = [], env = null, win = 0, wav = '';

    for (let attempt = 0; attempt < 2; attempt++) {
      if (!quiet) busy('Listening to the music' + (attempt ? ' (a bit further)' : '') + '\u2026');
      const solo = st.btrack >= 0 ? [st.btrack] : (music ? [music.track] : null);
      const a = await AudioTool.exportRange(from, from + span, solo, 'montage');
      env = a.env; win = a.win; wav = a.file || '';
      if (!env || !env.length) throw new Error('That track has no sound in it.');
      /* A beat is a moment that stands out from the music AROUND it. The old threshold was a percentile of the
         whole flux distribution, which always marks the same PROPORTION of the audio however quiet it is - so a
         still passage got cuts anyway. This asks something harder: rise sharply against the local average, and be
         somewhere the music is actually playing. */
      const flux = new Float32Array(env.length);
      for (let i = 1; i < env.length; i++) flux[i] = Math.max(0, env[i] - env[i - 1]);

      const ps = new Float64Array(flux.length + 1);
      for (let i = 0; i < flux.length; i++) ps[i + 1] = ps[i] + flux[i];
      const half = Math.max(1, Math.round(0.4 / win));          /* the neighbourhood a peak is judged against */
      const localMean = (i) => {
        const a = Math.max(0, i - half), b = Math.min(flux.length, i + half + 1);
        return (ps[b] - ps[a]) / Math.max(1, b - a);
      };
      let eLo = Infinity, eHi = -Infinity;
      for (let i = 0; i < env.length; i++) { if (env[i] < eLo) eLo = env[i]; if (env[i] > eHi) eHi = env[i]; }
      const eRange = Math.max(1e-6, eHi - eLo);
      const quietFloor = eLo + eRange * 0.12;                   /* below this the music is not really playing */
      const S = STRENGTH[st.strength] || STRENGTH.normal;

      /* every moment that rises above its neighbours while the music is playing */
      const cand = [];
      for (let i = 1; i < flux.length - 1; i++) {
        if (flux[i] < flux[i - 1] || flux[i] < flux[i + 1]) continue;       /* not a peak */
        if (env[i] < quietFloor) continue;                                  /* nothing is playing here */
        if (flux[i] < localMean(i) * 1.15 + eRange * 0.01) continue;        /* does not stand out from its neighbours */
        cand.push({ at: from + i * win, v: flux[i] });
      }
      /* then judge them against how hard this music hits, not against a fixed number: the loudest hits set the scale,
         and the choice says how far down from those to go. */
      const heights = cand.map((c) => c.v).sort((x, y) => x - y);
      const loud = heights[Math.floor(heights.length * 0.9)] || 1;
      const need = loud * S.frac;

      const strongEnough = cand.filter((c) => c.v >= need);

      /* How fast is this music? The typical distance between the hits that got through is the beat, and nothing
         closer than most of that is a beat: it is a sub-division, or the attack of the same hit picked up twice.
         Without this a track came back with beats 2 frames apart, which is 375 to the minute. */
      const raw = [];
      for (let i = 1; i < strongEnough.length; i++) raw.push(strongEnough[i].at - strongEnough[i - 1].at);
      raw.sort((x, y) => x - y);
      const typical = raw.length ? raw[Math.floor(raw.length / 2)] : 0;
      const minGap = Math.max(S.gap, typical * 0.62);

      const keep = [];
      for (const c of strongEnough) {
        const prev = keep[keep.length - 1];
        if (prev && c.at - prev.at < minGap) { if (c.v > prev.v) keep[keep.length - 1] = c; continue; }
        keep.push(c);
      }
      const beats = keep.map((c) => c.at);
      used = beats.filter((_, i) => i % Math.max(1, st.every) === 0);
      const enough = st.repeat ? used.length > 2 : used.length > st.rows.length;
      if (enough || span >= Math.min(240, seqEnd - from) - 0.01) break;
      span = Math.min(seqEnd - from, Math.min(240, span * 2.5));
    }
    busy('');
    if (used.length < 2) throw new Error('No beats found. Raise the sensitivity, or pick the track the music is on.');

    /* Where the run starts. The playhead is rarely sitting on a beat, so a run beginning there would open with a stub
       clip of whatever was left before the first beat. When that stub is less than most of a beat, the montage starts
       ON the first beat instead: it moves by under one beat, and every clip then gets its full length. */
    const fps = seqFps();
    const gaps = [];
    for (let i = 1; i < used.length; i++) gaps.push(used[i] - used[i - 1]);
    gaps.sort((x, y) => x - y);
    const median = gaps[Math.floor(gaps.length / 2)] || 0.5;
    const onBeat = (used[0] - from) < median * 0.75;
    const raw = onBeat ? used.slice() : [from].concat(used);

    /* From here the cuts are what matter, not the beats: they are what the montage is built from and what the user
       can drag, remove and add on the waveform. Snapped to whole frames, because Premiere would snap them anyway. */
    st.wave = { env: env, win: win, from: from, to: from + span, file: wav };
    st.cuts = raw.map((c) => Math.round(c * fps) / fps).filter((c, k, a) => k === 0 || c > a[k - 1]);
    st.beatsFound = used.length;
    st.musicEnd = seqEnd;
    planFromCuts();
    st.view = null; st.playFrom = null; st.playAt = null;   /* a fresh analysis starts over */
    fitView();
    drawWave();
    render();
    return st.plan;
  }

  /* The clips follow the cuts. Anything that changes a cut comes back through here. */
  function planFromCuts() {
    const fps = seqFps(), c = st.cuts;
    if (!c || c.length < 2 || !st.rows.length) { st.plan = null; return; }
    const room = c.length - 1;
    const count = Math.min(room, st.repeat ? 400 : st.rows.length);
    const plan = [];
    for (let i = 0; i < count; i++) plan.push(Math.max(1, Math.round(c[i + 1] * fps) - Math.round(c[i] * fps)) / fps);
    st.plan = plan.length ? plan : null;
    st.planStart = c[0];
    st.planShift = 0;
    summarise();
  }

  function summarise() {
    const el = $('#mg-beat-sum'); if (!el) return;
    if (!st.plan) { el.textContent = 'No cuts yet.'; return; }
    const fps = seqFps(), m = st.music;
    const fr = st.plan.map((d) => Math.round(d * fps));
    const shortOf = !st.repeat && st.plan.length < st.rows.length;
    el.textContent = (m ? '\u201c' + m.name + '\u201d on A' + (m.track + 1) + ' \u00b7 ' : '') +
      (st.beatsFound || st.cuts.length) + ' beats found \u00b7 ' + st.plan.length + ' clip' + (st.plan.length === 1 ? '' : 's') +
      ' \u00b7 ' + Math.min.apply(null, fr) + '\u2013' + Math.max.apply(null, fr) + ' frames each' +
      (shortOf ? ' \u00b7 the music ran out, the last ' + (st.rows.length - st.plan.length) + ' keep the fixed length' : '');
  }

  /* the visible stretch of the waveform: the montage, plus a little air */
  function fitView() {
    if (!st.wave) { st.view = null; return; }
    const w = st.wave;
    let end = st.cuts.length ? st.cuts[0] : w.from;
    for (const d of (st.plan || [])) end += d;
    if (end <= st.cuts[0] + 0.01) end = w.to;
    /* a short montage on its own is a keyhole: show at least a few seconds of the music around it, so the cuts can
       be read against the track they came from */
    const mid = (st.cuts[0] + end) / 2;
    const want = Math.min(w.to - w.from, Math.max(4, (end - st.cuts[0]) * 1.35));
    let a = mid - want / 2, b = a + want;
    if (a < w.from) { a = w.from; b = a + want; }
    if (b > w.to) { b = w.to; a = Math.max(w.from, b - want); }
    st.view = [a, b];
  }

  /* The music, the cut lines, and which clip lands between them. The lines can be dragged, removed and added, and
     the view scrolls and zooms, so this draws from st.view rather than the montage's own extent. */
  function drawWave() {
    const cv = $('#mg-wave'); if (!cv) return;
    const w = st.wave;
    cv.classList.toggle('off', !w);
    const hint = $('#mg-wave-hint'); if (hint) hint.style.display = w ? '' : 'none';
    const bar = $('#mg-wave-bar'); if (bar) bar.style.display = w ? '' : 'none';
    if (!w) return;
    if (!st.view) fitView();
    const cssW = cv.clientWidth || 300, cssH = cv.clientHeight || 86;
    const dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(cssW * dpr); cv.height = Math.round(cssH * dpr);
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, cssW, cssH);

    const v0 = st.view[0], v1 = st.view[1], span = Math.max(0.001, v1 - v0);
    const x = (sec) => ((sec - v0) / span) * cssW;
    const i0 = Math.max(0, Math.floor((v0 - w.from) / w.win));
    const i1 = Math.min(w.env.length - 1, Math.ceil((v1 - w.from) / w.win));
    let lo = Infinity, hi = -Infinity;
    for (let i = i0; i <= i1; i++) { const v = w.env[i]; if (v < lo) lo = v; if (v > hi) hi = v; }
    if (!(hi > lo)) { lo = 0; hi = 1; }

    /* which clip is sounding right now, so its stretch of music can be lit up */
    let liveA = null, liveB = null, liveI = -1;
    if (st.playAt != null && st.cuts) {
      for (let i = 0; i < st.cuts.length - 1; i++) {
        if (st.playAt >= st.cuts[i] && st.playAt < st.cuts[i + 1]) { liveA = st.cuts[i]; liveB = st.cuts[i + 1]; liveI = i; break; }
      }
    }
    if (liveA != null) {
      g.fillStyle = 'rgba(255,255,255,.07)';
      g.fillRect(x(liveA), 0, Math.max(1, x(liveB) - x(liveA)), cssH);
    }

    const mid = cssH / 2;
    for (let px = 0; px < cssW; px++) {
      const a = v0 + (px / cssW) * span, b = v0 + ((px + 1) / cssW) * span;
      let peak = lo;
      const ja = Math.max(i0, Math.floor((a - w.from) / w.win)), jb = Math.min(i1, Math.ceil((b - w.from) / w.win));
      for (let j = ja; j <= jb; j++) if (w.env[j] > peak) peak = w.env[j];
      const hgt = Math.max(1, ((peak - lo) / (hi - lo)) * (cssH * 0.42));
      const inLive = liveA != null && a >= liveA && a < liveB;
      g.fillStyle = inLive ? 'rgba(196,216,255,.95)' : 'rgba(120,150,200,.55)';
      g.fillRect(px, mid - hgt, 1, hgt * 2);
    }

    g.font = '600 10px Inter, system-ui, sans-serif';
    g.textBaseline = 'top';
    const cuts = st.cuts || [];
    const used = st.plan ? st.plan.length + 1 : cuts.length;
    for (let i = 0; i < cuts.length; i++) {
      if (cuts[i] < v0 - 0.05 || cuts[i] > v1 + 0.05) continue;
      const px = Math.round(x(cuts[i])) + 0.5;
      const live = i < used;                       /* cuts past the last clip are drawn faintly */
      const held = st.dragCut === i, sounding = i === liveI;
      g.strokeStyle = held || sounding ? '#fff' : i === 0 ? 'rgba(255,255,255,.85)' : live ? 'rgba(79,141,255,.95)' : 'rgba(120,140,170,.35)';
      g.lineWidth = held || sounding ? 2 : 1;
      g.beginPath(); g.moveTo(px, 0); g.lineTo(px, cssH); g.stroke();
      g.lineWidth = 1;
      if (i < cuts.length - 1 && live && i < used - 1) {
        const nx = x(cuts[i + 1]), r = rowAt(i);
        if (nx - px > 13 && r) {
          g.fillStyle = 'rgba(255,255,255,.75)';
          g.fillText(String(st.rows.indexOf(r) + 1), px + 3, 3);
        }
      }
    }
    if (st.playAt != null && st.playAt >= v0 && st.playAt <= v1) {
      const px = Math.round(x(st.playAt)) + 0.5;
      g.strokeStyle = '#ffcf4a'; g.lineWidth = 2;
      g.beginPath(); g.moveTo(px, 0); g.lineTo(px, cssH); g.stroke();
      g.lineWidth = 1;
    }

    drawScrub();
  }

  /* The whole analysed stretch as one strip: where the wave is looking, where the playhead is, and a place to click
     to start somewhere else. Clicking the wave itself adds a cut, so starting playback needs its own control. */
  function drawScrub() {
    const el = $('#mg-scrub'); if (!el) return;
    const w = st.wave;
    el.style.display = w ? '' : 'none';
    if (!w) return;
    const tot = Math.max(0.001, w.to - w.from);
    const vw = el.querySelector('.mg-scrub-view'), hd = el.querySelector('.mg-scrub-head');
    if (vw && st.view) {
      vw.style.left = (((st.view[0] - w.from) / tot) * 100) + '%';
      vw.style.width = Math.max(1, ((st.view[1] - st.view[0]) / tot) * 100) + '%';
    }
    const at = st.playAt != null ? st.playAt : st.playFrom;
    if (hd) {
      if (at == null) hd.style.display = 'none';
      else { hd.style.display = ''; hd.style.left = (((at - w.from) / tot) * 100) + '%'; }
    }
  }

  /* Playing the stretch that was analysed. exportRange leaves the wav on disk, so it can just be played back, and
     the line that walks across it is the same time base the cuts are in. */
  let player = null, raf = 0;
  function stopWave() {
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    if (player) { try { player.pause(); } catch (e) {} }
    st.playAt = st.playFrom;
    const b = $('#mg-play-wave'); if (b) b.textContent = '\u25b6 Play';
    const at = $('#mg-wave-at'); if (at) at.textContent = '';
    drawWave();
  }
  function playWave() {
    const w = st.wave;
    if (!w || !w.file) { toast('Find the beats first.'); return; }
    const url = 'file:///' + String(w.file).replace(/\\/g, '/');
    if (!player || player.dataset.src !== url) {
      player = new Audio(url); player.dataset.src = url;
      player.addEventListener('ended', stopWave);
      player.addEventListener('error', () => { stopWave(); toast('Could not play that audio.', 'err'); });
    }
    const startAt = Math.max(0, (st.playFrom != null ? st.playFrom : (st.view ? st.view[0] : w.from)) - w.from);
    try { player.currentTime = startAt; } catch (e) {}
    player.play().then(() => {
      const b = $('#mg-play-wave'); if (b) b.textContent = '\u23f8 Stop';
      const tick = () => {
        if (!player || player.paused) return;
        st.playAt = w.from + player.currentTime;
        /* keep the line on screen without yanking the view about */
        if (st.view && st.playAt > st.view[1] - (st.view[1] - st.view[0]) * 0.12) {
          const len = st.view[1] - st.view[0];
          let a2 = Math.min(w.to - len, st.playAt - len * 0.5);
          st.view = [Math.max(w.from, a2), Math.max(w.from, a2) + len];
        }
        const at = $('#mg-wave-at'); if (at) at.textContent = fmt(st.playAt - w.from) + ' of ' + fmt(w.to - w.from);
        drawWave();
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }).catch(() => { stopWave(); toast('Could not play that audio.', 'err'); });
  }

  /* dragging, adding, removing and zooming on the waveform */
  let waveWired = false;
  function wireWave() {
    const cv = $('#mg-wave'); if (!cv || waveWired) return;
    waveWired = true;
    const fps = () => seqFps();
    const timeAt = (e) => {
      const b = cv.getBoundingClientRect();
      const f = Math.max(0, Math.min(1, (e.clientX - b.left) / Math.max(1, b.width)));
      return st.view[0] + f * (st.view[1] - st.view[0]);
    };
    const nearest = (sec) => {
      let best = -1, bd = 1e9;
      const perPx = (st.view[1] - st.view[0]) / Math.max(1, cv.clientWidth);
      for (let i = 0; i < st.cuts.length; i++) { const d = Math.abs(st.cuts[i] - sec); if (d < bd) { bd = d; best = i; } }
      return bd <= perPx * 6 ? best : -1;
    };
    const snap = (sec) => Math.round(sec * fps()) / fps();
    const commit = () => { st.cuts.sort((a, b) => a - b); planFromCuts(); drawWave(); render(); };

    let mode = null, startX = 0, startView = null;
    cv.addEventListener('mousedown', (e) => {
      if (!st.wave) return;
      e.preventDefault();
      const at = timeAt(e), hit = nearest(at);
      if (hit >= 0) { mode = 'drag'; st.dragCut = hit; }
      else { mode = 'maybe'; startX = e.clientX; startView = st.view.slice(); }
      drawWave();
    });
    window.addEventListener('mousemove', (e) => {
      if (!mode || !st.wave) return;
      if (mode === 'drag') {
        const i = st.dragCut, lo = i > 0 ? st.cuts[i - 1] + 1 / fps() : st.wave.from;
        const hi = i < st.cuts.length - 1 ? st.cuts[i + 1] - 1 / fps() : st.wave.to;
        st.cuts[i] = Math.max(lo, Math.min(hi, snap(timeAt(e))));
        planFromCuts(); drawWave();
      } else if (mode === 'maybe' || mode === 'pan') {
        if (mode === 'maybe' && Math.abs(e.clientX - startX) < 4) return;
        mode = 'pan';
        const perPx = (startView[1] - startView[0]) / Math.max(1, cv.clientWidth);
        let d = -(e.clientX - startX) * perPx;
        const w = st.wave, len = startView[1] - startView[0];
        d = Math.max(w.from - startView[0], Math.min(w.to - startView[1], d));
        st.view = [startView[0] + d, startView[0] + d + len];
        drawWave();
      }
    });
    window.addEventListener('mouseup', (e) => {
      if (!mode) return;
      if (mode === 'maybe' && st.wave) {          /* a click on empty waveform puts a cut there */
        const at = snap(timeAt(e));
        if (at > st.wave.from && at < st.wave.to && !st.cuts.some((c) => Math.abs(c - at) < 0.5 / fps())) st.cuts.push(at);
        commit();
      } else if (mode === 'drag') { st.dragCut = -1; commit(); }
      else { drawWave(); }
      mode = null;
    });
    cv.addEventListener('dblclick', (e) => {      /* double-click a line to take it away */
      if (!st.wave) return;
      e.preventDefault();
      const hit = nearest(timeAt(e));
      if (hit > 0) { st.cuts.splice(hit, 1); commit(); }
      else if (hit === 0) toast('The first line is where the montage starts. Drag it instead.');
    });
    cv.addEventListener('wheel', (e) => {          /* scroll to zoom, around the pointer */
      if (!st.wave) return;
      e.preventDefault();
      const w = st.wave, at = timeAt(e);
      const len = st.view[1] - st.view[0];
      const next = Math.max(0.4, Math.min(w.to - w.from, len * (e.deltaY > 0 ? 1.25 : 0.8)));
      let a = at - (at - st.view[0]) * (next / len), b = a + next;
      if (a < w.from) { a = w.from; b = a + next; }
      if (b > w.to) { b = w.to; a = b - next; }
      st.view = [Math.max(w.from, a), Math.min(w.to, b)];
      drawWave();
    }, { passive: false });
    cv.addEventListener('dragstart', (e) => e.preventDefault());
    const pb = $('#mg-play-wave');
    if (pb) pb.addEventListener('click', () => { if (player && !player.paused) stopWave(); else playWave(); });

    const sc = $('#mg-scrub');
    if (sc) {
      let scrubbing = false;
      const setFrom = (e) => {
        const w = st.wave; if (!w) return;
        const b = sc.getBoundingClientRect();
        const f = Math.max(0, Math.min(1, (e.clientX - b.left) / Math.max(1, b.width)));
        st.playFrom = w.from + f * (w.to - w.from);
        if (player && !player.paused) { try { player.currentTime = st.playFrom - w.from; } catch (err) {} st.playAt = st.playFrom; }
        else st.playAt = st.playFrom;
        /* bring the wave to where the sound is about to start */
        if (st.view && (st.playFrom < st.view[0] || st.playFrom > st.view[1])) {
          const len = st.view[1] - st.view[0];
          let a3 = Math.max(w.from, Math.min(w.to - len, st.playFrom - len * 0.35));
          st.view = [a3, a3 + len];
        }
        drawWave();
      };
      sc.addEventListener('mousedown', (e) => { scrubbing = true; setFrom(e); e.preventDefault(); });
      window.addEventListener('mousemove', (e) => { if (scrubbing) setFrom(e); });
      window.addEventListener('mouseup', () => { scrubbing = false; });
    }
  }

  /* ---------- putting it on the timeline ---------- */
  /* Premiere's Transform effect cannot make a buffer wider or taller than 30000 pixels. Scaling a 4K clip past
     about 780% crosses that and the render stops with "cannot allocate a buffer larger than 30000 pixels", so the
     zoom is held below whatever this particular clip can take. */
  const maxScaleFor = (r) => {
    const seq = Math.max(st.seqW || 1920, st.seqH || 1080);
    const base = st.mode === 'adjustment' ? seq : Math.max((r && r.w) || 0, (r && r.h) || 0) || seq;
    return Math.max(110, Math.floor((29000 / base) * 100));
  };
  let capped = 0;
  /* Premiere's own interpolation for the shapes it has, and a baked curve only for the ones it does not: it gives
     extensions no way to place bezier handles, so anything else has to be written frame by frame. */
  const nativeCurve = () => {
    const c = CURVES[st.curve] || CURVES.quadInOut;
    return c.interp === undefined ? null : c.interp;
  };
  function keysFor(r, i) {
    const fps = seqFps(), len = durFor(i == null ? 0 : i, r), fn = curveFn((CURVES[st.curve] || CURVES.quadInOut).b);
    const cap = maxScaleFor(r);
    const frames = Math.max(1, Math.round(len * fps));
    /* the hold comes out of the clip's length rather than being added to it, so "Length" keeps meaning what it says:
       the move finishes early and the last frames sit still at the end value. */
    const hold = Math.max(0, Math.min(frames - 1, Math.round(st.hold || 0)));
    const moving = Math.max(1, frames - hold);
    /* one key per frame up to ten, every second frame beyond that: Premiere gives extensions no bezier handles, so
       the curve has to be baked, and every key costs real time in the host. */
    const at = (f) => +(f / fps).toFixed(5);
    const val = (v) => { if (v > cap) capped++; return +Math.min(cap, Math.max(1, v)).toFixed(3); };

    /* the clean case: a start, an end, and Premiere doing the easing between them */
    if (nativeCurve() !== null) {
      const two = [[at(0), val(st.from)], [at(moving), val(st.to)]];
      if (hold > 0) two.push([at(frames), val(st.to)]);
      return two;
    }

    const step = moving <= 10 ? 1 : 2;
    const out = [];
    for (let f = 0; f <= moving; f += step) {
      const e = fn(Math.min(1, f / moving));
      const raw = st.from + (st.to - st.from) * e;
      if (raw > cap) capped++;
      out.push([+(f / fps).toFixed(5), +Math.min(cap, Math.max(1, raw)).toFixed(3)]);
    }
    const endT = +(moving / fps).toFixed(5);
    if (out[out.length - 1][0] !== endT) out.push([endT, st.to]);
    /* two keyframes say "hold", hundreds of identical ones say the same thing slower */
    if (hold > 0) out.push([+(frames / fps).toFixed(5), Math.min(cap, Math.max(1, st.to))]);
    return out;
  }

  async function apply() {
    if (!st.rows.length) return;
    if (typeof License !== 'undefined' && !await License.guardExport('montage', 'Zoom Montage export')) return;
    const btn = $('#mg-apply'); btn.classList.add('loading');
    try {
      if (st.beat && !st.plan) await findBeats(true);
      capped = 0;
      const n = placedCount(), rows = [];
      for (let i = 0; i < n; i++) {
        const r = rowAt(i); if (!r) continue;
        rows.push({ path: r.path, name: r.name, still: !!r.still, in: +r.in.toFixed(4),
          dur: +durFor(i, r).toFixed(4), keys: keysFor(r, i), interp: nativeCurve() === null ? 0 : nativeCurve() });
      }
      const payload = { rows: rows, mode: st.mode, shutter: st.shutter, audio: st.audio !== false, name: 'Zoom Montage',
        start: (st.plan && st.planStart != null) ? st.planStart : undefined, template: CS.extensionPath ? String(CS.extensionPath() || '').replace(/\\/g, '/') + '/client/assets/adjustment-layer.prproj' : '' };
      const res = await CS.call('MG_build', viaFile(payload));
      if (!res.ok) throw new Error(res.error);
      st.last = { track: res.track, start: res.start, end: res.end, starts: res.starts || [], layers: res.layers || [] };
      if (capped) toast('The zoom was held back on some clips: Transform cannot make a picture bigger than 30000 pixels.');
      render();
      toast(res.clips + ' clip' + (res.clips === 1 ? '' : 's') + ' placed · ' + res.keyframes + ' keyframes' +
        (res.warnings && res.warnings.length ? ' · ' + res.warnings[0] : ''), res.warnings && res.warnings.length ? '' : 'ok');
      License.noteExport('montage');
      try { Usage.tick('montage'); } catch (e) {}
    } catch (e) {
      toast(e.message || String(e), 'err');
      try { Usage.fail('montage', 'apply', e.message); } catch (e2) {}
    }
    btn.classList.remove('loading');
  }

  async function revert() {
    if (!st.last) return;
    try {
      const res = await CS.call('MG_revert', JSON.stringify(st.last));
      if (!res.ok) throw new Error(res.error);
      st.last = null; render();
      toast(res.removed + ' clip(s) removed.', 'ok');
    } catch (e) { toast(e.message || String(e), 'err'); }
  }

  const viaFile = (payload) => {
    const text = JSON.stringify(payload);
    if (!CS.hasNode || text.length < 6000) return text;
    const dir = CS.path.join(CS.os.tmpdir(), 'OutflowStudio'); CS.mkdirp(dir);
    const f = CS.path.join(dir, 'montage-' + Date.now() + '.json'); CS.fs.writeFileSync(f, text); return f;
  };

  /* ---------- wiring ---------- */
  let wired = false;
  function wire() {
    if (wired) return; wired = true;
    $('#mg-proj').addEventListener('click', () => CS.inCEP ? fromProject() : toast('Only available inside Premiere Pro.'));
    $('#mg-seq').addEventListener('click', () => CS.inCEP ? fromTimeline() : toast('Only available inside Premiere Pro.'));
    $('#mg-clear').addEventListener('click', () => { st.rows = []; st.sel = 0; render(); });

    const fr = $('#mg-frames'), frv = $('#mg-frames-v');
    const setFrames = (v, quick) => {
      st.frames = Math.max(1, Math.min(120, Math.round(v)));
      fr.value = String(st.frames); frv.textContent = st.frames + (st.frames === 1 ? ' frame' : ' frames');
      for (const r of st.rows) { const len = Math.min(lenSec(), r.dur); r.in = Math.max(0, Math.min(Math.max(0, r.dur - len), r.in)); }
      save();
      /* while the slider is moving, nudge the window that is on screen rather than rebuilding the picker: the window
         has to grow and shrink under the cursor, and a rebuild would drop the <video> and its position */
      if (quick && live) { live.place(); sum(); } else render();
    };
    fr.addEventListener('input', () => setFrames(+fr.value, true));
    fr.addEventListener('change', () => setFrames(+fr.value));
    setFrames(st.frames);

    const from = $('#mg-from'), to = $('#mg-to');
    from.value = String(st.from); to.value = String(st.to);
    from.addEventListener('change', () => { st.from = Math.max(1, Math.min(1000, +from.value || 100)); from.value = String(st.from); save(); });
    to.addEventListener('change', () => { st.to = Math.max(1, Math.min(1000, +to.value || 100)); to.value = String(st.to); save(); });
    $('#mg-swap').addEventListener('click', () => { const a = st.from; st.from = st.to; st.to = a; from.value = String(st.from); to.value = String(st.to); save(); });

    const kp = $('#mg-keep');
    if (kp) {
      kp.classList.toggle('on', !!st.keepEnd);
      kp.onclick = () => { st.keepEnd = !kp.classList.contains('on'); kp.classList.toggle('on', st.keepEnd); save(); showBeat(); render(); };
    }
    const rpt = $('#mg-repeat');
    if (rpt) {
      rpt.classList.toggle('on', !!st.repeat);
      rpt.onclick = () => { st.repeat = !rpt.classList.contains('on'); rpt.classList.toggle('on', st.repeat); dropPlan(); save(); render(); };
    }
    const bt = $('#mg-beat'), bbox = $('#mg-beat-box');
    const showBeat = () => {
      bbox.style.display = st.beat ? '' : 'none';
      /* whichever setting is in charge of the length is the one that stays lit */
      const fixedOff = st.beat || (st.keepEnd && st.rows.some((r) => r.own > 0));
      $('#mg-frames').closest('.row').style.opacity = fixedOff ? '.45' : '';
      const kr = $('#mg-keep-row'); if (kr) kr.style.opacity = st.beat ? '.45' : '';
    };
    bt.classList.toggle('on', !!st.beat);
    bt.onclick = () => { st.beat = !bt.classList.contains('on'); bt.classList.toggle('on', st.beat); if (!st.beat) st.plan = null; save(); showBeat(); render(); };
    const sv = $('#mg-strength');
    if (sv) {
      sv.innerHTML = Object.keys(STRENGTH).map((k) => '<option value="' + k + '">' + STRENGTH[k].name + '</option>').join('');
      if (!STRENGTH[st.strength]) st.strength = 'normal';
      sv.value = st.strength;
      sv.addEventListener('change', () => { st.strength = sv.value; dropPlan(); save(); });
    }
    const ev = $('#mg-every');
    ev.value = String(st.every); ev.addEventListener('change', () => { st.every = +ev.value || 1; dropPlan(); save(); });
    const btr = $('#mg-btrack');
    btr.addEventListener('change', () => { st.btrack = +btr.value; dropPlan(); save(); });
    $('#mg-find').addEventListener('click', async () => {
      const b = $('#mg-find'); b.classList.add('loading');
      try { await findBeats(); showBeat(); }
      catch (e) { busy(''); toast(e.message || String(e), 'err'); }
      b.classList.remove('loading');
    });
    showBeat();

    const hd = $('#mg-hold'), hdv = $('#mg-hold-v');
    const setHold = () => {
      st.hold = Math.max(0, Math.min(30, Math.round(+hd.value || 0)));
      hdv.textContent = st.hold ? st.hold + (st.hold === 1 ? ' frame' : ' frames') : 'none';
      save();
    };
    hd.value = String(st.hold || 0); setHold();
    hd.addEventListener('input', setHold);

    const cv = $('#mg-curve');
    cv.innerHTML = Object.keys(CURVES).map((k) => '<option value="' + k + '">' + CURVES[k].name + '</option>').join('');
    cv.value = st.curve; cv.addEventListener('change', () => { st.curve = cv.value; save(); });

    const sh = $('#mg-shutter'), shv = $('#mg-shutter-v');
    sh.value = String(st.shutter); shv.textContent = st.shutter + '°';
    sh.addEventListener('input', () => { st.shutter = +sh.value; shv.textContent = st.shutter + '°'; save(); });

    const au = $('#mg-audio');
    if (au) { au.classList.toggle('on', st.audio !== false); au.onclick = () => { st.audio = !au.classList.contains('on'); au.classList.toggle('on', st.audio); save(); }; }
    const md = $('#mg-mode');
    md.value = st.mode; md.addEventListener('change', () => { st.mode = md.value; save(); });

    $('#mg-apply').addEventListener('click', apply);
    $('#mg-revert').addEventListener('click', revert);
    window.addEventListener('resize', () => { const sc = $('#screen-montage'); if (!sc || !sc.classList.contains('active')) return; renderPicker(); drawWave(); });
  }

  async function seqInfo() {
    if (!CS.inCEP) return;
    try {
      const r = await CS.call('AS_range');
      if (r && r.ok) {
        if (r.fps > 0) st.seqFps = r.fps;
        if (r.width > 0) { st.seqW = r.width; st.seqH = r.height; }
        const sel = $('#mg-btrack');
        if (sel && r.audioTracks) {
          sel.innerHTML = '<option value="-1">Whole mix</option><option value="-2">Selected clip</option>' + r.audioTracks.map((a) =>
            '<option value="' + a.index + '">A' + (a.index + 1) + (a.name && !/^A\d+$/.test(a.name) ? ' \u00b7 ' + a.name : '') + '</option>').join('');
          sel.value = String(st.btrack);
        }
      }
    } catch (e) {}
  }
  function open() { Hub.show('montage'); wire(); wireWave(); render(); drawWave(); seqInfo().then(render); }
  return { open, render };
})();
window.Montage = Montage;
