/* UI, state, undo/redo, preview loop. */
(() => {
  const $ = (s) => document.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const BGS = ['black', 'checker', '#101828', '#ffffff'];

  let state = templateState('classic');
  let sourceIds = [];
  const undo = [], redo = [];
  let playing = true, time = 0, lastTs = 0;
  let renderer = null, glFailed = false;
  let dragSnap = null;
  let userPresets = [];
  let editing = null;   /* { prefix, start, track } when a placed carousel was loaded for editing */

  const canvas = $('#cv'), phone = $('#phone');

  /* ------------------------------------------------------------ helpers */
  const getPath = (o, p) => p.split('.').reduce((a, k) => (a == null ? undefined : a[k]), o);
  const setPath = (o, p, v) => { const ks = p.split('.'); let a = o; for (let i = 0; i < ks.length - 1; i++) { if (a[ks[i]] == null || typeof a[ks[i]] !== 'object') a[ks[i]] = {}; a = a[ks[i]]; } a[ks[ks.length - 1]] = v; };
  const snapshot = () => JSON.stringify({ state, sourceIds });
  const restore = (s) => { const o = JSON.parse(s); state = o.state; sourceIds = o.sourceIds; };
  function pushUndo(snap) { undo.push(snap); if (undo.length > 80) undo.shift(); redo.length = 0; }
  function commit(fn) { const s = snapshot(); fn(); pushUndo(s); afterChange(); }
  function doUndo() { if (!undo.length) return; redo.push(snapshot()); restore(undo.pop()); afterChange(); }
  function doRedo() { if (!redo.length) return; undo.push(snapshot()); restore(redo.pop()); afterChange(); }
  let lastSrcKey = '';
  function afterChange() {
    const k = sourceIds.join(',');
    if (k !== lastSrcKey) { lastSrcKey = k; if (typeof Previews !== 'undefined') Previews.invalidate(); }
    renderThumbs(); renderControls(); renderStrip(); syncTop(); persist();
  }

  const toast = (msg, kind) => Hub.toast(msg, kind);
  function persist() {
    try {
      localStorage.setItem('c3d.state', JSON.stringify(state));
      const paths = sourceIds.map(id => Sources.get(id)).filter(s => s && s.path).map(s => s.path);
      localStorage.setItem('c3d.paths', JSON.stringify(paths));
      localStorage.setItem('c3d.adv', document.body.classList.contains('advanced') ? '1' : '0');
    } catch (e) {}
  }

  /* ------------------------------------------------------------ media */
  async function addInputs(list) {
    let added = 0;
    /* documents, installers and the like picked or dropped along with the media: skipped, with one note */
    const skipped = []; list = Array.from(list).filter((it) => { if (Sources.isMedia(it)) return true; skipped.push(String(it.name || it).split(/[\\/]/).pop()); return false; });
    if (skipped.length) toast('Skipped ' + (skipped.length === 1 ? skipped[0] : skipped.length + ' files') + ': only pictures and videos go into the carousel.', '');
    for (const item of list) {
      try { const s = await Sources.add(item); sourceIds.push(s.id); added++; renderThumbs(); }
      catch (e) { toast((item.name || item) + ': ' + e.message, 'err'); }
    }
    if (added) { pushUndo(JSON.stringify({ state, sourceIds: sourceIds.slice(0, sourceIds.length - added) })); afterChange(); if (playing) Sources.playAll(sourceIds); }
  }
  async function pickMedia() {
    const paths = CS.pickFiles();
    if (paths === null) { $('#file').click(); return; }
    if (paths.length) await addInputs(paths);
  }
  $('#btn-media').addEventListener('click', pickMedia);
  $('#file').addEventListener('change', (e) => { addInputs(Array.from(e.target.files)); e.target.value = ''; });
  document.addEventListener('dragover', (e) => { e.preventDefault(); $('#drop').classList.add('over'); });
  document.addEventListener('dragleave', () => $('#drop').classList.remove('over'));
  document.addEventListener('drop', (e) => {
    e.preventDefault(); $('#drop').classList.remove('over');
    const files = Array.from(e.dataTransfer.files || []);
    if (files.length) { addInputs(files); return; }
    /* a drag from Premiere's Project panel carries no files: use the panel selection */
    if (CS.inCEP) addFromProject();
  });
  async function addFromProject() {
    try {
      const items = await Exporter.projectSelection();
      if (!items.length) { toast('Select images or videos in the Project panel first, then click again.'); return; }
      await addInputs(items.map(i => i.path));
    } catch (e) { toast(e.message, 'err'); }
  }
  async function addFromTimeline() {
    try {
      const clips = await Exporter.timelineSelection();
      if (!clips.length) { toast('Select clips in the timeline first, then click again.'); return; }
      /* one card per selected clip, in timeline order, each opening on its own in-point. Collapsing them by file
         path turned eight trims of one video into a single card showing the same frame eight times. */
      const inOrder = clips.slice().sort((a, b) => (a.start || 0) - (b.start || 0));
      await addInputs(inOrder.map((c) => ({ path: c.path, in: c.inPoint || 0, name: c.name })));
    } catch (e) { toast(e.message, 'err'); }
  }
  $('#btn-proj').addEventListener('click', () => CS.inCEP ? addFromProject() : toast('Only available inside Premiere Pro.'));
  $('#btn-seq').addEventListener('click', () => CS.inCEP ? addFromTimeline() : toast('Only available inside Premiere Pro.'));

  function renderThumbs() {
    const box = $('#thumbs'); box.innerHTML = '';
    sourceIds.forEach((id, i) => {
      const s = Sources.get(id); if (!s) return;
      const t = el('div', 'thumb'); t.draggable = true; t.dataset.i = i;
      t.innerHTML = '<img src="' + s.thumb + '"><div class="num">' + String(i + 1).padStart(2, '0') + '</div>' + (s.type === 'video' ? '<span class="vid">VID</span>' : '') + '<button class="x" title="Remove">✕</button>';
      t.title = s.name;
      t.querySelector('.x').addEventListener('click', (e) => { e.stopPropagation(); commit(() => { sourceIds.splice(i, 1); }); });
      t.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', String(i)); t.classList.add('dragging'); });
      t.addEventListener('dragend', () => t.classList.remove('dragging'));
      t.addEventListener('dragover', (e) => { e.preventDefault(); e.stopPropagation(); t.classList.add('over'); });
      t.addEventListener('dragleave', () => t.classList.remove('over'));
      t.addEventListener('drop', (e) => {
        e.preventDefault(); e.stopPropagation(); t.classList.remove('over');
        const from = parseInt(e.dataTransfer.getData('text/plain'), 10);
        if (isNaN(from) || from === i) return;
        commit(() => { const [m] = sourceIds.splice(from, 1); sourceIds.splice(i, 0, m); });
      });
      box.appendChild(t);
    });
    $('#empty').style.display = sourceIds.length ? 'none' : 'flex';
    $('#btn-add').disabled = !sourceIds.length;
  }

  /* ------------------------------------------------------------ controls */
  function mkToggle(path, get, set) {
    const b = el('button', 'switch');
    const on = get ? get() : !!getPath(state, path);
    if (on) b.classList.add('on');
    b.addEventListener('click', () => commit(() => { if (set) set(!on); else setPath(state, path, !on); }));
    return b;
  }
  function mkSelect(path, options, onChange) {
    const s = el('select', 'sel');
    for (const [k, name] of options) { const o = el('option'); o.value = k; o.textContent = name; s.appendChild(o); }
    s.value = String(getPath(state, path));
    s.addEventListener('change', () => commit(() => { setPath(state, path, s.value); if (onChange) onChange(s.value); }));
    return s;
  }
  function mkRange(path, min, max, step, unit) {
    const wrap = el('div', 'slider');
    const r = el('input'); r.type = 'range'; r.min = min; r.max = max; r.step = step;
    const v = el('span', 'val');
    const cur = getPath(state, path);
    r.value = cur === undefined ? min : cur;
    const fmt = (x) => (Math.abs(step) >= 1 ? Math.round(x) : Number(x).toFixed(step < 0.1 ? 2 : 1)) + (unit || '');
    v.textContent = fmt(r.value);
    r.addEventListener('input', () => { if (!dragSnap) dragSnap = snapshot(); setPath(state, path, parseFloat(r.value)); v.textContent = fmt(r.value); });
    r.addEventListener('change', () => { if (dragSnap) { pushUndo(dragSnap); dragSnap = null; } setPath(state, path, parseFloat(r.value)); persist(); syncTop(); });
    r.addEventListener('dblclick', () => { const d = defaultFor(path); if (d !== undefined) commit(() => setPath(state, path, d)); });
    wrap.append(r, v);
    return wrap;
  }
  function mkColor(path) {
    const c = el('input'); c.type = 'color'; c.value = getPath(state, path) || '#ffffff';
    c.addEventListener('input', () => { if (!dragSnap) dragSnap = snapshot(); setPath(state, path, c.value); });
    c.addEventListener('change', () => { if (dragSnap) { pushUndo(dragSnap); dragSnap = null; } setPath(state, path, c.value); persist(); });
    return c;
  }
  /* slider + editable Bezier curve for the "linger at front" warp.
     Drag the two handles like a pen tool; the slider resets them. A yellow
     line shows where the preview is inside the current step. */
  let lingerDraw = null, lastRawPhase = 0;
  /* window listeners owned by a re-rendered control: the previous set is dropped before the new one is added */
  const winOwned = {};
  function winListen(owner, handlers) {
    const old = winOwned[owner]; if (old) for (const k of Object.keys(old)) window.removeEventListener(k, old[k]);
    winOwned[owner] = handlers; for (const k of Object.keys(handlers)) window.addEventListener(k, handlers[k]);
  }
  function mkLinger() {
    const wrap = el('div', 'slider lingerwrap');
    const cv = el('canvas', 'curve'); cv.width = 132; cv.height = 76;
    const r = mkRange('linger', 0, 1, 0.02);
    const pad = 8;
    const toPx = (x, y) => [pad + x * (cv.width - 2 * pad), cv.height - pad - y * (cv.height - 2 * pad)];
    const fromPx = (px, py) => [clamp((px - pad) / (cv.width - 2 * pad), 0, 1), clamp((cv.height - pad - py) / (cv.height - 2 * pad), 0, 1)];
    const handles = () => lingerHandles(state.linger || 0, state.lingerCurve);
    const draw = () => {
      const g = cv.getContext('2d'), w = cv.width, hh = cv.height, c = handles();
      g.clearRect(0, 0, w, hh);
      g.strokeStyle = '#2f3440'; g.lineWidth = 1; g.beginPath(); const a = toPx(0, 0), b = toPx(1, 1); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke();
      /* handle arms */
      g.strokeStyle = '#5a6070'; g.setLineDash([3, 3]); g.beginPath(); const p1 = toPx(c[0], c[1]), p2 = toPx(c[2], c[3]); g.moveTo(a[0], a[1]); g.lineTo(p1[0], p1[1]); g.moveTo(b[0], b[1]); g.lineTo(p2[0], p2[1]); g.stroke(); g.setLineDash([]);
      g.strokeStyle = '#7fb0ff'; g.lineWidth = 2; g.beginPath();
      for (let i = 0; i <= 48; i++) { const f = i / 48, y = bezierWarp(f, c); const p = toPx(f, y); if (i === 0) g.moveTo(p[0], p[1]); else g.lineTo(p[0], p[1]); }
      g.stroke();
      /* time marker */
      const fr = ((lastRawPhase % 1) + 1) % 1;
      const m0 = toPx(fr, 0), m1 = toPx(fr, 1);
      g.strokeStyle = '#ffd166'; g.lineWidth = 1; g.beginPath(); g.moveTo(m0[0], m0[1]); g.lineTo(m1[0], m1[1]); g.stroke();
      const mp = toPx(fr, bezierWarp(fr, c)); g.fillStyle = '#ffd166'; g.beginPath(); g.arc(mp[0], mp[1], 3, 0, Math.PI * 2); g.fill();
      for (const p of [p1, p2]) { g.fillStyle = '#fff'; g.strokeStyle = '#4f8dff'; g.lineWidth = 2; g.beginPath(); g.arc(p[0], p[1], 4, 0, Math.PI * 2); g.fill(); g.stroke(); }
    };
    let dragging = -1, snap = null;
    const pos = (e) => { const rc = cv.getBoundingClientRect(); return [(e.clientX - rc.left) * cv.width / rc.width, (e.clientY - rc.top) * cv.height / rc.height]; };
    cv.addEventListener('mousedown', (e) => {
      const [px, py] = pos(e), c = handles();
      const d1 = Math.hypot(...toPx(c[0], c[1]).map((v, i) => v - [px, py][i])), d2 = Math.hypot(...toPx(c[2], c[3]).map((v, i) => v - [px, py][i]));
      dragging = d1 < 12 ? 0 : d2 < 12 ? 1 : -1;
      if (dragging >= 0) { snap = snapshot(); state.lingerCurve = c.slice(); e.preventDefault(); }
    });
    winListen('linger', {
      mousemove: (e) => { if (dragging < 0 || !cv.isConnected) return; const [x, y] = fromPx(...pos(e)); const c = state.lingerCurve; c[dragging * 2] = x; c[dragging * 2 + 1] = y; },
      mouseup: () => { if (dragging < 0) return; dragging = -1; if (snap) { pushUndo(snap); snap = null; } persist(); }
    });
    cv.addEventListener('dblclick', () => commit(() => { state.lingerCurve = null; }));
    r.querySelector('input').addEventListener('input', () => { state.lingerCurve = null; });
    cv.title = 'Drag the handles (pen tool). Double-click to reset to the slider.';
    lingerDraw = draw;
    draw();
    wrap.append(cv, r);
    return wrap;
  }
  /* MachiCut-style timing strip: the whole duration as a bar, Appear and Disappear as draggable blocks, a playhead */
  let timingDraw = null;
  function mkTiming() {
    const wrap = el('div', 'timingwrap');
    const cv = el('canvas', 'timing');
    const H = 44, pad = 6;
    const draw = () => {
      const rc = cv.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 3);
      const W = Math.max(60, Math.round(rc.width || 240));
      if (cv.width !== W * dpr || cv.height !== H * dpr) { cv.width = W * dpr; cv.height = H * dpr; }
      const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const dur = Math.max(0.1, state.duration), x = (t) => pad + clamp(t / dur, 0, 1) * (W - 2 * pad);
      g.clearRect(0, 0, W, H); g.fillStyle = '#15171c'; g.fillRect(0, 0, W, H);
      g.fillStyle = '#2b2f38'; g.fillRect(pad, 14, W - 2 * pad, 16);
      g.fillStyle = '#3d7cf0'; g.fillRect(pad, 14, W - 2 * pad, 16);
      g.fillStyle = '#fff'; g.font = 'bold 9px sans-serif'; g.textBaseline = 'middle'; g.fillText(MOTIONS[state.motion] ? MOTIONS[state.motion].name : 'Animate', pad + 6, 22);
      const blk = (t0, t1, label, on, align) => { const a = x(t0), b = x(t1); g.fillStyle = on ? '#3ad29f' : 'rgba(255,255,255,.12)'; g.fillRect(Math.min(a, b), 4, Math.abs(b - a), 8); g.fillStyle = on ? '#fff' : 'rgba(255,255,255,.4)'; g.font = '9px sans-serif'; g.textAlign = align; g.fillText(label, align === 'left' ? a : b, 36); g.textAlign = 'left'; };
      blk(0, state.intro.dur, 'Appear ' + state.intro.dur.toFixed(2) + 's', state.intro.enabled, 'left');
      blk(dur - state.outro.dur, dur, 'Disappear ' + state.outro.dur.toFixed(2) + 's', state.outro.enabled, 'right');
      for (let i = 0; i <= 4; i++) { const t = dur * i / 4; g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(x(t), 30, 1, 3); }
      const px = x(time); g.fillStyle = '#ffd166'; g.fillRect(px - 1, 2, 2, H - 4); g.beginPath(); g.moveTo(px - 4, 2); g.lineTo(px + 4, 2); g.lineTo(px, 7); g.closePath(); g.fill();
    };
    let drag = null, snap = null;
    const pos = (e) => { const rc = cv.getBoundingClientRect(); const W = rc.width; const dur = Math.max(0.1, state.duration); return { t: clamp((e.clientX - rc.left - pad) / (W - 2 * pad), 0, 1) * dur, y: e.clientY - rc.top, W }; };
    cv.addEventListener('mousedown', (e) => {
      const p = pos(e), dur = Math.max(0.1, state.duration), tol = 0.06 * dur;
      if (Math.abs(p.t - state.intro.dur) < tol && p.y < 20) { drag = 'in'; snap = snapshot(); }
      else if (Math.abs(p.t - (dur - state.outro.dur)) < tol && p.y < 20) { drag = 'out'; snap = snapshot(); }
      else { drag = 'scrub'; time = p.t; playing = false; syncPlayIcon(); }
      e.preventDefault();
    });
    winListen('timing', {
      mousemove: (e) => {
        if (!drag || !cv.isConnected) return;
        const p = pos(e), dur = Math.max(0.1, state.duration);
        if (drag === 'scrub') time = p.t;
        else if (drag === 'in') { state.intro.dur = clamp(Math.round(p.t * 20) / 20, 0.1, dur / 2); state.intro.enabled = true; }
        else if (drag === 'out') { state.outro.dur = clamp(Math.round((dur - p.t) * 20) / 20, 0.1, dur / 2); state.outro.enabled = true; }
      },
      mouseup: () => { if (!drag) return; const d = drag; drag = null; if (d !== 'scrub' && snap) { pushUndo(snap); snap = null; afterChange(); } }
    });
    cv.title = 'Drag the green ends to set Appear / Disappear length. Click anywhere to scrub.';
    timingDraw = draw;
    wrap.appendChild(cv);
    requestAnimationFrame(draw);
    return wrap;
  }
  function defaultFor(path) {
    const d = getPath(DEFAULTS, path);
    if (d !== undefined) return d;
    const m = path.match(/^lp\.(\w+)\.(\w+)$/); if (m) { const p = (LAYOUTS[m[1]].params || []).find(x => x.k === m[2]); return p && p.def; }
    const m2 = path.match(/^mp\.(\w+)$/); if (m2) { const p = (MOTIONS[state.motion].params || []).find(x => x.k === m2[1]); return p && p.def; }
    const m3 = path.match(/^camera\.cp\.(\w+)$/); if (m3) { const p = (CAMERAS[state.camera.preset].params || []).find(x => x.k === m3[1]); return p && p.def; }
    return undefined;
  }
  function row(label, control, adv, hint) {
    const r = el('div', 'row' + (adv ? ' advanced-only' : ''));
    const l = el('label', '', label); if (hint) l.innerHTML += ' <span class="hint">' + hint + '</span>';
    r.append(l, control);
    return r;
  }
  function section(title, rows, adv) {
    const s = el('div', 'section' + (adv ? ' advanced-only' : ''));
    s.appendChild(el('h4', '', title));
    for (const r of rows) if (r) s.appendChild(r);
    return s;
  }
  function paramRows(defs, prefix, adv) {
    return (defs || []).map(p => {
      const path = prefix + p.k;
      if (getPath(state, path) === undefined) setPath(state, path, p.def);
      return row(p.name, mkRange(path, p.min, p.max, p.step, p.unit), adv);
    });
  }
  const opts = (obj) => Object.keys(obj).map(k => [k, obj[k].name]);

  function renderControls() {
    const box = $('#controls'); box.innerHTML = '';
    const bothIO = () => state.intro.enabled && state.outro.enabled;
    const motionIsStep = ['step', 'pulse', 'kick', 'bounce', 'elastic', 'stutter', 'random'].includes(state.motion);

    box.appendChild(section('Quick', [
      row('Speed', mkRange('speed', 0.1, 4, 0.05, '×')),
      row('Linger at front', mkLinger(), false, 'front card eases to a stop'),
      row('Card size', mkRange('card.size', 0.3, 2.5, 0.05)),
      row('Card aspect', mkSelect('card.aspect', Object.keys(CARD_ASPECTS).map(k => [k, k === 'auto' ? 'Auto (first image)' : k]))),
      row('Image fit', mkSelect('card.fit', [['cover', 'Fill card (crop)'], ['contain', 'Keep original aspect']])),
      row('Image position X', mkRange('card.offX', -1, 1, 0.02), false, 'which part survives the crop'),
      row('Image position Y', mkRange('card.offY', -1, 1, 0.02))
    ]));

    box.appendChild(section('Animation', [
      Object.assign(row('Timing', mkTiming(), false, 'drag the ends of Appear and Disappear · click to scrub'), { className: 'row wrapping' }),
      row('Step by step', mkToggle(null, () => motionIsStep, (on) => { state.motion = on ? 'step' : 'spin'; })),
      row('Depth blur', mkToggle('fx.depthBlur')),
      row('Appear & Disappear', mkToggle(null, bothIO, (on) => { state.intro.enabled = on; state.outro.enabled = on; })),
      row('Motion', mkSelect('motion', opts(MOTIONS))),
      ...paramRows(MOTIONS[state.motion].params, 'mp.', true),
      row('Easing', mkSelect('ease', opts(EASINGS)), true),
      row('Duration', mkRange('duration', 0.5, 30, 0.5, 's'), true)
    ]));

    box.appendChild(section('Layout', [
      row('Layout', mkSelect('layout', opts(LAYOUTS)), false, LAYOUTS[state.layout].desc),
      ...paramRows(LAYOUTS[state.layout].params, 'lp.' + state.layout + '.', false),
      row('Spacing', mkRange('card.spacing', 0.8, 3, 0.05), true),
      row('Ring radius', mkRange('card.radiusScale', 0.3, 3, 0.05), true),
      row('Corner radius', mkRange('card.corner', 0, 140, 1, 'px'), true),
      row('Border', (() => { const d = el('div', 'inline'); d.append(mkColor('card.borderColor'), mkRange('card.border', 0, 40, 1, 'px')); return d; })(), true),
      row('Vertical offset', mkRange('card.yOffset', -5, 5, 0.1), true),
      row('Focus offset', mkRange('card.focusOffset', -4, 4, 0.05, ' cards'), true)
    ]));

    box.appendChild(section('Look', [
      row('Blur amount', mkRange('fx.blurAmt', 0, 3, 0.05), true),
      row('Focus on', mkSelect('fx.focus', [['front', 'Front card'], ['center', 'Centre'], ['back', 'Back']]), true),
      row('Dim back cards', mkRange('fx.dim', 0, 1, 0.05)),
      row('Desaturate back', mkRange('fx.gray', 0, 1, 0.05), true),
      row('Reflection', mkRange('fx.reflection', 0, 1, 0.05)),
      row('Reflection blur', mkRange('fx.reflBlur', 0, 40, 1, 'px'), true),
      row('Shadow', mkRange('fx.shadow', 0, 1, 0.05)),
      row('Glow', (() => { const d = el('div', 'inline'); d.append(mkColor('fx.glowColor'), mkRange('fx.glow', 0, 1, 0.05)); return d; })(), true),
      row('Tint', (() => { const d = el('div', 'inline'); d.append(mkColor('fx.tint'), mkRange('fx.tintAmt', 0, 1, 0.05)); return d; })(), true),
      row('Parallax', mkRange('fx.parallax', 0, 1, 0.05), true),
      row('Vignette', mkRange('fx.vignette', 0, 1, 0.05), true),
      row('Brightness', mkRange('fx.bright', 0.2, 2, 0.05), true),
      row('Back of cards', mkSelect('fx.backface', [['dim', 'Dimmed'], ['mirror', 'Mirrored image'], ['unmirror', 'Same image'], ['hide', 'Hidden']]), true)
    ]));

    box.appendChild(section('Camera', [
      row('Camera move', mkSelect('camera.preset', opts(CAMERAS))),
      ...paramRows(CAMERAS[state.camera.preset].params, 'camera.cp.', true),
      row('Field of view', mkRange('camera.fov', 15, 110, 1, '°'), true),
      row('Zoom', mkRange('camera.zoom', 0.4, 3, 0.05), true),
      row('Height', mkRange('camera.height', -5, 5, 0.1), true),
      row('Pitch', mkRange('camera.pitch', -60, 60, 1, '°'), true),
      row('Yaw', mkRange('camera.yaw', -90, 90, 1, '°'), true),
      row('Roll', mkRange('camera.roll', -45, 45, 1, '°'), true)
    ]));

    box.appendChild(section('Rotate carousel', [
      row('Turn', mkRange('group.ry', -180, 180, 1, '°'), false, 'drag a ring on the preview'),
      row('Tip', mkRange('group.rx', -90, 90, 1, '°')),
      row('Twist', mkRange('group.rz', -90, 90, 1, '°'), true),
      row('Invert vertical drag', mkInvert(), false, 'for the preview and the gizmo')
    ]));

    box.appendChild(section('Appear (intro)', [
      row('Enabled', mkToggle('intro.enabled')),
      row('Style', mkSelect('intro.style', opts(INTROS))),
      row('Duration', mkRange('intro.dur', 0.1, 3, 0.05, 's')),
      row('Stagger', mkRange('intro.stagger', 0, 0.5, 0.01, 's'), true),
      row('Easing', mkSelect('intro.ease', opts(EASINGS)), true)
    ]));
    box.appendChild(section('Disappear (outro)', [
      row('Enabled', mkToggle('outro.enabled')),
      row('Style', mkSelect('outro.style', opts(INTROS))),
      row('Duration', mkRange('outro.dur', 0.1, 3, 0.05, 's')),
      row('Stagger', mkRange('outro.stagger', 0, 0.5, 0.01, 's'), true),
      row('Easing', mkSelect('outro.ease', opts(EASINGS)), true)
    ]));

    if (!state.bg) state.bg = deepMerge({}, DEFAULTS.bg);
    const bgMove = BG_MOVES[state.bg.move] || BG_MOVES.none;
    box.appendChild(section('Background layer', [
      row('Blurred background', mkToggle('bg.enabled'), false, 'separate clip under the carousel'),
      row('Image', mkSelect('bg.source', [['focus', 'Card in focus (crossfades)'], ['first', 'First card only']])),
      row('Blur', mkRange('bg.blur', 0, 1, 0.02)),
      row('Size', mkRange('bg.zoom', 1, 2.5, 0.05, '×')),
      row('Darken', mkRange('bg.dark', 0, 1, 0.05)),
      row('Saturation', mkRange('bg.sat', 0, 1.5, 0.05)),
      row('Opacity', mkRange('bg.opacity', 0, 1, 0.05)),
      row('Crossfade', mkRange('bg.fade', 0.05, 1, 0.05, ' of a step'), true),
      row('Movement', mkSelect('bg.move', opts(BG_MOVES))),
      ...paramRows(bgMove.params, 'bg.bgp.', false)
    ]));

    const isNative = state.output === 'native';
    const exportBtn = el('button', 'ghost', 'Export PNG sequence…');
    exportBtn.addEventListener('click', exportFrames);
    const saveBtn = el('button', 'ghost', 'Save as my preset');
    saveBtn.addEventListener('click', savePreset);
    const resetBtn = el('button', 'ghost', 'Reset template');
    resetBtn.addEventListener('click', () => applyTemplate(state.template));
    const editBtn = el('button', 'ghost', 'Edit selected carousel');
    editBtn.title = 'Select a carousel clip in the timeline, then click to load its settings';
    editBtn.addEventListener('click', editSelected);
    const replBtn = el('button', 'primary', editing ? 'Replace ' + editing.prefix : 'Replace selected');
    replBtn.title = 'Remove the carousel on the timeline and place this one at the same spot';
    replBtn.addEventListener('click', replaceSelected);
    const btns = el('div', 'inline'); btns.append(exportBtn, saveBtn, resetBtn);
    const btns2 = el('div', 'inline'); btns2.append(editBtn, replBtn);
    if (!state.native) state.native = deepMerge({}, DEFAULTS.native);
    box.appendChild(section('Output', [
      row('Mode', mkSelect('output', [['render', 'Rendered clip (exact look)']]), false, 'a transparent ProRes clip, or a PNG sequence without the video engine · live keyframes come with the After Effects version'),
      isNative ? row('3D method', mkSelect('native.method', [['cornerpin', 'Corner Pin (true perspective)'], ['scale', 'Motion only (fastest, flat)'], ['basic3d', 'Basic 3D (slow)']])) : null,
      isNative ? row('Bake corners into images', mkToggle('native.bake'), false, 'rounded corners, border and crop for image cards') : null,
      row('Frame rate', mkSelect('fps', [['seq', 'Match sequence'], ['24', '24 fps'], ['25', '25 fps'], ['30', '30 fps'], ['50', '50 fps'], ['60', '60 fps']]), false, isNative ? 'keyframe sampling' : 'fewer frames render faster'),
      isNative ? null : row('Split render', mkToggle('split'), false, 'back + front clips, footage goes between'),
      row('', btns2),
      row('', btns)
    ]));
    tabify(box);
  }
  /* the sections become tabs; the active tab is remembered */
  const TAB_GROUPS = { 'Quick': 'Quick', 'Animation': 'Animation', 'Layout': 'Layout', 'Look': 'Layout', 'Camera': 'Camera', 'Rotate carousel': 'Camera', 'Appear (intro)': 'In / Out', 'Disappear (outro)': 'In / Out', 'Background layer': 'Background', 'Output': 'Output' };
  let activeTab = localStorage.getItem('c3d.tab') || 'Quick';
  const TAB_ICONS = { 'Quick': 'star', 'Animation': 'transitions', 'Layout': 'carousel', 'Look': 'visual', 'Camera': 'stills', 'In / Out': 'export', 'Background': 'fill', 'Output': 'download', 'All': 'sidebar' };
  function tabify(box) {
    const secs = Array.from(box.querySelectorAll(':scope > .section'));
    const names = [];
    for (const s of secs) { const t = s.querySelector('h4') ? s.querySelector('h4').firstChild.textContent.trim() : ''; const g = TAB_GROUPS[t] || t; s.dataset.tab = g; if (!names.includes(g)) names.push(g); }
    names.push('All');
    if (!names.includes(activeTab)) activeTab = names[0];
    const bar = el('div', 'tabs');
    const apply = () => {
      bar.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x.dataset.tab === activeTab));
      secs.forEach(s => s.classList.toggle('tab-hidden', activeTab !== 'All' && s.dataset.tab !== activeTab));
      box.classList.toggle('all-tabs', activeTab === 'All');
    };
    for (const n of names) {
      const b = el('button', 'tab');
      b.dataset.tab = n; b.title = n;
      b.innerHTML = (typeof icon === 'function' && TAB_ICONS[n] ? icon(TAB_ICONS[n], 13) : '') + '<span>' + n + '</span>';
      b.addEventListener('click', () => { activeTab = n; try { localStorage.setItem('c3d.tab', n); } catch (e) {} apply(); });
      bar.appendChild(b);
    }
    apply();
    box.insertBefore(bar, box.firstChild);
  }
  async function editSelected() {
    if (!CS.inCEP) { toast('Only available inside Premiere Pro.'); return; }
    try {
      const r = await Exporter.loadFromSelection();
      const s = r.settings;
      commit(() => {
        state = deepMerge(deepMerge({}, DEFAULTS), s.state);
        sourceIds = [];
      });
      const paths = (s.sources || []).map(x => x.path).filter(p => p && CS.fs.existsSync(p));
      if (paths.length) await addInputs(paths);
      editing = { prefix: r.prefix, start: r.start, track: r.track };
      renderControls();
      toast('Loaded ' + r.prefix + '. Tweak it, then press Replace.', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  }
  async function replaceSelected() {
    if (!CS.inCEP) { toast('Only available inside Premiere Pro.'); return; }
    await withExport(async () => {
      let target = editing;
      if (!target) {
        const r = await Exporter.loadFromSelection();
        target = { prefix: r.prefix, start: r.start, track: r.track };
      }
      if (!sourceIds.length) throw new Error('Add some images or video first.');
      progressUI.title('Removing old clips');
      const rem = await Exporter.removeCarousel(target.prefix);
      const start = rem.count ? rem.start : target.start;
      const track = rem.count ? rem.track : target.track;
      await Exporter.setPlayhead(start);
      const r = await Exporter.addToTimeline(state, sourceIds, progressUI, { track, name: target.prefix });
      editing = { prefix: r.name, start, track };
      renderControls();
      reportResult(r, ' (replaced)');
    });
  }
  function reportResult(r, suffix) {
    /* one export = one count, whatever it contains (the blurred background is part of the same export); replacing an existing carousel is not a new export */
    /* a Replace is not a new export: not counted against the free ones, and reported apart so the two counts can be compared */
    try { if (suffix !== ' (replaced)') License.noteExport('carousel'); Usage.tick(suffix === ' (replaced)' ? 'carousel:replace' : 'carousel', 1, r && r.seconds ? { seconds: r.seconds } : undefined); if (state.template) Usage.tick('set:carousel:tpl:' + String(state.template).slice(0, 30)); Usage.tick('set:carousel:mode:' + (r && r.mode ? r.mode : 'unknown')); } catch (e) {}
    suffix = suffix || '';
    if (r.mode === 'native') {
      const msg = r.nested
        ? 'Nested sequence "' + r.name + '" (' + r.placed + ' keyframed clips inside) placed on V' + (r.base + 1) + suffix + '.'
        : r.placed + ' clips with keyframes on V' + (r.base + 1) + '–V' + (r.base + r.tracks) + suffix + '.';
      if (r.warnings && r.warnings.length) toast(msg + ' Notes: ' + r.warnings.slice(0, 3).join(' · '), 'err');
      else toast(msg, 'ok');
      return;
    }
    const tr = r.results.map(x => x.layer + ' → V' + (x.track + 1)).join(', ');
    toast('Placed ' + tr + suffix + (state.split ? '. Put your footage between back and front.' : '.'), 'ok');
  }

  /* ------------------------------------------------------------ templates */
  let favs = [];
  try { favs = JSON.parse(localStorage.getItem('c3d.favs') || '[]'); } catch (e) { favs = []; }
  const saveFavs = () => { try { localStorage.setItem('c3d.favs', JSON.stringify(favs)); } catch (e) {} };
  function toggleFav(id) { const i = favs.indexOf(id); if (i >= 0) favs.splice(i, 1); else favs.push(id); saveFavs(); renderStrip(); if (Hub.current() === 'gallery') renderGallery(); }
  function allTemplates() {
    const base = TEMPLATES.concat(userPresets.map(p => ({ id: p.id, name: p.name, icon: '⭐', cat: 'My presets', set: null, user: p })));
    const favList = favs.map(id => base.find(t => t.id === id)).filter(Boolean).map(t => Object.assign({}, t, { cat: 'Favorites' }));
    return favList.concat(base);
  }
  function keepState() {
    return { duration: state.duration, aspect: state.aspect, previewBg: state.previewBg, split: state.split, output: state.output, bg: state.bg, native: state.native, speed: state.speed, linger: state.linger, lingerCurve: state.lingerCurve };
  }
  function stateForTemplate(id, keep) {
    const u = userPresets.find(p => p.id === id);
    if (u) { const s = deepMerge(deepMerge({}, DEFAULTS), u.state); if (keep) Object.assign(s, keep); s.template = id; return s; }
    return templateState(id, keep);
  }
  function applyTemplate(id) {
    commit(() => { state = stateForTemplate(id, keepState()); });
  }

  /* rendered template thumbnails (still frame, animates on hover) */
  const Previews = (() => {
    let R = null, cv = null, demo = null, cache = new Map();
    async function list() {
      if (sourceIds.length) return sourceIds.map(id => Sources.get(id)).filter(Boolean);
      if (!demo) { demo = []; for (const f of await demoCards()) demo.push(await Sources.add(f)); }
      return demo;
    }
    function key() { return sourceIds.length ? sourceIds.join(',') : 'demo'; }
    function draw(target, id, t, srcs) {
      const w = target.width, h = target.height;
      if (!cv) { cv = document.createElement('canvas'); try { R = new Renderer(cv); } catch (e) { R = null; } }
      if (!R) return;
      R.setSize(w, h);
      /* the gallery previews move at the defaults a fresh carousel gets, so what you see is what you get */
      const st = stateForTemplate(id, { duration: 5, aspect: '4:5', previewBg: 'black', bg: deepMerge({}, DEFAULTS.bg), speed: DEFAULTS.speed, linger: DEFAULTS.linger });
      R.render(buildScene(st, srcs, t, w, h));
      const g = target.getContext('2d');
      g.clearRect(0, 0, w, h); g.drawImage(cv, 0, 0);
    }
    async function still(target, id) {
      const k = id + '|' + key() + '|' + target.width;
      if (cache.has(k)) { target.getContext('2d').drawImage(cache.get(k), 0, 0); return; }
      const srcs = await list();
      if (!target.isConnected) return;
      draw(target, id, 1.0, srcs);
      const c = document.createElement('canvas'); c.width = target.width; c.height = target.height;
      c.getContext('2d').drawImage(target, 0, 0);
      cache.set(k, c);
    }
    function hover(target, id) {
      let run = true;
      const t0 = performance.now();
      list().then(srcs => {
        const loop = (ts) => { if (!run || !target.isConnected) return; draw(target, id, ((ts - t0) / 1000 + 1.0) % 5, srcs); requestAnimationFrame(loop); };
        requestAnimationFrame(loop);
      });
      return () => { run = false; still(target, id); };
    }
    /* "Show animations": every registered preview animates, round-robin so it stays smooth */
    let all = [], raf = 0, cursor = 0, allOn = false;
    function register(target, id) { all.push({ c: target, id }); }
    function animateAll(on) {
      allOn = on;
      cancelAnimationFrame(raf);
      all = all.filter(it => it.c.isConnected);
      if (!on) { for (const it of all) still(it.c, it.id); return; }
      const t0 = performance.now();
      list().then(srcs => {
        const loop = (ts) => {
          if (!allOn) return;
          all = all.filter(it => it.c.isConnected);
          const per = Math.max(1, Math.ceil(all.length / 5));
          for (let k = 0; k < per && all.length; k++) {
            const it = all[(cursor + k) % all.length];
            const r = it.c.getBoundingClientRect();
            if (r.bottom > -50 && r.top < window.innerHeight + 50) draw(it.c, it.id, ((ts - t0) / 1000 + 1.0) % 5, srcs);
          }
          cursor = all.length ? (cursor + per) % all.length : 0;
          raf = requestAnimationFrame(loop);
        };
        raf = requestAnimationFrame(loop);
      });
    }
    return { still, hover, register, animateAll, isAllOn: () => allOn, invalidate: () => cache.clear() };
  })();
  function previewCanvas(id, w, h) {
    const c = el('canvas', 'pv'); c.width = w; c.height = h;
    Previews.still(c, id);
    Previews.register(c, id);
    let stop = null;
    return { c, enter: () => { if (!stop && !Previews.isAllOn()) stop = Previews.hover(c, id); }, leave: () => { if (stop) { stop(); stop = null; } } };
  }
  function syncAnimAll() {
    let on = true;
    try { const v = localStorage.getItem('c3d.animAll'); on = v === null ? true : v === '1'; } catch (e) {}
    $('#sw-anim').classList.toggle('on', on);
    Previews.animateAll(on);
  }
  $('#sw-anim').addEventListener('click', () => {
    const on = !$('#sw-anim').classList.contains('on');
    try { localStorage.setItem('c3d.animAll', on ? '1' : '0'); } catch (e) {}
    syncAnimAll();
  });
  function renderStrip() {
    const strip = $('#tstrip'); strip.innerHTML = '';
    for (const t of allTemplates()) {
      const b = el('button', 'tcard' + (t.id === state.template ? ' on' : ''));
      const pv = previewCanvas(t.id, 72, 54);
      b.append(pv.c, el('div', 'nm', t.name));
      b.title = t.name; b.addEventListener('click', () => applyTemplate(t.id));
      b.addEventListener('mouseenter', pv.enter); b.addEventListener('mouseleave', pv.leave);
      strip.appendChild(b);
    }
    const on = strip.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    if (Previews.isAllOn()) Previews.animateAll(true);
  }
  function renderGallery() {
    const g = $('#gallery'); g.innerHTML = '';
    const cats = [];
    for (const t of allTemplates()) if (!cats.includes(t.cat)) cats.push(t.cat);
    for (const c of cats) {
      g.appendChild(el('div', 'cat', c));
      const grid = el('div', 'ggrid');
      for (const t of allTemplates().filter(x => x.cat === c)) {
        const b = el('button', 'gcard' + (t.id === state.template ? ' on' : ''));
        const set = t.set || {};
        const sub = (LAYOUTS[set.layout || 'carousel'].name) + ' · ' + (MOTIONS[set.motion || 'step'].name.split(' ')[0]);
        const pv = previewCanvas(t.id, 120, 96);
        const star = el('button', 'fav' + (favs.includes(t.id) ? ' on' : ''), icon('star', 14));
        star.title = favs.includes(t.id) ? 'Remove from favorites' : 'Add to favorites';
        star.addEventListener('click', (e) => { e.stopPropagation(); toggleFav(t.id); });
        b.append(pv.c, el('div', 'nm', t.name), el('div', 'sub', t.user ? 'custom' : sub), star);
        b.addEventListener('click', () => { applyTemplate(t.id); showScreen('editor'); });
        b.addEventListener('mouseenter', pv.enter); b.addEventListener('mouseleave', pv.leave);
        grid.appendChild(b);
      }
      g.appendChild(grid);
    }
    syncAnimAll();
  }
  function savePreset() {
    const name = prompt('Preset name', 'My preset ' + (userPresets.length + 1));
    if (!name) return;
    userPresets.push({ id: 'user_' + Date.now().toString(36), name, state: JSON.parse(JSON.stringify(state)) });
    try { localStorage.setItem('c3d.userPresets', JSON.stringify(userPresets)); } catch (e) {}
    state.template = userPresets[userPresets.length - 1].id;
    renderStrip(); toast('Preset saved', 'ok');
  }
  function randomize() {
    const pick = (o) => { const k = Object.keys(o); return k[Math.floor(Math.random() * k.length)]; };
    commit(() => {
      state.layout = pick(LAYOUTS);
      const motions = Object.keys(MOTIONS).filter(k => k !== 'still');
      state.motion = motions[Math.floor(Math.random() * motions.length)];
      state.ease = pick(EASINGS);
      state.camera.preset = Math.random() < 0.5 ? 'static' : pick(CAMERAS);
      const io = Math.random() < 0.5;
      state.intro.enabled = io; state.outro.enabled = io;
      if (io) { state.intro.style = pick(INTROS); state.outro.style = pick(INTROS); }
      state.fx.reflection = Math.random() < 0.3 ? 0.4 : 0;
      state.fx.shadow = Math.random() < 0.3 ? 0.4 : 0;
      state.template = '';
    });
    toast(LAYOUTS[state.layout].name + ' · ' + MOTIONS[state.motion].name + ' · ' + CAMERAS[state.camera.preset].name);
  }

  /* ------------------------------------------------------------ top bar */
  function syncTop() {
    $('#btn-undo').disabled = !undo.length;
    $('#btn-redo').disabled = !redo.length;
    $('#dur').value = state.duration;
    $('#dir-l').classList.toggle('on', state.dir < 0);
    $('#dir-r').classList.toggle('on', state.dir > 0);
    $('#sel-aspect').value = state.aspect;
    if (!BGS.includes(state.previewBg)) state.previewBg = 'black';
    phone.classList.toggle('checker', state.previewBg === 'checker');
    phone.style.background = state.previewBg === 'checker' ? '' : state.previewBg;
    if (time > state.duration) time = 0;
  }
  function showScreen(name) { Hub.show(name); }
  document.addEventListener('screenchange', (e) => { if (e.detail === 'gallery') renderGallery(); });
  /* used by the hub and the stock browser ("Use in 3D Carousel") */
  window.CarouselTool = { addPaths: async (paths, opt) => { await addInputs(paths); if (!(opt && opt.stay)) showScreen('editor'); }, show: showScreen, count: () => sourceIds.length };
  $('#btn-back').addEventListener('click', () => showScreen('gallery'));
  $('#btn-gallery').addEventListener('click', () => showScreen('gallery'));
  $('#g-open').addEventListener('click', () => showScreen('editor'));
  $('#btn-undo').addEventListener('click', doUndo);
  $('#btn-redo').addEventListener('click', doRedo);
  $('#btn-random').addEventListener('click', randomize);
  $('#sw-adv').addEventListener('click', () => { document.body.classList.toggle('advanced'); $('#sw-adv').classList.toggle('on', document.body.classList.contains('advanced')); persist(); });
  $('#dur').addEventListener('change', (e) => { const v = clamp(parseFloat(e.target.value) || 5, 0.5, 60); commit(() => { state.duration = v; }); });
  $('#dir-l').addEventListener('click', () => commit(() => { state.dir = -1; }));
  $('#dir-r').addEventListener('click', () => commit(() => { state.dir = 1; }));
  $('#sel-aspect').addEventListener('change', (e) => commit(() => { state.aspect = e.target.value; }));
  $('#btn-bg').addEventListener('click', () => { state.previewBg = BGS[(BGS.indexOf(state.previewBg) + 1) % BGS.length]; syncTop(); persist(); });
  $('#btn-play').addEventListener('click', togglePlay);
  $('#scrub').addEventListener('input', (e) => { time = e.target.value / 1000 * state.duration; if (playing) togglePlay(); });
  document.addEventListener('keydown', (e) => {
    const tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'select' || tag === 'textarea') return;
    if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? doRedo() : doUndo(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); doRedo(); }
  });
  function togglePlay() {
    playing = !playing;
    syncPlayIcon();
    if (playing) Sources.playAll(sourceIds); else Sources.pauseAll();
  }
  function syncPlayIcon() {
    $('#ico-play').innerHTML = playing ? '<path d="M7 4h4v16H7zM13 4h4v16h-4z"/>' : '<path d="M6 4l14 8-14 8z"/>';
  }

  /* ------------------------------------------------------------ export */
  const progressUI = {
    show() { $('#progress').classList.add('show'); this.progress(0, ''); },
    hide() { $('#progress').classList.remove('show'); },
    title(t) { $('#prog-title').textContent = t; },
    progress(p, txt) { $('#prog-bar').style.width = Math.round(p * 100) + '%'; $('#prog-text').textContent = txt || ''; }
  };
  /* one Cancel for every tool: the carousel's own flag, and every engine process the panel has running */
  $('#prog-cancel').addEventListener('click', () => { Exporter.cancel(); try { const n = CS.cancelJobs(); if (n) $('#prog-text').textContent = 'Stopping…'; } catch (e) {} });
  let exporting = false;
  async function withExport(fn) {
    if (exporting) return;
    exporting = true;
    const wasPlaying = playing; if (playing) togglePlay();
    progressUI.show();
    try { await fn(); }
    catch (e) { toast(e.message || String(e), 'err'); }
    finally { progressUI.hide(); exporting = false; if (wasPlaying && !playing) togglePlay(); }
  }
  $('#btn-add').addEventListener('click', async () => { if (!await License.guardExport('carousel', 'carousel export')) return; withExport(async () => {
    if (!sourceIds.length) throw new Error('Add some images or video first.');
    const r = await Exporter.addToTimeline(state, sourceIds, progressUI);
    editing = null;
    renderControls();
    reportResult(r);
  }); });
  async function exportFrames() {
    await withExport(async () => {
      if (!sourceIds.length) throw new Error('Add some images or video first.');
      const a = ASPECTS[state.aspect] || 9 / 16;
      const h = 1920, w = Math.round(h * a / 2) * 2;
      const dir = await Exporter.exportToFolder(state, sourceIds, progressUI, a < 1 ? w : 1920, a < 1 ? h : Math.round(1920 / a / 2) * 2, 30);
      if (dir) toast('PNG sequence saved to ' + dir, 'ok');
    });
  }

  /* ------------------------------------------------------------ preview loop */
  function fitCanvas() {
    const a = ASPECTS[state.aspect] || 9 / 16;
    const scr = $('#screen-editor');
    const wide = scr.clientWidth >= 760;
    if (scr.classList.contains('wide') !== wide) scr.classList.toggle('wide', wide);
    const availW = Math.max(200, (wide ? $('.preview-wrap').clientWidth : scr.clientWidth) - 24);
    const availH = wide ? Math.max(220, scr.clientHeight - 110) : Math.max(220, Math.min(window.innerHeight * 0.5, 620));
    let w = Math.min(availW, availH * a), h = w / a;
    if (h > availH) { h = availH; w = h * a; }
    phone.style.width = Math.round(w) + 'px'; phone.style.height = Math.round(h) + 'px';
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = Math.round(w * dpr), ch = Math.round(h * dpr);
    if (renderer) renderer.setSize(cw, ch);
  }
  function frame(ts) {
    const dt = lastTs ? Math.min(0.1, (ts - lastTs) / 1000) : 0; lastTs = ts;
    if (playing) { time += dt; if (time >= state.duration) time -= state.duration; }
    if (Hub.current() !== 'editor') { requestAnimationFrame(frame); return; }
    fitCanvas();
    if (renderer && !glFailed) {
      try {
        const sc = buildScene(state, sourceIds.map(id => Sources.get(id)).filter(Boolean), time, canvas.width, canvas.height);
        lastRawPhase = sc.rawPhase || 0;
        renderer.render(sc);
        if (lingerDraw) lingerDraw();
        if (timingDraw) timingDraw();
      }
      catch (e) { glFailed = true; $('#warn').textContent = 'Render error: ' + e.message; $('#warn').style.display = 'block'; console.error(e); }
    }
    $('#scrub').value = Math.round(time / state.duration * 1000);
    $('#time').textContent = time.toFixed(2) + ' / ' + state.duration.toFixed(2);
    requestAnimationFrame(frame);
  }

  let invertY = localStorage.getItem('c3d.invertY2') === '1';
  function mkInvert() {
    const b = el('button', 'switch' + (invertY ? ' on' : ''));
    b.addEventListener('click', () => { invertY = !invertY; b.classList.toggle('on', invertY); try { localStorage.setItem('c3d.invertY2', invertY ? '1' : '0'); } catch (e) {} });
    return b;
  }
  /* ------------------------------------------------------------ gizmo (rotate the carousel / orbit the camera) */
  function mountGizmo() {
    const gz = $('#gizmo'); if (!gz || !canvas) return;
    const R = 36, RX = 13;
    const hit = (e) => {
      const rc = gz.getBoundingClientRect(), x = (e.clientX - rc.left) / rc.width * 84 - 42, y = (e.clientY - rc.top) / rc.height * 84 - 42;
      const r = Math.hypot(x, y);
      if (r < 10) return 'orbit';
      const ef = Math.hypot(x / R, y / RX), ev = Math.hypot(x / RX, y / R);
      if (Math.abs(ef - 1) < 0.2) return 'ry';
      if (Math.abs(ev - 1) < 0.2) return 'rx';
      if (Math.abs(r - R) < 7) return 'rz';
      return '';
    };
    let drag = null;
    const start = (axis, e) => {
      if (!axis) return;
      drag = { axis, x: e.clientX, y: e.clientY, snap: snapshot(), g: Object.assign({}, state.group), cam: Object.assign({}, state.camera), a0: Math.atan2(e.clientY - (gz.getBoundingClientRect().top + gz.getBoundingClientRect().height / 2), e.clientX - (gz.getBoundingClientRect().left + gz.getBoundingClientRect().width / 2)) };
      gz.classList.add('grabbing'); phone.classList.add('dragging'); e.preventDefault();
    };
    gz.addEventListener('mousemove', (e) => { if (!drag) gz.dataset.hot = hit(e); });
    gz.addEventListener('mouseleave', () => { if (!drag) gz.dataset.hot = ''; });
    gz.addEventListener('mousedown', (e) => start(hit(e), e));
    gz.addEventListener('dblclick', () => commit(() => { state.group = { rx: 0, ry: 0, rz: 0 }; state.camera.yaw = 0; state.camera.pitch = 0; }));
    /* dragging the preview itself orbits the camera; the wheel zooms */
    canvas.addEventListener('mousedown', (e) => { if (e.button === 0) start('orbit', e); });
    let wheelTimer = null, wheelSnap = null;
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (!wheelSnap) wheelSnap = snapshot();
      state.camera.zoom = clamp(+(state.camera.zoom * (1 + Math.sign(e.deltaY) * 0.06)).toFixed(3), 0.4, 3);
      clearTimeout(wheelTimer); wheelTimer = setTimeout(() => { pushUndo(wheelSnap); wheelSnap = null; afterChange(); }, 400);
    }, { passive: false });
    window.addEventListener('mousemove', (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      const sy = invertY ? -1 : 1;
      if (drag.axis === 'orbit') { state.camera.yaw = clamp(Math.round(drag.cam.yaw + dx * 0.4), -90, 90); state.camera.pitch = clamp(Math.round(drag.cam.pitch + sy * dy * 0.3), -60, 60); }
      else if (drag.axis === 'ry') state.group.ry = wrap180(drag.g.ry + dx * 0.6);
      else if (drag.axis === 'rx') state.group.rx = clamp(Math.round(drag.g.rx - sy * dy * 0.6), -90, 90);
      else if (drag.axis === 'rz') { const rc = gz.getBoundingClientRect(); const a = Math.atan2(e.clientY - (rc.top + rc.height / 2), e.clientX - (rc.left + rc.width / 2)); state.group.rz = clamp(Math.round(drag.g.rz + (a - drag.a0) * 180 / Math.PI), -90, 90); }
    });
    window.addEventListener('mouseup', () => {
      if (!drag) return;
      const d = drag; drag = null; gz.classList.remove('grabbing'); phone.classList.remove('dragging'); gz.dataset.hot = '';
      if (snapshot() !== d.snap) { pushUndo(d.snap); afterChange(); }
    });
  }
  const wrap180 = (v) => { v = Math.round(v); while (v > 180) v -= 360; while (v < -180) v += 360; return v; };

  /* ------------------------------------------------------------ boot */
  async function boot() {
    try { renderer = new Renderer(canvas); }
    catch (e) { glFailed = true; $('#warn').textContent = e.message; $('#warn').style.display = 'block'; }
    try { userPresets = JSON.parse(localStorage.getItem('c3d.userPresets') || '[]'); } catch (e) { userPresets = []; }
    try {
      const saved = localStorage.getItem('c3d.state');
      if (saved) {
        const s = JSON.parse(saved);
        if (typeof s.bg === 'string') { s.previewBg = s.bg; delete s.bg; }   /* migrate v1 settings */
        state = deepMerge(deepMerge({}, DEFAULTS), s);
        if (state.output !== 'render') state.output = 'render';   /* native keyframe mode was retired */
        /*  The defaults changed (9:16 / speed 1 / linger 0 -> 16:9 / 0.75 / 0.10): a saved state still on the
            old ones was never touched by its owner, so it moves along once; anything they set stays.  */
        if (!localStorage.getItem('c3d.defaults2')) {
          if (s.aspect === '9:16') state.aspect = '16:9';
          if (s.speed === 1 || s.speed === undefined) state.speed = 0.75;
          if (!s.linger) state.linger = 0.1;
        }
      }
      try { localStorage.setItem('c3d.defaults2', '1'); } catch (e2) {}
      if (localStorage.getItem('c3d.adv') === '1') { document.body.classList.add('advanced'); $('#sw-adv').classList.add('on'); }
    } catch (e) {}
    Hub.init();
    const licBoot = License.init();
    mountGizmo();
    $('#btn-add2').addEventListener('click', () => $('#btn-add').click());
    Stock.init();
    Assist.init();
    QuickFX.init();
    if (typeof Race !== 'undefined') Race.init();
    if (typeof Curves !== 'undefined') Curves.init();
    Transitions.init();
    Social.init();
    AudioAI.init();
    if (typeof Matte !== 'undefined') Matte.init();
    if (typeof Relight !== 'undefined') Relight.init();
    Update.init();
    Usage.init();
    Celebrate.init();
    Sidebar.render();
    /* the one-time "keep yours or take the new default" card, once the panel has settled and no update card is up */
    if (!licBoot.firstOpen) setTimeout(() => { try { Sidebar.maybeAskDefault(); } catch (e) {} }, 2500);
    $('#qfx-open').addEventListener('click', () => QuickFX.show());
    if (licBoot.firstOpen) License.showLogin(); else Hub.show('home');
    /* the walk through the tools, once, after the login screen has had its turn */
    const tourBtn = $('#home-tour');
    if (tourBtn && typeof Tour !== 'undefined') tourBtn.addEventListener('click', () => Tour.start('button'));
    if (typeof Tour !== 'undefined') {
      if (licBoot.firstOpen) document.addEventListener('screenchange', function once(e) { if (e.detail === 'home') { document.removeEventListener('screenchange', once); Tour.maybeFirstRun(); } });
      else Tour.maybeFirstRun();
    }
    afterChange();
    syncPlayIcon();
    requestAnimationFrame(frame);
    if (CS.inCEP) {
      const ok = await CS.loadHostScript();
      if (!ok) toast('Host script did not load. Restart Premiere and try again.', 'err');
      try {
        const paths = JSON.parse(localStorage.getItem('c3d.paths') || '[]');
        const existing = paths.filter(p => CS.fs && CS.fs.existsSync(p));
        if (existing.length) { await addInputs(existing); undo.length = 0; syncTop(); }
      } catch (e) {}
    } else if (!sourceIds.length) {
      /* demo cards when previewing in a plain browser */
      await addInputs(await demoCards());
      undo.length = 0; syncTop();
    }
  }
  async function demoCards() {
    const cols = [['#3a7bff', '#6fa2ff'], ['#19b3a6', '#4bd8cc'], ['#c53fd0', '#e57cf0'], ['#e8b331', '#f4d36b'], ['#ff6a4d', '#ff9b85']];
    const files = [];
    for (let i = 0; i < cols.length; i++) {
      const cv = document.createElement('canvas'); cv.width = 540; cv.height = 960;
      const g = cv.getContext('2d');
      const gr = g.createLinearGradient(0, 0, 540, 960); gr.addColorStop(0, cols[i][0]); gr.addColorStop(1, cols[i][1]);
      g.fillStyle = gr; g.fillRect(0, 0, 540, 960);
      g.fillStyle = 'rgba(255,255,255,.92)'; g.font = 'bold 200px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(String(i + 1).padStart(2, '0'), 270, 480);
      const blob = await new Promise(res => cv.toBlob(res, 'image/png'));
      files.push(new File([blob], 'demo' + (i + 1) + '.png', { type: 'image/png' }));
    }
    return files;
  }

  boot();
})();
