/*  3D Carousel - Premiere Pro host script (ExtendScript, ES3)
    Called from the panel through CSInterface.evalScript.
    Every function returns a JSON string so the panel can parse it.        */

var C3D_TICKS_PER_SECOND = 254016000000;

function C3D_json(v) {
    if (v === null || v === undefined) return "null";
    var t = typeof v;
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") {
        var s = v.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
        s = s.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t");
        return '"' + s + '"';
    }
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(C3D_json(v[i]));
        return "[" + a.join(",") + "]";
    }
    var o = [];
    for (var k in v) if (v.hasOwnProperty(k)) o.push(C3D_json(k) + ":" + C3D_json(v[k]));
    return "{" + o.join(",") + "}";
}

function C3D_err(msg) { return C3D_json({ ok: false, error: String(msg) }); }

function C3D_ping() { return C3D_json({ ok: true, app: app.name, version: app.version }); }

function C3D_getSequenceInfo() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var fps = C3D_TICKS_PER_SECOND / parseFloat(seq.timebase);
        var pos = seq.getPlayerPosition();
        var projDir = "";
        try {
            if (app.project.path) {
                var pf = new File(app.project.path);
                if (pf.parent) projDir = pf.parent.fsName;
            }
        } catch (e0) {}
        var docs = "";
        try { docs = Folder.myDocuments.fsName; } catch (e1) {}
        return C3D_json({
            ok: true,
            name: seq.name,
            fps: fps,
            width: seq.frameSizeHorizontal,
            height: seq.frameSizeVertical,
            playhead: pos ? pos.seconds : 0,
            projectDir: projDir,
            documents: docs,
            tracks: seq.videoTracks.numTracks
        });
    } catch (e) { return C3D_err(e); }
}

function C3D_findBin(parent, name) {
    for (var i = 0; i < parent.children.numItems; i++) {
        var c = parent.children[i];
        if (c.type === ProjectItemType.BIN && c.name === name) return c;
    }
    return null;
}

/*  One "Outflow" bin in the project panel, with a bin per tool inside it, instead of eight loose folders.
    A bin left at the top level by an older version is moved in rather than duplicated.                     */
function C3D_outflowBin() {
    var root = app.project.rootItem;
    var bin = C3D_findBin(root, "Outflow");
    if (!bin) { try { root.createBin("Outflow"); } catch (e) {} bin = C3D_findBin(root, "Outflow"); }
    return bin || root;
}
function C3D_toolBin(name) {
    var root = app.project.rootItem, parent = C3D_outflowBin();
    if (parent === root) return C3D_findBin(root, name) || root;   /* the parent could not be made: behave as before */
    /* strip a leading "Outflow" and whatever separator follows it, by hand: no regex, nothing ES3 can trip over */
    var leaf = String(name);
    if (leaf.length > 8 && leaf.substr(0, 7) === "Outflow") {
        leaf = leaf.substr(7);
        while (leaf.length) {
            var ch = leaf.charCodeAt(0);
            if (ch === 32 || ch === 45 || ch === 183) leaf = leaf.substr(1); else break;
        }
    }
    if (!leaf) leaf = String(name);
    var bin = C3D_findBin(parent, leaf) || C3D_findBin(parent, name);
    if (bin) return bin;
    /* left over from before there was a parent bin */
    var old = C3D_findBin(root, name) || C3D_findBin(root, leaf);
    if (old) {
        try { old.moveBin(parent); } catch (e1) {}
        try { if (old.name !== leaf) old.name = leaf; } catch (e2) {}
        var moved = C3D_findBin(parent, leaf) || C3D_findBin(parent, name);
        if (moved) return moved;
    }
    try { parent.createBin(leaf); } catch (e3) {}
    return C3D_findBin(parent, leaf) || parent;
}

function C3D_norm(p) { return String(p).replace(/\\/g, "/").toLowerCase(); }

function C3D_findItemByPath(parent, path, depth) {
    var want = C3D_norm(path);
    for (var i = 0; i < parent.children.numItems; i++) {
        var c = parent.children[i];
        if (c.type === ProjectItemType.BIN) {
            if (depth < 4) { var r = C3D_findItemByPath(c, path, depth + 1); if (r) return r; }
        } else {
            try { if (C3D_norm(c.getMediaPath()) === want) return c; } catch (e) {}
        }
    }
    return null;
}

function C3D_findFreeTrack(seq, s, e) {
    var top = -1;
    for (var i = 0; i < seq.videoTracks.numTracks; i++) {
        var tr = seq.videoTracks[i];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j];
            if (c.start.seconds < e && c.end.seconds > s) top = i;
        }
    }
    return top + 1;
}

function C3D_addVideoTrack(seq) {
    var before = seq.videoTracks.numTracks;
    try {
        app.enableQE();
        var q = qe.project.getActiveSequence();
        q.addTracks(1, before, 0, 1, 0, 0, 1);
    } catch (e) {}
    var after = app.project.activeSequence.videoTracks.numTracks;
    if (after > before) return true;
    try {
        var q2 = qe.project.getActiveSequence();
        q2.addTracks(1, 0, 0, 0, 0, 0, 0);
    } catch (e2) {}
    return app.project.activeSequence.videoTracks.numTracks > before;
}

/*  firstFile : full path of the first PNG of the numbered sequence
    fps       : frame rate to interpret the stills with
    duration  : clip length in seconds (used to find a free track)
    trackIndex: -1 = first free track above the footage at the playhead
    binName   : project bin to import into
    clipName  : display name of the project item                            */
function C3D_importAndInsert(firstFile, fps, duration, trackIndex, binName, clipName, startSec, minTrack) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var f = new File(firstFile);
        if (!f.exists) return C3D_err("Rendered frames not found: " + firstFile);
        var isVideo = /\.(mov|mp4)$/i.test(firstFile);

        var root = app.project.rootItem;
        var bin = C3D_toolBin(binName) || root;

        app.project.importFiles([firstFile], true, bin, !isVideo);

        var item = C3D_findItemByPath(bin, firstFile, 0);
        if (!item) item = C3D_findItemByPath(root, firstFile, 0);
        if (!item && bin.children.numItems > 0) item = bin.children[bin.children.numItems - 1];
        if (!item) return C3D_err("Import failed. Check the rendered " + (isVideo ? "clip" : "PNG sequence") + " in " + f.parent.fsName);

        var fpsApplied = isVideo;   /* a video clip carries its own frame rate */
        if (!isVideo) try {
            var interp = item.getFootageInterpretation();
            if (interp) {
                interp.frameRate = fps;
                fpsApplied = item.setFootageInterpretation(interp) ? true : false;
            }
        } catch (e1) {}
        if (!fpsApplied) { try { item.setOverrideFrameRate(fps); } catch (e2) {} }
        try { item.name = clipName; } catch (e3) {}

        var start = (typeof startSec === "number" && startSec >= 0) ? startSec : seq.getPlayerPosition().seconds;
        var end = start + duration;
        var idx = (trackIndex >= 0) ? trackIndex : C3D_findFreeTrack(seq, start, end);
        if (typeof minTrack === "number" && idx < minTrack) idx = minTrack;   /* e.g. two above the source, leaving an empty track between */
        var guard = 0;
        while (idx >= app.project.activeSequence.videoTracks.numTracks && guard < 4) {
            if (!C3D_addVideoTrack(app.project.activeSequence))
                return C3D_err("No empty video track above your footage. Add one and try again.");
            guard++;
        }
        seq = app.project.activeSequence;
        var track = seq.videoTracks[idx];
        var placed = false;
        try { placed = track.overwriteClip(item, start); } catch (e4) {}
        if (!placed) {
            try { var tm = new Time(); tm.seconds = start; placed = track.overwriteClip(item, tm); } catch (e5) {}
        }
        if (!placed) {
            try { placed = track.insertClip(item, start); } catch (e6) {}
        }
        if (!placed) return C3D_err("Could not place the clip on track V" + (idx + 1));
        return C3D_json({ ok: true, track: idx, start: start, fpsApplied: fpsApplied });
    } catch (e) { return C3D_err(e); }
}


/* ---------------- diagnostic log (same file as the panel's Log module) ---------------- */
var C3D_LOG_FILE = "";
function C3D_setLogFile(path) { C3D_LOG_FILE = path || ""; return C3D_json({ ok: true }); }
function C3D_log(tag, msg) {
    if (!C3D_LOG_FILE) return;
    try {
        var f = new File(C3D_LOG_FILE);
        f.encoding = "UTF-8";
        /* ExtendScript has no append mode: open for edit and seek to the end */
        var opened = f.exists ? f.open("e") : f.open("w");
        if (opened) {
            try { f.seek(0, 2); } catch (es) {}
            var d = new Date();
            var pad = function (n, w) { var s = String(n); while (s.length < (w || 2)) s = "0" + s; return s; };
            var stamp = d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds()) + "." + pad(d.getMilliseconds(), 3);
            f.writeln(stamp + " HOST  [" + tag + "] " + String(msg));
            f.close();
        }
    } catch (e) {}
}
/* compact description of a clip for the log */
function C3D_clipDesc(c) {
    try { return "'" + c.name + "' " + c.start.seconds.toFixed(3) + "-" + c.end.seconds.toFixed(3) + (c.nodeId !== undefined ? " #" + c.nodeId : ""); } catch (e) { return "(clip?)"; }
}
