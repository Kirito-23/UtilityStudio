/* Column-major 4x4 matrix helpers (gl-matrix style, minimal). */
const Mat4 = {
  identity() { return [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]; },
  multiply(a, b) {
    const o = new Array(16);
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
      o[c*4+r] = a[r]*b[c*4] + a[4+r]*b[c*4+1] + a[8+r]*b[c*4+2] + a[12+r]*b[c*4+3];
    }
    return o;
  },
  perspective(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return [f/aspect,0,0,0, 0,f,0,0, 0,0,(far+near)*nf,-1, 0,0,2*far*near*nf,0];
  },
  lookAt(eye, target, up) {
    let zx = eye[0]-target[0], zy = eye[1]-target[1], zz = eye[2]-target[2];
    let l = Math.hypot(zx,zy,zz) || 1; zx/=l; zy/=l; zz/=l;
    let xx = up[1]*zz - up[2]*zy, xy = up[2]*zx - up[0]*zz, xz = up[0]*zy - up[1]*zx;
    l = Math.hypot(xx,xy,xz) || 1; xx/=l; xy/=l; xz/=l;
    const yx = zy*xz - zz*xy, yy = zz*xx - zx*xz, yz = zx*xy - zy*xx;
    return [xx,yx,zx,0, xy,yy,zy,0, xz,yz,zz,0,
      -(xx*eye[0]+xy*eye[1]+xz*eye[2]), -(yx*eye[0]+yy*eye[1]+yz*eye[2]), -(zx*eye[0]+zy*eye[1]+zz*eye[2]), 1];
  },
  translate(m, x, y, z) {
    const t = Mat4.identity(); t[12]=x; t[13]=y; t[14]=z; return Mat4.multiply(m, t);
  },
  scale(m, x, y, z) {
    const s = Mat4.identity(); s[0]=x; s[5]=y; s[10]=z; return Mat4.multiply(m, s);
  },
  rotateX(m, a) { const c=Math.cos(a), s=Math.sin(a); return Mat4.multiply(m, [1,0,0,0, 0,c,s,0, 0,-s,c,0, 0,0,0,1]); },
  rotateY(m, a) { const c=Math.cos(a), s=Math.sin(a); return Mat4.multiply(m, [c,0,-s,0, 0,1,0,0, s,0,c,0, 0,0,0,1]); },
  rotateZ(m, a) { const c=Math.cos(a), s=Math.sin(a); return Mat4.multiply(m, [c,s,0,0, -s,c,0,0, 0,0,1,0, 0,0,0,1]); },
  transformPoint(m, p) {
    const x=p[0], y=p[1], z=p[2];
    return [m[0]*x+m[4]*y+m[8]*z+m[12], m[1]*x+m[5]*y+m[9]*z+m[13], m[2]*x+m[6]*y+m[10]*z+m[14], m[3]*x+m[7]*y+m[11]*z+m[15]];
  },
  transformDir(m, p) {
    const x=p[0], y=p[1], z=p[2];
    return [m[0]*x+m[4]*y+m[8]*z, m[1]*x+m[5]*y+m[9]*z, m[2]*x+m[6]*y+m[10]*z];
  }
};
