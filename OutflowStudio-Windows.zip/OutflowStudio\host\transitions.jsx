/*  Outflow Studio - transitions (ExtendScript, ES3). Requires index.jsx, native.jsx, quickfx.jsx, tools.jsx.
    A transition is a set of keyframed effects on an adjustment layer that sits
    across a cut (or, when the project has no adjustment layer and none can be
    made, on the outgoing and incoming clips themselves).                       */

/* names compared with apostrophes / quotes / spaces normalised ("Composition's" vs "Composition’s") */
function TR_normName(s) { return String(s).toLowerCase().replace(/[‘’‚′`']/g, "'").replace(/[“”]/g, '"').replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }
function TR_propByName(comp, name, aliases) {
    var i, n, names = [name].concat(aliases || []), k;
    for (k = 0; k < names.length; k++) {
        var want = TR_normName(names[k]);
        for (i = 0; i < comp.properties.numItems; i++) {
            n = ""; try { n = TR_normName(comp.properties[i].displayName); } catch (e) {}
            if (n === want) return comp.properties[i];
        }
    }
    var low = TR_normName(name);
    for (i = 0; i < comp.properties.numItems; i++) {
        n = ""; try { n = TR_normName(comp.properties[i].displayName); } catch (e2) {}
        if (n.indexOf(low) === 0) return comp.properties[i];
    }
    return null;
}

/* first track directly above the clips that meet at the cut, with [s,e] free on it */
function TR_trackAbove(seq, cut, s, e, eps) {
    var top = -1, t, j;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        var tr = seq.videoTracks[t];
        for (j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j]; if (c.start.seconds < e + eps && c.end.seconds > s - eps) top = Math.max(top, t); }
    }
    var idx = top + 1;
    while (idx < seq.videoTracks.numTracks) {
        var busy = false, tr2 = seq.videoTracks[idx];
        for (j = 0; j < tr2.clips.numItems; j++) { var c2 = tr2.clips[j]; if (c2.start.seconds < e + eps && c2.end.seconds > s - eps) { busy = true; break; } }
        if (!busy) return idx;
        idx++;
    }
    return idx;
}

function TR_propNames(comp) {
    var out = [];
    try { for (var i = 0; i < comp.properties.numItems; i++) out.push(String(comp.properties[i].displayName)); } catch (e) {}
    return out.join(", ");
}

/*  Premiere has no scripting call that makes an adjustment layer. What works:
    import a tiny project file that already contains one (client/assets/
    adjustment-layer.prproj), move the item to the root bin, delete the import bin. */
/*  The project's own "Adjustment Layer" items (File > New > Adjustment Layer) are still
    media and refuse scripted keyframes. Our template declares video media, so the
    imported item gets a distinct name and is looked up by that exact name.            */
var TR_AL_NAME = "Outflow Adjustment Layer";
function TR_findVideoAL(parent, depth) {
    for (var i = 0; i < parent.children.numItems; i++) {
        var c = parent.children[i];
        if (c.type === ProjectItemType.BIN) { if (depth < 6) { var r = TR_findVideoAL(c, depth + 1); if (r) return r; } continue; }
        if (String(c.name) === TR_AL_NAME) return c;
    }
    return null;
}
function TR_importAdjustmentTemplate(templatePath) {
    if (!templatePath) return null;
    var f = new File(templatePath);
    if (!f.exists) return null;
    var root = app.project.rootItem;
    var before = {};
    for (var i = 0; i < root.children.numItems; i++) before[root.children[i].nodeId] = true;
    try { app.project.importFiles([f.fsName], true, root, false); } catch (e0) { return null; }
    /* whatever is new at the root is the import (usually a bin named after the file) */
    var item = null, importBin = null;
    for (var j = 0; j < root.children.numItems; j++) {
        var c = root.children[j];
        if (before[c.nodeId]) continue;
        if (c.type === ProjectItemType.BIN) { importBin = c; var inner = QF_findAdjustmentItem(c, 0); if (inner) item = inner; }
        else if (/adjustment/i.test(String(c.name))) item = c;
    }
    if (item && importBin) {
        try { item.moveBin(root); } catch (e1) {}
        try { importBin.deleteBin(); } catch (e2) {}
    }
    if (item) { try { item.name = TR_AL_NAME; } catch (e3) {} }
    return item;
}

function TR_createAdjustmentLayer(seq, templatePath) {
    var item = TR_importAdjustmentTemplate(templatePath);
    if (item) return item;
    /* last resort: an undocumented QE call, if this build has one */
    try {
        app.enableQE();
        var methods = qe.project.reflect.methods, names = [];
        for (var i = 0; i < methods.length; i++) names.push(String(methods[i].name));
        for (var k = 0; k < names.length; k++) {
            if (!/adjust/i.test(names[k])) continue;
            var fn = qe.project[names[k]];
            var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, tb = String(seq.timebase);
            var attempts = [[W, H, tb, 1, "Adjustment Layer"], [W, H, tb, 1], [W, H], []];
            for (var a = 0; a < attempts.length; a++) {
                try { fn.apply(qe.project, attempts[a]); } catch (e1) { continue; }
                var it = QF_findAdjustmentItem(app.project.rootItem, 0);
                if (it) return it;
            }
        }
    } catch (e) {}
    return null;
}


/*  o = { placements: [{ time, dur, effects: [{ name, params: [{ name, keys: [[t, v] | [t, x, y]], point, rel }] }] }],
          mode: "adjustment" | "clips", name, width, height, fps }
    keys are relative to the start of the transition (time - dur/2).               */
function TR_apply(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, warnings = [], placed = 0;
        var mode = o.mode || "adjustment";
        var adj = null, adjKind = "";
        if (mode === "adjustment") {
            adj = TR_findVideoAL(app.project.rootItem, 0); adjKind = adj ? "outflow" : "";
            if (!adj) { adj = TR_importAdjustmentTemplate(o.template); adjKind = adj ? "outflow-new" : ""; }
            if (!adj) { adj = QF_findAdjustmentItem(app.project.rootItem, 0); adjKind = adj ? "project" : ""; }
            if (!adj) { mode = "clips"; warnings.push("adjustment layer unavailable, keyframed on the clips"); }
        }
        var qeSeq = null;
        try { app.enableQE(); qeSeq = qe.project.getActiveSequence(); } catch (e0) {}
        if (!qeSeq) return C3D_err("QE DOM not available.");

        var applyEffects = function (clip, tIdx, clipStart, effects, tOff, clipMediaOffset) {
            try { qeSeq = qe.project.getActiveSequence(); } catch (eq) {}   /* fresh: tracks may have been added */
            var qc = C3D_qeClipAt(qeSeq, tIdx, clipStart);
            if (!qc) { warnings.push("QE clip not found at " + clipStart.toFixed(2)); return false; }
            for (var f = 0; f < effects.length; f++) {
                var fx = effects[f], comp = null;
                if (fx.name === "Motion" || fx.name === "Opacity") comp = C3D_componentByName(clip, fx.name);
                else {
                    if (!C3D_qeAddEffect(qc, fx.name)) { warnings.push("effect not found: " + fx.name); continue; }
                    clip = C3D_findClipAt(app.project.activeSequence.videoTracks[tIdx], clipStart) || clip;
                    comp = QF_lastComponentByName(clip, fx.name);
                }
                if (!comp) { warnings.push(fx.name + " component missing"); continue; }
                for (var p = 0; p < fx.params.length; p++) {
                    var pa = fx.params[p], prop = TR_propByName(comp, pa.name, pa.alias);
                    if (!prop) { if (!pa.optional) warnings.push(fx.name + ": no parameter '" + pa.name + "' (has: " + TR_propNames(comp) + ")"); continue; }
                    var conv;
                    if (pa.point) {
                        var norm = C3D_isNormalized(prop), base = [0.5, 0.5];
                        try { var dv = prop.getValue(); if (dv && dv.length === 2) base = dv; } catch (e2) {}
                        conv = function (kk) {
                            if (pa.rel) return norm ? [base[0] + kk[1], base[1] + kk[2]] : [base[0] + kk[1] * W, base[1] + kk[2] * H];
                            return norm ? [kk[1], kk[2]] : [kk[1] * W, kk[2] * H];
                        };
                    } else conv = function (kk) { return kk[1]; };
                    C3D_setKeys(prop, pa.keys, tOff + clipMediaOffset, conv, warnings, fx.name + "/" + pa.name);
                }
            }
            return true;
        };

        C3D_KEYS_WRITTEN = 0;
        if (mode === "adjustment") {
            /* the adjustment layer goes on the first free track directly above the clips at the cut */
            var fpsA = AS_fps(seq), epsA = 0.5 / fpsA, tIdx = -1, usedTrack = -1;
            for (var i = 0; i < o.placements.length; i++) {
                var pl = o.placements[i], s = pl.time - pl.dur / 2, e = pl.time + pl.dur / 2;
                if (s < 0) { e -= s; s = 0; }
                seq = app.project.activeSequence;
                tIdx = TR_trackAbove(seq, pl.time, s, e, epsA);
                while (tIdx >= app.project.activeSequence.videoTracks.numTracks) { if (!C3D_addVideoTrack(app.project.activeSequence)) { warnings.push("no track for placement " + i); break; } }
                seq = app.project.activeSequence;
                if (tIdx >= seq.videoTracks.numTracks) continue;
                usedTrack = tIdx;
                var track = seq.videoTracks[tIdx], ok = false;
                try { ok = track.overwriteClip(adj, s); } catch (e3) {}
                if (!ok) { warnings.push("placement " + i + " not placed"); continue; }
                var clip = C3D_findClipAt(track, s);
                if (!clip) { warnings.push("placement " + i + " not found"); continue; }
                try { var en = new Time(); en.seconds = e; clip.end = en; } catch (e4) { warnings.push("length: " + e4); }
                try { clip.name = o.name || "Transition"; } catch (e5) {}
                var before = C3D_KEYS_WRITTEN;
                var alIn = 0; try { alIn = clip.inPoint.seconds; } catch (e7) {}
                var okFx = applyEffects(clip, tIdx, s, pl.effects, 0, alIn);
                var expectKeys = 0;
                for (var q = 0; q < pl.effects.length; q++) for (var q2 = 0; q2 < pl.effects[q].params.length; q2++) if (pl.effects[q].params[q2].keys.length > 1) expectKeys++;
                /* Premiere refuses keyframes on still media: if none landed, take the layer away and keyframe the clips */
                if (okFx && expectKeys && C3D_KEYS_WRITTEN - before === 0) {
                    try { clip.remove(false, false); } catch (e6) {}
                    warnings.push("layer '" + adjKind + "' refused keyframes (still media); keyframed the clips instead");
                    mode = "clips";
                    break;
                }
                if (okFx) placed++;
            }
            if (mode === "adjustment") return C3D_json({ ok: true, placed: placed, mode: mode, track: usedTrack, keyframes: C3D_KEYS_WRITTEN, layer: adjKind, layerIn: alIn, warnings: warnings });
            placed = 0; C3D_KEYS_WRITTEN = 0;
        }

        /* clips mode: outgoing clip gets the first half, incoming the second half */
        var fps = AS_fps(seq), eps = 0.5 / fps;
        for (var j = 0; j < o.placements.length; j++) {
            var pj = o.placements[j], cut = pj.time, half = pj.dur / 2, done = 0;
            for (var t = 0; t < seq.videoTracks.numTracks; t++) {
                var tr = seq.videoTracks[t];
                for (var k = 0; k < tr.clips.numItems; k++) {
                    var c = tr.clips[k], isOut = Math.abs(c.end.seconds - cut) < eps, isIn = Math.abs(c.start.seconds - cut) < eps;
                    if (!isOut && !isIn) continue;
                    /* media time of the transition start inside this clip */
                    var mediaOffset = c.inPoint.seconds + ((cut - half) - c.start.seconds);
                    /* keep keyframes inside the clip: the outgoing clip only gets the first half, the incoming the second */
                    var trimmed = [];
                    for (var f2 = 0; f2 < pj.effects.length; f2++) {
                        var fx2 = pj.effects[f2], np = [];
                        for (var p2 = 0; p2 < fx2.params.length; p2++) {
                            var pa2 = fx2.params[p2], ks = [];
                            for (var k2 = 0; k2 < pa2.keys.length; k2++) {
                                var kt = pa2.keys[k2][0];
                                if (pa2.keys.length === 1 || (isOut && kt <= half + 0.0001) || (isIn && kt >= half - 0.0001)) ks.push(pa2.keys[k2]);
                            }
                            if (ks.length) np.push({ name: pa2.name, alias: pa2.alias, point: pa2.point, rel: pa2.rel, keys: ks });
                        }
                        if (np.length) trimmed.push({ name: fx2.name, params: np });
                    }
                    if (applyEffects(c, t, c.start.seconds, trimmed, 0, mediaOffset)) done++;
                }
            }
            if (done) placed++; else warnings.push("no clip boundary at " + cut.toFixed(2) + "s");
        }
        return C3D_json({ ok: true, placed: placed, mode: mode, keyframes: C3D_KEYS_WRITTEN, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}
