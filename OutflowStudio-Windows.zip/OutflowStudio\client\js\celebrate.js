/* The little party when a plan becomes active: blurred panel, a card with the plan, confetti.
   Celebrate.plan(me) is called by License when the entitlements go up (purchase or a grant). */
const Celebrate = (() => {
  const $ = (s) => document.querySelector(s);
  function confetti(x, y) {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const cv = document.createElement('canvas');
    Object.assign(cv.style, { position: 'fixed', left: 0, top: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 70 });
    document.body.appendChild(cv);
    const ctx = cv.getContext('2d'), dpr = Math.min(devicePixelRatio || 1, 2);
    cv.width = innerWidth * dpr; cv.height = innerHeight * dpr; ctx.scale(dpr, dpr);
    const colors = ['#4f8dff', '#7fb0ff', '#e2b04a', '#f4d36b', '#2fd0bf', '#ffffff'];
    const P = [];
    for (let i = 0; i < 160; i++) { const a = -Math.PI / 2 + (Math.random() - .5) * Math.PI * 1.2, v = 5 + Math.random() * 9; P.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, w: 5 + Math.random() * 6, h: 3 + Math.random() * 5, r: Math.random() * Math.PI, vr: (Math.random() - .5) * .35, c: colors[i % colors.length], t: 0, ttl: 1.8 + Math.random() * 1.4 }); }
    let last = 0;
    const loop = (ts) => {
      const dt = last ? Math.min(.05, (ts - last) / 1000) : .016; last = ts; const k = dt * 60;
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      let alive = 0;
      for (const p of P) {
        p.t += dt; if (p.t > p.ttl) continue; alive++;
        p.vy += .3 * k; p.vx *= Math.pow(.985, k); p.vy *= Math.pow(.992, k); p.x += p.vx * k; p.y += p.vy * k; p.r += p.vr * k;
        ctx.save(); ctx.globalAlpha = Math.min(1, (p.ttl - p.t) / .6); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore();
      }
      if (alive) requestAnimationFrame(loop); else cv.remove();
    };
    requestAnimationFrame(loop);
  }
  const PLAN = { monthly: 'Pro · monthly', yearly: 'Pro · yearly', lifetime: 'Pro · lifetime', tools: 'Creative tools' };
  const TOOLN = { carousel: '3D Carousel', transitions: 'Transitions' };
  function plan(me) {
    const m = $('#plan-modal'); if (!m) return;
    const pro = (me.features || []).includes('all');
    const what = pro ? (PLAN[me.plan] || 'Pro') : (me.tools && me.tools.length ? me.tools.map((t) => TOOLN[t] || t).join(' + ') + ' · unlimited' : 'Free');
    $('#pm-title').textContent = me.granted ? 'You have been granted ' + (pro ? 'Pro' : what.replace(' · unlimited', '')) : (pro ? 'Your Pro plan is active' : 'Your unlock is active');
    $('#pm-sub').textContent = me.granted ? 'A gift from Outflow Studio. Everything below is yours, no payment needed.' : 'Thank you for supporting Outflow Studio. Everything below is unlocked on this computer.';
    const items = pro ? ['Unlimited 3D Carousel and transitions', 'Auto Edit and every assistant', 'Remove music, downloads, overlays', 'Every new tool as it ships', (me.seats ? me.seats.max : 2) + ' computers'] : ['Unlimited exports in ' + what.replace(' · unlimited', ''), 'All templates and transitions', (me.seats ? me.seats.max : 2) + ' computers'];
    $('#pm-list').innerHTML = items.map((t) => '<li>' + t + '</li>').join('');
    $('#pm-plan').textContent = what + (me.currentPeriodEnd && me.plan !== 'lifetime' ? ' · renews ' + new Date(me.currentPeriodEnd).toLocaleDateString() : '');
    m.classList.add('show');
    setTimeout(() => confetti(innerWidth / 2, innerHeight * .35), 150);
    setTimeout(() => confetti(innerWidth * .3, innerHeight * .3), 700);
    setTimeout(() => confetti(innerWidth * .7, innerHeight * .3), 1100);
  }
  function init() { const b = $('#pm-close'); if (b) b.addEventListener('click', () => $('#plan-modal').classList.remove('show')); }
  return { plan, init, confetti };
})();
