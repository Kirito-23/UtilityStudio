/* MDX-Net stem separation without Python: a Node script the panel runs with its own node.exe.
   It ports the MDX path of python-audio-separator (MIT): STFT -> ONNX model (UVR MDX-Net) -> ISTFT,
   overlapping chunks with a Hann window, the secondary stem = mix - primary * compensate.
   ONNX Runtime comes from the onnxruntime-node package (DirectML for the GPU on Windows).

   node separate.js --model X.onnx --in in.wav --primary p.wav --secondary s.wav --ffmpeg ffmpeg.exe
                    --nfft 6144 --dimf 3072 --dimt 256 --compensate 1.022 --ort <dir with node_modules> [--cpu]
   Prints "progress 0.37" lines and "done" on stdout. */
'use strict';
const fs = require('fs'), path = require('path'), { spawnSync } = require('child_process');

const args = {}; for (let i = 2; i < process.argv.length; i++) { const a = process.argv[i]; if (a.startsWith('--')) { const k = a.slice(2); const v = process.argv[i + 1]; if (v == null || v.startsWith('--')) args[k] = true; else { args[k] = v; i++; } } }
const need = (k) => { if (!args[k]) { console.error('missing --' + k); process.exit(2); } return args[k]; };
const MODEL = need('model'), IN = need('in'), OUT_P = need('primary'), OUT_S = args.secondary, FFMPEG = need('ffmpeg');
const N_FFT = +args.nfft || 6144, DIM_F = +args.dimf || 3072, DIM_T = +args.dimt || 256, COMP = +args.compensate || 1, HOP = 1024, OVERLAP = 0.25, SR = 44100;
const ort = require(args.ort ? path.join(args.ort, 'node_modules', 'onnxruntime-node') : 'onnxruntime-node');
const say = (s) => { process.stdout.write(s + '\n'); };

/* ---- mixed-radix FFT (2, 3, 4, 5) for the odd sizes MDX uses (6144 = 2^11·3, 7680 = 2^9·3·5) ---- */
function makeFFT(N) {
  const factors = []; let n = N;
  for (const p of [4, 2, 3, 5]) while (n % p === 0) { factors.push(p); n /= p; }
  if (n !== 1) throw new Error('FFT size ' + N + ' has a prime factor above 5');
  const cosT = new Float64Array(N), sinT = new Float64Array(N);
  for (let i = 0; i < N; i++) { cosT[i] = Math.cos(2 * Math.PI * i / N); sinT[i] = -Math.sin(2 * Math.PI * i / N); }
  const scratchRe = [], scratchIm = [];
  /* recursive decimation in time: out[k] for k < n from x[off + j*stride] */
  function rec(inRe, inIm, off, stride, n, level, outRe, outIm, outOff) {
    if (n === 1) { outRe[outOff] = inRe[off]; outIm[outOff] = inIm[off]; return; }
    const r = factors[level], n1 = n / r;
    if (!scratchRe[level]) { scratchRe[level] = new Float64Array(N); scratchIm[level] = new Float64Array(N); }
    const sRe = scratchRe[level], sIm = scratchIm[level];
    /* r sub-transforms of size n1, written back to back in the scratch of this level (n values from outOff) */
    for (let m = 0; m < r; m++) rec(inRe, inIm, off + m * stride, stride * r, n1, level + 1, sRe, sIm, outOff + m * n1);
    const tw = N / n;   /* twiddle stride in the full table */
    for (let k = 0; k < n1; k++) {
      for (let q = 0; q < r; q++) {
        const kk = k + q * n1; let re = 0, im = 0;
        for (let m = 0; m < r; m++) {
          const idx = ((m * kk) % n) * tw; const c = cosT[idx], s = sinT[idx];
          const xr = sRe[outOff + m * n1 + k], xi = sIm[outOff + m * n1 + k];
          re += xr * c - xi * s; im += xr * s + xi * c;
        }
        outRe[outOff + kk] = re; outIm[outOff + kk] = im;
      }
    }
  }
  const outRe = new Float64Array(N), outIm = new Float64Array(N);
  return {
    N,
    forward(re, im) { rec(re, im, 0, 1, N, 0, outRe, outIm, 0); return [outRe, outIm]; },
    inverse(re, im) { /* conj trick, unnormalised */ const ci = new Float64Array(N); for (let i = 0; i < N; i++) ci[i] = -im[i]; rec(re, ci, 0, 1, N, 0, outRe, outIm, 0); for (let i = 0; i < N; i++) outIm[i] = -outIm[i]; return [outRe, outIm]; }
  };
}

/* ---- STFT / ISTFT the way torch.stft does it: centre padding (reflect), periodic Hann, one-sided ---- */
const fft = makeFFT(N_FFT), NB = N_FFT / 2 + 1, HALF = N_FFT / 2;
const win = new Float64Array(N_FFT); for (let i = 0; i < N_FFT; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / N_FFT);
function stft(x) {   /* x: Float32Array(len) -> { re, im } as Float32Array[DIM_F * frames] laid out [bin][frame] */
  const len = x.length, frames = 1 + Math.floor(len / HOP);
  const padded = new Float64Array(len + N_FFT);
  for (let i = 0; i < HALF; i++) padded[i] = x[HALF - i];                                   /* reflect left */
  for (let i = 0; i < len; i++) padded[HALF + i] = x[i];
  for (let i = 0; i < HALF; i++) padded[HALF + len + i] = x[len - 2 - i];                   /* reflect right */
  const re = new Float32Array(DIM_F * frames), im = new Float32Array(DIM_F * frames);
  const bufRe = new Float64Array(N_FFT), bufIm = new Float64Array(N_FFT);
  for (let f = 0; f < frames; f++) {
    const o = f * HOP;
    for (let i = 0; i < N_FFT; i++) { bufRe[i] = padded[o + i] * win[i]; bufIm[i] = 0; }
    const [R, I] = fft.forward(bufRe, bufIm);
    for (let b = 0; b < DIM_F; b++) { re[b * frames + f] = R[b]; im[b * frames + f] = I[b]; }
  }
  return { re, im, frames };
}
function istft(re, im, frames, outLen) {   /* bins above DIM_F are zero; returns Float32Array(outLen) */
  const total = N_FFT + HOP * (frames - 1);
  const y = new Float64Array(total), env = new Float64Array(total);
  const bufRe = new Float64Array(N_FFT), bufIm = new Float64Array(N_FFT);
  for (let f = 0; f < frames; f++) {
    bufRe.fill(0); bufIm.fill(0);
    for (let b = 0; b < DIM_F; b++) { bufRe[b] = re[b * frames + f]; bufIm[b] = im[b * frames + f]; }
    for (let b = 1; b < NB - 1; b++) { if (b < DIM_F) { bufRe[N_FFT - b] = bufRe[b]; bufIm[N_FFT - b] = -bufIm[b]; } }   /* hermitian half */
    const [R] = fft.inverse(bufRe, bufIm);
    const o = f * HOP;
    for (let i = 0; i < N_FFT; i++) { const w = win[i]; y[o + i] += R[i] / N_FFT * w; env[o + i] += w * w; }
  }
  const out = new Float32Array(outLen);
  for (let i = 0; i < outLen; i++) { const e = env[HALF + i]; out[i] = e > 1e-11 ? y[HALF + i] / e : 0; }
  return out;
}

/* ---- audio in / out through ffmpeg (any format -> 44.1 kHz stereo float) ---- */
function decode(file) {
  const r = spawnSync(FFMPEG, ['-v', 'error', '-i', file, '-ac', '2', '-ar', String(SR), '-f', 'f32le', '-'], { maxBuffer: 1 << 30, windowsHide: true });
  if (r.status !== 0) throw new Error('ffmpeg decode failed: ' + String(r.stderr).slice(0, 300));
  const f = new Float32Array(r.stdout.buffer, r.stdout.byteOffset, r.stdout.length >> 2);
  const n = f.length >> 1, L = new Float32Array(n), R = new Float32Array(n);
  for (let i = 0; i < n; i++) { L[i] = f[2 * i]; R[i] = f[2 * i + 1]; }
  return [L, R];
}
function writeWav(file, L, R) {
  const n = L.length, data = Buffer.alloc(n * 8);
  for (let i = 0; i < n; i++) { data.writeFloatLE(L[i], i * 8); data.writeFloatLE(R[i], i * 8 + 4); }
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVE', 8); h.write('fmt ', 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(3, 20); h.writeUInt16LE(2, 22);
  h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * 8, 28); h.writeUInt16LE(8, 32); h.writeUInt16LE(32, 34); h.write('data', 36); h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(file, Buffer.concat([h, data]));
}

/* ---- the separation ---- */
(async () => {
  const t0 = Date.now();
  const [L0, R0] = decode(IN);
  const n = L0.length;
  let peak = 0; for (let i = 0; i < n; i++) { const a = Math.abs(L0[i]), b = Math.abs(R0[i]); if (a > peak) peak = a; if (b > peak) peak = b; }
  const L = new Float32Array(L0), R = new Float32Array(R0);
  if (peak > 0.9) { const g = 0.9 / peak; for (let i = 0; i < n; i++) { L[i] *= g; R[i] *= g; } }   /* audio-separator's normalize(max_peak=0.9) */
  if (peak === 0) peak = 1;

  const session = await ort.InferenceSession.create(MODEL, { executionProviders: args.cpu ? ['cpu'] : (process.platform === 'win32' ? ['dml', 'cpu'] : ['coreml', 'cpu']) });
  const inName = session.inputNames[0], outName = session.outputNames[0];
  say('backend ' + (args.cpu ? 'cpu' : process.platform === 'win32' ? 'dml' : 'coreml'));

  const trim = HALF, chunk = HOP * (DIM_T - 1), gen = chunk - 2 * trim;
  const pad = gen + trim - (n % gen);
  const total = trim + n + pad;
  const mixL = new Float32Array(total), mixR = new Float32Array(total);
  mixL.set(L, trim); mixR.set(R, trim);
  const step = Math.floor((1 - OVERLAP) * chunk);
  const resL = new Float64Array(total), resR = new Float64Array(total), div = new Float64Array(total);
  const nChunks = Math.ceil(total / step);
  let done = 0;
  for (let start = 0; start < total; start += step) {
    const end = Math.min(start + chunk, total), len = end - start;
    const cl = new Float32Array(chunk), cr = new Float32Array(chunk);
    cl.set(mixL.subarray(start, end)); cr.set(mixR.subarray(start, end));
    /* spectrum [4, DIM_F, DIM_T]: ch0 re, ch0 im, ch1 re, ch1 im; the first 3 bins are zeroed like UVR does */
    const sl = stft(cl), sr = stft(cr);
    const frames = sl.frames; if (frames !== DIM_T) throw new Error('frames ' + frames + ' != ' + DIM_T);
    const plane = DIM_F * DIM_T, x = new Float32Array(4 * plane);
    x.set(sl.re, 0); x.set(sl.im, plane); x.set(sr.re, 2 * plane); x.set(sr.im, 3 * plane);
    for (let c = 0; c < 4; c++) for (let b = 0; b < 3; b++) x.fill(0, c * plane + b * DIM_T, c * plane + (b + 1) * DIM_T);
    const out = await session.run({ [inName]: new ort.Tensor('float32', x, [1, 4, DIM_F, DIM_T]) });
    const y = out[outName].data;
    const yl = istft(y.subarray(0, plane), y.subarray(plane, 2 * plane), DIM_T, chunk);
    const yr = istft(y.subarray(2 * plane, 3 * plane), y.subarray(3 * plane, 4 * plane), DIM_T, chunk);
    /* symmetric Hann over the actual chunk length (np.hanning), overlap-add */
    for (let i = 0; i < len; i++) { const w = len > 1 ? 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (len - 1)) : 1; resL[start + i] += yl[i] * w; resR[start + i] += yr[i] * w; div[start + i] += w; }
    done++; say('progress ' + (done / nChunks).toFixed(3));
  }
  const primL = new Float32Array(n), primR = new Float32Array(n);
  for (let i = 0; i < n; i++) { const d = div[trim + i] || 1; primL[i] = resL[trim + i] / d * peak; primR[i] = resR[trim + i] / d * peak; }
  writeWav(OUT_P, primL, primR);
  if (OUT_S) {
    const secL = new Float32Array(n), secR = new Float32Array(n);
    for (let i = 0; i < n; i++) { secL[i] = L[i] - primL[i] * COMP; secR[i] = R[i] - primR[i] * COMP; }
    writeWav(OUT_S, secL, secR);
  }
  say('done ' + ((Date.now() - t0) / 1000).toFixed(1) + 's');
})().catch((e) => { console.error(String(e && e.stack || e)); process.exit(1); });
