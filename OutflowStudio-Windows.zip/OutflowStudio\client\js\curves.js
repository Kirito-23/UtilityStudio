/* Motion Curves: pick a clip, choose a curve (preset, or drag handles and add points), then either curve the
   keyframes the clip already has or add an in / out animation with it. Premiere cannot take custom Bezier handles
   from a script, so the curve is baked: a row of keyframes, one per frame (or every 2nd / 3rd), that follows it.
   "Keyframes on" decides where they live: an adjustment layer above the clip with a Transform effect (default,
   motion blur through the shutter angle), a Transform effect on the clip, or the clip's own Motion / Opacity.
   Motion / Opacity keyframes the user made are moved there and the clip is reset, so nothing has to be set up by
   hand. The originals are kept in the panel so Revert puts everything back. Host side: host/curves.jsx. */
const Curves = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const KEY = 'os.curves';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const esc = (t) => String(t).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

  /* ---- presets, Flow-style: the Penner family as cubic beziers (in / out / in-out), back (anticipation and
     overshoot), bounce and elastic from easing.js, linear, and custom (whatever the editor holds) ---- */
  const FAMILY = [
    ['sine', 'Sine', [0.12, 0, 0.39, 0], [0.61, 1, 0.88, 1], [0.37, 0, 0.63, 1]],
    ['quad', 'Quad', [0.11, 0, 0.5, 0], [0.5, 1, 0.89, 1], [0.45, 0, 0.55, 1]],
    ['cubic', 'Cubic', [0.32, 0, 0.67, 0], [0.33, 1, 0.68, 1], [0.65, 0, 0.35, 1]],
    ['quart', 'Quart', [0.5, 0, 0.75, 0], [0.25, 1, 0.5, 1], [0.76, 0, 0.24, 1]],
    ['quint', 'Quint', [0.64, 0, 0.78, 0], [0.22, 1, 0.36, 1], [0.83, 0, 0.17, 1]],
    ['expo', 'Expo', [0.7, 0, 0.84, 0], [0.16, 1, 0.3, 1], [0.87, 0, 0.13, 1]],
    ['circ', 'Circ', [0.55, 0, 1, 0.45], [0, 0.55, 0.45, 1], [0.85, 0, 0.15, 1]],
    ['back', 'Back', [0.36, 0, 0.66, -0.56], [0.34, 1.56, 0.64, 1], [0.68, -0.6, 0.32, 1.6]]
  ];
  const PRESETS = {};
  for (const [id, name, i, o, io] of FAMILY) {
    PRESETS[id + 'InOut'] = { name: name, bezier: io };
    PRESETS[id + 'In'] = { name: name + ' in', bezier: i };
    PRESETS[id + 'Out'] = { name: name + ' out', bezier: o };
  }
  PRESETS.bounce = { name: 'Bounce', fn: 'easeOutBounce' };
  PRESETS.elastic = { name: 'Elastic', fn: 'easeOutElastic' };
  PRESETS.linear = { name: 'Linear', bezier: [0.25, 0.25, 0.75, 0.75], interp: 0 };
  /* Premiere's own ease, the one F9 applies. Two keyframes, no baking, and the graph editor stays usable. */
  PRESETS.ease = { name: 'Ease (Premiere)', bezier: [0.33, 0, 0.67, 1], interp: 1 };
  PRESETS.custom = { name: 'Custom', custom: true };
  const DEFAULT = 'quadInOut';

  /* a custom curve is a spline: anchors a = [[x, y], ...] from (0,0) to (1,1), and for every segment between two
     anchors a pair of handles h = [[x1, y1, x2, y2], ...] in the same absolute coordinates. One segment from (0,0)
     to (1,1) is exactly a CSS cubic-bezier, so the four numbers read the same as in Flow. */
  const ANIM0 = { in: 'slideL', out: null, dur: 0.5, amount: 100, all: false, v: 4 };   /* a coming-in and a going-out animation, either of them optional */
  const st = { preset: DEFAULT, spline: { a: [[0, 0], [1, 1]], h: [[0.45, 0, 0.55, 1]] }, every: 1, all: true, orig: {},
    mode: 'adjustment', shutter: 180, tab: 'animate', anim: Object.assign({}, ANIM0) };
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    if (saved.bezier && !saved.spline) saved.spline = { a: [[0, 0], [1, 1]], h: [saved.bezier] };
    delete saved.bezier; Object.assign(st, saved);
    st.anim = Object.assign({}, ANIM0, saved.anim || {}); delete st.anim.chips; delete st.anim.dir;
    if ((saved.anim || {}).v !== 4) {
      /* the gallery used to hold one choice for both halves, and to play every card at once */
      const old = (saved.anim || {}).sel;
      st.anim.all = false; st.anim.v = 4; st.anim.out = st.anim.out || null;
      st.anim.in = ANIM_BY[old] && ANIM_BY[old].io === 'in' ? old : (ANIM_BY[st.anim.in] ? st.anim.in : 'slideL');
      if (ANIM_BY[old] && ANIM_BY[old].io === 'out') { st.anim.out = old; st.anim.in = null; }
    }
    delete st.anim.sel;
  } catch (e) {}
  if (!PRESETS[st.preset]) st.preset = DEFAULT;
  if (!(st.shutter >= 0 && st.shutter <= 360)) st.shutter = 180;
  if (st.tab !== 'curve') st.tab = 'animate';
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} };

  const bezPt = (p0, p1, p2, p3, t) => { const u = 1 - t; return u * u * u * p0 + 3 * u * u * t * p1 + 3 * u * t * t * p2 + t * t * t * p3; };
  /* y of the spline at x = f; the handles' x stay inside their segment, so x is monotonic and bisection finds t */
  function splineFn(sp) {
    return (f) => {
      if (f <= 0) return 0; if (f >= 1) return 1;
      const a = sp.a, hs = sp.h;
      let i = 0; while (i < hs.length - 1 && f > a[i + 1][0]) i++;
      const p0 = a[i], p3 = a[i + 1], hh = hs[i];
      let lo = 0, hi = 1, t = 0.5;
      for (let k = 0; k < 24; k++) { t = (lo + hi) / 2; if (bezPt(p0[0], hh[0], hh[2], p3[0], t) < f) lo = t; else hi = t; }
      return bezPt(p0[1], hh[1], hh[3], p3[1], t);
    };
  }
  const fromBezier = (b) => ({ a: [[0, 0], [1, 1]], h: [b.slice()] });
  /* bounce and elastic are functions, not beziers: sampled into a spline when the user starts editing them */
  function sampled(fn, n) {
    const a = [], hs = [], d = (x) => (fn(Math.min(1, x + 0.002)) - fn(Math.max(0, x - 0.002))) / 0.004;
    for (let i = 0; i <= n; i++) a.push([+(i / n).toFixed(4), +fn(i / n).toFixed(4)]);
    a[0] = [0, 0]; a[n] = [1, 1];
    for (let i = 0; i < n; i++) { const dx = 1 / n / 3; hs.push([+(a[i][0] + dx).toFixed(4), +(a[i][1] + d(a[i][0]) * dx).toFixed(4), +(a[i + 1][0] - dx).toFixed(4), +(a[i + 1][1] - d(a[i + 1][0]) * dx).toFixed(4)]); }
    return { a, h: hs };
  }
  const presetFn = (p) => {
    if (p.custom) return splineFn(st.spline);
    if (p.fn && typeof EASINGS !== 'undefined' && EASINGS[p.fn]) return EASINGS[p.fn].fn;
    return splineFn(fromBezier(p.bezier || [0.45, 0, 0.55, 1]));
  };
  const curveFn = () => presetFn(PRESETS[st.preset] || PRESETS[DEFAULT]);
  /* null when the curve has to be written frame by frame, otherwise the interpolation type Premiere should use */
  const nativeInterp = () => { const p = PRESETS[st.preset] || PRESETS[DEFAULT]; return p.interp === undefined ? null : p.interp; };
  const currentSpline = () => { const p = PRESETS[st.preset] || PRESETS[DEFAULT]; return p.custom ? st.spline : (p.bezier ? fromBezier(p.bezier) : null); };
  function makeCustom() {
    if ((PRESETS[st.preset] || {}).custom) return;
    st.spline = currentSpline() || sampled(curveFn(), 24);
    st.preset = 'custom'; markGrid();
  }

  let clips = [];        /* [{ track, start, end, name, fps, inPoint, width, height, props: [...] }] from the timeline */
  let running = false;
  const clipKey = (c) => c.track + '@' + c.start.toFixed(3);
  const propKey = (p) => p.comp + ':' + p.param;
  const kindOf = (name) => /position/i.test(name) ? 'pos' : /scale/i.test(name) ? 'scale' : /rotation/i.test(name) ? 'rot' : /opacity/i.test(name) ? 'op' : null;
  const KIND_NAME = { pos: 'Position', scale: 'Scale', rot: 'Rotation', op: 'Opacity' };
  const MODE_NAME = { adjustment: 'adjustment layer', transform: 'Transform effect', motion: 'Motion' };
  const template = () => CS.extensionPath ? String(CS.extensionPath() || '').replace(/\\/g, '/') + '/client/assets/adjustment-layer.prproj' : '';
  /* evalScript truncates long strings: a baked curve can be hundreds of keys, so the host gets a file */
  const viaFile = (payload) => {
    const text = JSON.stringify(payload);
    if (!CS.hasNode || text.length < 6000) return text;
    const dir = CS.path.join(CS.os.tmpdir(), 'OutflowStudio'); CS.mkdirp(dir);
    const f = CS.path.join(dir, 'curves-' + Date.now() + '.json'); CS.fs.writeFileSync(f, text); return f;
  };

  /* ---- curve editor: drag handles, click the line to add a point, drag points, double-click a point to remove ---- */
  const PEN = 'url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2720%27 height=%2720%27%3E%3Cpath d=%27M3 17l3-9 8-5 3 3-5 8z%27 fill=%27%23fff%27 stroke=%27%23000%27/%3E%3Ccircle cx=%275%27 cy=%2715%27 r=%271.5%27 fill=%27%23000%27/%3E%3C/svg%3E") 4 16, crosshair';
  const win = {};
  function mkEditor() {
    const wrap = h('div', 'curvewrap');
    const cv = h('canvas', 'curve big');
    const pad = 12, W = 200, H = 130;
    let yLo = 0, yHi = 1;
    const toPx = (x, y) => [pad + x * (W - 2 * pad), H - pad - (y - yLo) / (yHi - yLo) * (H - 2 * pad)];
    const fromPx = (px, py) => [clamp((px - pad) / (W - 2 * pad), 0, 1), clamp(yLo + (H - pad - py) / (H - 2 * pad) * (yHi - yLo), -1, 2)];
    const fitRange = () => {
      const fn = curveFn(), sp = currentSpline();
      let lo = 0, hi = 1;
      for (let i = 0; i <= 50; i++) { const y = fn(i / 50); lo = Math.min(lo, y); hi = Math.max(hi, y); }
      if (sp) for (const hh of sp.h) { lo = Math.min(lo, hh[1], hh[3]); hi = Math.max(hi, hh[1], hh[3]); }
      yLo = Math.floor((lo - 0.05) * 10) / 10; yHi = Math.ceil((hi + 0.05) * 10) / 10;
    };
    const points = () => {
      const sp = currentSpline(), out = []; if (!sp) return out;
      for (let i = 0; i < sp.h.length; i++) { out.push({ kind: 'h', i, side: 0, x: sp.h[i][0], y: sp.h[i][1] }); out.push({ kind: 'h', i, side: 1, x: sp.h[i][2], y: sp.h[i][3] }); }
      for (let i = 1; i < sp.a.length - 1; i++) out.push({ kind: 'a', i, x: sp.a[i][0], y: sp.a[i][1] });
      return out;
    };
    const draw = () => {
      fitRange();
      const rc = cv.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 3);
      const cw = Math.max(1, Math.round((rc.width || W) * dpr)), ch = Math.max(1, Math.round((rc.height || H) * dpr));
      if (cv.width !== cw || cv.height !== ch) { cv.width = cw; cv.height = ch; }
      const g = cv.getContext('2d'); g.setTransform(cw / W, 0, 0, ch / H, 0, 0);
      g.clearRect(0, 0, W, H); g.fillStyle = '#15171c'; g.fillRect(0, 0, W, H);
      g.strokeStyle = '#2b2f38'; g.lineWidth = 1; g.beginPath();
      for (let i = 0; i <= 4; i++) { const a = toPx(i / 4, yLo), b = toPx(i / 4, yHi), c = toPx(0, i / 4), d = toPx(1, i / 4); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.moveTo(c[0], c[1]); g.lineTo(d[0], d[1]); }
      g.stroke();
      if (yLo < 0 || yHi > 1) { g.strokeStyle = '#3a3f4a'; g.beginPath(); for (const y of [0, 1]) { const a = toPx(0, y), b = toPx(1, y); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); } g.stroke(); }
      const o = toPx(0, 0), e = toPx(1, 1);
      g.strokeStyle = '#3c4250'; g.setLineDash([3, 3]); g.beginPath(); g.moveTo(o[0], o[1]); g.lineTo(e[0], e[1]); g.stroke(); g.setLineDash([]);
      const sp = currentSpline(), custom = !!(PRESETS[st.preset] || {}).custom;
      if (sp) {
        g.strokeStyle = custom ? '#5a6070' : '#3a3f4a'; g.setLineDash([3, 3]); g.beginPath();
        for (let i = 0; i < sp.h.length; i++) { const p0 = toPx(sp.a[i][0], sp.a[i][1]), p3 = toPx(sp.a[i + 1][0], sp.a[i + 1][1]), h1 = toPx(sp.h[i][0], sp.h[i][1]), h2 = toPx(sp.h[i][2], sp.h[i][3]); g.moveTo(p0[0], p0[1]); g.lineTo(h1[0], h1[1]); g.moveTo(p3[0], p3[1]); g.lineTo(h2[0], h2[1]); }
        g.stroke(); g.setLineDash([]);
      }
      const fn = curveFn();
      g.strokeStyle = '#4fb3ff'; g.lineWidth = 2; g.beginPath();
      for (let i = 0; i <= 120; i++) { const f = i / 120, p = toPx(f, fn(f)); if (i === 0) g.moveTo(p[0], p[1]); else g.lineTo(p[0], p[1]); }
      g.stroke();
      for (const pt of points()) {
        const p = toPx(pt.x, pt.y);
        if (pt.kind === 'a') { g.fillStyle = '#fff'; g.strokeStyle = '#4fb3ff'; g.lineWidth = 2; g.beginPath(); g.rect(p[0] - 4, p[1] - 4, 8, 8); g.fill(); g.stroke(); }
        else { g.fillStyle = custom ? '#fff' : '#9aa3b5'; g.strokeStyle = '#4f8dff'; g.lineWidth = 2; g.beginPath(); g.arc(p[0], p[1], 4.5, 0, Math.PI * 2); g.fill(); g.stroke(); }
      }
      g.fillStyle = '#6b7280'; g.font = '9px sans-serif';
      g.fillText(custom ? 'drag · click line: add point · dbl-click: remove' : (PRESETS[st.preset] || {}).name + ' · drag, or click the line to add a point', pad, H - 3);
    };
    const pos = (ev) => { const rc = cv.getBoundingClientRect(); return [(ev.clientX - rc.left) * W / rc.width, (ev.clientY - rc.top) * H / rc.height]; };
    const hit = (px, py) => {
      let best = null, bd = 9;
      for (const pt of points()) { const p = toPx(pt.x, pt.y), d = Math.hypot(p[0] - px, p[1] - py); if (d < bd) { bd = d; best = pt; } }
      return best;
    };
    const nearCurve = (px, py) => {
      const fn = curveFn(); let bd = 7, bx = -1;
      for (let i = 0; i <= 120; i++) { const f = i / 120, p = toPx(f, fn(f)), d = Math.hypot(p[0] - px, p[1] - py); if (d < bd) { bd = d; bx = f; } }
      return bx;
    };
    /* split segment i at x = f with De Casteljau, so the shape does not change; returns the new anchor's index */
    const insertAt = (f) => {
      const sp = st.spline, a = sp.a, hs = sp.h;
      let i = 0; while (i < hs.length - 1 && f > a[i + 1][0]) i++;
      const p0 = a[i], p3 = a[i + 1], hh = hs[i];
      let lo = 0, hi = 1, t = 0.5;
      for (let k = 0; k < 24; k++) { t = (lo + hi) / 2; if (bezPt(p0[0], hh[0], hh[2], p3[0], t) < f) lo = t; else hi = t; }
      const L = (p, q) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t];
      const P1 = [hh[0], hh[1]], P2 = [hh[2], hh[3]];
      const q0 = L(p0, P1), q1 = L(P1, P2), q2 = L(P2, p3), r0 = L(q0, q1), r1 = L(q1, q2), sPt = L(r0, r1);
      const rnd = (v) => Math.round(v * 1000) / 1000;
      a.splice(i + 1, 0, [rnd(sPt[0]), rnd(sPt[1])]);
      hs.splice(i, 1, [rnd(q0[0]), rnd(q0[1]), rnd(r0[0]), rnd(r0[1])], [rnd(r1[0]), rnd(r1[1]), rnd(q2[0]), rnd(q2[1])]);
      return i + 1;
    };
    const removeAnchor = (i) => {
      const sp = st.spline; if (i <= 0 || i >= sp.a.length - 1) return;
      sp.h.splice(i - 1, 2, [sp.h[i - 1][0], sp.h[i - 1][1], sp.h[i][2], sp.h[i][3]]);
      sp.a.splice(i, 1);
    };
    let drag = null;
    const after = () => { draw(); drawPreview(); readout(); markGrid(); };
    cv.addEventListener('mousedown', (ev) => {
      if (ev.button !== 0) return;
      const [px, py] = pos(ev);
      let pt = currentSpline() ? hit(px, py) : null;
      if (!pt) { const f = nearCurve(px, py); if (f < 0) return; makeCustom(); pt = { kind: 'a', i: insertAt(f) }; }
      else makeCustom();
      drag = pt; ev.preventDefault(); after();
    });
    cv.addEventListener('mousemove', (ev) => {
      if (drag) return;
      const [px, py] = pos(ev);
      cv.style.cursor = (currentSpline() && hit(px, py)) ? 'grab' : (nearCurve(px, py) >= 0 ? PEN : 'default');
    });
    if (win.move) { window.removeEventListener('mousemove', win.move); window.removeEventListener('mouseup', win.up); window.removeEventListener('resize', win.resize); }
    win.move = (ev) => {
      if (!drag || !cv.isConnected) return;
      const [x, y] = fromPx(...pos(ev)), sp = st.spline, r = (v) => Math.round(v * 100) / 100;
      if (drag.kind === 'a') {
        const i = drag.i, nx = clamp(x, sp.a[i - 1][0] + 0.01, sp.a[i + 1][0] - 0.01), dx = nx - sp.a[i][0], dy = y - sp.a[i][1];
        sp.a[i] = [r(nx), r(y)];
        sp.h[i - 1][2] = r(clamp(sp.h[i - 1][2] + dx, sp.a[i - 1][0], nx)); sp.h[i - 1][3] = r(sp.h[i - 1][3] + dy);
        sp.h[i][0] = r(clamp(sp.h[i][0] + dx, nx, sp.a[i + 1][0])); sp.h[i][1] = r(sp.h[i][1] + dy);
      } else {
        const hh = sp.h[drag.i], k = drag.side * 2;
        hh[k] = r(clamp(x, sp.a[drag.i][0], sp.a[drag.i + 1][0])); hh[k + 1] = r(y);
      }
      draw(); drawPreview(); readout();
    };
    win.up = () => { if (!drag) return; drag = null; save(); markGrid(); };
    win.resize = () => { if (cv.isConnected) draw(); };
    window.addEventListener('mousemove', win.move); window.addEventListener('mouseup', win.up); window.addEventListener('resize', win.resize);
    cv.addEventListener('dblclick', (ev) => {
      const [px, py] = pos(ev), pt = currentSpline() ? hit(px, py) : null;
      if (pt && pt.kind === 'a') { makeCustom(); removeAnchor(pt.i); }
      else if (pt) return;
      else { st.spline = fromBezier(PRESETS[DEFAULT].bezier); st.preset = 'custom'; }
      save(); after();
    });
    cv.addEventListener('contextmenu', (ev) => {
      ev.preventDefault();
      const [px, py] = pos(ev), pt = currentSpline() ? hit(px, py) : null;
      if (pt && pt.kind === 'a') { makeCustom(); removeAnchor(pt.i); save(); after(); }
    });
    wrap.append(cv);
    draw(); requestAnimationFrame(draw);
    return { el: wrap, draw };
  }
  let editor = null;

  /* ---- the preset grid: small curve thumbnails, click one to use it ---- */
  function thumb(cv, fn) {
    const W = 44, H = 34, pad = 5, dpr = Math.min(window.devicePixelRatio || 1, 3);
    cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px';
    let lo = 0, hi = 1; for (let i = 0; i <= 40; i++) { const y = fn(i / 40); lo = Math.min(lo, y); hi = Math.max(hi, y); }
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const px = (x, y) => [pad + x * (W - 2 * pad), H - pad - (y - lo) / (hi - lo) * (H - 2 * pad)];
    g.strokeStyle = '#3a3f4a'; g.lineWidth = 1; g.beginPath(); const a = px(0, 0), b = px(1, 1); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke();
    g.strokeStyle = '#dfe3ea'; g.lineWidth = 1.6; g.beginPath();
    for (let i = 0; i <= 40; i++) { const q = px(i / 40, fn(i / 40)); if (i) g.lineTo(q[0], q[1]); else g.moveTo(q[0], q[1]); }
    g.stroke();
  }
  function renderGrid() {
    const box = $('#mc-grid'); if (!box) return; box.innerHTML = '';
    for (const [id, p] of Object.entries(PRESETS)) {
      const cell = h('button', 'mc-cell' + (id === st.preset ? ' on' : '')); cell.type = 'button'; cell.dataset.id = id; cell.title = p.name;
      const cv = document.createElement('canvas'); thumb(cv, presetFn(p));
      cell.append(cv, h('span', '', p.name));
      cell.addEventListener('click', () => { st.preset = id; save(); markGrid(); if (editor) editor.draw(); drawPreview(); readout(); });
      box.appendChild(cell);
    }
  }
  function markGrid() {
    const box = $('#mc-grid'); if (!box) return;
    for (const cell of box.children) {
      cell.classList.toggle('on', cell.dataset.id === st.preset);
      if (cell.dataset.id === 'custom') thumb(cell.querySelector('canvas'), splineFn(st.spline));
    }
    const lab = $('#mc-curname'); if (lab) lab.textContent = (PRESETS[st.preset] || {}).name || '';
  }
  /* the four handle numbers, like Flow shows them; typing new ones makes a one-segment custom curve */
  function readout() {
    const inp = $('#mc-bez'); if (!inp || document.activeElement === inp) return;
    const sp = currentSpline();
    if (!sp) inp.value = (PRESETS[st.preset] || {}).name;
    else if (sp.h.length === 1) inp.value = sp.h[0].map((v) => (+v).toFixed(2)).join(', ');
    else inp.value = sp.a.length + ' points';
  }
  function readoutInput() {
    const inp = $('#mc-bez'); if (!inp) return;
    const parse = () => {
      const n = inp.value.split(/[\s,;]+/).filter(Boolean).map(Number);
      if (n.length !== 4 || n.some((v) => !isFinite(v))) return false;
      st.spline = fromBezier([clamp(n[0], 0, 1), clamp(n[1], -1, 2), clamp(n[2], 0, 1), clamp(n[3], -1, 2)]);
      st.preset = 'custom'; save(); markGrid(); if (editor) editor.draw(); drawPreview(); return true;
    };
    inp.onchange = () => { parse(); inp.blur(); readout(); };
    inp.onkeydown = (e) => { if (e.key === 'Enter') inp.blur(); };
  }

  /* ---- the little clip: one drawing routine, used by the big preview and by every gallery card ---- */
  let previewRaf = 0, previewT0 = 0;
  /* moved entries in st.orig that belong to a selected clip: { key, o } */
  const movedFor = (c) => Object.entries(st.orig).filter(([k, o]) => o.moved && k.startsWith(clipKey(c) + '|')).map(([key, o]) => ({ key, o }));
  function previewTracks() {
    if (st.tab === 'animate') return animTracks();
    const c = clips.find((x) => x.props.length || movedFor(x).length); if (!c) return DEMO;
    const tracks = [];
    let t0 = Infinity, t1 = -Infinity;
    const push = (kind, keys, rel) => { for (const k of keys) { t0 = Math.min(t0, k[0]); t1 = Math.max(t1, k[0]); } tracks.push({ kind, keys, rel, W: c.width || 1920, H: c.height || 1080 }); };
    for (const p of c.props) { if (!p.on) continue; const kind = kindOf(p.name); if (kind) push(kind, p.keys, false); }
    for (const { o } of movedFor(c)) { if (o.on === false) continue; push(o.moved.kind, o.moved.layerKeys, false); }
    if (!tracks.length || !(t1 > t0)) return DEMO;
    for (const tr of tracks) tr.keys = tr.keys.map((k) => [k[0] - t0, k[1]]);
    return { tracks, len: t1 - t0 };
  }
  /* nothing selected yet: the same little clip travelling left to right, so the curve is still visible */
  const DEMO = { demo: true, len: 1.1, tracks: [{ kind: 'pos', rel: true, keys: [[0, [-0.3, 0]], [1.1, [0.3, 0]]] }] };
  function valueAt(track, t, fn) {
    const ks = track.keys;
    if (t <= ks[0][0]) return ks[0][1];
    if (t >= ks[ks.length - 1][0]) return ks[ks.length - 1][1];
    let i = 0; while (t > ks[i + 1][0]) i++;
    const [ta, va] = ks[i], [tb, vb] = ks[i + 1], e = fn((t - ta) / (tb - ta));
    return Array.isArray(va) ? va.map((x, j) => x + (vb[j] - x) * e) : va + (vb - va) * e;
  }
  const num = (v) => Array.isArray(v) ? v[0] : v;
  /* where in the loop we are: an "in" animation rests on the finished frame, an "out" one rests before it leaves */
  const loopT = (pv, x, hold) => (pv.preset && pv.preset.io === 'out') ? clamp(x - hold, 0, pv.len) : Math.min(x, pv.len);
  /* the frame and the thumbnail inside it, at moment t. opts: pad, ghosts, grid, bar, label */
  function drawScene(g, w, hh, pv, t, opts) {
    /* t may be moved by the poster branch below */
    const o = opts || {}, pad = o.pad === undefined ? 8 : o.pad, r = o.pad === undefined ? 7 : 5;
    const fn = curveFn(), fx = pad, fy = pad, fw = w - pad * 2, fh = hh - pad * 2;
    if (!(fw > 12 && fh > 12)) return;   /* the canvas has no size yet (hidden tab, first layout) */
    const rr = (x, y, ww, hg, rad) => { g.beginPath(); if (g.roundRect) g.roundRect(x, y, ww, hg, rad); else g.rect(x, y, ww, hg); };
    const put = (s, tr, v) => {
      if (tr.kind === 'scaleW') { s.sx = num(v) / 100; return; }
      if (tr.kind === 'pos') {
        if (tr.rel) { s.dx = v[0] * fw; s.dy = v[1] * fh; }
        else { const norm = Math.abs(v[0]) <= 1 && Math.abs(v[1]) <= 1; s.dx = (norm ? v[0] - 0.5 : v[0] / tr.W - 0.5) * fw; s.dy = (norm ? v[1] - 0.5 : v[1] / tr.H - 0.5) * fh; }
      } else if (tr.kind === 'scale') s.sc = num(v) / 100;
      else if (tr.kind === 'rot') s.rot = num(v) * Math.PI / 180;
      else if (tr.kind === 'op') s.op = clamp(num(v) / 100, 0, 1);
    };
    const at = (tt) => {
      const s = { dx: 0, dy: 0, sc: 1, sx: 1, rot: 0, op: 1 };
      for (const tr of pv.tracks) put(s, tr, valueAt(tr, tt, fn));
      return s;
    };
    /* a pose a fraction of the way through the movement, ignoring the curve's timing: the still thumbnail wants
       the picture caught mid-flight, not wherever the easing happens to be at that moment */
    const atFrac = (f) => {
      const s = { dx: 0, dy: 0, sc: 1, sx: 1, rot: 0, op: 1 };
      for (const tr of pv.tracks) {
        const k = tr.keys, a0 = k[0][1], a1 = k[k.length - 1][1];
        put(s, tr, Array.isArray(a0) ? a0.map((x, i) => x + (a1[i] - x) * f) : a0 + (a1 - a0) * f);
      }
      return s;
    };
    const bh = Math.max(8, Math.min(fh * 0.5, fw * 0.45 * 9 / 16)), bw = bh * 16 / 9;
    g.clearRect(0, 0, w, hh);
    g.save(); rr(fx, fy, fw, fh, r); g.clip();
    const bg = g.createLinearGradient(0, fy, 0, fy + fh); bg.addColorStop(0, '#13161c'); bg.addColorStop(1, '#0a0c10');
    g.fillStyle = bg; g.fillRect(fx, fy, fw, fh);
    if (o.grid !== false) {
      g.strokeStyle = 'rgba(255,255,255,.045)'; g.lineWidth = 1; g.beginPath();
      for (let i = 1; i < 3; i++) { g.moveTo(fx + fw * i / 3, fy); g.lineTo(fx + fw * i / 3, fy + fh); g.moveTo(fx, fy + fh * i / 3); g.lineTo(fx + fw, fy + fh * i / 3); }
      g.stroke();
    }
    /* onion skin at even steps in time: where they bunch up, the curve is slow */
    if (o.ghosts) {
      for (let i = 0; i <= 14; i++) {
        const s = at(pv.len * i / 14);
        g.save(); g.translate(fx + fw / 2 + s.dx, fy + fh / 2 + s.dy); g.rotate(s.rot); g.scale(s.sc * s.sx, s.sc);
        g.globalAlpha = 0.11 * s.op; g.strokeStyle = '#8ab4ff'; g.lineWidth = 1;
        rr(-bw / 2, -bh / 2, bw, bh, 5); g.stroke(); g.restore();
      }
    }
    let poseOverride = null; const posterRings = [];
    /* the flat version of the card, used for the trail on a still thumbnail */
    const flatCard = () => {
      const gr = g.createLinearGradient(-bw / 2, -bh / 2, bw / 2, bh / 2);
      gr.addColorStop(0, '#5aa0ff'); gr.addColorStop(1, '#8b5cf6');
      g.fillStyle = gr; rr(-bw / 2, -bh / 2, bw, bh, 5); g.fill();
    };
    /* a still thumbnail that shows what the motion does, without playing it */
    if (o.poster) {
      /* An entrance shows the frame it lands on, with fainter copies trailing back to where it came from.
         An exit is caught on its way out, with the copies left behind at the resting spot.
         Distances are measured from where the picture rests. */
      const isOut = !!(pv.preset && pv.preset.io === 'out');
      const home = isOut ? 0 : 1, away = isOut ? 1 : 0, along = (d) => home + (away - home) * d;
      const trail = isOut ? [[0.22, 0.16], [0.06, 0.32]] : [[0.8, 0.13], [0.45, 0.3]];
      poseOverride = atFrac(along(isOut ? 0.5 : 0));
      for (const [dist, alpha] of trail) {
        const st2 = atFrac(along(dist));
        g.save(); g.translate(fx + fw / 2 + st2.dx, fy + fh / 2 + st2.dy); g.rotate(st2.rot); g.scale(Math.max(0.08, st2.sc * st2.sx), Math.max(0.1, st2.sc));
        g.globalAlpha = alpha * Math.max(0.3, st2.op); flatCard(); g.restore();   /* an animation that fades leaves a fainter trail */
        /* a copy that is smaller and in the same spot would hide behind the picture: outline it instead */
        const near = Math.abs(st2.dx - poseOverride.dx) < fw * 0.16 && Math.abs(st2.dy - poseOverride.dy) < fh * 0.16;
        if (near && st2.sc * st2.sx < poseOverride.sc * poseOverride.sx * 0.98) posterRings.push([st2, alpha]);
      }
    }
    const c = poseOverride || at(t);
    g.save(); g.translate(fx + fw / 2 + c.dx, fy + fh / 2 + c.dy); g.rotate(c.rot); g.scale(c.sc * c.sx, c.sc); g.globalAlpha = c.op;
    g.shadowColor = 'rgba(0,0,0,.55)'; g.shadowBlur = 14; g.shadowOffsetY = 5;
    g.fillStyle = '#4f8dff'; rr(-bw / 2, -bh / 2, bw, bh, 5); g.fill();
    g.shadowColor = 'transparent'; g.shadowBlur = 0; g.shadowOffsetY = 0;
    g.save(); rr(-bw / 2, -bh / 2, bw, bh, 5); g.clip();
    const sky = g.createLinearGradient(0, -bh / 2, 0, bh / 2); sky.addColorStop(0, '#5aa0ff'); sky.addColorStop(0.5, '#6d7cf0'); sky.addColorStop(1, '#8b5cf6');
    g.fillStyle = sky; g.fillRect(-bw / 2, -bh / 2, bw, bh);
    const sx = -bw * 0.26, sy = -bh * 0.17, sr = bh * 0.13;
    const glow = g.createRadialGradient(sx, sy, 0, sx, sy, sr * 3.4);
    glow.addColorStop(0, 'rgba(255,216,150,.7)'); glow.addColorStop(1, 'rgba(255,216,150,0)');
    g.fillStyle = glow; g.beginPath(); g.arc(sx, sy, sr * 3.4, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#ffe3ad'; g.beginPath(); g.arc(sx, sy, sr, 0, Math.PI * 2); g.fill();
    g.fillStyle = 'rgba(24,18,52,.5)'; g.beginPath();
    g.moveTo(-bw / 2, bh / 2); g.lineTo(-bw * 0.2, -bh * 0.04); g.lineTo(bw * 0.04, bh * 0.2); g.lineTo(bw * 0.3, -bh * 0.12); g.lineTo(bw / 2, bh * 0.28); g.lineTo(bw / 2, bh / 2); g.closePath(); g.fill();
    g.fillStyle = 'rgba(12,10,30,.8)'; g.beginPath();
    g.moveTo(-bw / 2, bh / 2); g.lineTo(-bw * 0.3, bh * 0.14); g.lineTo(-bw * 0.02, bh * 0.36); g.lineTo(bw * 0.24, bh * 0.12); g.lineTo(bw / 2, bh * 0.44); g.lineTo(bw / 2, bh / 2); g.closePath(); g.fill();
    g.restore();
    g.strokeStyle = 'rgba(255,255,255,.32)'; g.lineWidth = 1; rr(-bw / 2, -bh / 2, bw, bh, 5); g.stroke();
    g.restore();
    g.restore();
    for (const [st2, alpha] of posterRings) {
      g.save(); g.translate(fx + fw / 2 + st2.dx, fy + fh / 2 + st2.dy); g.rotate(st2.rot); g.scale(Math.max(0.08, st2.sc * st2.sx), Math.max(0.1, st2.sc));
      g.globalAlpha = Math.min(0.5, alpha + 0.16) * Math.max(0.3, st2.op); g.strokeStyle = '#cfe0ff'; g.lineWidth = 1 / Math.max(0.2, st2.sc);
      rr(-bw / 2, -bh / 2, bw, bh, 5); g.stroke(); g.restore();
    }
    g.strokeStyle = '#2b2f38'; g.lineWidth = 1; rr(fx + 0.5, fy + 0.5, fw - 1, fh - 1, r); g.stroke();
    if (o.bar) {
      g.fillStyle = 'rgba(255,255,255,.09)'; rr(fx + 10, fy + fh - 7, fw - 20, 3, 1.5); g.fill();
      g.fillStyle = '#4f8dff'; rr(fx + 10, fy + fh - 7, (fw - 20) * (t / pv.len), 3, 1.5); g.fill();
    }
    if (o.label) { g.fillStyle = 'rgba(255,255,255,.32)'; g.font = '9px sans-serif'; g.fillText(o.label, fx + 10, fy + 15); }
  }
  /* the big preview above the presets */
  function drawPreview() {
    const cv = $('#mc-motion'); if (!cv) return;
    cancelAnimationFrame(previewRaf);
    const loop = (ts) => {
      if (!cv.isConnected) return;
      if (!active() || !cv.offsetWidth) { previewRaf = requestAnimationFrame(loop); return; }   /* screen hidden: keep the loop, draw nothing */
      if (!previewT0) previewT0 = ts;
      const rc = cv.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 3);
      const W = Math.max(1, Math.round(rc.width * dpr)), H = Math.max(1, Math.round(rc.height * dpr));
      if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
      const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
      const pv = previewTracks(), hold = 0.6;
      const t = loopT(pv, ((ts - previewT0) / 1000) % (pv.len + hold), hold);
      drawScene(g, rc.width, rc.height, pv, t, { ghosts: true, bar: true, label: pv.demo ? 'example' : '' });
      previewRaf = requestAnimationFrame(loop);
    };
    previewRaf = requestAnimationFrame(loop);
  }

  /* ---- tabs: Motion | Curve; the preview canvas follows the active tab ---- */
  function showTab(name) {
    st.tab = name; save();
    document.querySelectorAll('#mc-tabbar button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    document.querySelectorAll('.mc-tab').forEach((t) => { t.style.display = t.dataset.tab === name ? '' : 'none'; });
    const slot = document.querySelector('.mc-tab[data-tab="' + name + '"] .mc-pv-slot'), cv = $('#mc-motion');
    if (slot && cv && cv.parentNode !== slot) slot.appendChild(cv);
    /* the curve belongs to both tabs: one editor, moved to the one you are looking at */
    const cSlot = document.querySelector('.mc-tab[data-tab="' + name + '"] .mc-curve-slot'), block = $('#mc-curve-block');
    if (cSlot && block && block.parentNode !== cSlot) cSlot.appendChild(block);
    if (editor) editor.draw();
    previewT0 = 0; drawPreview();
    if (name === 'curve' && editor) editor.draw();
  }

  /* ---- clips and properties, kept fresh while the screen is open ---- */
  const active = () => { const s = $('#screen-curves'); return !!(s && s.classList.contains('active')); };
  let lastSig = '', poll = 0, pollN = 0;
  async function loadClips(quiet) {
    const box = $('#mc-props'); if (!box) return;
    if (!CS.inCEP) { box.innerHTML = '<div class="kbd">Motion Curves runs inside Premiere Pro.</div>'; renderAnim(); return; }
    if (!quiet && !clips.length) box.innerHTML = '<div class="kbd">Reading the selected clips…</div>';
    try {
      if (quiet) CS.quiet++;
      const sel = await CS.call('C3D_getSelectedClips'); if (!sel.ok) throw new Error(sel.error);
      const found = [];
      for (const c of sel.clips || []) {
        const r = await CS.call('MC_listProps', JSON.stringify({ track: c.track, start: c.start }));
        if (r.ok) found.push({ track: c.track, start: c.start, end: c.end, name: r.name, fps: r.fps, inPoint: r.inPoint || 0, width: r.width, height: r.height, props: r.props || [] });
      }
      const ticked = {}; for (const c of clips) for (const p of c.props) ticked[clipKey(c) + '|' + propKey(p)] = p.on;
      for (const c of found) for (const p of c.props) { const k = clipKey(c) + '|' + propKey(p); p.on = (k in ticked) ? ticked[k] : st.all; }
      const sig = JSON.stringify(found.map((c) => [clipKey(c), c.props.map((p) => [propKey(p), p.keys.length, p.keys[0], p.keys[p.keys.length - 1]])]));
      clips = found;
      if (sig !== lastSig) { lastSig = sig; renderProps(); renderAnim(); previewT0 = 0; }
    } catch (e) { if (!quiet) box.innerHTML = '<div class="kbd">' + esc(e.message || String(e)) + '</div>'; }
    finally { if (quiet) CS.quiet = Math.max(0, CS.quiet - 1); }
  }
  function startPolling() {
    clearInterval(poll);
    poll = setInterval(async () => {
      if (!active()) { clearInterval(poll); poll = 0; return; }
      if (running || !CS.inCEP) return;
      pollN++;
      try {
        CS.quiet++;
        const sel = await CS.call('C3D_getSelectedClips');
        const s = sel.ok ? (sel.clips || []).map((c) => c.track + '@' + c.start.toFixed(3)).join(',') : '';
        const cur = clips.map(clipKey).join(',');
        if (s !== cur || pollN % 4 === 0) await loadClips(true);
      } catch (e) {} finally { CS.quiet = Math.max(0, CS.quiet - 1); }
    }, 1000);
  }
  const fmtVal = (v) => Array.isArray(v) ? v.map((x) => +x.toFixed(2)).join(', ') : (+v).toFixed(2);
  function renderProps() {
    const box = $('#mc-props'); if (!box) return; box.innerHTML = '';
    const rows = clips.filter((c) => c.props.length || movedFor(c).length);
    if (!clips.length) { box.innerHTML = '<div class="kbd">Select a clip in the timeline. Its keyframed properties (Position, Scale, Rotation, Opacity or any effect) show up here.</div>'; return; }
    if (!rows.length) { box.innerHTML = '<div class="kbd">' + esc(clips[0].name) + (clips.length > 1 ? ' and ' + (clips.length - 1) + ' more' : '') + ': no keyframes yet. Add keyframes in Effect Controls, or use the Animate tab.</div>'; return; }
    for (const c of rows) {
      const card = h('div', 'mc-clip');
      const n = c.props.length + movedFor(c).length;
      card.innerHTML = '<div class="mc-clip-h"><b title="' + esc(c.name) + '">' + esc(c.name) + '</b><span class="hint">V' + (c.track + 1) + ' · ' + n + ' animated</span></div>';
      for (const p of c.props) {
        const k = clipKey(c) + '|' + propKey(p), had = st.orig[k] && !st.orig[k].moved;
        const row = h('label', 'mc-prop');
        row.innerHTML = '<input type="checkbox" ' + (p.on ? 'checked' : '') + '><span class="mc-name">' + esc(p.compName) + ' › ' + esc(p.name) + '</span><span class="hint">' + p.keys.length + ' keys · ' + fmtVal(p.keys[0][1]) + ' → ' + fmtVal(p.keys[p.keys.length - 1][1]) + (had ? ' · curved' : '') + '</span>';
        row.querySelector('input').addEventListener('change', (e) => { p.on = e.target.checked; previewT0 = 0; });
        card.appendChild(row);
      }
      for (const { o } of movedFor(c)) {
        const row = h('label', 'mc-prop moved'), m = o.moved;
        const where = m.layer ? 'adjustment layer V' + (m.layer.track + 1) : 'Transform effect';
        row.innerHTML = '<input type="checkbox" ' + (o.on !== false ? 'checked' : '') + '><span class="mc-name">' + esc(o.compName) + ' › ' + esc(o.name) + ' <span class="hint">→ ' + where + '</span></span><span class="hint">' + o.keys.length + ' keys · curved · Revert puts them back on the clip</span>';
        row.querySelector('input').addEventListener('change', (e) => { o.on = e.target.checked; save(); previewT0 = 0; });
        card.appendChild(row);
      }
      box.appendChild(card);
    }
  }

  /* ---- bake: the curve between every pair of keyframes, one key per N frames ---- */
  function bake(keys, fps) {
    /* nothing to bake when Premiere can draw this shape: the keys as given are the whole animation */
    if (nativeInterp() !== null) return keys;
    const fn = curveFn(), step = Math.max(1, st.every) / fps, out = [];
    const lerp = (a, b, e) => Array.isArray(a) ? a.map((x, i) => x + (b[i] - x) * e) : a + (b - a) * e;
    const same = (a, b) => Array.isArray(a) ? a.length === b.length && a.every((x, i) => Math.abs(x - b[i]) < 1e-6) : Math.abs(a - b) < 1e-6;
    for (let i = 0; i < keys.length - 1; i++) {
      const [t0, v0] = keys[i], [t1, v1] = keys[i + 1];
      out.push([t0, v0]);
      /* the stretch between an entrance and an exit holds the same value: two keyframes say that, hundreds do not */
      if (same(v0, v1)) continue;
      const span = t1 - t0; if (span <= step * 1.5) continue;
      for (let t = t0 + step; t < t1 - step * 0.5; t += step) out.push([+t.toFixed(5), lerp(v0, v1, fn((t - t0) / span))]);
    }
    out.push(keys[keys.length - 1]);
    return out;
  }
  const same = (a, b) => Math.abs(a[0] - b[0]) < 0.002 && JSON.stringify(a[1]) === JSON.stringify(b[1]);
  async function apply() {
    if (running) return;
    await loadClips(true);
    const any = clips.some((c) => c.props.some((p) => p.on) || movedFor(c).some(({ o }) => o.on !== false));
    if (!any) { toast(clips.length ? 'Tick at least one property.' : 'Select a clip with keyframes in the timeline first.', 'err'); return; }
    if (!await License.guardExport('curves', 'Motion Curves export')) return;
    running = true; const btn = $('#mc-apply'); btn.disabled = true; btn.textContent = 'Applying…';
    try {
      let written = 0; const warnings = [];
      const mode = st.mode || 'adjustment', justMoved = new Set();
      for (const c of clips) {
        const inPlace = [], move = [];
        for (const p of c.props) {
          if (!p.on) continue;
          const kind = kindOf(p.name), movable = mode !== 'motion' && kind && (p.compName === 'Motion' || p.compName === 'Opacity');
          (movable ? move : inPlace).push(p);
        }
        /* keyframes that stay where they are: curved in place */
        if (inPlace.length) {
          for (const p of inPlace) {
            const k = clipKey(c) + '|' + propKey(p), o = st.orig[k];
            if (!o || o.moved || !same(o.keys[0], p.keys[0]) || !same(o.keys[o.keys.length - 1], p.keys[p.keys.length - 1]) || p.keys.length < o.keys.length) st.orig[k] = { keys: p.keys, name: p.name, compName: p.compName };
          }
          const r = await CS.call('MC_writeKeys', viaFile({ track: c.track, start: c.start, interp: nativeInterp(), props: inPlace.map((p) => ({ comp: p.comp, param: p.param, name: p.name, interp: nativeInterp(), keys: bake(st.orig[clipKey(c) + '|' + propKey(p)].keys, c.fps) })) }));
          if (!r.ok) throw new Error(r.error);
          written += r.written || 0; warnings.push(...(r.warnings || []));
        }
        /* Motion / Opacity keyframes: moved onto a Transform effect (on an adjustment layer, or on the clip) */
        if (move.length) {
          const r = await CS.call('MC_moveKeys', viaFile({ track: c.track, start: c.start, mode, template: template(), name: 'Motion Curves · ' + c.name, shutter: st.shutter,
            interp: nativeInterp(), props: move.map((p) => ({ comp: p.comp, param: p.param, kind: kindOf(p.name), keys: bake(p.keys, c.fps), orig: p.keys })) }));
          if (!r.ok) throw new Error(r.error);
          written += r.keyframes || 0; warnings.push(...(r.warnings || []));
          for (const p of move) {
            const got = (r.props || []).find((x) => x.kind === kindOf(p.name));
            justMoved.add(clipKey(c) + '|' + propKey(p));
            st.orig[clipKey(c) + '|' + propKey(p)] = { keys: p.keys, name: p.name, compName: p.compName, on: true,
              moved: got ? { kind: got.kind, comp: got.comp, param: got.param, layerKeys: got.layerKeys, target: r.target, layer: r.layer } : { kind: kindOf(p.name), target: r.target, layer: r.layer, layerKeys: [] } };
          }
        }
        /* keyframes moved earlier: re-curved where they live now */
        const again = movedFor(c).filter(({ key, o }) => !justMoved.has(key) && o.on !== false && o.moved.layerKeys && o.moved.layerKeys.length > 1 && o.moved.comp >= 0);
        if (again.length) {
          const t = again[0].o.moved.target;
          const r = await CS.call('MC_writeKeys', viaFile({ track: t.track, start: t.start, interp: nativeInterp(), props: again.map(({ o }) => ({ comp: o.moved.comp, param: o.moved.param, name: o.name, interp: nativeInterp(), keys: bake(o.moved.layerKeys, c.fps) })) }));
          if (!r.ok) throw new Error(r.error);
          written += r.written || 0; warnings.push(...(r.warnings || []));
        }
      }
      save();
      toast((PRESETS[st.preset] || {}).name + ' applied · ' + written + ' keyframes' + (mode !== 'motion' ? ' on the ' + MODE_NAME[mode] : '') + (warnings.length ? ' · ' + warnings[0] : ''), warnings.length ? '' : 'ok');
      License.noteExport('curves');
      try { Usage.tick('curves'); Usage.tick('set:curves:preset:' + st.preset); Usage.tick('set:curves:mode:' + mode); } catch (e) {}
      lastSig = ''; await loadClips(true);
    } catch (e) { toast(e.message || String(e), 'err'); try { Usage.fail('curves', 'apply', e.message); } catch (e2) {} }
    finally { running = false; btn.disabled = false; btn.textContent = 'Apply curve'; }
  }
  async function revert() {
    if (running) return;
    await loadClips(true);
    running = true;
    try {
      let did = 0;
      for (const c of clips) {
        /* curved in place */
        const list = c.props.filter((p) => p.on && st.orig[clipKey(c) + '|' + propKey(p)] && !st.orig[clipKey(c) + '|' + propKey(p)].moved);
        if (list.length) {
          const r = await CS.call('MC_writeKeys', viaFile({ track: c.track, start: c.start, props: list.map((p) => ({ comp: p.comp, param: p.param, name: p.name, keys: st.orig[clipKey(c) + '|' + propKey(p)].keys })) }));
          if (!r.ok) throw new Error(r.error);
          for (const p of list) delete st.orig[clipKey(c) + '|' + propKey(p)];
          did += list.length;
        }
        /* moved away: back onto the clip, layer removed or Transform cleared */
        const moved = movedFor(c).filter(({ o }) => o.on !== false);
        if (moved.length) {
          const byLayer = new Map();
          for (const m of moved) { const id = JSON.stringify(m.o.moved.layer || m.o.moved.target); if (!byLayer.has(id)) byLayer.set(id, []); byLayer.get(id).push(m); }
          for (const group of byLayer.values()) {
            const m0 = group[0].o.moved, [comp, param] = group.map(({ key }) => key.split('|')[1].split(':').map(Number))[0] || [];
            const r = await CS.call('MC_undoMove', viaFile({ track: c.track, start: c.start, layer: m0.layer, target: m0.target,
              props: group.map(({ key, o }) => { const [cc, pp] = key.split('|')[1].split(':').map(Number); return { comp: cc, param: pp, name: o.name, keys: o.keys }; }),
              tparams: group.filter(({ o }) => o.moved.comp >= 0).map(({ o }) => ({ comp: o.moved.comp, param: o.moved.param, kind: o.moved.kind })) }));
            if (!r.ok) throw new Error(r.error);
            for (const { key } of group) delete st.orig[key];
            did += group.length;
          }
        }
      }
      if (!did) { toast('Nothing to revert: these properties were not curved from here.', 'err'); return; }
      save(); toast('Original keyframes restored on the clip.', 'ok');
      lastSig = ''; await loadClips(true);
    } catch (e) { toast(e.message || String(e), 'err'); }
    finally { running = false; }
  }

  /* a slider with its value label: slider('#id', object, key, format) */
  function slider(id, obj, key, fmt, after) {
    const el = $(id); if (!el) return;
    const lab = el.parentNode.querySelector('.val');
    const show = () => { if (lab) lab.textContent = fmt(+obj[key]); };
    el.value = String(obj[key]); show();
    el.oninput = () => { obj[key] = +el.value; show(); };
    el.onchange = () => { obj[key] = +el.value; show(); save(); if (after) after(); };
  }
  function modeInit() {
    const sel = $('#mc-mode'); if (!sel) return;
    sel.value = st.mode; sel.onchange = () => { st.mode = sel.value; save(); modeRender(); };
    slider('#mc-shutter', st, 'shutter', (v) => v + '°');
    modeRender();
  }
  function modeRender() {
    const sh = $('#mc-shutter-row'); if (sh) sh.hidden = st.mode === 'motion';
    const note = $('#mc-mode-note'); if (note) note.textContent = st.mode === 'adjustment' ? 'An adjustment layer with a Transform effect is placed above the clip. Motion keyframes on the clip are moved onto it.' : st.mode === 'transform' ? 'A Transform effect is added to the clip. Its Motion keyframes are moved onto it.' : 'Keyframes go on the clip itself (Motion, Opacity or the effect they are on). No motion blur.';
  }

  /* ---- animate the clip: ready animations for coming in and going out, both built from the chosen curve ---- */
  const ANIMS = [
    { id: 'slideL', name: 'From left', cat: 'In', io: 'in', slide: [-1, 0] },
    { id: 'slideR', name: 'From right', cat: 'In', io: 'in', slide: [1, 0] },
    { id: 'slideT', name: 'From top', cat: 'In', io: 'in', slide: [0, -1] },
    { id: 'slideB', name: 'From bottom', cat: 'In', io: 'in', slide: [0, 1] },
    { id: 'cornerIn', name: 'From corner', cat: 'In', io: 'in', slide: [-0.8, -0.8] },
    { id: 'growIn', name: 'Grow in', cat: 'In', io: 'in', scale: 0 },
    { id: 'pullIn', name: 'Pull back', cat: 'In', io: 'in', scale: 1.8 },
    { id: 'popIn', name: 'Pop in', cat: 'In', io: 'in', scale: 0.4, fade: true },
    { id: 'fadeIn', name: 'Fade in', cat: 'In', io: 'in', fade: true },
    { id: 'spinIn', name: 'Spin in', cat: 'In', io: 'in', rot: -360 },
    { id: 'flipIn', name: 'Flip in', cat: 'In', io: 'in', scaleW: 0 },
    { id: 'tiltIn', name: 'Tilt in', cat: 'In', io: 'in', rot: -25, scale: 0.7, fade: true },
    { id: 'slideLo', name: 'To left', cat: 'Out', io: 'out', slide: [-1, 0] },
    { id: 'slideRo', name: 'To right', cat: 'Out', io: 'out', slide: [1, 0] },
    { id: 'slideTo', name: 'To top', cat: 'Out', io: 'out', slide: [0, -1] },
    { id: 'slideBo', name: 'To bottom', cat: 'Out', io: 'out', slide: [0, 1] },
    { id: 'cornerOut', name: 'To corner', cat: 'Out', io: 'out', slide: [0.8, 0.8] },
    { id: 'shrinkOut', name: 'Shrink out', cat: 'Out', io: 'out', scale: 0 },
    { id: 'pushOut', name: 'Push out', cat: 'Out', io: 'out', scale: 1.8 },
    { id: 'popOut', name: 'Pop out', cat: 'Out', io: 'out', scale: 0.4, fade: true },
    { id: 'fadeOut', name: 'Fade out', cat: 'Out', io: 'out', fade: true },
    { id: 'spinOut', name: 'Spin out', cat: 'Out', io: 'out', rot: 360 },
    { id: 'flipOut', name: 'Flip out', cat: 'Out', io: 'out', scaleW: 0 },
    { id: 'tiltOut', name: 'Tilt out', cat: 'Out', io: 'out', rot: 25, scale: 0.7, fade: true }
  ];
  const ANIM_BY = {}; for (const a of ANIMS) ANIM_BY[a.id] = a;
  /* one animation as tracks on a clip of length L: "in" starts at the clip's start, "out" ends at its end */
  function tracksFor(p, io, len, dur, amt) {
    const d = Math.min(dur, len), a = io === 'in' ? 0 : Math.max(0, len - d), b = io === 'in' ? d : len;
    const seg = (off, on) => io === 'in' ? [[a, off], [b, on]] : [[a, on], [b, off]];
    const t = [];
    if (p.slide) t.push({ kind: 'pos', rel: true, keys: seg([p.slide[0] * amt, p.slide[1] * amt], [0, 0]) });
    if (p.scale !== undefined) t.push({ kind: 'scale', keys: seg(+(100 * (1 + (p.scale - 1) * amt)).toFixed(2), 100) });
    if (p.scaleW !== undefined) t.push({ kind: 'scaleW', keys: seg(+(100 * (1 + (p.scaleW - 1) * amt)).toFixed(2), 100) });
    if (p.rot) t.push({ kind: 'rot', keys: seg(+(p.rot * amt).toFixed(2), 0) });
    if (p.fade) t.push({ kind: 'op', keys: seg(0, 100) });
    return t;
  }
  const animOpts = () => ({ dur: clamp(+st.anim.dur || 0.5, 0.05, 10), amt: clamp(+st.anim.amount || 100, 1, 300) / 100 });
  /* one preset on its own, for its card in the gallery */
  function animTracksFor(p, L) {
    const o = animOpts(), len = L || o.dur + 0.5;
    return { tracks: tracksFor(p, p.io, len, o.dur, o.amt), len, preset: p };
  }
  const inAnim = () => ANIM_BY[st.anim.in] || null, outAnim = () => ANIM_BY[st.anim.out] || null;
  /* what will actually be written: the chosen coming-in and going-out animations on one clip. A property both of
     them touch becomes a single row of keyframes: off, on … on, off. */
  function animTracks(L) {
    const o = animOpts(), len = L || Math.max(o.dur * 2 + 0.5, 1.4);
    const parts = [];
    const pi = inAnim(), po = outAnim();
    if (pi) parts.push(...tracksFor(pi, 'in', len, o.dur, o.amt));
    if (po) parts.push(...tracksFor(po, 'out', len, o.dur, o.amt));
    const byKind = new Map();
    for (const t of parts) {
      const e = byKind.get(t.kind);
      if (!e) byKind.set(t.kind, t);
      else {
        const seen = {}; e.keys = e.keys.concat(t.keys).sort((x, y) => x[0] - y[0])
          .filter((k) => { const key = k[0].toFixed(4); if (seen[key]) return false; seen[key] = 1; return true; });
      }
    }
    return { tracks: [...byKind.values()], len, preset: pi || po, both: !!(pi && po) };
  }

  /* the gallery: a card per animation, playing on hover (or all of them, like the transitions gallery) */
  const cards = [];
  let cardRaf = 0, cardCursor = 0, cardTick = 0, loopId = 0;
  const midOf = (pv) => { const k = pv.tracks[0].keys; return (k[0][0] + k[k.length - 1][0]) / 2; };
  function cardFrame(rec, t) {
    const pv = animTracksFor(rec.preset);
    const still = t === undefined;
    drawScene(rec.cv.getContext('2d'), rec.cv.width, rec.cv.height, pv, still ? 0 : clamp(t, 0, pv.len), { pad: 4, ghosts: false, poster: still });
  }
  function cardLoop(ts, id) {
    if (id !== loopId) return;   /* an older loop: let it die */
    cardTick = ts;
    const live = cards.filter((c) => c.cv.isConnected);
    const want = st.anim.all ? live : live.filter((c) => c.hover);
    if (!want.length) { cardRaf = 0; return; }   /* nothing to draw: stop, and start again on the next hover */
    const per = st.anim.all ? Math.max(1, Math.ceil(live.length / 5)) : live.length;
    let drawn = 0;
    for (let k = 0; k < live.length && drawn < per; k++) {
      const c = live[(cardCursor + k) % live.length];
      if (!st.anim.all && !c.hover) continue;
      const r = c.cv.getBoundingClientRect();
      if (r.bottom < -40 || r.top > window.innerHeight + 40) continue;
      const pv = animTracksFor(c.preset), hold = 0.5, period = pv.len + hold;
      /* a hovered card starts at the first frame straight away instead of joining the loop wherever it happens to be */
      /* a hovered card waits a beat on its first frame (an arriving picture starts on an empty frame), then plays */
      const lead = 0.18;
      const x = c.hover && c.t0 ? Math.max(0, ((ts - c.t0) / 1000) % (period + lead) - lead) : (ts / 1000 + c.phase) % period;
      cardFrame(c, loopT(pv, x, hold));
      drawn++;
    }
    cardCursor = (cardCursor + per) % live.length;
    cardRaf = requestAnimationFrame((t) => cardLoop(t, id));
  }
  /* start the loop, and start a fresh one if the old handle went stale (a hidden panel never runs its frames) */
  const ensureCards = () => {
    if (cardRaf && performance.now() - cardTick < 1000) return;
    const id = ++loopId;
    cardRaf = requestAnimationFrame((t) => cardLoop(t, id));
  };
  function renderGallery() {
    const box = $('#mc-gallery'); if (!box) return;
    box.innerHTML = ''; cards.length = 0;
    for (const cat of ['In', 'Out']) {
      box.appendChild(h('div', 'cat', cat === 'In' ? 'Comes in' : 'Goes out'));
      const grid = h('div', 'ggrid');
      for (const p of ANIMS.filter((x) => x.cat === cat)) {
        const b = h('button', 'gcard' + (p.id === (p.io === 'in' ? st.anim.in : st.anim.out) ? ' on' : '')); b.dataset.id = p.id; b.title = p.name;
        const cv = h('canvas', 'pv'); cv.width = 120; cv.height = 96;
        const rec = { cv, preset: p, hover: false, phase: Math.random() * 2 };
        cards.push(rec); cardFrame(rec);
        b.append(cv, h('div', 'nm', p.name));
        b.addEventListener('mouseenter', () => { rec.hover = true; rec.t0 = performance.now(); cardFrame(rec, 0); ensureCards(); });
        b.addEventListener('mouseleave', () => { rec.hover = false; rec.t0 = 0; if (!st.anim.all) cardFrame(rec); });
        /* clicking picks it; clicking the chosen one again takes it off, so you can have only an in, only an out, or both */
        b.addEventListener('click', () => {
          const k = p.io === 'in' ? 'in' : 'out';
          st.anim[k] = st.anim[k] === p.id ? null : p.id;
          save(); renderAnim(); previewT0 = 0; drawPreview();
        });
        grid.appendChild(b);
      }
      box.appendChild(grid);
    }
    if (st.anim.all) ensureCards();
  }
  function renderAnim() {
    const box = $('#mc-anim'); if (!box) return;
    box.querySelectorAll('.gcard').forEach((b) => b.classList.toggle('on', b.dataset.id === st.anim.in || b.dataset.id === st.anim.out));
    const pi = inAnim(), po = outAnim();
    const what = [pi && pi.name.toLowerCase(), po && po.name.toLowerCase()].filter(Boolean).join(' + ');
    const btn = $('#mc-animate');
    if (btn) { btn.disabled = running || !clips.length || !what; btn.textContent = running ? 'Adding…' : (what ? 'Add ' + what : 'Pick an animation below'); }
    const hint = $('#mc-anim-hint'); if (hint) hint.textContent = clips.length ? (clips.length === 1 ? clips[0].name : clips.length + ' clips selected') : 'Select a clip in the timeline first.';
  }
  function animInit() {
    const restart = () => { previewT0 = 0; drawPreview(); if (!st.anim.all) for (const c of cards) if (!c.hover) cardFrame(c); };
    slider('#mc-dur', st.anim, 'dur', (v) => v.toFixed(2) + ' s', restart);
    slider('#mc-amount', st.anim, 'amount', (v) => v + '%', restart);
    const all = $('#mc-animall');
    if (all) { all.classList.toggle('on', !!st.anim.all); all.onclick = () => { st.anim.all = !st.anim.all; all.classList.toggle('on', st.anim.all); save(); if (st.anim.all) ensureCards(); else for (const c of cards) cardFrame(c); }; }
    renderGallery(); renderAnim();
  }
  async function animate() {
    if (running) return;
    await loadClips(true);
    if (!clips.length) { toast('Select a clip in the timeline first.', 'err'); return; }
    if (!inAnim() && !outAnim()) { toast('Pick an animation from the gallery first.', 'err'); return; }
    if (!await License.guardExport('curves', 'Motion Curves export')) return;
    const mode = st.mode || 'adjustment';
    running = true; renderAnim();
    try {
      let keys = 0; const warnings = [];
      for (const c of clips) {
        const L = Math.max(0.1, c.end - c.start), list = animTracks(L), fx = [];
        const params = (tr) => {
          const keys = bake(tr.keys, c.fps), interp = nativeInterp();
          if (tr.kind === 'pos') return { name: 'Position', point: true, rel: true, keys, interp };
          if (tr.kind === 'scale') return { name: mode === 'motion' ? 'Scale' : 'Scale Height', alias: ['Scale'], keys, interp };
          if (tr.kind === 'scaleW') return { name: 'Scale Width', keys, interp };
          if (tr.kind === 'rot') return { name: 'Rotation', keys, interp };
          return { name: 'Opacity', keys, interp };
        };
        if (mode === 'motion') {
          const motion = list.tracks.filter((t) => t.kind !== 'op').map(params), op = list.tracks.filter((t) => t.kind === 'op').map(params);
          /* a flip squashes one side only, which Premiere allows once Uniform Scale is off */
          if (list.tracks.some((t) => t.kind === 'scaleW')) motion.unshift({ name: 'Uniform Scale', keys: [[0, false]], optional: true });
          if (motion.length) fx.push({ name: 'Motion', params: motion });
          if (op.length) fx.push({ name: 'Opacity', params: op });
        } else {
          const ps = list.tracks.map(params);
          const flat = list.tracks.some((t) => t.kind === 'scaleW');
          if (flat || list.tracks.some((t) => t.kind === 'scale')) ps.unshift({ name: 'Uniform Scale', keys: [[0, !flat]] });
          ps.push({ name: "Use Composition's Shutter Angle", keys: [[0, false]], optional: true }, { name: 'Shutter Angle', keys: [[0, clamp(+st.shutter || 180, 0, 360)]], optional: true });
          fx.push({ name: 'Transform', params: ps });
        }
        const r = await CS.call('MC_animate', viaFile({ track: c.track, start: c.start, mode, template: template(), name: 'Motion Curves · ' + c.name, effects: fx }));
        if (!r.ok) throw new Error(r.error);
        keys += r.keyframes || 0; warnings.push(...(r.warnings || []));
      }
      const pi = inAnim(), po = outAnim();
      const label = [pi && pi.name, po && po.name].filter(Boolean).join(' + ');
      toast(label + ' added · ' + keys + ' keyframes on the ' + MODE_NAME[mode] + (warnings.length ? ' · ' + warnings[0] : ''), warnings.length ? '' : 'ok');
      License.noteExport('curves');
      try { Usage.tick('curves'); if (pi) Usage.tick('set:curves:in:' + pi.id); if (po) Usage.tick('set:curves:out:' + po.id); } catch (e) {}
      lastSig = ''; await loadClips(true);
    } catch (e) { toast(e.message || String(e), 'err'); try { Usage.fail('curves', 'animate', e.message); } catch (e2) {} }
    finally { running = false; renderAnim(); }
  }

  function open() {
    Hub.show('curves');
    const ed = $('#mc-editor'); ed.innerHTML = ''; editor = mkEditor(); ed.appendChild(editor.el);
    renderGrid(); readoutInput(); readout(); markGrid();
    const ev = $('#mc-every'); ev.value = String(st.every); ev.onchange = () => { st.every = +ev.value; save(); };
    const all = $('#mc-all'); all.classList.toggle('on', !!st.all); all.onclick = () => { st.all = !st.all; all.classList.toggle('on', st.all); for (const c of clips) for (const p of c.props) p.on = st.all; save(); renderProps(); previewT0 = 0; };
    modeInit(); animInit();
    document.querySelectorAll('#mc-tabbar button').forEach((b) => { b.onclick = () => showTab(b.dataset.tab); });
    showTab(st.tab === 'curve' ? 'curve' : 'animate');
    lastSig = ''; loadClips().then(startPolling);
  }
  function init() {
    const a = $('#mc-apply'); if (a) a.addEventListener('click', apply);
    const r = $('#mc-revert'); if (r) r.addEventListener('click', revert);
    const f = $('#mc-refresh'); if (f) f.addEventListener('click', () => { lastSig = ''; loadClips(); });
    const go = $('#mc-animate'); if (go) go.addEventListener('click', animate);
  }
  return { open, init };
})();
