/* Turns (state, sources, time) into either WebGL quads (render mode) or
   screen-space samples (native keyframe mode). */
const BASE_AREA = 3.3 * (3.3 * 16 / 9);   /* a 9:16 card is 3.3 units wide */
const BG_BLUR_PX = 260;

function wrapD(i, phase, n) {
  let d = (((i - phase) % n) + n) % n;
  if (d > n / 2) d -= n;
  return d;
}

/* cover crop of a source (aspect sa) into a box of aspect qa -> [uvScale, uvOff] */
function coverUV(sa, qa, off) {
  let uvScale = [1, 1];
  if (sa > qa) uvScale = [qa / sa, 1]; else uvScale = [1, sa / qa];
  const ox = 0.5 + (off ? off[0] : 0) * 0.5, oy = 0.5 - (off ? off[1] : 0) * 0.5;
  return [uvScale, [(1 - uvScale[0]) * ox, (1 - uvScale[1]) * oy]];
}

/* ---------------------------------------------------------------- core solve */
function solveScene(state, sources, t, frameW, frameH) {
  const n = sources.length;
  const aspect = frameW / frameH;
  const viewW = aspect < 1 ? 10 : 10 * aspect;
  const viewH = aspect < 1 ? 10 / aspect : 10;
  const dur = Math.max(0.1, state.duration);
  const cam = state.camera, fx = state.fx, cardS = state.card;
  const rnd = (a, b) => hashRand(a + 11, b + 7);
  const easeMain = (x) => ease(state.ease, x);

  /* camera */
  const camDef = CAMERAS[cam.preset] || CAMERAS.static;
  const cp = paramValues(camDef.params, cam.cp);
  const cm = camDef.fn(t, { dur, p: cp }) || {};
  const baseFov = cam.fov * DEG;
  const fov = baseFov * (cm.fovMul || 1);
  const dist = (viewH / 2) / Math.tan(baseFov / 2) * cam.zoom * (cm.dist || 1);
  const yaw = cam.yaw * DEG + (cm.yaw || 0), pitch = cam.pitch * DEG + (cm.pitch || 0), roll = cam.roll * DEG + (cm.roll || 0);
  const target = [cm.x || 0, cam.height + (cm.y || 0), 0];
  const eye = [target[0] + dist * Math.cos(pitch) * Math.sin(yaw), target[1] + dist * Math.sin(pitch), target[2] + dist * Math.cos(pitch) * Math.cos(yaw)];
  const up = [Math.sin(roll), Math.cos(roll), 0];
  const proj = Mat4.perspective(fov, aspect, 0.05, 400);
  const view = Mat4.lookAt(eye, target, up);
  const vp = Mat4.multiply(proj, view);
  const out = { n, aspect, viewW, viewH, dur, eye, view, proj, vp, dist, fov, cards: [], phase: 0, w: 0, h: 0, ca: 1, minD: 0, maxD: 1, focusDepth: 0 };
  if (!n) return out;

  /* card size */
  let ca = CARD_ASPECTS[cardS.aspect] || 0;
  if (!ca) ca = clamp(sources[0].aspect || 0.5625, 0.3, 3);
  const w = Math.sqrt(BASE_AREA * ca) * cardS.size, h = w / ca;
  const R = Math.max(w * 0.9, n * w * cardS.spacing / TAU) * cardS.radiusScale;
  const Rv = Math.max(h * 0.9, n * h * cardS.spacing / TAU) * cardS.radiusScale;
  out.w = w; out.h = h; out.ca = ca;

  /* motion */
  const motDef = MOTIONS[state.motion] || MOTIONS.step;
  const mp = paramValues(motDef.params, state.mp);
  let phase = motDef.fn(t * (state.speed || 1), { dur, n, p: mp, ease: easeMain, rnd }) * state.dir + cardS.focusOffset;
  out.rawPhase = phase;
  if (state.linger > 0 || state.lingerCurve) { const kf = Math.floor(phase); phase = kf + lingerWarp(phase - kf, state.linger, state.lingerCurve); }

  /* intro / outro */
  const intro = state.intro, outro = state.outro;
  const inDef = INTROS[intro.style] || INTROS.none, outDef = INTROS[outro.style] || INTROS.none;
  const gm = { phase: 0, s: 1, sy: 1, y: 0, gx: 0, gy: 0, o: 1 };
  const applyGroup = (g) => { if (!g) return; gm.phase += g.phase || 0; gm.s *= g.s === undefined ? 1 : g.s; gm.sy *= g.sy === undefined ? 1 : g.sy; gm.y += g.y || 0; gm.gx += g.gx || 0; gm.gy += g.gy || 0; gm.o *= g.o === undefined ? 1 : g.o; };
  const ctxG = { n, viewW, viewH, camDist: dist, rnd };
  if (intro.enabled && inDef.group) applyGroup(inDef.group(ease(intro.ease, clamp(t / Math.max(0.01, intro.dur), 0, 1)), ctxG));
  if (outro.enabled && outDef.group) applyGroup(outDef.group(ease(outro.ease, clamp((dur - t) / Math.max(0.01, outro.dur), 0, 1)), ctxG));
  phase += gm.phase;
  out.phase = phase;

  /* layout */
  const layDef = LAYOUTS[state.layout] || LAYOUTS.carousel;
  const lp = paramValues(layDef.params, (state.lp || {})[state.layout]);
  const ctx = { phase, frac: ((phase / n) % 1 + 1) % 1, t, dur, w, h, R, Rv, p: lp, camDist: dist, viewW, viewH, rnd, n };

  const cards = out.cards;
  for (let i = 0; i < n; i++) {
    const src = sources[i];
    const d = wrapD(i, phase, n);
    const tr = layDef.fn(d, i, n, ctx);
    let x = tr.x, y = tr.y + cardS.yOffset, z = tr.z, rx = tr.rx, ry = tr.ry, rz = tr.rz, sx = tr.s, sy = tr.s, o = tr.o * gm.o, blur = tr.blur || 0;
    const mod = (def, p) => {
      if (!def.fn) return;
      const m = def.fn(p, i, n, ctxG);
      if (!m || m === ID) return;
      x += m.x || 0; y += m.y || 0; z += m.z || 0; rx += m.rx || 0; ry += m.ry || 0; rz += m.rz || 0;
      if (m.s !== undefined) { sx *= m.s; sy *= m.s; }
      if (m.sx !== undefined) sx *= m.sx;
      if (m.sy !== undefined) sy *= m.sy;
      if (m.o !== undefined) o *= m.o;
      blur += m.blur || 0;
    };
    if (intro.enabled) mod(inDef, ease(intro.ease, clamp((t - i * intro.stagger) / Math.max(0.01, intro.dur), 0, 1)));
    if (outro.enabled) mod(outDef, ease(outro.ease, clamp((dur - t - (n - 1 - i) * outro.stagger) / Math.max(0.01, outro.dur), 0, 1)));
    if (o <= 0.002 || sx <= 0.0001 || sy <= 0.0001) continue;

    let qw = w, qh = h;
    if (cardS.fit === 'contain' && src.aspect) {
      if (src.aspect > ca) { qw = w; qh = w / src.aspect; } else { qh = h; qw = h * src.aspect; }
    }
    const g = tr.g || [0, 0, 0];
    let G = Mat4.translate(Mat4.identity(), 0, gm.y, 0);
    G = Mat4.scale(G, gm.s, gm.s * gm.sy, gm.s);
    const grp = state.group;
    if (grp && (grp.rx || grp.ry || grp.rz)) { G = Mat4.rotateY(G, (grp.ry || 0) * DEG); G = Mat4.rotateX(G, (grp.rx || 0) * DEG); G = Mat4.rotateZ(G, (grp.rz || 0) * DEG); }
    G = Mat4.rotateZ(G, g[2]);
    G = Mat4.rotateX(G, g[0] + gm.gx);
    G = Mat4.rotateY(G, g[1] + gm.gy);
    let M = Mat4.translate(G, x, y, z);
    M = Mat4.rotateY(M, ry); M = Mat4.rotateX(M, rx); M = Mat4.rotateZ(M, rz);
    M = Mat4.scale(M, sx, sy, 1);
    const center = Mat4.transformPoint(M, [0, 0, 0]);
    const vc = Mat4.transformPoint(view, center);
    const depth = -vc[2];
    if (depth < 0.02) continue;
    const normal = Mat4.transformDir(M, [0, 0, 1]);
    const toCam = [eye[0] - center[0], eye[1] - center[1], eye[2] - center[2]];
    const facing = (normal[0] * toCam[0] + normal[1] * toCam[1] + normal[2] * toCam[2]) >= 0;
    const layer = center[2] >= -0.0001 ? 'front' : 'back';
    cards.push({ i, src, M, depth, facing, layer, o, blur, qw, qh, d, ry: ry + g[1] + gm.gy + yaw + (grp ? (grp.ry || 0) * DEG : 0), center });
  }
  if (!cards.length) return out;
  let minD = Infinity, maxD = -Infinity;
  for (const c of cards) { minD = Math.min(minD, c.depth); maxD = Math.max(maxD, c.depth); }
  const originDepth = -Mat4.transformPoint(view, [0, 0, 0])[2];
  out.minD = minD; out.maxD = maxD;
  out.focusDepth = fx.focus === 'center' ? originDepth : fx.focus === 'back' ? maxD : minD;
  for (const c of cards) {
    const dn = (c.depth - minD) / (maxD - minD + 1e-6);
    c.bright = (1 - fx.dim * dn) * fx.bright;
    c.gray = fx.gray * dn;
    if (fx.depthBlur) c.blur += Math.abs(c.depth - out.focusDepth) * fx.blurAmt * 9;
    c.blur = Math.min(c.blur, 70);
    const qa = c.qw / c.qh, sa = c.src.aspect || qa;
    if (state.card.fit !== 'contain') { const cu = coverUV(sa, qa, [state.card.offX || 0, state.card.offY || 0]); c.uvScale = cu[0]; c.uvOff = cu[1]; }
    else { c.uvScale = [1, 1]; c.uvOff = [0, 0]; }
    if (!c.facing) { if (fx.backface === 'hide') c.o = 0; else if (fx.backface === 'dim') c.bright *= 0.5; }
  }
  cards.sort((a, b) => b.depth - a.depth);
  return out;
}

/* ------------------------------------------------------------- background */
function solveBackground(state, sources, S, t) {
  const bg = state.bg;
  if (!bg || !bg.enabled || !S.n) return [];
  const n = S.n;
  let items = [];
  if (bg.source === 'first') items.push({ src: sources[0], weight: 1 });
  else {
    const ph = ((S.phase % n) + n) % n;
    const a = Math.floor(ph) % n, b = (a + 1) % n, frac = ph - Math.floor(ph);
    const fade = Math.max(0.02, bg.fade);
    const wB = a === b ? 0 : clamp((frac - (1 - fade)) / fade, 0, 1);
    const wSmooth = wB * wB * (3 - 2 * wB);
    items.push({ src: sources[a], weight: 1 });
    if (wSmooth > 0.001) items.push({ src: sources[b], weight: wSmooth });
  }
  const mv = BG_MOVES[bg.move] || BG_MOVES.none;
  const bp = paramValues(mv.params, bg.bgp);
  let focusX = 0;
  for (const c of S.cards) if (Math.abs(c.d) < 0.5) { focusX = c.center[0]; break; }
  const m = mv.fn(t, { dur: S.dur, phase: S.phase, n, p: bp, focusX }) || {};
  const frameA = S.viewW / S.viewH;
  for (const it of items) {
    const cu = coverUV(it.src.aspect || frameA, frameA);
    Object.assign(it, {
      x: (m.x || 0), y: (m.y || 0), s: bg.zoom * (m.s || 1), rz: m.rz || 0,
      blurPx: bg.blur * BG_BLUR_PX, bright: 1 - bg.dark, gray: 1 - bg.sat, opacity: bg.opacity * it.weight,
      uvScale: cu[0], uvOff: cu[1]
    });
  }
  return items;
}

/* -------------------------------------------------------------- render mode */
function buildScene(state, sources, t, frameW, frameH, opts) {
  opts = opts || {};
  const layer = opts.layer || 'all';
  const quads = [];
  const S = solveScene(state, sources, t, frameW, frameH);
  const out = { quads, n: S.n, rawPhase: S.rawPhase || 0 };
  if (!S.n) return out;
  const K = PX_PER_UNIT, fx = state.fx, cardS = state.card;

  if (layer === 'all' || layer === 'bg') {
    const items = solveBackground(state, sources, S, t);
    const ortho = [2 / S.viewW, 0, 0, 0, 0, 2 / S.viewH, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
    for (const it of items) {
      let M = Mat4.translate(Mat4.identity(), it.x, it.y, 0);
      M = Mat4.rotateZ(M, it.rz);
      M = Mat4.scale(M, it.s, it.s, 1);
      const padPx = 4;
      quads.push({
        src: it.src, sizePx: [S.viewW * K, S.viewH * K], padPx, quad: [S.viewW + 2 * padPx / K, S.viewH + 2 * padPx / K],
        mvp: Mat4.multiply(ortho, M), radius: 0, blur: it.blurPx, opacity: it.opacity, uvScale: it.uvScale, uvOff: it.uvOff,
        tint: [0, 0, 0], tintAmt: 0, gray: it.gray, bright: it.bright, border: 0, borderColor: [0, 0, 0, 1], gradTop: 1, gradBot: 1,
        vignette: 0, glow: 0, glowColor: [0, 0, 0, 0], color: [0, 0, 0, 1], bgQuad: true
      });
    }
  }
  if (layer === 'bg') return out;

  const tint = hexToRgb(fx.tint), borderColor = hexToRgb(cardS.borderColor).concat([1]), glowColor = hexToRgb(fx.glowColor).concat([fx.glow]);
  const glowPx = fx.glow > 0 ? 18 + fx.glow * 30 : 0;
  for (const c of S.cards) {
    if (c.o <= 0.002) continue;
    if (layer !== 'all' && layer !== c.layer) continue;
    let uvScale = c.uvScale.slice(), uvOff = c.uvOff.slice();
    if (fx.parallax > 0) {
      const zoom = 1 - 0.18 * fx.parallax;
      const base = coverUV(c.src.aspect || 1, c.qw / c.qh);
      uvScale = [base[0][0] * zoom, base[0][1] * zoom];
      const slackX = 1 - uvScale[0];
      uvOff = [Math.sin(c.ry) * slackX * 0.5 + (1 - uvScale[0]) / 2, (1 - uvScale[1]) / 2];
    }
    if (!c.facing && fx.backface === 'unmirror') { uvScale = [-uvScale[0], uvScale[1]]; uvOff = [1 - uvOff[0], uvOff[1]]; }
    const sizePx = [c.qw * K, c.qh * K];
    const base = {
      src: c.src, sizePx, radius: cardS.corner, uvScale, uvOff, tint, tintAmt: fx.tintAmt, gray: c.gray, bright: c.bright,
      border: cardS.border, borderColor, gradTop: 1, gradBot: 1, vignette: fx.vignette, glow: glowPx, glowColor, color: [0, 0, 0, 1]
    };
    const mk = (M, extra) => {
      const q = Object.assign({}, base, extra);
      const padPx = Math.max(q.blur * 1.6, q.glow * 3.2) + 6;
      q.padPx = padPx;
      q.quad = [c.qw + 2 * padPx / K, c.qh + 2 * padPx / K];
      q.mvp = Mat4.multiply(S.vp, M);
      return q;
    };
    if (fx.shadow > 0) {
      const Ms = Mat4.translate(c.M, 0.05 * c.qw, -0.07 * c.qh, -0.02);
      quads.push(mk(Ms, { src: null, color: [0, 0, 0, 1], blur: Math.min(70, 28 + c.blur * 0.5), opacity: 0.7 * fx.shadow * c.o, glow: 0, border: 0, bright: 1, gray: 0, tintAmt: 0 }));
    }
    if (fx.reflection > 0) {
      let Mr = Mat4.translate(c.M, 0, -c.qh, 0);
      Mr = Mat4.scale(Mr, 1, -1, 1);
      quads.push(mk(Mr, { blur: c.blur + fx.reflBlur, opacity: c.o, gradTop: 0, gradBot: fx.reflection, glow: 0 }));
    }
    quads.push(mk(c.M, { blur: c.blur, opacity: c.o }));
  }
  return out;
}

/* -------------------------------------------------------------- native mode
   Returns per-frame screen-space samples for Premiere keyframes:
   cards: [{ i, x, y (px), scale (%), rot (deg, clockwise), swivel, tilt (deg),
             opacity (%), blur (px), depth, crop: {l,t,r,b} }]  sorted far -> near
   bg:    [{ i, x, y (px), scale (%), rot, opacity (%), blur (px), crop }]     */
function sampleNative(state, sources, t, frameW, frameH, opts) {
  opts = opts || {};
  const S = solveScene(state, sources, t, frameW, frameH);
  const K = PX_PER_UNIT;
  const toPx = (p) => {
    const c = Mat4.transformPoint(S.vp, p);
    if (c[3] <= 0.0001) return null;
    return [(c[0] / c[3] * 0.5 + 0.5) * frameW, (1 - (c[1] / c[3] * 0.5 + 0.5)) * frameH];
  };
  const cards = [];
  for (const c of S.cards) {
    if (c.o <= 0.002) continue;
    const ctr = toPx(Mat4.transformPoint(c.M, [0, 0, 0]));
    const top = toPx(Mat4.transformPoint(c.M, [0, c.qh / 2, 0])), bot = toPx(Mat4.transformPoint(c.M, [0, -c.qh / 2, 0]));
    const lef = toPx(Mat4.transformPoint(c.M, [-c.qw / 2, 0, 0])), rig = toPx(Mat4.transformPoint(c.M, [c.qw / 2, 0, 0]));
    if (!ctr || !top || !bot || !lef || !rig) continue;
    const sh = Math.hypot(top[0] - bot[0], top[1] - bot[1]), sw = Math.hypot(rig[0] - lef[0], rig[1] - lef[1]);
    const ow = c.src.ow || c.src.w, oh = c.src.oh || c.src.h;
    const visW = ow * c.uvScale[0], visH = oh * c.uvScale[1];
    const scale = Math.max(sh / visH, sw / visW) * 100;
    /* orientation in view space */
    const nv = Mat4.transformDir(S.view, Mat4.transformDir(c.M, [0, 0, 1]));
    const yv = Mat4.transformDir(S.view, Mat4.transformDir(c.M, [0, 1, 0]));
    const nl = Math.hypot(nv[0], nv[1], nv[2]) || 1;
    const swivel = Math.atan2(nv[0] / nl, nv[2] / nl) / DEG;
    const tilt = -Math.asin(clamp(nv[1] / nl, -1, 1)) / DEG;
    /* roll from the card's up vector (clockwise positive, like Premiere) */
    const rot = Math.atan2(yv[0], yv[1]) / DEG;
    const pxPerCardPx = sh / (c.qh * K);
    const corners = [[-c.qw / 2, c.qh / 2], [c.qw / 2, c.qh / 2], [-c.qw / 2, -c.qh / 2], [c.qw / 2, -c.qh / 2]].map(p => toPx(Mat4.transformPoint(c.M, [p[0], p[1], 0])));
    if (corners.some(p => !p)) continue;
    cards.push({
      i: c.i, x: ctr[0], y: ctr[1], scale, rot, swivel, tilt, opacity: c.o * 100, blur: c.blur * pxPerCardPx, depth: c.depth, bright: c.bright, corners,
      crop: { l: c.uvOff[0] * 100, r: (1 - c.uvOff[0] - c.uvScale[0]) * 100, t: (1 - c.uvOff[1] - c.uvScale[1]) * 100, b: c.uvOff[1] * 100 }
    });
  }
  const bg = [];
  if (S.n) {
    const pxPerUnit = frameW / S.viewW;
    for (const it of solveBackground(state, opts.bgSources || sources, S, t)) {
      const ow = it.src.ow || it.src.w, oh = it.src.oh || it.src.h;
      const scale = Math.max(frameW / (ow * it.uvScale[0]), frameH / (oh * it.uvScale[1])) * it.s * 100;
      bg.push({
        i: (opts.bgSources || sources).indexOf(it.src), x: frameW / 2 + it.x * pxPerUnit, y: frameH / 2 - it.y * pxPerUnit, scale, rot: -it.rz / DEG,
        opacity: it.opacity * 100, blur: it.blurPx * pxPerUnit / K, bright: it.bright,
        crop: { l: it.uvOff[0] * 100, r: (1 - it.uvOff[0] - it.uvScale[0]) * 100, t: (1 - it.uvOff[1] - it.uvScale[1]) * 100, b: it.uvOff[1] * 100 }
      });
    }
  }
  return { cards, bg };
}
