/* Live preview for Relight: WebGL shades the frame with the same light model as relight/relight.js, using the
   original picture and the model's normal map (depth is kept for the Depth view and as a fallback).
   Light handles are DOM elements over the canvas; dragging one moves the light. */
const RelightPreview = (() => {
  const MAXW = 960, MAXL = 6, GOBO_N = 128;
  let gl = null, prog = null, canvas = null, texO = null, texD = null, texN = null, texG = null, hasN = false, W = 0, H = 0, ready = false, u = {};
  let origImg = null, depthImg = null, sil = null;
  const VS = 'attribute vec2 p; varying vec2 v; void main(){ v = vec2(p.x, 1.0 - p.y); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }';
  const FS = `precision highp float; varying vec2 v; uniform sampler2D orig, depth, nrm, gobo; uniform int hasNormal; uniform float aspect, ambient, wrap, specular, shininess, relief, texel; uniform int nl; uniform int mode;
    uniform vec3 lpos[${MAXL}]; uniform vec3 lcol[${MAXL}]; uniform vec2 lpar[${MAXL}]; uniform vec3 laim[${MAXL}]; uniform vec2 lcone[${MAXL}];
    uniform vec3 ambColor; uniform float even, evenAmb, evenMean; uniform vec3 evenDir;
    uniform float gAmount, gSize, gSpeed, gSoft, gTime;
    uniform float shOn, shOpacity, shR, shK, shDx, shDy, feetY;
    uniform float colorOn, exGain, ct, sat, zsh, zmi, zhi; uniform vec3 gains;
    float gtex(vec2 c) { return texture2D(gobo, (c + 0.5) / ${GOBO_N}.0).r; }
    float gnoise(vec2 q) { vec2 i = floor(q), f = q - i; f = f * f * (3.0 - 2.0 * f); float a = gtex(i), b = gtex(i + vec2(1.0, 0.0)), c = gtex(i + vec2(0.0, 1.0)), d = gtex(i + vec2(1.0, 1.0)); return mix(mix(a, b, f.x), mix(c, d, f.x), f.y); }
    float goboMul(vec2 p) { float t = gTime, sp = gSpeed; vec2 dr = vec2(t * sp * 0.02 + sin(t * 0.7) * 0.01 * sp, t * sp * 0.013 + cos(t * 0.5) * 0.01 * sp); vec2 q = p * gSize + dr; float n = 0.62 * gnoise(q) + 0.38 * gnoise(q * 2.17 + vec2(0.37, 0.71)); float e = 0.08 + gSoft * 0.3; float m = smoothstep(0.5 - e, 0.5 + e, n); return 1.0 - gAmount * (1.0 - m); }
    float silAt(vec2 s) { if (s.x < 0.0 || s.x > 1.0 || s.y < 0.0 || s.y > 1.0) return 0.0; return texture2D(orig, s).a; }
    float shadowAt(vec2 uv) {
      float hgt = (uv.y - feetY) / (shK * shDy); if (hgt < 0.0) return 0.0;
      vec2 src = vec2(uv.x - hgt * shK * shDx, feetY - hgt / aspect);
      vec2 r = vec2(shR, shR / aspect) * 0.8; float m = 0.0;
      for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) m += silAt(src + vec2(float(i), float(j)) * r);
      return m / 9.0;
    }
    void main(){
      vec2 uv = v;   /* image y grows downwards, like the light handles */
      float k = relief * 518.0 * 0.5;
      vec4 oc = texture2D(orig, uv); vec3 c = oc.rgb; float alpha = oc.a;
      float dc = texture2D(depth, uv).r;
      float lum = (c.r + c.g + c.b) * alpha;
      float vl = step(0.07, dot(texture2D(orig, uv - vec2(texel, 0.0)).rgb, vec3(1.0))), vr = step(0.07, dot(texture2D(orig, uv + vec2(texel, 0.0)).rgb, vec3(1.0)));
      float vu = step(0.07, dot(texture2D(orig, uv - vec2(0.0, texel)).rgb, vec3(1.0))), vd = step(0.07, dot(texture2D(orig, uv + vec2(0.0, texel)).rgb, vec3(1.0)));
      float dl = mix(dc, texture2D(depth, uv - vec2(texel, 0.0)).r, vl), dr = mix(dc, texture2D(depth, uv + vec2(texel, 0.0)).r, vr);
      float du = mix(dc, texture2D(depth, uv - vec2(0.0, texel)).r, vu), dd = mix(dc, texture2D(depth, uv + vec2(0.0, texel)).r, vd);
      vec2 g = clamp(vec2((dr - dl) * 0.5 * k, (dd - du) * 0.5 * k), -2.5, 2.5);
      vec3 N = normalize(vec3(g, 1.0));
      if (hasNormal == 1) { vec3 m = texture2D(nrm, uv).rgb * 2.0 - 1.0; N = normalize(vec3(m.xy * max(0.1, relief * 2.0), max(0.05, m.z))); }
      /* shine only lands on pixels that have some brightness of their own, never on black edges or matte fringes */
      float gate = smoothstep(0.12, 1.0, lum);
      vec3 diff = ambient * ambColor; vec3 spec = vec3(0.0);
      vec2 p = vec2(uv.x, uv.y * aspect);
      for (int i = 0; i < ${MAXL}; i++) { if (i >= nl) break;
        vec3 L = vec3(lpos[i].x - p.x, lpos[i].y * aspect - p.y, lpos[i].z); float d2 = dot(L, L); L = L / max(1e-4, sqrt(d2));
        float fall = lpar[i].x / (1.0 + d2 / (lpar[i].y * lpar[i].y));
        fall *= smoothstep(lcone[i].x, lcone[i].y, dot(-L, laim[i]));   /* spot cone; point lights get a cone that is always open */
        float ndl = max(0.0, (dot(N, L) + wrap) / (1.0 + wrap));
        diff += ndl * fall * lcol[i];
        vec3 Hh = normalize(L + vec3(0.0, 0.0, 1.0)); float ndh = max(0.0, dot(N, Hh));
        spec += pow(ndh, shininess) * specular * fall * lcol[i];
      }
      if (mode == 1) { gl_FragColor = vec4(vec3(dc), alpha); return; }
      if (mode == 2) { gl_FragColor = vec4(N * 0.5 + 0.5, alpha); return; }
      if (gAmount > 0.0) diff *= goboMul(p);
      if (even > 0.0) { float sh = evenAmb + (1.0 - evenAmb) * max(0.0, dot(N, evenDir)); diff *= clamp(1.0 + even * (evenMean / sh - 1.0), 0.4, 2.5); }
      vec3 outc = (mode == 3 ? vec3(0.5) : c) * diff + spec * gate;
      /* soft shoulder above 75% that keeps the hue: bright areas roll off instead of clipping to yellow/green */
      float m = max(outc.r, max(outc.g, outc.b));
      if (m > 0.75) outc *= (0.75 + 0.25 * (1.0 - exp(-(m - 0.75) / 0.25))) / m;
      outc = clamp(outc, 0.0, 1.0);
      if (colorOn > 0.5) {
        outc *= gains * exGain; outc = 0.5 + (outc - 0.5) * (1.0 + ct);
        vec3 ws = (1.0 - outc) * (1.0 - outc), wh = outc * outc, wm = max(vec3(0.0), 1.0 - ws - wh);
        outc += 0.25 * (zsh * ws + zmi * wm + zhi * wh); outc = clamp(outc, 0.0, 1.0);
        float l = dot(outc, vec3(0.299, 0.587, 0.114)); outc = clamp(l + (outc - l) * sat, 0.0, 1.0);
      }
      if (shOn > 0.5) { float sm = shadowAt(uv) * shOpacity * (1.0 - alpha); if (sm > 0.002) { float An = alpha + sm; outc *= alpha / An; alpha = An; } }
      gl_FragColor = vec4(outc, alpha);
    }`;
  const load = (src) => new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('preview image failed')); im.src = src; });
  function mk(type, src) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }
  function tex(im, filter) { const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter); return t; }
  /* the dapple table: the same random bytes as the render script (same generator, same seed) */
  function goboTexture() {
    const data = new Uint8Array(GOBO_N * GOBO_N); let x = 1234567;
    for (let i = 0; i < data.length; i++) { x = (Math.imul(x, 1664525) + 1013904223) >>> 0; data[i] = (x >>> 8) & 255; }
    const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t); gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1); gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, GOBO_N, GOBO_N, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, data);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4); return t;
  }
  /* reads the picture at a small size: where the feet are, the subject's centre near the feet, whether there is transparency */
  function silhouette(im) {
    const w = 160, hh = Math.max(2, Math.round(im.naturalHeight / im.naturalWidth * w));
    const cv = document.createElement('canvas'); cv.width = w; cv.height = hh; const ctx = cv.getContext('2d'); ctx.drawImage(im, 0, 0, w, hh);
    const d = ctx.getImageData(0, 0, w, hh).data;
    let yb = -1, hasAlpha = false, cxs = 0, cxn = 0;
    for (let y = 0; y < hh; y++) { let cnt = 0; for (let x = 0; x < w; x++) { const a = d[(y * w + x) * 4 + 3]; if (a < 250) hasAlpha = true; if (a > 128) cnt++; } if (cnt >= 2) yb = y; }
    if (!hasAlpha || yb < 0) return { hasAlpha, yb: 1, cx: 0.5 };
    for (let y = Math.max(0, yb - Math.round(hh * 0.12)); y <= yb; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] > 128) { cxs += x; cxn++; }
    return { hasAlpha, yb: (yb + 0.5) / hh, cx: cxn ? (cxs / cxn + 0.5) / w : 0.5 };
  }
  async function set(files, target) {
    canvas = target;
    if (!gl) {
      gl = canvas.getContext('webgl', { premultipliedAlpha: false, preserveDrawingBuffer: true });
      prog = gl.createProgram(); gl.attachShader(prog, mk(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      gl.useProgram(prog);
      const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      for (const n of ['orig', 'depth', 'nrm', 'gobo', 'aspect', 'ambient', 'wrap', 'specular', 'shininess', 'relief', 'texel', 'nl', 'lpos', 'lcol', 'lpar', 'mode', 'hasNormal', 'laim', 'lcone', 'ambColor', 'even', 'evenAmb', 'evenMean', 'evenDir',
        'gAmount', 'gSize', 'gSpeed', 'gSoft', 'gTime', 'shOn', 'shOpacity', 'shR', 'shK', 'shDx', 'shDy', 'feetY', 'colorOn', 'exGain', 'ct', 'sat', 'zsh', 'zmi', 'zhi', 'gains']) u[n] = gl.getUniformLocation(prog, n);
      texG = goboTexture();
    }
    const [a, d, nImg] = await Promise.all([load(files.original), load(files.depth), files.normal ? load(files.normal).catch(() => null) : Promise.resolve(null)]);
    origImg = a; depthImg = d; sil = silhouette(a);
    const scale = Math.min(1, MAXW / a.naturalWidth);
    W = Math.max(2, Math.round(a.naturalWidth * scale)); H = Math.max(2, Math.round(a.naturalHeight * scale));
    canvas.width = W; canvas.height = H;
    if (texO) gl.deleteTexture(texO); if (texD) gl.deleteTexture(texD);
    texO = tex(a, gl.LINEAR); texD = tex(d, gl.LINEAR);
    if (texN) { gl.deleteTexture(texN); texN = null; }
    hasN = !!nImg; if (nImg) texN = tex(nImg, gl.LINEAR);
    ready = true;
  }
  const has = () => ready;
  /* the subject seen from above: per column, how far the nearest visible point sticks out (0..1) */
  function profile(cols) {
    if (!ready || !depthImg) return null;
    const hh = Math.max(2, Math.round(H / W * cols));
    const cv = document.createElement('canvas'); cv.width = cols; cv.height = hh; const ctx = cv.getContext('2d');
    ctx.drawImage(depthImg, 0, 0, cols, hh); const dd = ctx.getImageData(0, 0, cols, hh).data;
    ctx.clearRect(0, 0, cols, hh); ctx.drawImage(origImg, 0, 0, cols, hh); const od = ctx.getImageData(0, 0, cols, hh).data;
    const out = new Float32Array(cols);
    for (let x = 0; x < cols; x++) { let m = 0; for (let y = 0; y < hh; y++) { const i = (y * cols + x) * 4; if (od[i + 3] < 128) continue; const v = dd[i] / 255; if (v > m) m = v; } out[x] = m; }
    return out;
  }
  const hex3 = (c) => [parseInt(c.slice(0, 2), 16) / 255, parseInt(c.slice(2, 4), 16) / 255, parseInt(c.slice(4, 6), 16) / 255];
  function render(rig) {
    if (!ready) return;
    gl.viewport(0, 0, W, H); gl.useProgram(prog);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texO); gl.uniform1i(u.orig, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, texD); gl.uniform1i(u.depth, 1);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, texN || texD); gl.uniform1i(u.nrm, 2); gl.uniform1i(u.hasNormal, hasN ? 1 : 0);
    gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, texG); gl.uniform1i(u.gobo, 3);
    const aspect = H / W;
    gl.uniform1f(u.aspect, aspect); gl.uniform1f(u.ambient, +rig.ambient); gl.uniform1f(u.wrap, +rig.wrap); gl.uniform1f(u.specular, +rig.specular); gl.uniform1f(u.shininess, +rig.shininess); gl.uniform1f(u.relief, +rig.relief); gl.uniform1f(u.texel, 1 / 518);
    const ls = (rig.lights || []).slice(0, MAXL);
    const pos = new Float32Array(MAXL * 3), col = new Float32Array(MAXL * 3), par = new Float32Array(MAXL * 2), aim = new Float32Array(MAXL * 3), cone = new Float32Array(MAXL * 2);
    ls.forEach((l, i) => {
      let z = l.z == null ? 0.6 : +l.z; if (Math.abs(z) < 0.02) z = z < 0 ? -0.02 : 0.02;
      pos[i * 3] = +l.x; pos[i * 3 + 1] = +l.y; pos[i * 3 + 2] = z; const c = hex3(l.color || 'ffffff'); col[i * 3] = c[0]; col[i * 3 + 1] = c[1]; col[i * 3 + 2] = c[2]; par[i * 2] = +l.intensity; par[i * 2 + 1] = Math.max(0.05, +l.radius);
      cone[i * 2] = -2; cone[i * 2 + 1] = -1;
      if (l.type === 'spot') { let ax = (+l.ax || 0.5) - +l.x, ay = ((+l.ay || 0.5) - +l.y) * aspect, az = -z; const n = Math.sqrt(ax * ax + ay * ay + az * az) || 1; aim[i * 3] = ax / n; aim[i * 3 + 1] = ay / n; aim[i * 3 + 2] = az / n; const half = Math.max(2, Math.min(89, (+l.cone || 40) / 2)) * Math.PI / 180, soft = Math.max(0.02, Math.min(1, l.soft == null ? 0.5 : +l.soft)); cone[i * 2] = Math.cos(half); cone[i * 2 + 1] = Math.cos(half * (1 - soft)); }
    });
    const ac = hex3(rig.ambientColor || 'ffffff'); gl.uniform3f(u.ambColor, ac[0], ac[1], ac[2]);
    const ev = rig.evenFit && +rig.even > 0 ? rig.evenFit : null;
    gl.uniform1f(u.even, ev ? Math.max(0, Math.min(1, +rig.even)) : 0); gl.uniform1f(u.evenAmb, ev ? +ev.ambient : 0.5); gl.uniform1f(u.evenMean, ev ? +ev.mean || 1 : 1); gl.uniform3f(u.evenDir, ev ? +ev.dir[0] : 0, ev ? +ev.dir[1] : 0, ev ? +ev.dir[2] : 1);
    gl.uniform3fv(u.laim, aim); gl.uniform2fv(u.lcone, cone);
    /* dapples */
    const g = rig.gobo && rig.gobo.on ? rig.gobo : null;
    gl.uniform1f(u.gAmount, g ? Math.max(0, Math.min(1, +g.amount || 0)) : 0); gl.uniform1f(u.gSize, g ? +g.size || 3 : 3); gl.uniform1f(u.gSpeed, g ? +g.speed || 0 : 0); gl.uniform1f(u.gSoft, g ? (g.soft == null ? 0.5 : +g.soft) : 0.5); gl.uniform1f(u.gTime, +rig.time || 0);
    /* ground shadow (only when the picture has transparency and a subject standing in it) */
    const sc = rig.shadow, L = sc && ls[Math.max(0, Math.min(ls.length - 1, +sc.light || 0))];
    let shOn = 0, shK = 1, shDx = 0, shDy = -0.2;
    if (sc && sc.on && +sc.opacity > 0 && L && sil && sil.hasAlpha && sil.yb < 1) {
      const lz = L.z == null ? 0.6 : +L.z; shK = (+sc.length || 1) * 0.8 / (0.4 + Math.abs(lz));
      shDx = Math.max(-1.5, Math.min(1.5, (sil.cx - +L.x) * 1.2)); shDy = -0.35 * lz / (Math.abs(lz) + 0.3); if (Math.abs(shDy) < 0.12) shDy = shDy < 0 ? -0.12 : 0.12; shOn = 1;
    }
    gl.uniform1f(u.shOn, shOn); gl.uniform1f(u.shOpacity, sc ? Math.max(0, Math.min(1, +sc.opacity || 0)) : 0); gl.uniform1f(u.shR, sc ? (+sc.soft || 0) * 0.025 : 0); gl.uniform1f(u.shK, shK); gl.uniform1f(u.shDx, shDx); gl.uniform1f(u.shDy, shDy); gl.uniform1f(u.feetY, sil ? sil.yb : 1);
    /* colour */
    const c = rig.color || {}; const ex = +c.exposure || 0, ct = +c.contrast || 0, sat = c.saturation == null ? 1 : +c.saturation, te = +c.temp || 0, ti = +c.tint || 0, zs = +c.shadows || 0, zm = +c.mids || 0, zh = +c.highs || 0;
    const on = !!(ex || ct || sat !== 1 || te || ti || zs || zm || zh);
    gl.uniform1f(u.colorOn, on ? 1 : 0); gl.uniform1f(u.exGain, Math.pow(2, ex)); gl.uniform1f(u.ct, ct); gl.uniform1f(u.sat, sat); gl.uniform1f(u.zsh, zs); gl.uniform1f(u.zmi, zm); gl.uniform1f(u.zhi, zh); gl.uniform3f(u.gains, 1 + 0.25 * te + 0.08 * ti, 1 - 0.2 * ti, 1 - 0.25 * te + 0.08 * ti);
    gl.uniform1i(u.mode, (+rig.mode) || 0);
    gl.uniform1i(u.nl, ls.length); gl.uniform3fv(u.lpos, pos); gl.uniform3fv(u.lcol, col); gl.uniform2fv(u.lpar, par);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
  return { set, has, render, profile, silhouette: () => sil, size: () => ({ W, H }) };
})();
