/*  Something to do while the panel works: a small 3D race in the panel itself.

    A button on the progress box after a few seconds of waiting. The game takes the keyboard completely -
    the arrows, WASD and space are registered with Premiere as ours while it runs, so the space bar does
    not start playback and the panel's own shortcuts (the wheel) are stopped before they see a key. The
    moment the job finishes the game pauses and asks whether to go back to editing.

    Rendering is raw WebGL, flat shaded, one static buffer for the map and a handful of moving parts. The
    map: an arena with buildings to steer round, a bridge, a chain of small ramps and one big jump, and
    eight checkpoints to drive through in order - the tall glowing pillars, the way a certain other game
    does it. Best lap time is kept in localStorage.                                                       */
const Race = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };

  /* ------------------------------------------------------------ the map: a small city */
  const ARENA = 90;                       /* half-size: the world runs from -90 to 90 */
  const ROADS = [-60, 0, 60];             /* road centre lines, both directions: a 3 x 3 grid */
  const RW = 7, KERB = 2.2;               /* half-width of the asphalt, width of the pavement */
  /* the blocks between the roads: [from, to] on each axis */
  const CELLS = [[-ARENA, ROADS[0] - RW - KERB], [ROADS[0] + RW + KERB, ROADS[1] - RW - KERB], [ROADS[1] + RW + KERB, ROADS[2] - RW - KERB], [ROADS[2] + RW + KERB, ARENA]].map(([a, b]) => [a + 1, b - 1]);
  const PARKS = { '1,1': true, '2,2': true };   /* two of the nine inner blocks are parks */
  /* boxes: buildings (walls) and platforms (drive on top when reached from a ramp). y is the bottom. */
  const BOXES = [
    /* the bridge deck on the north road, reached by ramps at both ends */
    { x: 0, z: -60, w: 30, d: 12, y: 0, hgt: 4, c: [0.45, 0.47, 0.55], top: true },
    /* the landing pad after the big jump, on the south-east corner */
    { x: 62, z: 60, w: 22, d: 14, y: 0, hgt: 3, c: [0.42, 0.46, 0.52], top: true },
  ];
  const TREES = [];
  /* buildings fill the blocks; a fixed seed so the city is the same every time */
  (function city() {
    let seed = 7; const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    const palette = [[0.62, 0.36, 0.30], [0.30, 0.42, 0.62], [0.50, 0.50, 0.58], [0.62, 0.55, 0.30], [0.36, 0.58, 0.42], [0.28, 0.30, 0.38], [0.66, 0.40, 0.55], [0.72, 0.62, 0.50], [0.35, 0.50, 0.60]];
    for (let i = 0; i < CELLS.length; i++) for (let j = 0; j < CELLS.length; j++) {
      const [x0, x1] = CELLS[i], [z0, z1] = CELLS[j], cw = x1 - x0, cd = z1 - z0;
      if (PARKS[i + ',' + j]) {
        for (let k = 0; k < 7; k++) TREES.push({ x: x0 + 3 + rnd() * (cw - 6), z: z0 + 3 + rnd() * (cd - 6), s: 1.6 + rnd() * 1.4 });
        continue;
      }
      /* the outer ring of blocks is narrow: one building; the inner blocks get a few of different heights */
      const n = cw < 30 || cd < 30 ? 1 : 2 + Math.floor(rnd() * 2);
      const cols = n === 1 ? 1 : 2, rows = n <= 2 ? 1 : 2;
      for (let bi = 0; bi < n; bi++) {
        const cx = bi % cols, rz = Math.floor(bi / cols);
        const bw = (cw / cols) - 4 - rnd() * 4, bd = (cd / rows) - 4 - rnd() * 4;
        const bx = x0 + 2 + cx * (cw / cols) + (cw / cols - 2 - bw) / 2 + bw / 2, bz = z0 + 2 + rz * (cd / rows) + (cd / rows - 2 - bd) / 2 + bd / 2;
        const tall = rnd();
        BOXES.push({ x: bx, z: bz, w: Math.max(6, bw), d: Math.max(6, bd), y: 0, hgt: 5 + Math.round(tall * tall * 22), c: palette[Math.floor(rnd() * palette.length)] });
      }
    }
  })();
  /* ramps: footprint, low height y0 at the low side, y1 at the high side, rising along dir. All on roads. */
  const RAMPS = [
    { x: 22, z: -60, w: 14, d: 12, y0: 0, y1: 4, dir: '-x' },      /* north road, heading west: up onto the bridge */
    { x: -22, z: -60, w: 14, d: 12, y0: 0, y1: 4, dir: '+x' },     /* and down again */
    { x: -60, z: -10, w: 10, d: 10, y0: 0, y1: 1.6, dir: '+z' },   /* west road, heading south: a chain of small ramps */
    { x: -60, z: 4, w: 10, d: 10, y0: 0, y1: 1.6, dir: '+z' },
    { x: -60, z: 18, w: 10, d: 10, y0: 0, y1: 1.6, dir: '+z' },
    { x: 30, z: 60, w: 14, d: 10, y0: 0, y1: 4.5, dir: '+x' },     /* south road, heading east: the big jump */
    { x: 60, z: -18, w: 10, d: 12, y0: 0, y1: 3, dir: '-z' },      /* east road, heading north: a lip */
  ];
  /* checkpoints in order, on the roads: x, z. Start on the north road heading west; the last is the finish on the bridge. */
  const CHECKS = [[-40, -60], [-60, -30], [-60, 30], [-30, 60], [20, 60], [60, 30], [60, -40], [0, -60]];
  const CHECK_R = 4.5;

  /* ------------------------------------------------------------ geometry */
  const verts = [];       /* static map: x y z nx ny nz r g b */
  function quad(a, b, c, d, n, col) {
    for (const p of [a, b, c, a, c, d]) verts.push(p[0], p[1], p[2], n[0], n[1], n[2], col[0], col[1], col[2]);
  }
  function box(x, y, z, w, hgt, d, col, into) {
    const out = into || verts, x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2, y0 = y, y1 = y + hgt;
    const q = (a, b, c, dd, n, cc) => { for (const p of [a, b, c, a, c, dd]) out.push(p[0], p[1], p[2], n[0], n[1], n[2], cc[0], cc[1], cc[2]); };
    const lit = (k) => [col[0] * k, col[1] * k, col[2] * k];
    q([x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [0, 1, 0], lit(1));
    q([x0, y0, z1], [x0, y1, z1], [x1, y1, z1], [x1, y0, z1], [0, 0, 1], lit(0.86));
    q([x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [x0, y0, z0], [0, 0, -1], lit(0.7));
    q([x1, y0, z1], [x1, y1, z1], [x1, y1, z0], [x1, y0, z0], [1, 0, 0], lit(0.78));
    q([x0, y0, z0], [x0, y1, z0], [x0, y1, z1], [x0, y0, z1], [-1, 0, 0], lit(0.66));
  }
  function ramp(r) {
    const x0 = r.x - r.w / 2, x1 = r.x + r.w / 2, z0 = r.z - r.d / 2, z1 = r.z + r.d / 2;
    /* corner heights by direction */
    const hAt = (x, z) => rampHeight(r, x, z);
    const c = [0.55, 0.58, 0.66], side = [0.42, 0.44, 0.5];
    const p00 = [x0, hAt(x0, z0), z0], p10 = [x1, hAt(x1, z0), z0], p11 = [x1, hAt(x1, z1), z1], p01 = [x0, hAt(x0, z1), z1];
    /* top: normal from the slope */
    const ax = r.dir[1] === 'x' ? (r.dir[0] === '+' ? 1 : -1) : 0, az = r.dir[1] === 'z' ? (r.dir[0] === '+' ? 1 : -1) : 0;
    const len = r.dir[1] === 'x' ? r.w : r.d, slope = (r.y1 - r.y0) / len;
    const n = [-ax * slope, 1, -az * slope]; const nl = Math.hypot(n[0], n[1], n[2]); n[0] /= nl; n[1] /= nl; n[2] /= nl;
    quad(p00, p01, p11, p10, n, c);
    /* the four vertical sides, down to the ground */
    const wall = (a, b, nn) => quad([a[0], 0, a[2]], [a[0], a[1], a[2]], [b[0], b[1], b[2]], [b[0], 0, b[2]], nn, side);
    wall(p01, p11, [0, 0, 1]); wall(p10, p00, [0, 0, -1]); wall(p11, p10, [1, 0, 0]); wall(p00, p01, [-1, 0, 0]);
  }
  function rampHeight(r, x, z) {
    const t = r.dir[1] === 'x' ? (x - (r.x - r.w / 2)) / r.w : (z - (r.z - r.d / 2)) / r.d;
    const u = r.dir[0] === '+' ? t : 1 - t;
    return r.y0 + Math.max(0, Math.min(1, u)) * (r.y1 - r.y0);
  }
  function inRamp(r, x, z) { return x >= r.x - r.w / 2 && x <= r.x + r.w / 2 && z >= r.z - r.d / 2 && z <= r.z + r.d / 2; }
  function inBox(b, x, z, pad) { return x >= b.x - b.w / 2 - (pad || 0) && x <= b.x + b.w / 2 + (pad || 0) && z >= b.z - b.d / 2 - (pad || 0) && z <= b.z + b.d / 2 + (pad || 0); }
  function buildMap() {
    verts.length = 0;
    /* the ground: paved blocks in two tones, so speed is visible off the road too */
    const T = 6;
    for (let x = -ARENA; x < ARENA; x += T) for (let z = -ARENA; z < ARENA; z += T) {
      const k = ((x / T + z / T) & 1) ? 0.30 : 0.33;
      quad([x, 0, z], [x, 0, z + T], [x + T, 0, z + T], [x + T, 0, z], [0, 1, 0], [k, k, k + 0.03]);
    }
    /* the parks: grass */
    for (let i = 0; i < CELLS.length; i++) for (let j = 0; j < CELLS.length; j++) if (PARKS[i + ',' + j]) {
      const [x0, x1] = CELLS[i], [z0, z1] = CELLS[j];
      quad([x0, 0.01, z0], [x0, 0.01, z1], [x1, 0.01, z1], [x1, 0.01, z0], [0, 1, 0], [0.22, 0.40, 0.22]);
    }
    /* the roads: asphalt, a dashed centre line, and a kerb along each side between the crossings */
    const ASPH = [0.15, 0.16, 0.19], DASH = [0.85, 0.75, 0.25], KERBC = [0.55, 0.55, 0.60];
    for (const r of ROADS) {
      quad([r - RW, 0.02, -ARENA], [r - RW, 0.02, ARENA], [r + RW, 0.02, ARENA], [r + RW, 0.02, -ARENA], [0, 1, 0], ASPH);   /* north-south */
      quad([-ARENA, 0.02, r - RW], [-ARENA, 0.02, r + RW], [ARENA, 0.02, r + RW], [ARENA, 0.02, r - RW], [0, 1, 0], ASPH);   /* east-west */
    }
    for (const r of ROADS) for (let t = -ARENA + 2; t < ARENA - 2; t += 7) {
      if (ROADS.some((o) => Math.abs(t + 1.5 - o) < RW + 2)) continue;   /* no dashes across a crossing */
      quad([r - 0.3, 0.03, t], [r - 0.3, 0.03, t + 3], [r + 0.3, 0.03, t + 3], [r + 0.3, 0.03, t], [0, 1, 0], DASH);
      quad([t, 0.03, r - 0.3], [t, 0.03, r + 0.3], [t + 3, 0.03, r + 0.3], [t + 3, 0.03, r - 0.3], [0, 1, 0], DASH);
    }
    for (const r of ROADS) for (const [a0, a1] of CELLS) {
      const len = a1 - a0 + 2, mid = (a0 + a1) / 2;
      box(r - RW - KERB / 2, 0, mid, KERB, 0.22, len, KERBC); box(r + RW + KERB / 2, 0, mid, KERB, 0.22, len, KERBC);
      box(mid, 0, r - RW - KERB / 2, len, 0.22, KERB, KERBC); box(mid, 0, r + RW + KERB / 2, len, 0.22, KERB, KERBC);
    }
    /* the trees in the parks */
    for (const t of TREES) { box(t.x, 0, t.z, 0.5, t.s * 1.2, 0.5, [0.35, 0.22, 0.12]); box(t.x, t.s * 1.0, t.z, t.s * 1.6, t.s * 1.5, t.s * 1.6, [0.20, 0.48, 0.24]); }
    /* the walls around the arena */
    const W = 1.2, HW = 2.2, edge = [0.35, 0.36, 0.42];
    box(0, 0, -ARENA, ARENA * 2 + W, HW, W, edge); box(0, 0, ARENA, ARENA * 2 + W, HW, W, edge);
    box(-ARENA, 0, 0, W, HW, ARENA * 2, edge); box(ARENA, 0, 0, W, HW, ARENA * 2, edge);
    for (const b of BOXES) box(b.x, b.y, b.z, b.w, b.hgt, b.d, b.c);
    for (const r of RAMPS) ramp(r);
    return new Float32Array(verts);
  }
  /* a checkpoint pillar: an open cylinder, drawn translucent */
  function pillar() {
    const out = [], n = 20, R = CHECK_R, H = 9;
    for (let i = 0; i < n; i++) {
      const a0 = i / n * Math.PI * 2, a1 = (i + 1) / n * Math.PI * 2;
      const x0 = Math.cos(a0) * R, z0 = Math.sin(a0) * R, x1 = Math.cos(a1) * R, z1 = Math.sin(a1) * R;
      const nn = [Math.cos((a0 + a1) / 2), 0, Math.sin((a0 + a1) / 2)];
      for (const p of [[x0, 0, z0], [x0, H, z0], [x1, H, z1], [x0, 0, z0], [x1, H, z1], [x1, 0, z1]]) out.push(p[0], p[1], p[2], nn[0], nn[1], nn[2], 1, 0.85, 0.2);
    }
    return new Float32Array(out);
  }
  /* a slanted panel between two edges: [x0,x1] at (y0,z0) up to (y1,z1); used for bonnet, screens and spoiler */
  function slab(out, x0, x1, y0, z0, y1, z1, col, thick) {
    const t = thick || 0.08;
    const nz = -(y1 - y0), ny = (z1 - z0); const l = Math.hypot(ny, nz) || 1;   /* normal of the slope, facing up/forward */
    const n = [0, ny / l, nz / l];
    const q = (p0, p1, p2, p3, nn, cc) => { for (const p of [p0, p1, p2, p0, p2, p3]) out.push(p[0], p[1], p[2], nn[0], nn[1], nn[2], cc[0], cc[1], cc[2]); };
    q([x0, y0, z0], [x0, y1, z1], [x1, y1, z1], [x1, y0, z0], n, col);
    q([x1, y0 - t, z0], [x1, y1 - t, z1], [x0, y1 - t, z1], [x0, y0 - t, z0], [0, -n[1], -n[2]], col);
    q([x0, y0 - t, z0], [x0, y1 - t, z1], [x0, y1, z1], [x0, y0, z0], [-1, 0, 0], col.map(v => v * 0.7));
    q([x1, y0, z0], [x1, y1, z1], [x1, y1 - t, z1], [x1, y0 - t, z0], [1, 0, 0], col.map(v => v * 0.7));
  }
  function carMesh() {
    const out = [];
    const RED = [0.92, 0.18, 0.24], DARK = [0.10, 0.10, 0.13], GLASS = [0.25, 0.42, 0.62], RIM = [0.72, 0.72, 0.76], TRIM = [0.16, 0.16, 0.2];
    /* body: a low tub, wider at the sills */
    box(0, 0.42, -0.1, 2.0, 0.42, 3.9, RED, out);
    box(0, 0.25, -0.1, 2.15, 0.22, 3.4, TRIM, out);                  /* sills and bumpers */
    box(0, 0.68, -0.9, 1.9, 0.14, 1.9, RED, out);                    /* rear deck */
    /* the bonnet slopes down to the nose; the windscreen slopes up to the roof; the rear screen down to the deck */
    slab(out, -0.92, 0.92, 0.66, 0.35, 0.56, 1.95, RED, 0.12);        /* bonnet */
    slab(out, -0.80, 0.80, 0.66, 0.30, 1.16, -0.45, GLASS, 0.10);     /* windscreen */
    box(0, 1.14, -0.9, 1.62, 0.10, 0.95, RED, out);                  /* roof */
    slab(out, -0.78, 0.78, 1.16, -1.35, 0.76, -1.95, GLASS, 0.10);    /* rear screen */
    box(-0.82, 0.92, -0.9, 0.06, 0.34, 0.95, GLASS, out);            /* side windows */
    box(0.82, 0.92, -0.9, 0.06, 0.34, 0.95, GLASS, out);
    box(-0.86, 0.93, -0.9, 0.08, 0.4, 1.0, DARK, out);               /* pillars */
    box(0.86, 0.93, -0.9, 0.08, 0.4, 1.0, DARK, out);
    /* spoiler on two posts */
    box(-0.7, 0.9, -1.85, 0.1, 0.3, 0.1, DARK, out); box(0.7, 0.9, -1.85, 0.1, 0.3, 0.1, DARK, out);
    box(0, 1.06, -1.85, 2.0, 0.07, 0.42, RED, out);
    /* wheels: tyre, rim, a hub */
    for (const [x, z] of [[-1.0, 1.25], [1.0, 1.25], [-1.0, -1.25], [1.0, -1.25]]) {
      box(x, 0.36, z, 0.36, 0.72, 0.72, DARK, out);
      box(x + (x < 0 ? -0.02 : 0.02), 0.36, z, 0.34, 0.40, 0.40, RIM, out);
      box(x + (x < 0 ? -0.05 : 0.05), 0.36, z, 0.30, 0.12, 0.12, DARK, out);
    }
    /* lights and a stripe */
    box(-0.6, 0.55, 1.98, 0.5, 0.14, 0.05, [1, 0.96, 0.75], out); box(0.6, 0.55, 1.98, 0.5, 0.14, 0.05, [1, 0.96, 0.75], out);
    box(0, 0.62, -2.06, 1.8, 0.1, 0.05, [1, 0.15, 0.15], out);
    box(0, 0.75, 1.0, 0.4, 0.02, 1.7, [0.98, 0.98, 0.98], out);
    return new Float32Array(out);
  }
  /* the arrow that floats over a checkpoint, pointing at the next: a flat chevron with some thickness, nose to +z */
  function arrowMesh() {
    const out = [], T = 0.5, Y = [1, 0.85, 0.2];
    const pts = [[0, 2.2], [1.6, 0.2], [0.7, 0.2], [0.7, -1.6], [-0.7, -1.6], [-0.7, 0.2], [-1.6, 0.2]];   /* x, z */
    const tri = (a, b, c, y, n) => { for (const p of [a, b, c]) out.push(p[0], y, p[1], n[0], n[1], n[2], Y[0], Y[1], Y[2]); };
    /* top and bottom as fans from the tip */
    for (let i = 1; i < pts.length - 1; i++) { tri(pts[0], pts[i + 1], pts[i], T, [0, 1, 0]); tri(pts[0], pts[i], pts[i + 1], 0, [0, -1, 0]); }
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length], nx = (b[1] - a[1]), nz = -(b[0] - a[0]), l = Math.hypot(nx, nz) || 1, n = [nx / l, 0, nz / l];
      for (const p of [[a[0], 0, a[1]], [a[0], T, a[1]], [b[0], T, b[1]], [a[0], 0, a[1]], [b[0], T, b[1]], [b[0], 0, b[1]]]) out.push(p[0], p[1], p[2], n[0], n[1], n[2], Y[0] * 0.8, Y[1] * 0.8, Y[2] * 0.8);
    }
    return new Float32Array(out);
  }

  /* ------------------------------------------------------------ webgl */
  const VS = 'attribute vec3 p; attribute vec3 n; attribute vec3 c; uniform mat4 uP, uV, uM; uniform vec3 uLight; uniform float uAlpha; varying vec3 vc; varying float vd; varying float va;' +
    'void main(){ vec4 w = uM * vec4(p,1.0); vec3 nn = normalize((uM * vec4(n,0.0)).xyz); float l = 0.55 + 0.45 * max(0.0, dot(nn, normalize(uLight))); vc = c * l; vec4 e = uV * w; vd = -e.z; va = uAlpha; gl_Position = uP * e; }';
  const FS = 'precision mediump float; varying vec3 vc; varying float vd; varying float va; uniform vec3 uFog;' +
    'void main(){ float f = clamp((vd - 60.0) / 110.0, 0.0, 1.0); gl_FragColor = vec4(mix(vc, uFog, f), va); }';
  let gl = null, prog = null, loc = {}, bufMap = null, bufPillar = null, bufCar = null, bufArrow = null, nMap = 0, nPillar = 0, nCar = 0, nArrow = 0;
  function initGL(cv) {
    gl = cv.getContext('webgl', { antialias: true, alpha: false });
    if (!gl) throw new Error('WebGL is not available here.');
    const sh = (t, src) => { const s = gl.createShader(t); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    prog = gl.createProgram(); gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    gl.useProgram(prog);
    for (const a of ['p', 'n', 'c']) loc[a] = gl.getAttribLocation(prog, a);
    for (const u of ['uP', 'uV', 'uM', 'uLight', 'uAlpha', 'uFog']) loc[u] = gl.getUniformLocation(prog, u);
    const upload = (arr) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STATIC_DRAW); return b; };
    const m = buildMap(); bufMap = upload(m); nMap = m.length / 9;
    const pl = pillar(); bufPillar = upload(pl); nPillar = pl.length / 9;
    const cm = carMesh(); bufCar = upload(cm); nCar = cm.length / 9;
    const am = arrowMesh(); bufArrow = upload(am); nArrow = am.length / 9;
    gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);   /* both sides of every face: the map mixes windings, and depth sorts it out */
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.uniform3f(loc.uLight, 0.4, 1, 0.3); gl.uniform3f(loc.uFog, 0.06, 0.07, 0.1);
  }
  function draw(buf, n, model, alpha) {
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.enableVertexAttribArray(loc.p); gl.vertexAttribPointer(loc.p, 3, gl.FLOAT, false, 36, 0);
    gl.enableVertexAttribArray(loc.n); gl.vertexAttribPointer(loc.n, 3, gl.FLOAT, false, 36, 12);
    gl.enableVertexAttribArray(loc.c); gl.vertexAttribPointer(loc.c, 3, gl.FLOAT, false, 36, 24);
    gl.uniformMatrix4fv(loc.uM, false, model); gl.uniform1f(loc.uAlpha, alpha);
    gl.drawArrays(gl.TRIANGLES, 0, n);
  }

  /* ------------------------------------------------------------ the car */
  const car = { x: 0, y: 0, z: -60, a: Math.PI, v: 0, vy: 0, grounded: true, lastH: 0 };
  const keys = {};
  let next = 0, lapStart = 0, lapTime = 0, best = 0, laps = 0, msg = '', msgUntil = 0;
  try { best = parseFloat(localStorage.getItem('os.race.best') || '0') || 0; } catch (e) {}
  function groundAt(x, z, y) {
    let g = 0;
    for (const r of RAMPS) if (inRamp(r, x, z)) g = Math.max(g, rampHeight(r, x, z));
    for (const b of BOXES) if (b.top && inBox(b, x, z) && y >= b.y + b.hgt - 0.9) g = Math.max(g, b.y + b.hgt);
    return g;
  }
  /* the start: on the back straight, the first checkpoint dead ahead */
  function resetCar() { car.x = 48; car.y = 0; car.z = -60; car.a = -Math.PI / 2; car.v = 0; car.vy = 0; car.grounded = true; next = 0; lapStart = performance.now(); cam.x = car.x + 10; cam.y = 5; cam.z = car.z; }
  function step(dt) {
    dt = Math.min(dt, 0.05);
    const fwd = keys.ArrowUp || keys.w || keys.W, back = keys.ArrowDown || keys.s || keys.S, left = keys.ArrowLeft || keys.a || keys.A, right = keys.ArrowRight || keys.d || keys.D, brake = keys[' '];
    const MAX = 42, ACC = 22, REV = 24;
    if (car.grounded) {
      if (fwd) car.v += ACC * dt; else if (back) car.v -= (car.v > 0 ? 30 : REV) * dt; else car.v -= car.v * 1.2 * dt;
      if (brake) car.v -= car.v * 5 * dt;
      car.v = Math.max(-24, Math.min(MAX, car.v));
      const steer = (right ? 1 : 0) - (left ? 1 : 0);
      const turn = 1.9 * Math.min(1, Math.abs(car.v) / 12) * (car.v < 0 ? -1 : 1);
      car.a -= steer * turn * dt;
    }
    const nx = car.x + Math.sin(car.a) * car.v * dt, nz = car.z + Math.cos(car.a) * car.v * dt;
    /* walls: the arena edge and the buildings (a platform is a wall until you are on top of it) */
    let cx = nx, cz = nz, hit = false;
    const lim = ARENA - 1.6;
    if (cx > lim) { cx = lim; hit = true; } if (cx < -lim) { cx = -lim; hit = true; } if (cz > lim) { cz = lim; hit = true; } if (cz < -lim) { cz = -lim; hit = true; }
    for (const b of BOXES) {
      if (b.top && car.y >= b.y + b.hgt - 0.9) continue;
      if (!inBox(b, cx, cz, 1.1)) continue;
      /* push out along the shallowest axis */
      const dx = cx - b.x, dz = cz - b.z, px = b.w / 2 + 1.1 - Math.abs(dx), pz = b.d / 2 + 1.1 - Math.abs(dz);
      if (px < pz) cx += (dx > 0 ? px : -px); else cz += (dz > 0 ? pz : -pz);
      hit = true;
    }
    for (const tr of TREES) {
      const dx = cx - tr.x, dz = cz - tr.z, d = Math.hypot(dx, dz), R = 1.9;
      if (d < R && d > 0.001) { cx = tr.x + dx / d * R; cz = tr.z + dz / d * R; hit = true; }
    }
    if (hit) car.v *= 0.35;
    car.x = cx; car.z = cz;
    /* height: ramps launch, gravity brings you down */
    const g = groundAt(car.x, car.z, car.y);
    if (car.grounded) {
      /*  Stay on the ground unless the drop is more than a slope could give at this speed: a descent used to
          count as "drove off an edge" every frame, and the car hopped its way down every ramp.            */
      const drop = car.y - g, slopeDrop = Math.abs(car.v) * dt * 1.6 + 0.35;
      if (drop <= slopeDrop) { car.vy = Math.min(9, (g - car.lastH) / dt); car.y = g; }
      else { car.grounded = false; }                           /* a real edge: off the bridge side, off the top of a ramp */
    }
    if (!car.grounded) {
      car.vy -= 30 * dt; car.y += car.vy * dt;
      if (car.y <= g) { car.y = g; car.vy = 0; car.grounded = true; }
    }
    car.lastH = g;
    /* checkpoints */
    const c = CHECKS[next];
    if (Math.hypot(car.x - c[0], car.z - c[1]) < CHECK_R + 1) {
      next++;
      if (next >= CHECKS.length) {
        next = 0; laps++; lapTime = (performance.now() - lapStart) / 1000; lapStart = performance.now();
        if (!best || lapTime < best) { best = lapTime; try { localStorage.setItem('os.race.best', String(best)); } catch (e) {} msg = 'New best lap ' + fmt(lapTime) + '!'; }
        else msg = 'Lap ' + fmt(lapTime);
        msgUntil = performance.now() + 2500;
      }
    }
  }
  const fmt = (s) => { const m = Math.floor(s / 60), r = s - m * 60; return (m ? m + ':' : '') + (m && r < 10 ? '0' : '') + r.toFixed(2); };

  /* ------------------------------------------------------------ frame */
  let cv = null, hud = null, raf = 0, last = 0, running = false, paused = false;
  const cam = { x: 0, y: 6, z: -70 };
  let pitch = 0;
  function frame(t) {
    if (!running) return;
    raf = requestAnimationFrame(frame);
    const dt = last ? (t - last) / 1000 : 0; last = t;
    if (!paused) step(dt);
    /* size */
    const W = cv.clientWidth, H = cv.clientHeight, dpr = Math.min(2, window.devicePixelRatio || 1);
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); hud.width = W; hud.height = H; }
    gl.viewport(0, 0, cv.width, cv.height);
    gl.clearColor(0.06, 0.07, 0.1, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    /* chase camera, eased */
    const tx = car.x - Math.sin(car.a) * 10, tz = car.z - Math.cos(car.a) * 10, ty = car.y + 4.5;
    const k = paused ? 1 : Math.min(1, dt * 4);
    cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k; cam.z += (tz - cam.z) * k;
    const P = Mat4.perspective(1.05, W / Math.max(1, H), 0.5, 400);
    const V = Mat4.lookAt([cam.x, cam.y, cam.z], [car.x, car.y + 1, car.z], [0, 1, 0]);
    gl.uniformMatrix4fv(loc.uP, false, P); gl.uniformMatrix4fv(loc.uV, false, V);
    draw(bufMap, nMap, Mat4.identity(), 1);
    let M = Mat4.translate(Mat4.identity(), car.x, car.y, car.z); M = Mat4.rotateY(M, car.a);
    if (!car.grounded) M = Mat4.rotateX(M, -Math.max(-0.4, Math.min(0.4, car.vy * 0.03)));
    else {
      /* nose up going up a ramp, down coming off it: the ground a car-length ahead against a car-length behind */
      const L = 1.6, fx = Math.sin(car.a), fz = Math.cos(car.a);
      const ahead = groundAt(car.x + fx * L, car.z + fz * L, car.y), behind = groundAt(car.x - fx * L, car.z - fz * L, car.y);
      pitch += (Math.atan2(ahead - behind, 2 * L) - pitch) * Math.min(1, dt * 12);
      M = Mat4.rotateX(M, -pitch);
    }
    draw(bufCar, nCar, M, 1);
    /* checkpoints: the next one bright, the one after dim, the rest not shown; above the next one, a big arrow to the one after */
    {
      const c = CHECKS[next], after = CHECKS[(next + 1) % CHECKS.length];
      const base = groundAt(c[0], c[1], 99), ang = Math.atan2(after[0] - c[0], after[1] - c[1]);
      let A = Mat4.translate(Mat4.identity(), c[0], base + 11.5 + Math.sin(t / 300) * 0.5, c[1]);
      A = Mat4.rotateY(A, ang); A = Mat4.rotateX(A, 0.25); A = Mat4.scale(A, 2.2, 2.2, 2.2);
      draw(bufArrow, nArrow, A, 1);
    }
    gl.depthMask(false);
    for (let i = 0; i < 2; i++) {
      const idx = (next + i) % CHECKS.length, c = CHECKS[idx];
      const pulse = i === 0 ? 0.55 + 0.15 * Math.sin(t / 250) : 0.18;
      draw(bufPillar, nPillar, Mat4.translate(Mat4.identity(), c[0], groundAt(c[0], c[1], 99), c[1]), pulse);
    }
    gl.depthMask(true);
    drawHud(t);
  }
  function drawHud(t) {
    const g = hud.getContext('2d'), W = hud.width, H = hud.height;
    g.clearRect(0, 0, W, H);
    g.font = '700 13px system-ui, sans-serif'; g.textBaseline = 'top';
    const pill = (x, y, txt, col) => { g.font = '700 13px system-ui, sans-serif'; const w = g.measureText(txt).width + 18; g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.roundRect(x, y, w, 24, 12); g.fill(); g.fillStyle = col || '#fff'; g.fillText(txt, x + 9, y + 5); return w; };
    let x = 10;
    x += pill(x, 10, 'Checkpoint ' + (next + 1) + ' / ' + CHECKS.length, '#ffd84d') + 6;
    x += pill(x, 10, fmt((performance.now() - lapStart) / 1000)) + 6;
    if (best) x += pill(x, 10, 'Best ' + fmt(best), '#9fe0a0') + 6;
    pill(x, 10, Math.round(Math.abs(car.v) * 3.2) + ' km/h');
    /* the arrow to the next checkpoint, bottom centre */
    const c = CHECKS[next], ang = Math.atan2(c[0] - car.x, c[1] - car.z) - car.a;
    g.save(); g.translate(W / 2, H - 34); g.rotate(-ang);
    g.fillStyle = 'rgba(255,216,77,.9)'; g.beginPath(); g.moveTo(0, -16); g.lineTo(11, 8); g.lineTo(0, 2); g.lineTo(-11, 8); g.closePath(); g.fill(); g.restore();
    if (msg && t < msgUntil) { g.font = '800 22px system-ui, sans-serif'; g.textAlign = 'center'; g.fillStyle = '#fff'; g.shadowColor = 'rgba(0,0,0,.7)'; g.shadowBlur = 8; g.fillText(msg, W / 2, H / 2 - 40); g.shadowBlur = 0; g.textAlign = 'left'; }
    g.font = '12px system-ui, sans-serif'; g.fillStyle = 'rgba(255,255,255,.55)'; g.textAlign = 'right';
    g.fillText('arrows / WASD · space brakes · R resets · Esc leaves', W - 10, H - 22); g.textAlign = 'left';
  }

  /* ------------------------------------------------------------ keys: ours, and only ours, while the game is up */
  const GAME_KEYS = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd', 'W', 'A', 'S', 'D', ' ', 'r', 'R', 'Escape', 'p', 'P', 'Enter'];
  function onKey(e) {
    if (!running) return;
    const k = e.key;
    if (e.type === 'keydown') {
      if (k === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); leave(); return; }
      if (k === 'r' || k === 'R') { resetCar(); }
      if (k === 'p' || k === 'P') { paused = !paused; }
    }
    keys[k] = e.type === 'keydown';
    /* nothing reaches the panel's own shortcuts (the wheel) or Premiere: every key is ours while the game is up */
    e.preventDefault(); e.stopImmediatePropagation();
  }
  /*  Premiere hands a key to the panel only when the panel has said it wants it; the rest go to Premiere
      (space = play, arrows = frame step). While the game runs, every key it uses is claimed.           */
  function claimKeys(on) {
    try {
      if (!window.__adobe_cep__) return;
      /*  Every field spelled out: an entry with only a keyCode did not register (Premiere kept the arrows, A,
          S and D for its own shortcuts and only W - which it does not use with a panel focused - got
          through). The wheel's registration, which works, names all four modifiers; so does this now.  */
      const KEYS = [37, 38, 39, 40, 65, 68, 83, 87, 32, 82, 80, 27, 13, 16];
      /*  On a Mac, Premiere matches this list against the Mac virtual key codes (W is 13, the arrows are 123
          to 126, space is 49), not the JavaScript codes above. With only the JavaScript codes the keys never
          reached the panel: Premiere took them, had no use for them and beeped. Both sets are registered
          there, so the game works whichever set the host reads.                                          */
      const MAC = [123, 126, 124, 125, 0, 2, 1, 13, 49, 15, 35, 53, 36, 56];
      const codes = [];
      if (on) for (const c of CS.mac ? KEYS.concat(MAC) : KEYS) { codes.push({ keyCode: c, ctrlKey: false, altKey: false, shiftKey: false, metaKey: false }); codes.push({ keyCode: c, ctrlKey: false, altKey: false, shiftKey: true, metaKey: false }); }
      window.__adobe_cep__.registerKeyEventsInterest(JSON.stringify(codes));
      if (!on && typeof QuickFX !== 'undefined' && QuickFX.registerKeys) QuickFX.registerKeys();   /* the wheel's own shortcut comes back */
    } catch (e) {}
  }

  /* ------------------------------------------------------------ open / close / the job finishing */
  let root = null, doneBox = null;
  function open() {
    if (running) return;
    if (!root) {
      root = h('div', 'race'); root.id = 'race';
      root.innerHTML = '<canvas id="race-gl"></canvas><canvas id="race-hud"></canvas><div class="race-top" id="race-top"></div><button class="race-x" id="race-x" title="Leave the game (Esc)">✕</button>' +
        '<div class="race-done" id="race-done"><div class="ubox"><div class="ueyebrow">Outflow Studio</div><h2>Done!</h2><p class="small" id="race-done-txt">The panel has finished.</p><div class="ubtns"><button class="primary" id="race-back">Back to editing</button><button class="ghost" id="race-more">Keep playing</button></div></div></div>';
      document.body.appendChild(root);
      cv = $('#race-gl'); hud = $('#race-hud'); doneBox = $('#race-done');
      $('#race-back').addEventListener('click', leave);
      $('#race-x').addEventListener('click', leave);
      $('#race-more').addEventListener('click', resume);
      cv.tabIndex = 0;
      try { initGL(cv); } catch (e) { root.remove(); root = null; toast('The game needs WebGL: ' + e.message, 'err'); return; }
      root.addEventListener('mousedown', (e) => { if (!e.target.closest('button')) { cv.focus(); if (running && !paused) claimKeys(true); } });
    }
    root.classList.add('show'); doneBox.classList.remove('show');
    running = true; paused = false; last = 0; resetCar(); msg = 'Drive through the checkpoints in order'; msgUntil = performance.now() + 3000;
    window.addEventListener('keydown', onKey, true); window.addEventListener('keyup', onKey, true);
    claimKeys(true);
    setTimeout(() => cv.focus(), 30);
    try { const prog = $('#progress'), tp = $('#race-top'); if (tp) tp.textContent = prog && prog.classList.contains('show') ? (($('#prog-title').textContent || '') + ' ' + ($('#prog-bar').style.width || '')) : ''; } catch (e) {}
    raf = requestAnimationFrame(frame);
    try { Usage.tick('set:race:open'); } catch (e) {}
  }
  /*  Back to driving after the "done" card. The job that just finished may have handed the keyboard to
      Premiere (a timeline change pulls focus), so the keys are claimed again, any key still marked as held
      is released, and the track takes focus; a click anywhere on it does the same.                     */
  function resume() {
    doneBox.classList.remove('show'); paused = false;
    for (const k in keys) keys[k] = false;
    claimKeys(true);
    last = 0;
    setTimeout(() => { try { cv.focus(); } catch (e) {} }, 20);
  }
  function leave() {
    if (!running) return;
    running = false; cancelAnimationFrame(raf);
    window.removeEventListener('keydown', onKey, true); window.removeEventListener('keyup', onKey, true);
    for (const k in keys) keys[k] = false;
    claimKeys(false);
    root.classList.remove('show'); doneBox.classList.remove('show');
  }
  /* the job the person was waiting for has finished: stop the car, ask */
  function jobDone(what) {
    if (!running) return;
    paused = true;
    $('#race-done-txt').textContent = (what ? what + ' has finished.' : 'The panel has finished.') + ' Back to editing, or one more lap?';
    doneBox.classList.add('show');
  }
  /* the progress box: an invitation after a few seconds of waiting, the question when it goes away */
  function watchProgress() {
    const prog = $('#progress'); if (!prog) return;
    const btn = h('button', 'ghost small', '🏁 Play a game while you wait'); btn.id = 'race-invite'; btn.style.display = 'none';
    btn.addEventListener('click', open);
    prog.querySelector('.box').appendChild(btn);
    let timer = null, title = '';
    const obs = new MutationObserver(() => {
      const on = prog.classList.contains('show');
      if (on) { if (!timer) timer = setTimeout(() => { if (prog.classList.contains('show') && !running) btn.style.display = ''; }, 5000); try { title = $('#prog-title').textContent; } catch (e) {} }
      else { clearTimeout(timer); timer = null; btn.style.display = 'none'; if (running) jobDone(title.replace(/[…:.]+$/, '')); }
      /* the game shows what the job is doing along the top */
      if (running) { const tp = $('#race-top'); if (tp) tp.textContent = on ? (($('#prog-title').textContent || '') + ' ' + ($('#prog-bar').style.width || '')) : ''; }
    });
    obs.observe(prog, { attributes: true, attributeFilter: ['class'] });
    const bar = $('#prog-bar'); if (bar) new MutationObserver(() => { if (running) { const tp = $('#race-top'); if (tp && prog.classList.contains('show')) tp.textContent = ($('#prog-title').textContent || '') + ' ' + (bar.style.width || ''); } }).observe(bar, { attributes: true, attributeFilter: ['style'] });
  }
  function init() { watchProgress(); const b = $('#home-race'); if (b) b.addEventListener('click', open); }
  return { init, open, leave, jobDone, active: () => running, car: () => car, dbg: () => ({ BOXES, RAMPS, CHECKS, TREES, cam, next: () => next }) };
})();
