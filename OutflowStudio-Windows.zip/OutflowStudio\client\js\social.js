/* Download media from YouTube, Instagram, TikTok, X, Vimeo, Facebook… with
   yt-dlp. Two steps: Fetch (title, thumbnail, duration, available qualities),
   then pick a quality and download. H.264 is preferred because Premiere cannot
   decode the AV1/VP9 streams yt-dlp would otherwise choose. ffmpeg is fetched
   automatically (YouTube serves video and audio as separate streams). */
const Social = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const cp = nodeReq ? nodeReq('child_process') : null;
  const st = { place: true, lastQuality: 'hd', noAudio: false };
  try { Object.assign(st, JSON.parse(localStorage.getItem('os.social') || '{}')); } catch (e) {}
  const save = () => { try { localStorage.setItem('os.social', JSON.stringify(st)); } catch (e) {} };
  let history = [];
  try { history = JSON.parse(localStorage.getItem('os.social.history') || '[]'); } catch (e) {}
  let info = null, options = [], chosen = null;
  let audioLang = null, subLang = '';

  function home() { return CS.dataDir('ytdlp'); }
  async function downloadDir() {
    const k = Hub.keys();
    if (k.downloadDir && CS.fs.existsSync(k.downloadDir)) { const d = CS.path.join(k.downloadDir, 'downloads'); CS.mkdirp(d); return d; }
    const p = await CS.call('OS_getPaths');
    const base = (p.ok && (p.projectDir || p.documents)) || CS.os.homedir();
    const d = CS.path.join(base, 'OutflowStudio', 'downloads'); CS.mkdirp(d); return d;
  }
  const exe = () => CS.fs && CS.fs.existsSync(CS.path.join(home(), CS.bin('yt-dlp'))) ? CS.path.join(home(), CS.bin('yt-dlp')) : null;
  function findExe(root, name) {
    if (!CS.fs || !CS.fs.existsSync(root)) return null;
    const walk = (d, depth) => { if (depth > 4) return null; for (const f of CS.fs.readdirSync(d)) { const p = CS.path.join(d, f); let s; try { s = CS.fs.statSync(p); } catch (e) { continue; } if (s.isDirectory()) { const r = walk(p, depth + 1); if (r) return r; } else if (f.toLowerCase() === name) return p; } return null; };
    return walk(root, 0);
  }
  function ffmpeg() { const custom = (Hub.keys().ffmpegExe || '').trim(); if (custom && CS.fs && CS.fs.existsSync(custom)) return custom; const f = findExe(CS.path.join(home(), 'ffmpeg'), CS.bin('ffmpeg')); if (f && CS.mac) CS.chmodX(f); return f; }
  const deno = () => findExe(CS.path.join(home(), 'deno'), CS.bin('deno'));

  /*  GitHub's "latest" link answers 404 for the minutes a new release is still uploading its files, and a
      release can come out without the file at all. Each engine has a build known to carry it as the fallback. */
  async function dlFirst(urls, dest, onProgress) {
    let last = null;
    for (const u of urls) {
      try { return await Net.download(u, dest, onProgress); }
      catch (e) { last = e; if (!/HTTP 40[34]/.test(String((e && e.message) || e))) throw e; try { Log.warn('social', 'not there, trying the known build: ' + u); } catch (x) {} }
    }
    throw last;
  }
  const YTDLP_PIN = '2026.08.19', DENO_PIN = 'v2.9.6', FFSTATIC_PIN = 'b6.1.1';
  async function ensureYtDlp(onProgress) {
    if (!cp || !CS.fs) throw new Error('Downloads need the panel to run inside Premiere Pro.');
    if (exe()) return exe();
    const dest = CS.path.join(home(), CS.bin('yt-dlp'));
    const ytName = CS.mac ? 'yt-dlp_macos' : 'yt-dlp.exe';
    await dlFirst(['https://github.com/yt-dlp/yt-dlp/releases/latest/download/' + ytName, 'https://github.com/yt-dlp/yt-dlp/releases/download/' + YTDLP_PIN + '/' + ytName], dest, (p) => onProgress(p, 'Downloading the download engine' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    CS.chmodX(dest);
    return exe();
  }
  async function unzip(zip, dest) { await CS.unzip(zip, dest); try { CS.fs.unlinkSync(zip); } catch (e) {} }
  async function installFfmpeg(onProgress) {
    const zip = CS.path.join(home(), 'ffmpeg.zip');
    if (CS.mac) {
      /*  Native builds for this Mac's own CPU (Apple Silicon or Intel), one plain file each, from the
          ffmpeg-static project - the same binaries thousands of Node apps ship. The Intel-only evermeet
          builds were the first try: on an Apple Silicon Mac without Rosetta they do not run at all, which
          yt-dlp reports as "ffmpeg is not installed".                                                   */
      const dir = CS.path.join(home(), 'ffmpeg'); CS.mkdirp(dir);
      const base = 'https://github.com/eugeneware/ffmpeg-static/releases/latest/download/', arch = CS.arch();
      const f1 = CS.path.join(dir, 'ffmpeg'), f2 = CS.path.join(dir, 'ffprobe');
      const pin = base.replace('latest/download/', 'download/' + FFSTATIC_PIN + '/');
      await dlFirst([base + 'ffmpeg-darwin-' + arch, pin + 'ffmpeg-darwin-' + arch], f1, (p) => onProgress(p * 0.5, 'Downloading the video engine 1/2 (about 45 MB, once)' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
      await dlFirst([base + 'ffprobe-darwin-' + arch, pin + 'ffprobe-darwin-' + arch], f2, (p) => onProgress(0.5 + p * 0.45, 'Downloading the video engine 2/2' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
      CS.chmodX(f1); CS.chmodX(f2);
      if (!CS.runs(f1)) throw new Error('The video engine will not run on this Mac. Report a problem and say which Mac it is.');
      return;
    }
    await Net.download('https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip', zip, (p) => onProgress(p * 0.9, 'Downloading the video engine (about 90 MB, once)' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    onProgress(0.92, 'Unpacking the video engine');
    await unzip(zip, CS.path.join(home(), 'ffmpeg'));
    try { CS.fs.unlinkSync(zip); } catch (e) {}
    if (!ffmpeg()) throw new Error('The video engine was not found after unpacking (antivirus?).');
    trimFfmpeg();
  }
  /* the build ships ffplay and docs we never use: about 170 MB gone */
  function trimFfmpeg() {
    try {
      const f = ffmpeg(); if (!f || !CS.fs) return;
      const bin = CS.path.dirname(f), pkg = CS.path.dirname(bin);
      for (const x of [CS.bin('ffplay')]) { const p = CS.path.join(bin, x); if (CS.fs.existsSync(p)) CS.fs.unlinkSync(p); }
      for (const d of ['doc', 'presets']) { const p = CS.path.join(pkg, d); if (CS.fs.existsSync(p)) CS.fs.rmSync(p, { recursive: true, force: true }); }
      const zip = CS.path.join(home(), 'ffmpeg.zip'); if (CS.fs.existsSync(zip)) CS.fs.unlinkSync(zip);
    } catch (e) {}
  }
  async function installDeno(onProgress) {
    const zip = CS.path.join(home(), 'deno.zip');
    const asset = CS.mac ? (CS.arch() === 'arm64' ? 'deno-aarch64-apple-darwin.zip' : 'deno-x86_64-apple-darwin.zip') : 'deno-x86_64-pc-windows-msvc.zip';
    await dlFirst(['https://github.com/denoland/deno/releases/latest/download/' + asset, 'https://github.com/denoland/deno/releases/download/' + DENO_PIN + '/' + asset], zip, (p) => onProgress(p * 0.9, 'Downloading the YouTube helper' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    await unzip(zip, CS.path.join(home(), 'deno'));
    if (deno()) CS.chmodX(deno());
  }
  const ffprobe = () => { const f = ffmpeg(); return f ? findExe(CS.path.dirname(f), CS.bin('ffprobe')) || CS.path.join(CS.path.dirname(f), CS.bin('ffprobe')) : null; };
  function runCmd(cmd, args, onLine) {
    return new Promise((resolve, reject) => {
      const p = CS.track(cp.spawn(cmd, args, { windowsHide: true }));
      let out = '', err = '';
      p.stdout.on('data', d => { const s = String(d); out += s; if (onLine) s.split(/[\r\n]+/).forEach(l => l && onLine(l)); });
      p.stderr.on('data', d => { const s = String(d); err += s; if (onLine) s.split(/[\r\n]+/).forEach(l => l && onLine(l)); });
      p.on('error', reject);
      p.on('close', code => p.cancelled ? reject(new Error('Cancelled.')) : code === 0 ? resolve(out) : reject(new Error((err || out).trim().split('\n').slice(-2).join(' ').slice(0, 240) || (cmd + ' exited with code ' + code))));
    });
  }
  const NEEDS_CONVERT = /^(vp9|vp8|av1)$/i;
  async function probe(file) {
    if (!ffprobe() || !CS.fs.existsSync(ffprobe())) return { codec: '', duration: 0 };
    try {
      const out = await runCmd(ffprobe(), ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name:format=duration', '-of', 'json', file]);
      const j = JSON.parse(out);
      return { codec: ((j.streams || [])[0] || {}).codec_name || '', duration: parseFloat((j.format || {}).duration) || 0 };
    } catch (e) { return { codec: '', duration: 0 }; }
  }
  async function hasAudioStream(file) {
    if (!ffprobe() || !CS.fs.existsSync(ffprobe())) return true;
    try { const out = await runCmd(ffprobe(), ['-v', 'error', '-select_streams', 'a:0', '-show_entries', 'stream=codec_name', '-of', 'json', file]); return ((JSON.parse(out).streams || []).length > 0); } catch (e) { return true; }
  }
  /* the same file without its sound: a stream copy, so it takes a moment and loses nothing of the picture */
  async function stripAudio(file) {
    const out = file.replace(/\.([a-z0-9]+)$/i, '_noaudio.mp4');
    if (CS.fs.existsSync(out) && CS.fs.statSync(out).size > 1000) return out;
    await runCmd(ffmpeg(), ['-y', '-hide_banner', '-loglevel', 'error', '-i', file, '-c:v', 'copy', '-an', '-movflags', '+faststart', out]);
    if (!CS.fs.existsSync(out) || CS.fs.statSync(out).size < 1000) throw new Error('Could not take the sound out.');
    return out;
  }
  /*  The H.264 encoder for this machine, found once and remembered per ffmpeg build. Each candidate
      is tried on six generated frames; the first that works wins. The hardware ones are five to ten
      times faster than libx264 at 4K and, at these settings, at least as faithful (SSIM against the
      source, 4K60 VP9: NVENC cq 25 0.9936, x264 crf 18 0.9915).                                      */
  const ENCODERS = () => CS.mac
    ? [{ name: 'h264_videotoolbox', args: ['-q:v', '62', '-allow_sw', '1'] }, { name: 'libx264', args: ['-preset', 'veryfast', '-crf', '18'] }]
    : [{ name: 'h264_nvenc', args: ['-preset', 'p3', '-tune', 'hq', '-rc', 'vbr', '-cq', '26', '-b:v', '0'], hwaccel: ['-hwaccel', 'cuda'] },
       { name: 'h264_qsv', args: ['-preset', 'veryfast', '-global_quality', '23'] },
       { name: 'h264_amf', args: ['-quality', 'balanced', '-rc', 'cqp', '-qp_i', '22', '-qp_p', '24'] },
       { name: 'libx264', args: ['-preset', 'veryfast', '-crf', '18'] }];
  let encPick = null;
  async function h264Encoder() {
    if (encPick) return encPick;
    const ff = ffmpeg(); if (!ff) return ENCODERS()[ENCODERS().length - 1];
    let key = ff; try { key += ':' + CS.fs.statSync(ff).size; } catch (e) {}
    try { const c = JSON.parse(localStorage.getItem('os.h264enc') || 'null'); if (c && c.key === key) { encPick = ENCODERS().find((e) => e.name === c.name) || null; if (encPick) return encPick; } } catch (e) {}
    for (const e of ENCODERS()) {
      try {
        await runCmd(ff, ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=320x240:rate=30', '-frames:v', '6', '-c:v', e.name].concat(e.args, ['-pix_fmt', 'yuv420p', '-f', 'null', '-']));
        encPick = e; break;
      } catch (err) { Log.info('social', 'encoder ' + e.name + ' not usable here: ' + String(err.message || err).slice(0, 120)); }
    }
    if (!encPick) encPick = ENCODERS()[ENCODERS().length - 1];
    try { localStorage.setItem('os.h264enc', JSON.stringify({ key, name: encPick.name })); } catch (e) {}
    Log.info('social', 'H.264 encoder: ' + encPick.name);
    return encPick;
  }
  const encName = () => (encPick ? encPick.name : 'libx264').replace(/^h264_/, '').replace('videotoolbox', 'VideoToolbox').replace('nvenc', 'NVENC').replace('qsv', 'Quick Sync').replace('amf', 'AMD').replace('libx264', 'x264');
  /*  One encode with the picked encoder; when the hardware decode it asked for is what fails, the
      same job runs again with software decoding before anyone hears about it.                       */
  async function encodeH264(inputArgs, outputArgs, out, onLine) {
    const e = await h264Encoder();
    const build = (hw) => ['-y', '-hide_banner', '-loglevel', 'info', '-stats'].concat(hw && e.hwaccel ? e.hwaccel : [], inputArgs, ['-c:v', e.name], e.args, ['-pix_fmt', 'yuv420p'], outputArgs, [out]);
    try { await runCmd(ffmpeg(), build(true), onLine); }
    catch (err) {
      if (!e.hwaccel) throw err;
      Log.warn('social', 'encode with ' + e.hwaccel.join(' ') + ' failed, again without: ' + String(err.message || err).slice(0, 160));
      await runCmd(ffmpeg(), build(false), onLine);
    }
  }
  /* Premiere cannot decode VP9 / AV1: re-encode to H.264 next to the original */
  async function convertToH264(file, onProgress) {
    if (!ffmpeg()) await installFfmpeg(onProgress);
    const info = await probe(file);
    /*  "Permission denied" opening the output happens when a converted file from an earlier run is
        already there and Premiere has it open - an imported clip is locked for writing. So never write
        over one: take the next free name. The probe below turns a read-only or synced folder into a
        message that says what to do instead of ffmpeg's.                                              */
    const stem = file.replace(/\.[a-z0-9]+$/i, '');
    let out = stem + '_h264.mp4';
    for (let n = 2; n < 200 && CS.fs.existsSync(out); n++) out = stem + '_h264_' + n + '.mp4';
    try { CS.fs.writeFileSync(out + '.probe', ''); CS.fs.unlinkSync(out + '.probe'); }
    catch (e) { throw new Error('Cannot write into ' + CS.path.dirname(file) + '. Choose another folder under "Save to" - a Desktop synced by OneDrive often blocks this.'); }
    onProgress(0, 'Converting to H.264…');
    await encodeH264(['-i', file], ['-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart'], out, (line) => {
      const m = /time=(\d+):(\d+):([\d.]+)/.exec(line);
      if (m && info.duration) { const t = (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]); onProgress(Math.min(0.99, t / info.duration), 'Converting to H.264 (' + encName() + ') · ' + Math.round(Math.min(0.99, t / info.duration) * 100) + '%'); }
    });
    if (!CS.fs.existsSync(out)) throw new Error('Conversion produced no file.');
    return out;
  }
  function run(args, onLine) {
    return new Promise((resolve, reject) => {
      const p = CS.track(cp.spawn(exe(), args, { windowsHide: true }));
      let out = '', err = '';
      p.stdout.on('data', d => { const s = String(d); out += s; if (onLine) s.split(/\r?\n/).forEach(l => l && onLine(l)); });
      /* ffmpeg (the downloader for a trimmed piece) reports on stderr with \r between updates, not newlines */
      p.stderr.on('data', d => { const s = String(d); err += s; if (onLine) s.split(/[\r\n]+/).forEach(l => l && onLine(l)); });
      p.on('error', reject);
      p.on('close', code => p.cancelled ? reject(new Error('Cancelled.')) : code === 0 ? resolve(out) : reject(new Error((err || out).trim().split('\n').filter(l => /ERROR/i.test(l)).pop() || ('yt-dlp exited with code ' + code))));
    });
  }
  const baseArgs = () => { const a = ['--no-playlist', '--no-warnings']; if (deno()) a.push('--js-runtimes', 'deno:' + deno()); return a; };
  async function withRuntime(fn, onProgress) {
    try { return await fn(); }
    catch (e) {
      if (/JavaScript runtime|js.?runtime|nsig|n challenge/i.test(String(e.message || e)) && !deno()) { await installDeno(onProgress); return await fn(); }
      throw e;
    }
  }

  /* ---- step 1: info + options ---- */
  const fmtSize = (b) => b ? (b > 1e9 ? (b / 1e9).toFixed(2) + ' GB' : (b / 1e6).toFixed(1) + ' MB') : '';
  const fmtDur = (s) => { s = Math.round(s || 0); const m = Math.floor(s / 60); return (m >= 60 ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : m) + ':' + String(s % 60).padStart(2, '0'); };
  const codecName = (v) => /^avc1|^h264/i.test(v) ? 'H.264' : /^vp0?9/i.test(v) ? 'VP9' : /^av01/i.test(v) ? 'AV1' : /^hev|^hvc|^h265/i.test(v) ? 'HEVC' : (v || '').split('.')[0].toUpperCase();
  const codecRank = (v) => /^avc1|^h264/i.test(v) ? 0 : /^hev|^hvc/i.test(v) ? 1 : /^vp0?9/i.test(v) ? 2 : /^av01/i.test(v) ? 3 : 4;
  const langName = (code) => { try { const n = new Intl.DisplayNames(['en'], { type: 'language' }).of(code); if (n && n !== code) return n; } catch (e) {} return code === 'und' ? 'Unknown' : code; };
  const baseLang = (f) => ((f.language || '') + '').split('-')[0].toLowerCase();
  /* one entry per language: YouTube dubs come as extra audio-only formats with a language tag */
  function audioTracks(d) {
    const out = {};
    const vidLang = String(d.language || '').split('-')[0].toLowerCase();
    let n = 0;
    for (const f of (d.formats || [])) {
      if (!(f.acodec && f.acodec !== 'none' && (!f.vcodec || f.vcodec === 'none'))) continue;
      if (/drc/i.test(f.format_note || '') || /drc/i.test(f.format_id || '')) continue;
      const L = baseLang(f) || 'und', note = f.format_note || '';
      const orig = /original|\(default\)/i.test(note) || (f.language_preference || 0) > 0;
      const cur = out[L];
      if (!cur || (f.abr || f.tbr || 0) > cur.abr) out[L] = { lang: L, abr: f.abr || f.tbr || 0, original: !!(orig || (cur && cur.original)), own: L === vidLang, order: cur ? cur.order : n++, label: langName(L) + (orig ? ' (original)' : /dub/i.test(note) ? ' (dubbed)' : '') };
      else if (orig && !cur.original) { cur.original = true; cur.label = langName(L) + ' (original)'; }
    }
    /*  First in the list is the default. The original when yt-dlp flags one; else the track in the video's
        own language; else the first track the way YouTube lists them. Never the alphabet - that put
        Arabic on top of every dubbed video whose original was not flagged.                              */
    /*  Booleans go through Number(): a subtraction with an undefined in it is NaN, which a sort takes as
        "equal" - that is how the alphabet crept back in even with the original flagged.                */
    const N = (v) => (v ? 1 : 0);
    return Object.values(out).sort((a, b) => (N(b.original) - N(a.original)) || (N(b.own) - N(a.own)) || (a.order - b.order));
  }
  /*  The default track for this video: the flagged original. The language remembered from an earlier
      download only counts when the video does not say which track is the original.                    */
  function defaultLang(tracks, remembered) {
    if (!tracks.length) return '';
    if (tracks[0].original) return tracks[0].lang;
    return remembered && tracks.some(t => t.lang === remembered) ? remembered : tracks[0].lang;
  }
  function buildOptions(d, lang) {
    const fmts = (d.formats || []).filter(f => f.url || f.format_id);
    let audio = fmts.filter(f => f.acodec && f.acodec !== 'none' && (!f.vcodec || f.vcodec === 'none')).sort((a, b) => (/mp4a|m4a/i.test(b.acodec) - /mp4a|m4a/i.test(a.acodec)) || ((b.abr || b.tbr || 0) - (a.abr || a.tbr || 0)));
    const tracks = audioTracks(d);
    const want = lang || (tracks[0] && tracks[0].lang) || '';
    if (want && tracks.length > 1) { const same = audio.filter(f => (baseLang(f) || 'und') === want && !/drc/i.test(f.format_note || '')); if (same.length) audio = same; }
    const bestAudio = audio[0] || null;
    const videos = fmts.filter(f => f.vcodec && f.vcodec !== 'none' && f.height);
    const byH = {};
    for (const f of videos) {
      const key = f.height;
      const cur = byH[key];
      const better = !cur || codecRank(f.vcodec) < codecRank(cur.vcodec) || (codecRank(f.vcodec) === codecRank(cur.vcodec) && ((f.fps || 0) > (cur.fps || 0) || (!/m3u8/i.test(f.protocol || '') && /m3u8/i.test(cur.protocol || ''))));
      if (better) byH[key] = f;
    }
    const opts = Object.values(byH).sort((a, b) => b.height - a.height).slice(0, 7).map(f => {
      const combined = f.acodec && f.acodec !== 'none';
      const size = (f.filesize || f.filesize_approx || 0) + (combined ? 0 : (bestAudio ? (bestAudio.filesize || bestAudio.filesize_approx || 0) : 0));
      const label = f.height >= 2160 ? '4K' : f.height >= 1440 ? '2K' : f.height + 'p';
      return { id: 'v' + f.format_id, label, height: f.height, fps: f.fps ? Math.round(f.fps) + 'fps' : '', codec: codecName(f.vcodec), warn: codecRank(f.vcodec) >= 2 ? 'converted for you' : '', size, fmt: combined ? f.format_id : (bestAudio ? f.format_id + '+' + bestAudio.format_id : f.format_id), audioOnly: false };
    });
    if (bestAudio) opts.push({ id: 'audio', label: 'Audio only', height: 0, fps: '', codec: /mp4a|m4a/i.test(bestAudio.acodec) ? 'AAC → MP3' : (bestAudio.acodec || 'audio'), warn: '', size: bestAudio.filesize || bestAudio.filesize_approx || 0, fmt: bestAudio.format_id, audioOnly: true });
    return opts;
  }
  /* subtitle languages: uploaded ones first, then automatic captions (video language, English, Dutch on top) */
  function subtitleOptions(d) {
    const out = [], seen = {};
    const add = (code, auto) => { const key = (auto ? 'auto:' : '') + code; if (seen[key]) return; seen[key] = 1; out.push({ id: key, label: langName(code.split('-')[0]) + (code.includes('-') ? ' (' + code + ')' : '') + (auto ? ' · auto' : ''), auto }); };
    for (const k of Object.keys(d.subtitles || {})) if ((d.subtitles[k] || []).length && !/live_chat/i.test(k)) add(k, false);
    const autos = Object.keys(d.automatic_captions || {}).filter(k => (d.automatic_captions[k] || []).length && !/-orig$/.test(k));
    const top = [(d.language || '').split('-')[0], 'en', 'nl'].filter(Boolean);
    for (const t of top) if (autos.includes(t)) add(t, true);
    for (const k of autos.sort()) add(k, true);
    return out;
  }
  async function fetchInfo(url, onProgress) {
    await ensureYtDlp(onProgress);
    onProgress(0.2, 'Reading video info');
    const out = await withRuntime(() => run(baseArgs().concat(['-J', url])), onProgress);
    const d = JSON.parse(out);
    if (d._type === 'playlist' && d.entries && d.entries.length) return d.entries[0];
    return d;
  }
  /* ---- a trimmed piece, fast ----
     ffmpeg fetches a section with HTTP Range headers, and googlevideo throttles those to about 200 KB/s
     (measured: a 20 MB range took 109 s, an 11 s piece at 1080p took 19 s while the whole 21-minute
     video took 20 s). yt-dlp's own downloader is not throttled because it asks for chunks with a
     "range=" QUERY parameter. This local proxy does that translation for ffmpeg: it takes ffmpeg's Range
     requests, fetches the bytes upstream in 10 MB range= chunks, and streams them back. */
  let proxy = null, proxyPort = 0, proxyUp = null;
  const CHUNK = 10 * 1024 * 1024;
  const Buf = nodeReq ? nodeReq('buffer').Buffer : null;
  function upstreamGet(url, redirects) {
    const https = nodeReq('https'), http = nodeReq('http');
    return new Promise((resolve, reject) => {
      const mod = /^http:/i.test(url) ? http : https;
      const req = mod.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' } }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) { res.resume(); upstreamGet(new URL(res.headers.location, url).toString(), redirects - 1).then(resolve, reject); return; }
        if (res.statusCode >= 400) { res.resume(); reject(new Error('HTTP ' + res.statusCode + ' from the video server')); return; }
        resolve(res);
      });
      req.on('error', reject);
      req.setTimeout(60000, () => req.destroy(new Error('the video server stopped answering')));
    });
  }
  /*  Resolves to the port. listen(port, host) looks the host up first, so address() is null right
      after the call - reading .port there is what killed this route in every build before 1.13.4. */
  function sectionProxy() {
    if (proxyUp) return proxyUp;
    const http = nodeReq('http');
    proxy = http.createServer(async (req, res) => {
      try {
        const q = new URL(req.url, 'http://127.0.0.1').searchParams;
        const up = Buf.from(q.get('u') || '', 'base64').toString('utf8');
        const total = parseInt(q.get('len') || '0', 10) || 0;
        if (!up || !total) { res.writeHead(400); res.end(); return; }
        let start = 0, end = total - 1;
        const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
        if (m) { if (m[1]) start = +m[1]; if (m[2]) end = Math.min(total - 1, +m[2]); if (!m[1] && m[2]) { start = Math.max(0, total - +m[2]); end = total - 1; } }
        if (start > end || start >= total) { res.writeHead(416, { 'Content-Range': 'bytes */' + total }); res.end(); return; }
        res.writeHead(m ? 206 : 200, { 'Content-Type': 'application/octet-stream', 'Accept-Ranges': 'bytes', 'Content-Length': String(end - start + 1), 'Content-Range': 'bytes ' + start + '-' + end + '/' + total });
        if (req.method === 'HEAD') { res.end(); return; }
        let cur = start, closed = false, live = null;
        res.on('close', () => { closed = true; if (live) live.destroy(); });
        res.on('drain', () => { if (live) live.resume(); });
        while (cur <= end && !closed) {
          const to = Math.min(end, cur + CHUNK - 1);
          const r = live = await upstreamGet(up + (up.includes('?') ? '&' : '?') + 'range=' + cur + '-' + to, 5);
          await new Promise((done, fail) => { r.on('data', (d) => { if (closed) { r.destroy(); done(); return; } if (!res.write(d)) r.pause(); }); r.on('end', done); r.on('close', done); r.on('error', fail); });
          cur = to + 1;
        }
        live = null;
        res.end();
      } catch (e) { try { Log.warn('social', 'proxy: ' + e.message); res.destroy(); } catch (e2) {} }
    });
    proxyUp = new Promise((resolve, reject) => {
      proxy.once('error', (e) => { proxy = null; proxyPort = 0; proxyUp = null; reject(e); });
      proxy.listen(0, '127.0.0.1', () => { proxyPort = proxy.address().port; resolve(proxyPort); });
    });
    return proxyUp;
  }
  /* the proxied address of a format's stream; null when the format has no direct URL or no known length */
  async function proxied(f) {
    if (!f || !f.url || /m3u8|dash_manifest/i.test(f.protocol || '')) return null;
    let len = 0; try { len = parseInt(new URL(f.url).searchParams.get('clen') || '0', 10) || 0; } catch (e) {}
    if (!len) len = f.filesize || 0;
    if (!len) return null;
    return 'http://127.0.0.1:' + (await sectionProxy()) + '/f?len=' + len + '&u=' + Buf.from(f.url, 'utf8').toString('base64');
  }
  /*  The piece, fetched through the proxy by ffmpeg directly. Returns the file, or null when this video
      cannot go that way (no direct stream URLs, no length): then the yt-dlp path below takes over.     */
  async function downloadSection(dir, opt, onProgress) {
    if (!info || !info.formats) return null;
    const ids = String(opt.fmt || '').split('/')[0].split('+');
    const fm = ids.map((id) => (info.formats || []).find((f) => f.format_id === id)).filter(Boolean);
    if (!fm.length) return null;
    const srcs = await Promise.all(fm.map(proxied));
    if (srcs.some((x) => !x)) return null;
    const A = opt.section.a, len = Math.max(0.1, opt.section.b - opt.section.a);
    const stem = ((info.title || 'video').replace(/[^A-Za-z0-9._-]+/g, '_').slice(0, 70)) + ' [' + (info.id || 'x') + ']_' + A.toFixed(2) + '-' + opt.section.b.toFixed(2) + (opt.multiAudio && opt.lang ? '_' + String(opt.lang).replace(/[^a-z]/gi, '').slice(0, 5) : '');
    const out = CS.path.join(dir, stem + (opt.audioOnly ? '.mp3' : '.mp4'));
    if (CS.fs.existsSync(out) && CS.fs.statSync(out).size > 1000) return out;
    /*  Fetched and cut in the same pass. -ss before -i makes ffmpeg decode from the keyframe and drop
        everything up to the in-point, so the piece starts exactly there and lasts exactly as asked. A
        stream copy cannot do that: it begins at the keyframe before the in-point, a few seconds early. */
    const inputs = [];
    for (const src of srcs) inputs.push('-ss', A.toFixed(3), '-i', src);
    inputs.push('-t', len.toFixed(3));
    const t0 = Date.now();
    const onLine = (line) => {
      const ft = /time=(\d+):(\d\d):(\d\d(?:\.\d+)?)/.exec(line);
      if (!ft) return;
      const t = (+ft[1]) * 3600 + (+ft[2]) * 60 + parseFloat(ft[3]);
      const p = Math.max(0, Math.min(1, t / len)), el = (Date.now() - t0) / 1000;
      const eta = p > 0.05 && el > 2 ? Math.round(el / p - el) : 0;
      onProgress(Math.min(0.98, p), Math.round(p * 100) + '% of the piece' + (eta > 3 ? ' · about ' + (eta >= 90 ? Math.round(eta / 60) + ' min' : eta + ' s') + ' left' : ''));
    };
    Log.info('social', 'section through the proxy', { formats: ids, piece: A.toFixed(2) + '-' + opt.section.b.toFixed(2), out });
    onProgress(0, 'Fetching the piece');
    if (opt.audioOnly) await runCmd(ffmpeg(), ['-y', '-hide_banner', '-loglevel', 'info', '-stats'].concat(inputs, ['-vn', '-c:a', 'libmp3lame', '-q:a', '2', out]), onLine);
    else {
      await h264Encoder();
      onProgress(0, 'Fetching and cutting the piece (' + encName() + ')');
      await encodeH264(inputs, (srcs.length > 1 ? ['-map', '0:v:0', '-map', '1:a:0'] : ['-map', '0:v:0', '-map', '0:a:0?']).concat(['-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart']), out, onLine);
    }
    if (!CS.fs.existsSync(out) || CS.fs.statSync(out).size < 1000) throw new Error('The piece came back empty.');
    return out;
  }

  /* ---- step 2: download the chosen option ---- */
  /* the engine files, executable and unquarantined, every time on a Mac: cheap, and it is what an update leaves behind */
  function macReady() {
    if (!CS.mac) return;
    for (const f of [exe(), ffmpeg(), ffprobe(), deno()]) if (f) CS.chmodX(f);
  }
  async function download(url, opt, onProgress) {
    await ensureYtDlp(onProgress);
    macReady();
    /* an engine that is there but will not run (the Intel build on an Apple Silicon Mac): fetched again, native */
    if (CS.mac && ffmpeg() && !CS.runs(ffmpeg())) { try { CS.fs.rmSync(CS.path.join(home(), 'ffmpeg'), { recursive: true, force: true }); } catch (e) {} }
    if (!ffmpeg()) await installFfmpeg(onProgress);
    const dir = opt.dirOverride || await downloadDir();
    /* a trimmed piece: through the proxy when the streams allow it (see above); otherwise yt-dlp's slow way */
    let file = null;
    if (opt.section && !opt.viaYtdlp) {
      try { file = await downloadSection(dir, opt, onProgress); }
      catch (e) { Log.warn('social', 'proxy section failed, falling back to yt-dlp: ' + e.message); file = null; }
    }
    /*  The piece is named after the section ("_12.50-23.00"), the whole video after itself: yt-dlp skips a
        file that already exists, and for a while a second piece - or the whole video - came back as the
        first piece under the same name.                                                                 */
    /* a dubbed video: the language is part of the name, so English is never handed the Arabic file */
    const langTag = opt.multiAudio && opt.lang ? '_' + String(opt.lang).replace(/[^a-z]/gi, '').slice(0, 5) : '';
    const tmpl = opt.section ? '%(title).70s [%(id)s]_' + opt.section.a.toFixed(2) + '-' + opt.section.b.toFixed(2) + langTag + '.%(ext)s' : '%(title).70s [%(id)s]' + langTag + '.%(ext)s';
    const args = baseArgs().concat(['--newline', '-o', CS.path.join(dir, tmpl), '--print', 'after_move:filepath', '--no-simulate', '--restrict-filenames', '--ffmpeg-location', ffmpeg()]);
    if (opt.sub) { args.push(opt.sub.auto ? '--write-auto-subs' : '--write-subs', '--sub-langs', opt.sub.id.replace(/^auto:/, ''), '--sub-format', 'srt/best', '--convert-subs', 'srt'); if (opt.sub.auto) args.push('--write-subs'); }
    /*  --download-sections pulls only the bytes for that stretch, so ten seconds of a ten minute video is a
        few seconds and a couple of MB. --force-keyframes-at-cuts re-encodes around the ends so the piece is
        exactly the length asked for instead of snapping out to the nearest keyframes.                     */
    if (opt.section) args.push('--download-sections', '*' + opt.section.a.toFixed(2) + '-' + opt.section.b.toFixed(2), '--force-keyframes-at-cuts');
    if (opt.audioOnly) args.push('-f', opt.fmt, '-x', '--audio-format', 'mp3');
    else {
      /* when the exact formats are not there, the fallbacks still ask for the chosen language first */
      const L = opt.multiAudio && opt.lang && opt.lang !== 'und' ? '[language^=' + String(opt.lang).replace(/[^a-z-]/gi, '') + ']' : '';
      const chain = (L ? 'bv*[vcodec^=avc1]+ba' + L + '/bv*+ba' + L + '/' : '') + 'bv*[vcodec^=avc1]+ba/bv*+ba/b';
      args.push('-f', opt.fmt + '/' + chain, '-S', 'vcodec:h264,res:' + (opt.height || 4320) + ',ext:mp4:m4a', '--merge-output-format', 'mp4');
    }
    args.push(url);
    /*  Everything already in the folder. The "newest file" fallback further down used to be able to pick
        up a download from an hour ago and present it as this one - which looks exactly like the trim
        being ignored.                                                                                  */
    const before = {};
    try { for (const f of CS.fs.readdirSync(dir)) before[f] = 1; } catch (e) {}
    try { if (!file) Log.info('social', 'yt-dlp', { section: opt.section ? opt.section.a.toFixed(2) + '-' + opt.section.b.toFixed(2) : 'none', fmt: opt.fmt, args: args.join(' ') }); } catch (e) {}
    if (!file) onProgress(0, 'Starting download');
    let out;
    try {
      /*  A trimmed piece is fetched by ffmpeg, not by yt-dlp's own downloader, and ffmpeg says nothing in
          the "[download] 42%" form - it prints "time=00:00:05.12" as it goes. That, against the length of
          the piece, is the bar. Video and audio come as two passes, so the time starts over once.      */
      const secLen = opt.section ? Math.max(0.1, opt.section.b - opt.section.a) : 0;
      let pass = 0, lastT = -1;
      out = file ? '' : await withRuntime(() => run(args, (line) => {
        const m = /\[download\]\s+([\d.]+)%/.exec(line);
        const ft = secLen ? /time=(\d+):(\d\d):(\d\d(?:\.\d+)?)/.exec(line) : null;
        if (m) onProgress(parseFloat(m[1]) / 100, line.replace('[download]', '').trim());
        else if (ft) {
          const t = (+ft[1]) * 3600 + (+ft[2]) * 60 + parseFloat(ft[3]);
          if (lastT >= 0 && t < lastT - 1) pass++;
          lastT = t;
          const p = Math.max(0, Math.min(1, t / secLen)), half = opt.audioOnly ? 1 : 0.5;
          const overall = opt.audioOnly ? p : Math.min(0.99, pass * half + p * half);
          onProgress(overall, (opt.audioOnly ? 'Audio' : pass === 0 ? 'Video' : 'Audio') + ' · ' + Math.round(p * 100) + '% of the piece');
        }
        else if (/Merging|Extracting|Post-process|Destination/i.test(line)) onProgress(0.97, line.trim().slice(0, 80));
        if (/^[A-Za-z]:\\.+\.[a-z0-9]{2,4}$/i.test(line.trim()) && CS.fs.existsSync(line.trim())) file = line.trim();
      }), onProgress);
    } catch (e) {
      /*  The folder next to the project would not take the file (a synced or read-only drive, a file with
          the same name open in Premiere). One more go in the panel's own folder before giving up.      */
      if (!opt.dirOverride && /Permission denied|EACCES|EPERM|Error opening output/i.test(String(e.message || e))) {
        const alt = CS.dataDir('downloads');
        CS.mkdirp(alt);
        Log.warn('social', 'output folder refused the file, trying ' + alt, String(e.message || e).slice(0, 200));
        return download(url, Object.assign({}, opt, { dirOverride: alt }), onProgress);
      }
      throw e;
    }
    if (!file) { const cand = out.split(/\r?\n/).map(s => s.trim()).filter(l => /^[A-Za-z]:\\/.test(l) && CS.fs.existsSync(l)); file = cand[cand.length - 1] || null; }
    if (!file) {
      const files = CS.fs.readdirSync(dir).filter(f => !before[f] && !/\.(part|ytdl|jpg|webp)$/i.test(f)).map(f => CS.path.join(dir, f))
        .sort((a, b) => CS.fs.statSync(b).mtimeMs - CS.fs.statSync(a).mtimeMs);
      file = files[0] || null;
    }
    if (!file) throw new Error('Download finished but the file could not be found in ' + dir);
    /* thumbnail for the Recent list */
    let thumb = '';
    try { if (info && info.thumbnail) { thumb = file.replace(/\.[a-z0-9]+$/i, '') + '.jpg'; if (!CS.fs.existsSync(thumb)) await Net.download(info.thumbnail, thumb, () => {}); } } catch (e) { thumb = ''; }
    /*  The promise this tool makes is that you get the piece you chose. yt-dlp normally does it, but if
        anything makes it fall back - an unavailable format, a site that will not serve ranges - it hands
        back the whole video, and until now that went quietly onto the timeline. Measure it, and cut it
        here when it is wrong.                                                                          */
    if (opt.section && file) {
      const want = Math.max(0.1, opt.section.b - opt.section.a);
      let got = 0;
      try { got = (await probe(file)).duration || 0; } catch (e) {}
      if (got > want + 0.6) {
        Log.warn('social', 'the download came back longer than the piece asked for, cutting it here', { want: want.toFixed(2), got: got.toFixed(2) });
        onProgress(0.97, 'Trimming to the piece you chose');
        const cut = file.replace(/\.([a-z0-9]+)$/i, '_cut.mp4');
        try {
          /*  Re-encoded, not stream-copied: a copy can only cut on keyframes and measured 15.3 s for an
              11 s request. This only ever runs when the download already went wrong, so being right
              matters more than being quick.                                                           */
          await encodeH264(['-ss', opt.section.a.toFixed(2), '-to', opt.section.b.toFixed(2), '-i', file], ['-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart'], cut, () => {});
          if (CS.fs.existsSync(cut) && CS.fs.statSync(cut).size > 1000) { try { CS.fs.unlinkSync(file); } catch (e) {} file = cut; }
        } catch (e) { Log.warn('social', 'could not cut it', e.message); }
      }
    }
    let subs = '';
    if (opt.sub && opt.section && !opt.viaYtdlp) {
      /* the proxy fetched the piece; the subtitles come from yt-dlp on their own, named like the file */
      try {
        const sargs = baseArgs().concat(['--skip-download', '-o', CS.path.join(dir, tmpl), '--restrict-filenames', '--ffmpeg-location', ffmpeg(),
          opt.sub.auto ? '--write-auto-subs' : '--write-subs', '--sub-langs', opt.sub.id.replace(/^auto:/, ''), '--sub-format', 'srt/best', '--convert-subs', 'srt']);
        if (opt.sub.auto) sargs.push('--write-subs');
        sargs.push(url);
        onProgress(0.98, 'Fetching the subtitles');
        await withRuntime(() => run(sargs, () => {}), onProgress);
      } catch (e) { Log.warn('social', 'subtitles: ' + e.message); }
    }
    if (opt.sub) {
      try {
        const stem = CS.path.basename(file).replace(/\.[a-z0-9]+$/i, '');
        const cand = CS.fs.readdirSync(dir).filter(f => f.startsWith(stem) && /\.srt$/i.test(f)).map(f => CS.path.join(dir, f)).sort((a, b) => CS.fs.statSync(b).mtimeMs - CS.fs.statSync(a).mtimeMs);
        subs = cand[0] || '';
      } catch (e) { subs = ''; }
    }
    return { file, thumb, subs };
  }

  /* ---- the scrubbing thumbnails, so the trim can be done before anything is downloaded ----
     Sites that have a scrub bar publish it as sheets of small frames ("storyboards"); yt-dlp lists them as
     formats sb0, sb1... with the sheet URLs in `fragments`. Reading those is a handful of small images, not
     the video, so the filmstrip appears in a second and costs nothing. Anything without them (Instagram,
     TikTok, X) falls back to the poster frame and a plain bar - the trim still works.                     */
  function storyboard(d) {
    const sbs = (d.formats || []).filter((f) => f.format_note === 'storyboard' || /^sb\d/.test(String(f.format_id || '')));
    if (!sbs.length) return null;
    /* the biggest tiles that still come in a handful of sheets: quality without a dozen round trips */
    const usable = sbs.filter((f) => (f.fragments || []).length && (f.fragments || []).length <= 12 && f.width >= 60);
    if (!usable.length) return null;
    usable.sort((a, b) => (b.width || 0) - (a.width || 0));
    const f = usable[0];
    return { rows: f.rows || 1, cols: f.columns || 1, tw: f.width || 160, th: f.height || 90, fps: +f.fps || 0, frags: (f.fragments || []).map((x) => x.url), each: (f.fragments[0] || {}).duration || 0 };
  }
  /*  No crossOrigin: the thumbnail host sends no CORS header, so asking for an anonymous request makes the
      load fail outright. Without it the sheet loads and draws; the canvas is then tainted, which costs us
      nothing because it is only ever shown, never read back.                                            */
  /*  The sheets stay in memory after the strip is built: the strip is only 40 frames across the whole
      video, far too coarse to trim on, but the sheets hold one frame every few seconds and drawing one
      of those under the cursor costs nothing.                                                        */
  let sbCache = null;   /* { sb, sheets, duration, total } */
  const loadImg = (url) => new Promise((res) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = url; });
  /* draws TILES frames evenly across the video into one canvas, the same shape of filmstrip the other tools use */
  async function buildStrip(sb, duration, canvas) {
    const TILES = 40, per = sb.rows * sb.cols;
    const g = canvas.getContext('2d');
    const th = canvas.height, tw = Math.round(th * (sb.tw / sb.th));
    canvas.width = tw * TILES;
    g.fillStyle = '#0b0d11'; g.fillRect(0, 0, canvas.width, th);
    const sheets = {};
    /*  The last sheet is only partly filled: a 10:35 video at one frame every 5 s is 128 frames in 6 sheets
        of 25, so slots 128-149 are empty. Spreading over sheets x per would leave the end of the strip
        black. The frame count comes from the rate the site published.                                   */
    const total = Math.max(1, Math.min(sb.frags.length * per, sb.fps > 0 ? Math.round(duration * sb.fps) : sb.frags.length * per));
    sbCache = { sb, sheets, duration, total, per };
    for (let i = 0; i < TILES; i++) {
      const t = (i + 0.5) / TILES * duration;
      const idx = Math.min(total - 1, Math.floor(t / Math.max(0.001, duration) * total));
      const sheetNo = Math.min(sb.frags.length - 1, Math.floor(idx / per));
      if (!(sheetNo in sheets)) sheets[sheetNo] = await loadImg(sb.frags[sheetNo]);
      const im = sheets[sheetNo];
      if (!im) continue;
      const cell = idx % per, cx = (cell % sb.cols) * sb.tw, cy = Math.floor(cell / sb.cols) * sb.th;
      try { g.drawImage(im, cx, cy, sb.tw, sb.th, i * tw, 0, tw, th); } catch (e) {}
    }
    return true;
  }

  /*  One frame at time t, from the sheets already loaded for the strip. Returns false when that sheet is
      not in memory yet - the caller leaves the last frame up rather than flashing an empty box.       */
  function drawMoment(t, canvas) {
    if (!sbCache || !canvas) return false;
    const { sb, sheets, duration, total, per } = sbCache;
    const idx = Math.max(0, Math.min(total - 1, Math.floor(t / Math.max(0.001, duration) * total)));
    const sheetNo = Math.min(sb.frags.length - 1, Math.floor(idx / per));
    const im = sheets[sheetNo];
    if (!im) { loadImg(sb.frags[sheetNo]).then((x) => { if (x) sheets[sheetNo] = x; }); return false; }
    const cell = idx % per, cx = (cell % sb.cols) * sb.tw, cy = Math.floor(cell / sb.cols) * sb.th;
    const g = canvas.getContext('2d');
    canvas.width = sb.tw; canvas.height = sb.th;
    try { g.drawImage(im, cx, cy, sb.tw, sb.th, 0, 0, sb.tw, sb.th); } catch (e) { return false; }
    return true;
  }

  /* ------------------------------------------------------------- UI */
  /* the piece the user wants: null means the whole thing */
  let trim = null;   /* { on, a, b, dur } in seconds */
  const trimLen = () => trim ? Math.max(0.1, trim.b - trim.a) : 0;
  /*  The chapters: what yt-dlp hands over (YouTube's own, or the ones it read from the description) and,
      failing that, the description read here - lines that begin with a time, at least two of them, in
      order. Each gets a start, an end (the next start, or the end of the video) and a title.          */
  function chaptersOf(info) {
    const dur = +info.duration || 0;
    let list = [];
    if (Array.isArray(info.chapters) && info.chapters.length >= 2) list = info.chapters.map(c => ({ s: +c.start_time || 0, e: +c.end_time || 0, t: String(c.title || '').trim() }));
    if (!list.length && info.description) {
      const re = /^\s*[\[(]?(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[\])]?\s*[-–—:|.]?\s*(.+?)\s*$/;
      for (const line of String(info.description).split(/\r?\n/)) {
        const m = re.exec(line); if (!m) continue;
        const s = (m[1] ? +m[1] * 3600 : 0) + (+m[2]) * 60 + (+m[3]);
        if (list.length && s <= list[list.length - 1].s) continue;      /* out of order: not a chapter list */
        list.push({ s, e: 0, t: m[4].replace(/^[-–—:|.\s]+/, '') });
      }
      if (list.length < 2) list = [];
    }
    list = list.filter(c => c.s >= 0 && (!dur || c.s < dur)).sort((a, b) => a.s - b.s);
    for (let i = 0; i < list.length; i++) if (!list[i].e || list[i].e <= list[i].s) list[i].e = i + 1 < list.length ? list[i + 1].s : dur;
    return list.length >= 2 ? list : [];
  }
  const chapterAt = (t) => { const cs = trim && trim.chapters || []; for (let i = cs.length - 1; i >= 0; i--) if (t >= cs[i].s - 0.01) return cs[i]; return null; };
  /* a time near a chapter start (within a few pixels of the strip) lands on it */
  function snapTime(t) {
    const strip = $('#so-strip'); if (!strip || !trim || !trim.chapters.length) return t;
    const tol = 7 / Math.max(1, strip.clientWidth) * trim.dur;
    let best = t, d = tol;
    for (const c of trim.chapters) for (const x of [c.s, c.e]) { const dd = Math.abs(x - t); if (dd < d) { d = dd; best = x; } }
    return best;
  }

  const prog = { show(t) { $('#progress').classList.add('show'); $('#prog-title').textContent = t; $('#prog-bar').style.width = '0%'; $('#prog-text').textContent = ''; }, hide() { $('#progress').classList.remove('show'); } };
  let running = false;
  async function busy(title, fn) {
    if (running) { toast('Please wait, the current download is still running.'); return; }
    running = true;
    prog.show(title);
    const pr = (p, txt) => { $('#prog-bar').style.width = Math.round(Math.max(0, p) * 100) + '%'; if (txt) $('#prog-text').textContent = txt; };
    try { await fn(pr); } catch (e) { toast(e.message || String(e), CS.isCancel(null, e) ? '' : 'err'); } finally { prog.hide(); running = false; }
  }
  async function open(url) {
    Hub.show('social');
    const inp = $('#so-url'); if (url) inp.value = url;
    renderStatus(); renderHistory(); renderDir();
    setTimeout(() => inp.focus(), 50);
    if (!url) setTimeout(autoFromClipboard, 120);
  }
  /*  A video link sitting on the clipboard is pasted and fetched by itself: when the tool opens, and when
      the panel comes back into focus while the tool is up (copy in the browser, click the panel). Each
      link once, so a link that was already fetched, or dismissed, is not fetched again.                 */
  const VIDEO_LINK = /^https?:\/\/(www\.|m\.|mobile\.)?(youtube\.com|youtu\.be|instagram\.com|tiktok\.com|vm\.tiktok\.com|x\.com|twitter\.com|vimeo\.com|facebook\.com|fb\.watch|twitch\.tv|reddit\.com|dailymotion\.com|streamable\.com)\/\S+$/i;
  async function autoFromClipboard() {
    try {
      if (running || (typeof Hub !== 'undefined' && Hub.current && Hub.current() !== 'social')) return;
      let t = '';
      try { if (CS.inCEP && cp) t = CS.clipboardText(); else t = await navigator.clipboard.readText(); } catch (e) {}
      t = (t || '').trim().split(/\s+/)[0] || '';
      if (!VIDEO_LINK.test(t) || t === st.lastClip) return;
      if ($('#so-url').value.trim() === t || (info && info.__url === t)) { st.lastClip = t; save(); return; }
      st.lastClip = t; save();
      $('#so-url').value = t;
      toast('Link taken from the clipboard.', '');
      fetchStep();
    } catch (e) {}
  }
  async function renderDir() { try { $('#so-dir').textContent = CS.inCEP ? await downloadDir() : '(project)/OutflowStudio/downloads'; } catch (e) { $('#so-dir').textContent = '(project)/OutflowStudio/downloads'; } }
  function renderStatus() {
    const s = $('#so-status');
    if (!CS.inCEP) { s.textContent = 'Downloads run inside Premiere Pro.'; return; }
    s.innerHTML = (exe() ? icon('check', 12) + ' Download engine ready' : 'Download engine fetched on first use (about 17 MB)') + ' · ' + (ffmpeg() ? icon('check', 12) + ' Video engine ready' : 'Video engine (about 90 MB) fetched on the first download');
  }
  function renderInfo() {
    const box = $('#so-info'); box.innerHTML = '';
    if (!info) return;
    const card = h('div', 'so-card');
    card.innerHTML = '<img src="' + (info.thumbnail || '') + '" alt=""><div class="so-meta"><b>' + (info.title || 'Untitled') + '</b><span>' + (info.uploader || info.channel || '') + (info.duration ? ' · ' + fmtDur(info.duration) : '') + '</span></div>';
    box.appendChild(card);
    box.appendChild(h('div', 'cat', 'Quality'));
    const list = h('div', 'so-opts');
    options.forEach((o, i) => {
      const r = h('button', 'so-opt' + (chosen === o ? ' on' : ''));
      r.innerHTML = '<span class="so-radio"></span><b>' + o.label + '</b><span class="so-codec">' + (o.audioOnly ? 'MP3' : 'MP4 · ' + o.codec) + (o.fps ? ' · ' + o.fps : '') + '</span><span class="so-size">' + (o.warn ? '<em title="Premiere cannot play this format. The panel turns it into H.264 straight after downloading and puts that on your timeline - there is nothing for you to do.">' + o.warn + '</em> ' : '') + (o.size ? '~ ' + fmtSize(o.size) : '') + '</span>';
      r.addEventListener('click', () => { chosen = o; st.lastQuality = o.height >= 2160 ? '4k' : o.height >= 1080 ? 'hd' : o.height ? 'sd' : 'audio'; save(); renderInfo(); });
      list.appendChild(r);
    });
    box.appendChild(list);
    const tracks = audioTracks(info);
    if (tracks.length > 1) {
      const r = h('div', 'row'); r.innerHTML = '<label>Audio track <span class="hint">' + tracks.length + ' languages</span></label><select class="sel"></select>';
      const sel = r.querySelector('select');
      for (const t of tracks) { const o = document.createElement('option'); o.value = t.lang; o.textContent = t.label; sel.appendChild(o); }
      sel.value = audioLang && tracks.some(t => t.lang === audioLang) ? audioLang : defaultLang(tracks, null);
      sel.addEventListener('change', () => { audioLang = sel.value; st.lastAudio = audioLang; save(); const keep = chosen && chosen.id; options = buildOptions(info, audioLang); chosen = options.find(o => o.id === keep) || options[0]; renderInfo(); });
      box.appendChild(r);
    }
    const subsList = subtitleOptions(info);
    if (subsList.length) {
      const r2 = h('div', 'row'); r2.innerHTML = '<label>Subtitles <span class="hint">added as a caption track</span></label><select class="sel"><option value="">None</option></select>';
      const sel2 = r2.querySelector('select');
      for (const s of subsList) { const o = document.createElement('option'); o.value = s.id; o.textContent = s.label; sel2.appendChild(o); }
      sel2.value = subLang && subsList.some(s => s.id === subLang) ? subLang : '';
      sel2.addEventListener('change', () => { subLang = sel2.value; st.lastSub = subLang; save(); });
      box.appendChild(r2);
    }
    /* ---- trim before downloading ---- */
    const dur = +info.duration || 0;
    if (dur > 3) {
      /* on by default, opening on the first 30 seconds: people come here for a piece of a video far
         more often than for the whole of it. Turning it off is remembered. */
      if (!trim || trim.dur !== dur) trim = { on: st.trimOff !== true, a: 0, b: Math.min(dur, 30), dur, chapters: chaptersOf(info) };
      const sw = h('div', 'row');
      sw.innerHTML = '<label>Only part of it <span class="hint">download just the piece you need</span></label><button class="switch' + (trim.on ? ' on' : '') + '" id="so-trim-sw"></button>';
      box.appendChild(sw);
      const panel = h('div', 'so-trim' + (trim.on ? ' on' : ''));
      panel.innerHTML =
        '<div class="so-strip" id="so-strip">' +
          '<canvas id="so-canvas" height="54"></canvas>' +
          '<div class="so-chaplines">' + trim.chapters.slice(1).map(c => '<i style="left:' + (c.s / dur * 100).toFixed(3) + '%"></i>').join('') + '</div>' +
          '<div class="so-win" id="so-win"><i class="l" data-h="a"></i><i class="r" data-h="b"></i></div>' +
        '</div>' +
        /* the chapter rail: a dot per chapter, click to select exactly that chapter */
        (trim.chapters.length ? '<div class="so-chaps" id="so-chaps">' + trim.chapters.map((c, i) => '<b style="left:' + (c.s / dur * 100).toFixed(3) + '%" data-ch="' + i + '" title="' + fmtDur(c.s) + ' · ' + String(c.t).replace(/"/g, '&quot;') + '"></b>').join('') + '</div>' : '') +
        /* outside the strip: the strip clips its own overflow, which is what keeps the window's dimming
           from covering the whole panel */
        '<div class="so-scrub" id="so-scrub"><canvas></canvas><span></span></div>' +
        '<div class="so-trim-foot"><span id="so-trim-at"><input class="so-tc" id="so-ta" title="Start, typed: 1:23 or 0:01:23" spellcheck="false"> → <input class="so-tc" id="so-tb" title="End, typed: 1:53 or 0:01:53" spellcheck="false"></span><span id="so-trim-len"></span></div>' +
        (trim.chapters.length ? '<div class="so-chap-name" id="so-chap-name"></div>' : '');
      box.appendChild(panel);
      panel.querySelectorAll('[data-ch]').forEach(b => b.addEventListener('click', (e) => {
        const c = trim.chapters[+b.dataset.ch]; if (!c) return;
        trim.a = c.s; trim.b = Math.max(c.s + 0.5, c.e); placeWin();
        try { Usage.tick('set:download:chapter'); } catch (e2) {}
      }));
      sw.querySelector('#so-trim-sw').addEventListener('click', () => { trim.on = !trim.on; st.trimOff = !trim.on; save(); sw.querySelector('#so-trim-sw').classList.toggle('on', trim.on); panel.classList.toggle('on', trim.on); dl.textContent = dlLabel(); if (trim.on) fillStrip(); });
      wireTrim(panel);
      /* typed times: m:ss, h:mm:ss or plain seconds; applied on Enter or when the field is left */
      const parseTc = (t) => { const p = String(t || '').trim().split(':').map((x) => parseFloat(x)); if (!p.length || p.some((x) => isNaN(x))) return null; return p.reduce((a, x) => a * 60 + x, 0); };
      const typed = (which) => { const el = $(which === 'a' ? '#so-ta' : '#so-tb'); const v = parseTc(el.value); if (v === null) { placeWin(); return; }
        if (which === 'a') trim.a = Math.max(0, Math.min(trim.dur - 0.1, v)); else trim.b = Math.max(0.1, Math.min(trim.dur, v));
        if (trim.b <= trim.a) { if (which === 'a') trim.b = Math.min(trim.dur, trim.a + 0.1); else trim.a = Math.max(0, trim.b - 0.1); }
        placeWin(); try { Usage.tick('set:download:typed'); } catch (e2) {} };
      for (const w of ['a', 'b']) { const el = $(w === 'a' ? '#so-ta' : '#so-tb'); el.addEventListener('change', () => typed(w)); el.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } e.stopPropagation(); }); }
      if (trim.on) fillStrip();
    } else trim = null;

    const dlLabel = () => 'Download' + (chosen ? ' ' + chosen.label : '') + (trim && trim.on ? ' · ' + fmtDur(trimLen()) : '');
    const dl = h('button', 'primary big', 'Download' + (chosen ? ' ' + chosen.label : ''));
    dl.textContent = dlLabel();
    dl.addEventListener('click', go);
    box.appendChild(dl);
  }
  /* the filmstrip is only fetched when the switch is turned on, and only once per video */
  let stripFor = '';
  async function fillStrip() {
    const cv = $('#so-canvas'); if (!cv || !info) return;
    const key = info.id || info.webpage_url || '';
    /*  Changing the quality re-renders the whole panel and throws the old canvas away. A brand new
        canvas is 300x150, so asking whether its width was > 10 answered "already drawn" and the strip
        stayed blank. Mark the ELEMENT: a new one carries no mark and gets drawn again.                */
    if (stripFor === key && cv.dataset.drawn === key) { placeWin(); return; }
    const sb = storyboard(info);
    /* the status goes on the right; the left holds the two typed times and stays as it is */
    const foot = $('#so-trim-len');
    if (!sb) { cv.width = 10; if (foot) foot.textContent = 'No preview frames for this site — drag the ends anyway.'; stripFor = key; cv.dataset.drawn = key; return; }
    if (foot) foot.textContent = 'Getting the preview frames…';
    try { await buildStrip(sb, +info.duration || 1, cv); stripFor = key; cv.dataset.drawn = key; } catch (e) {}
    placeWin();
  }
  function placeWin() {
    const strip = $('#so-strip'), win = $('#so-win');
    if (!strip || !win || !trim) return;
    const w = strip.clientWidth || 1;
    win.style.left = (trim.a / trim.dur) * w + 'px';
    win.style.width = Math.max(10, ((trim.b - trim.a) / trim.dur) * w) + 'px';
    const ta = $('#so-ta'), tb = $('#so-tb'), len = $('#so-trim-len');
    if (ta && document.activeElement !== ta) ta.value = fmtDur(trim.a);
    if (tb && document.activeElement !== tb) tb.value = fmtDur(trim.b);
    if (len) len.textContent = fmtDur(trimLen()) + ' of ' + fmtDur(trim.dur);
    const cn = $('#so-chap-name');
    if (cn && trim.chapters.length) {
      const ca = chapterAt(trim.a), cb = chapterAt(Math.max(trim.a, trim.b - 0.05));
      cn.textContent = ca ? (ca === cb || !cb ? ca.t : ca.t + ' → ' + cb.t) : '';
      document.querySelectorAll('#so-chaps [data-ch]').forEach(b => { const c = trim.chapters[+b.dataset.ch]; b.classList.toggle('on', !!c && c.s >= trim.a - 0.01 && c.s < trim.b); });
    }
    const btn = $('#so-info button.primary.big');
    if (btn && trim.on) btn.textContent = 'Download' + (chosen ? ' ' + chosen.label : '') + ' · ' + fmtDur(trimLen());
  }
  /*  Two handles and a middle that slides. The listeners live on window and are registered ONCE, below:
      re-registering them per render leaves old closures behind, still dragging a video that is no longer
      on screen (montage.js carries the same warning, for the same reason).                              */
  let tDrag = null;   /* { mode, t0, a, b } while the mouse is down */
  const stripTime = (e) => {
    const strip = $('#so-strip'); if (!strip || !trim) return 0;
    const r = strip.getBoundingClientRect();
    return Math.max(0, Math.min(1, (e.clientX - r.left) / (r.width || 1))) * trim.dur;
  };
  const startDrag = (e, mode) => { if (!trim) return; tDrag = { mode, t0: stripTime(e), a: trim.a, b: trim.b }; e.preventDefault(); e.stopPropagation(); };
  window.addEventListener('mousemove', (e) => {
    if (!tDrag || !trim) return;
    const d = stripTime(e) - tDrag.t0, MIN = 0.5, dur = trim.dur;
    if (tDrag.mode === 'a') trim.a = Math.max(0, Math.min(tDrag.b - MIN, snapTime(tDrag.a + d)));
    else if (tDrag.mode === 'b') trim.b = Math.min(dur, Math.max(tDrag.a + MIN, snapTime(tDrag.b + d)));
    else { const len = tDrag.b - tDrag.a; trim.a = Math.max(0, Math.min(dur - len, tDrag.a + d)); trim.b = trim.a + len; }
    placeWin();
    /* while dragging, the frame shown is the end being moved - the one you are deciding on */
    showMoment(tDrag.mode === 'b' ? trim.b : trim.a, null);
  });
  window.addEventListener('mouseup', () => { if (tDrag) hideMoment(); tDrag = null; });

  /*  Show the frame under the cursor. Also called while dragging a handle, because that is exactly when
      you most want to see the frame you are landing on.                                               */
  function showMoment(t, clientX) {
    const strip = $('#so-strip'), sc = $('#so-scrub');
    if (!strip || !sc || !trim) return;
    const cv = sc.querySelector('canvas'), lab = sc.querySelector('span');
    if (drawMoment(t, cv)) sc.classList.add('has');
    if (lab) { const c = chapterAt(t); lab.textContent = fmtDur(t) + (c ? ' · ' + c.t : ''); }
    const r = strip.getBoundingClientRect();
    const x = clientX == null ? r.left + (t / trim.dur) * r.width : clientX;
    const half = sc.offsetWidth / 2 || 80;
    sc.style.left = Math.max(half, Math.min(r.width - half, x - r.left)) + 'px';
    sc.classList.add('on');
  }
  const hideMoment = () => { const sc = $('#so-scrub'); if (sc) sc.classList.remove('on'); };

  function wireTrim(panel) {
    const strip = panel.querySelector('#so-strip'), win = panel.querySelector('#so-win');
    strip.addEventListener('mousemove', (e) => { if (!tDrag) showMoment(stripTime(e), e.clientX); });
    strip.addEventListener('mouseleave', () => { if (!tDrag) hideMoment(); });
    win.querySelector('.l').addEventListener('mousedown', (e) => startDrag(e, 'a'));
    win.querySelector('.r').addEventListener('mousedown', (e) => startDrag(e, 'b'));
    win.addEventListener('mousedown', (e) => startDrag(e, 'move'));
    /* clicking the strip outside the window moves the selection there, keeping its length */
    strip.addEventListener('mousedown', (e) => {
      if (win.contains(e.target)) return;
      const t = stripTime(e), len = trim.b - trim.a;
      trim.a = Math.max(0, Math.min(trim.dur - len, t - len / 2));
      trim.b = trim.a + len;
      placeWin();
      startDrag(e, 'move');
    });
    setTimeout(placeWin, 0);
  }

  const saveHistory = () => { try { localStorage.setItem('os.social.history', JSON.stringify(history)); } catch (e) {} };
  const escH = (s) => String(s || '').replace(/[<>&"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[c]));
  const tc = (s) => { s = Math.max(0, Math.round(s)); const m = Math.floor(s / 60), r = s % 60; return (m >= 60 ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : m) + ':' + String(r).padStart(2, '0'); };
  /* what an entry was: quality, the trimmed part, the language, subtitles - so two trims of one video tell apart */
  const describe = (it) => [it.quality, it.section ? 'Trim ' + tc(it.section.a) + ' – ' + tc(it.section.b) : '', it.lang ? langName(it.lang) : '', it.sub ? 'Subs: ' + it.sub : ''].filter(Boolean).join(' · ');
  const ago = (t) => { const d = (Date.now() - t) / 60000; return d < 1 ? 'just now' : d < 60 ? Math.round(d) + ' min ago' : d < 1440 ? Math.round(d / 60) + ' h ago' : Math.round(d / 1440) + ' d ago'; };
  function renderHistory() {
    const box = $('#so-history'); box.innerHTML = '';
    if (!history.length) { box.appendChild(h('div', 'kbd', 'Nothing downloaded yet.')); return; }
    for (const it of history.slice(0, 12)) {
      const r = h('div', 'so-hist');
      r.innerHTML = '<div class="so-thumb">' + (it.thumb && CS.fs && CS.fs.existsSync(it.thumb) ? '<img src="' + CS.fileURL(it.thumb) + '">' : icon(it.kind === 'audio' ? 'audio' : 'stock', 18)) + '</div><div class="so-meta"><b>' + escH(it.title || it.name || it.url) + '</b><span>' + escH(describe(it)) + '</span><span class="so-when">' + escH(ago(it.t || 0)) + ' · ' + escH(it.url.slice(0, 50)) + '</span></div>';
      const b = h('button', 'ghost', 'Place'); b.title = 'Place again at the playhead';
      b.addEventListener('click', () => busy('Placing', async () => { if (!CS.fs.existsSync(it.file)) throw new Error('File no longer exists.'); const snd = it.kind === 'video' ? await hasAudioStream(it.file) : false; const rr = await CS.call('OS_importMedia', it.file, 'Outflow Downloads', true, it.kind, snd); if (!rr.ok) throw new Error(rr.error); toast('Placed on ' + rr.track + '.', 'ok'); }));
      r.appendChild(b);
      /* remove from the list (the file stays); an Undo takes its place for a few seconds */
      const x = h('button', 'ghost so-x', '✕'); x.title = 'Remove from this list. The file stays where it is.';
      x.addEventListener('click', () => {
        const at = history.indexOf(it); if (at < 0) return;
        history.splice(at, 1); saveHistory();
        const u = h('div', 'so-hist so-undo'); u.innerHTML = '<span>Removed from the list.</span>';
        const ub = h('button', 'ghost', 'Undo'); ub.addEventListener('click', () => { history.splice(Math.min(at, history.length), 0, it); saveHistory(); renderHistory(); });
        u.appendChild(ub); r.replaceWith(u);
        setTimeout(() => { if (u.parentNode) u.remove(); if (!history.length) renderHistory(); }, 8000);
      });
      r.appendChild(x);
      box.appendChild(r);
    }
  }
  async function fetchStep() {
    const url = $('#so-url').value.trim();
    if (!/^https?:\/\//i.test(url)) { toast('Paste a link first.', 'err'); return; }
    if (!CS.inCEP) { toast('Downloads run inside Premiere Pro.'); return; }
    await busy('Fetching', async (pr) => {
      info = await fetchInfo(url, pr);
      info.__url = url;
      audioLang = defaultLang(audioTracks(info), st.lastAudio || null) || null;
      subLang = st.lastSub || '';
      options = buildOptions(info, audioLang);
      if (!options.length) throw new Error('No downloadable formats found for this link.');
      const pref = st.lastQuality;
      chosen = options.find(o => (pref === '4k' && o.height >= 2160) || (pref === 'hd' && o.height === 1080) || (pref === 'sd' && o.height === 720) || (pref === 'audio' && o.audioOnly)) || options.find(o => o.height <= 1080 && !o.audioOnly) || options[0];
      renderInfo();
    });
  }
  async function go() {
    if (!info || !chosen) return;
    /* three free downloads an account, counted on the server; Pro is unlimited */
    if (typeof License !== 'undefined' && !await License.guardExport('social', 'download')) return;
    const url = info.__url;
    await busy('Downloading ' + chosen.label + (trim && trim.on ? ' · ' + fmtDur(trimLen()) : ''), async (pr) => {
      const subsList = subtitleOptions(info);
      const tracks = audioTracks(info);
      const subOpt = Object.assign({}, chosen, {
        lang: audioLang && tracks.some(t => t.lang === audioLang) ? audioLang : (tracks[0] ? tracks[0].lang : ''),
        multiAudio: tracks.length > 1,
        sub: subsList.find(s => s.id === subLang) || null,
        section: trim && trim.on && trimLen() < trim.dur - 0.2 ? { a: trim.a, b: trim.b } : null,
      });
      const r = await download(url, subOpt, pr);
      const kind = chosen.audioOnly || /\.(mp3|m4a|wav|aac|opus)$/i.test(r.file) ? 'audio' : 'video';
      let converted = '';
      if (kind === 'video') { const pi = await probe(r.file); if (NEEDS_CONVERT.test(pi.codec)) { r.file = await convertToH264(r.file, pr); converted = ' Converted from ' + pi.codec.toUpperCase() + ' to H.264.'; } }
      let withSound = kind === 'video' ? await hasAudioStream(r.file) : false;
      if (kind === 'video' && st.noAudio && withSound) { pr(0.985, 'Taking the sound out'); r.file = await stripAudio(r.file); withSound = false; }
      pr(0.99, 'Importing into Premiere');
      const imp = await CS.call('OS_importMedia', r.file, 'Outflow Downloads', st.place, kind, withSound);
      if (!imp.ok) throw new Error(imp.error);
      let subNote = '';
      if (subOpt.sub && !r.subs) subNote = ' Subtitles were not available for this language.';
      else if (r.subs && imp.placed) {
        const cr = await CS.call('TL_captionsFromSRT', r.subs, imp.start || 0);
        subNote = cr.ok ? ' Subtitles added as a caption track.' : ' Subtitles saved next to the file (' + (cr.error || 'caption track failed') + ').';
      } else if (r.subs) {
        try { await CS.call('OS_importMedia', r.subs, 'Outflow Downloads', false, 'captions'); subNote = ' Subtitles imported into the bin.'; } catch (e) { subNote = ' Subtitles saved next to the file.'; }
      }
      /*  One entry per video AND what was done with it: the same video trimmed the same way with the same
          settings replaces its older entry (moved to the top); a different trim or language is new.    */
      const entry = { url, file: r.file, thumb: r.thumb, kind, title: info.title, quality: chosen.label + (chosen.audioOnly ? '' : ' ' + chosen.codec) + (kind === 'video' && !withSound ? ' · no audio' : ''), section: subOpt.section ? { a: subOpt.section.a, b: subOpt.section.b } : null, lang: subOpt.multiAudio ? subOpt.lang : '', sub: subOpt.sub ? subOpt.sub.label : '', t: Date.now() };
      const keyOf = (e) => [(e.url || '').replace(/[?&](si|feature|t|utm_[a-z]+)=[^&]*/g, ''), e.quality, e.section ? e.section.a.toFixed(2) + '-' + e.section.b.toFixed(2) : '', e.lang || '', e.sub || ''].join('|');
      const k = keyOf(entry);
      history = history.filter((e) => keyOf(e) !== k && e.file !== r.file);
      history.unshift(entry); history = history.slice(0, 30);
      saveHistory();
      renderHistory();
      try { License.noteExport('social'); } catch (e) {}
      try { Usage.tick('download'); } catch (e) {}
      toast((imp.placed ? 'Placed on ' + imp.track + ' at the playhead.' : 'Imported into Outflow › Downloads.') + converted + subNote, 'ok');
    });
  }
  function init() {
    $('#so-go').addEventListener('click', fetchStep);
    window.addEventListener('focus', () => setTimeout(autoFromClipboard, 80));
    $('#so-url').addEventListener('keydown', (e) => { if (e.key === 'Enter') fetchStep(); });
    let lastAuto = '';
    $('#so-url').addEventListener('input', () => { const u = $('#so-url').value.trim(); if (/^https?:\/\/\S+$/i.test(u) && u !== lastAuto) { lastAuto = u; fetchStep(); } });
    const pl = $('#so-place'); pl.classList.toggle('on', st.place); pl.addEventListener('click', () => { st.place = !st.place; pl.classList.toggle('on', st.place); save(); });
    const na = $('#so-noaudio'); na.classList.toggle('on', !!st.noAudio); na.addEventListener('click', () => { st.noAudio = !st.noAudio; na.classList.toggle('on', st.noAudio); save(); });
    $('#so-update').addEventListener('click', () => busy('Updating the download engine', async (pr) => { await ensureYtDlp(pr); await run(['-U'], (l) => pr(0.5, l.slice(0, 80))); renderStatus(); toast('The download engine is up to date.', 'ok'); }));
    $('#so-dirbtn').addEventListener('click', () => { const p = CS.pickFolder('Download folder'); if (p) { Hub.keys().downloadDir = p; Hub.saveKeys(); renderDir(); } else if (!CS.inCEP) toast('Only inside Premiere Pro.'); });
    $('#so-paste').addEventListener('click', async () => {
      let t = '';
      try { if (CS.inCEP && cp) t = CS.clipboardText(); else t = await navigator.clipboard.readText(); } catch (e) {}
      t = (t || '').trim();
      if (t) { $('#so-url').value = t; fetchStep(); } else toast('Clipboard has no text. Use Ctrl+V in the field.');
    });
  }
  /* for the Engines section in Settings */
  const safe = (fn) => { try { return !!fn(); } catch (e) { return false; } };
  const engines = () => [
    { id: 'ffmpeg', name: 'Video engine', size: '90 MB', uses: 'Download media, 3D Carousel export, Auto Edit, Remove music', ready: safe(ffmpeg), install: installFfmpeg },
    { id: 'ytdlp', name: 'Download engine', size: '17 MB', uses: 'Download media', ready: safe(exe), install: ensureYtDlp },
    { id: 'deno', name: 'YouTube helper', size: '40 MB', uses: 'Download media (YouTube)', ready: safe(deno), install: installDeno }
  ];
  try { setTimeout(trimFfmpeg, 4000); } catch (e) {}
  /* for the browser preview only: show a saved -J result as if it had just been fetched */
  function preview(d) { if (CS.inCEP) return; info = d; options = [{ id: 'p', label: '1080p', height: 1080, codec: 'h264', fmt: 'best' }]; chosen = options[0]; trim = null; open(); renderInfo(); }
  return { open, init, download, ffmpeg, exe, installFfmpeg, engines, preview, trim: () => trim };
})();
