/* Quick FX wheel: saved effect presets (with parameter values) on a radial menu,
   plus a search box in the centre for presets and every Premiere effect.
   Opens with a shortcut (default Ctrl+Alt+X, panel focused) or the round button. */
const QuickFX = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const COLORS = ['#4f8dff', '#ffb547', '#3ad29f', '#ff6a4d', '#c53fd0', '#19b3a6', '#ff3b6b', '#9cc4ff'];
  const DEFAULT_PRESETS = [
    { id: 'blur', name: 'Blur', color: '#4f8dff', target: 'selected', effects: [{ name: 'Gaussian Blur', params: [{ i: 0, name: 'Blurriness', value: 30 }, { i: 2, name: 'Repeat Edge Pixels', value: true }] }] },
    { id: 'zoom', name: 'Zoom 115%', color: '#ffb547', target: 'adjustment', effects: [{ name: 'Motion', params: [{ i: 1, name: 'Scale', value: 115 }] }] },
    { id: 'bw', name: 'Black & White', color: '#aab2c5', target: 'selected', effects: [{ name: 'Black & White', params: [] }] },
    { id: 'sharpen', name: 'Sharpen', color: '#3ad29f', target: 'selected', effects: [{ name: 'Sharpen', params: [{ i: 0, name: 'Sharpen Amount', value: 40 }] }] },
    { id: 'flip', name: 'Flip H', color: '#c53fd0', target: 'selected', effects: [{ name: 'Horizontal Flip', params: [] }] },
    { id: 'dim', name: 'Opacity 60%', color: '#ff6a4d', target: 'selected', effects: [{ name: 'Opacity', params: [{ i: 0, name: 'Opacity', value: 60 }] }] }
  ];
  /* current (non-obsolete) Premiere video effects */
  const COMMON_EFFECTS = ['Gaussian Blur', 'Directional Blur', 'Camera Blur', 'Compound Blur', 'Channel Blur', 'Sharpen', 'Unsharp Mask', 'Black & White', 'Tint', 'Brightness & Contrast', 'Lumetri Color', 'Color Balance', 'Color Balance (HLS)', 'Color Pass', 'Color Replace', 'Change Color', 'Change to Color', 'Channel Mixer', 'Equalize', 'Invert', 'Posterize', 'Mosaic', 'Noise', 'Dust & Scratches', 'Median', 'Crop', 'Transform', 'Corner Pin', 'Mirror', 'Horizontal Flip', 'Vertical Flip', 'Lens Distortion', 'Rolling Shutter Repair', 'Warp Stabilizer', 'Drop Shadow', 'Bevel Alpha', 'Bevel Edges', 'Edge Feather', 'Roughen Edges', 'Track Matte Key', 'Ultra Key', 'Luma Key', 'Color Key', 'Difference Matte', 'Image Matte Key', 'Alpha Adjust', 'Timecode', 'Clip Name', 'Simple Text', 'Magnify', 'Twirl', 'Wave Warp', 'Turbulent Displace', 'Offset', 'Replicate', 'Spherize', 'Gamma Correction', 'Levels', 'Shadow/Highlight', 'Extract', 'Solarize', 'Strobe Light', 'Echo', 'Posterize Time', 'Lightning', 'Lens Flare', 'Ramp', '4-Color Gradient', 'Cell Pattern', 'Checkerboard', 'Circle', 'Ellipse', 'Eyedropper Fill', 'Grid', 'Write-on', 'Threshold', 'Emboss', 'Find Edges', 'Color Emboss', 'Video Limiter', 'SDR Conform', 'Set Matte', 'Remove Matte', 'Morph Cut', 'Feather Edges', 'VR Blur', 'VR Chromatic Aberrations', 'VR Glow', 'VR Sharpen', 'VR Rotate Sphere', 'VR Plane to Sphere', 'VR Digital Glitch', 'VR Fractal Noise', 'ProcAmp', 'Reduce Interlace Flicker', 'Cineon Converter'];
  /* legacy / obsolete effects Premiere still lists but should not be suggested */
  const LEGACY = /obsolete|legacy|^basic 3d$|^camera view$|^convolution kernel$|^lighting effects$|^auto (color|contrast|levels)$|^three-way color corrector$|^fast color corrector$|^rgb curves$|^luma curve$|^luma corrector$|^rgb color corrector$|^leave color$|^fast blur$|^tint \(|^video limiter \(|^brightness & contrast \(|^shadow\/highlight \(|^channel blur \(|^compound blur \(|^spherize \(|^solarize \(|^find edges \(|^color balance \(rgb\)|^gamma correction \(|^levels \(|^alpha glow$|^replicate \(|^clip name \(|^timecode \(|^lens distortion \(|^chroma key$|^rgb difference key$|^blue screen key$|^non red key$|^remove matte \(|^bevel alpha \(|^drop shadow \(|^bend$|^wave warp \(|^twirl \(/i;
  const notLegacy = (n) => !LEGACY.test(String(n).trim());
  let presets = null, settings = { enabled: true, fab: true, key: 'x', ctrl: true, alt: true, shift: false, duration: 5 };
  try { presets = JSON.parse(localStorage.getItem('os.qfx.presets') || 'null'); } catch (e) {}
  try { Object.assign(settings, JSON.parse(localStorage.getItem('os.qfx.settings') || '{}')); } catch (e) {}
  if (settings.key === ' ' && settings.ctrl && !settings.alt) { settings.key = 'x'; settings.alt = true; }   /* old default clashed with Premiere playback */
  if (!presets) presets = JSON.parse(JSON.stringify(DEFAULT_PRESETS));
  let effectList = null;
  const save = () => { try { localStorage.setItem('os.qfx.presets', JSON.stringify(presets)); localStorage.setItem('os.qfx.settings', JSON.stringify(settings)); } catch (e) {} syncFab(); registerKeys(); };
  const keyName = () => (settings.ctrl ? (CS.mac ? '⌘' : 'Ctrl+') : '') + (settings.alt ? (CS.mac ? '⌥' : 'Alt+') : '') + (settings.shift ? 'Shift+' : '') + (settings.key === ' ' ? 'Space' : settings.key.length === 1 ? settings.key.toUpperCase() : settings.key);

  /* ------------------------------------------------------------ wheel */
  let open = false;
  function polar(cx, cy, r, a) { return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; }
  function segPath(cx, cy, r0, r1, a0, a1) {
    const [x0, y0] = polar(cx, cy, r1, a0), [x1, y1] = polar(cx, cy, r1, a1), [x2, y2] = polar(cx, cy, r0, a1), [x3, y3] = polar(cx, cy, r0, a0);
    const large = a1 - a0 > Math.PI ? 1 : 0;
    return 'M' + x0 + ' ' + y0 + ' A' + r1 + ' ' + r1 + ' 0 ' + large + ' 1 ' + x1 + ' ' + y1 + ' L' + x2 + ' ' + y2 + ' A' + r0 + ' ' + r0 + ' 0 ' + large + ' 0 ' + x3 + ' ' + y3 + ' Z';
  }
  function renderWheel() {
    const box = $('#qfx-wheel'); box.innerHTML = '';
    const n = Math.max(1, presets.length), S = 340, c = S / 2, r0 = 66, r1 = 160, gap = 0.03;
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '-40 -40 ' + (S + 80) + ' ' + (S + 80));   /* room for the glow */
    svg.style.overflow = 'visible';
    /* defs: neon gradient per segment + glow filters + outer ring */
    const defs = document.createElementNS(NS, 'defs');
    const mkGrad = (id, col) => {
      const gr = document.createElementNS(NS, 'radialGradient');
      gr.setAttribute('id', id); gr.setAttribute('cx', '50%'); gr.setAttribute('cy', '50%'); gr.setAttribute('r', '50%');
      const s1 = document.createElementNS(NS, 'stop'); s1.setAttribute('offset', '35%'); s1.setAttribute('stop-color', col); s1.setAttribute('stop-opacity', '0.8');
      const s2 = document.createElementNS(NS, 'stop'); s2.setAttribute('offset', '100%'); s2.setAttribute('stop-color', col); s2.setAttribute('stop-opacity', '1');
      gr.append(s1, s2); defs.appendChild(gr);
    };
    const flt = document.createElementNS(NS, 'filter'); flt.setAttribute('id', 'qglow'); flt.setAttribute('x', '-40%'); flt.setAttribute('y', '-40%'); flt.setAttribute('width', '180%'); flt.setAttribute('height', '180%');
    flt.innerHTML = '<feGaussianBlur stdDeviation="6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>';
    defs.appendChild(flt);
    svg.appendChild(defs);
    const ring = document.createElementNS(NS, 'circle');
    ring.setAttribute('cx', c); ring.setAttribute('cy', c); ring.setAttribute('r', r1 + 8); ring.setAttribute('class', 'qring');
    svg.appendChild(ring);
    const info = $('#qfx-info');
    const setInfo = (html) => { info.innerHTML = html; };
    presets.forEach((p, i) => {
      const a0 = -Math.PI / 2 + i * 2 * Math.PI / n + gap, a1 = -Math.PI / 2 + (i + 1) * 2 * Math.PI / n - gap;
      const col = p.color || COLORS[i % COLORS.length];
      mkGrad('qg' + i, col);
      const g = document.createElementNS(NS, 'g');
      g.setAttribute('class', 'qseg');
      g.style.animationDelay = (i * 40) + 'ms';
      const path = document.createElementNS(NS, 'path');
      path.setAttribute('d', segPath(c, c, r0, r1, a0, a1));
      path.setAttribute('fill', 'url(#qg' + i + ')');
      path.setAttribute('stroke', col);
      path.setAttribute('class', 'seg');
      path.style.setProperty('--seg', col);
      const mid = (a0 + a1) / 2, [tx, ty] = polar(c, c, (r0 + r1) / 2 + 4, mid);
      const t = document.createElementNS(NS, 'text');
      t.setAttribute('x', tx); t.setAttribute('y', ty); t.setAttribute('class', 'seglbl' + (n > 8 ? ' small' : ''));
      t.style.setProperty('--seg', col);
      const words = String(p.name).split(' ');
      const lines = words.length > 1 && p.name.length > 9 ? [words.slice(0, Math.ceil(words.length / 2)).join(' '), words.slice(Math.ceil(words.length / 2)).join(' ')] : [p.name];
      lines.forEach((ln, li) => { const ts = document.createElementNS('http://www.w3.org/2000/svg', 'tspan'); ts.setAttribute('x', tx); ts.setAttribute('dy', li === 0 ? (lines.length > 1 ? '-0.45em' : '0') : '1.1em'); ts.textContent = ln; t.appendChild(ts); });
      const k = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      const [kx, ky] = polar(c, c, r1 - 14, mid);
      k.setAttribute('x', kx); k.setAttribute('y', ky); k.setAttribute('class', 'segkey'); k.textContent = i + 1;
      g.append(path, t, k);
      g.addEventListener('mouseenter', () => setInfo('<b>' + p.name + '</b> ' + p.effects.map(e => e.name).join(' · ') + ' → ' + (p.target === 'adjustment' ? 'adjustment layer' : 'selected clips')));
      g.addEventListener('mouseleave', () => setInfo(''));
      g.addEventListener('click', () => apply(p));
      svg.appendChild(g);
    });
    box.appendChild(svg);
    setInfo('');
  }
  function show() {
    if (!settings.enabled && !pinned) return;
    renderWheel();
    $('#qfx-overlay').classList.add('show'); open = true;
    const inp = $('#qfx-search'); inp.value = ''; renderResults(''); setTimeout(() => inp.focus(), 30);
    $('#qfx-wheel').classList.remove('dim');
    if (!effectList && CS.inCEP) CS.call('QF_effectList').then(r => { if (r.ok && r.effects.length) effectList = r.effects.filter(notLegacy); });
  }
  /* pinned = the floating window: the wheel is the whole window and never hides, a close just clears the search */
  let pinned = false;
  function hide() {
    if (pinned) { const inp = $('#qfx-search'); if (inp) { inp.value = ''; renderResults(''); } $('#qfx-wheel').classList.remove('dim'); return; }
    $('#qfx-overlay').classList.remove('show'); open = false;
  }
  /* re-read presets and settings from storage (the floating window does this when the panel saved new ones) */
  function reload() {
    try { const p = JSON.parse(localStorage.getItem('os.qfx.presets') || 'null'); if (p) presets = p; } catch (e) {}
    try { Object.assign(settings, JSON.parse(localStorage.getItem('os.qfx.settings') || '{}')); } catch (e) {}
    registerKeys();
  }
  function toggle() { open ? hide() : show(); }

  /* search: presets first, then every Premiere effect (applied with default settings).
     Matches on any part of the name; words in any order ("blur gauss" finds Gaussian Blur). */
  function score(name, q) {
    const n = name.toLowerCase(), terms = q.split(/\s+/).filter(Boolean);
    if (!terms.every(t => n.includes(t))) return -1;
    let s = 0;
    if (n.startsWith(q)) s += 30;
    if (n.split(/\s+/).some(w => w.startsWith(terms[0]))) s += 15;
    s += Math.max(0, 20 - n.length / 2);
    return s;
  }
  function highlight(name, q) {
    let out = name;
    for (const t of q.split(/\s+/).filter(Boolean)) out = out.replace(new RegExp('(' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig'), '$1');
    return out.replace(/</g, '&lt;').replace(//g, '<mark>').replace(//g, '</mark>');
  }
  function matchesOf(q) {
    q = q.trim().toLowerCase();
    if (!q) return [];
    const out = [];
    for (const p of presets) { const s = Math.max(score(p.name, q), ...p.effects.map(e => score(e.name, q) - 5)); if (s >= 0) out.push({ kind: 'preset', p, label: p.name, sub: p.effects.map(e => e.name).join(' · ') + ' → ' + (p.target === 'adjustment' ? 'adjustment layer' : 'selected'), s: s + 10, color: p.color }); }
    const names = (effectList || COMMON_EFFECTS).filter(notLegacy);
    const seen = new Set();
    for (const n of names) { if (seen.has(n)) continue; seen.add(n); const s = score(n, q); if (s >= 0) out.push({ kind: 'effect', name: n, label: n, sub: 'Premiere effect · default settings → selected clips', s }); }
    out.sort((a, b) => b.s - a.s);
    return out.slice(0, 40);
  }
  let results = [], selIdx = 0;
  function renderResults(q) {
    results = matchesOf(q); selIdx = 0;
    const box = $('#qfx-results'); box.innerHTML = '';
    const wheel = $('#qfx-wheel');
    if (!results.length) { box.style.display = 'none'; wheel.classList.remove('dim'); $('#qfx-info').textContent = q.trim() ? 'No effect or preset matches "' + q + '"' : ''; return; }
    wheel.classList.add('dim');
    $('#qfx-info').textContent = '';
    let lastKind = '';
    results.forEach((r, i) => {
      if (r.kind !== lastKind) { box.appendChild(h('div', 'qhead', r.kind === 'preset' ? 'Your presets' : 'Premiere effects')); lastKind = r.kind; }
      const b = h('button', 'qres' + (i === selIdx ? ' on' : ''));
      b.innerHTML = '<span class="qdot" style="background:' + (r.color || '#4f8dff') + '">' + (r.kind === 'preset' ? icon('quickfx', 12) : icon('visual', 12)) + '</span><span class="qtxt"><b>' + highlight(r.label, q.trim().toLowerCase()) + '</b><span>' + r.sub + '</span></span><span class="qkey">' + (i === selIdx ? 'Enter ↵' : '') + '</span>';
      b.addEventListener('mouseenter', () => setSel(i));
      b.addEventListener('click', () => pick(r));
      box.appendChild(b);
    });
    box.style.display = 'block';
  }
  function setSel(i) {
    selIdx = i;
    document.querySelectorAll('.qres').forEach((b, k) => { b.classList.toggle('on', k === i); const kk = b.querySelector('.qkey'); if (kk) kk.textContent = k === i ? 'Enter ↵' : ''; });
    const on = document.querySelector('.qres.on'); if (on) on.scrollIntoView({ block: 'nearest' });
  }
  function pick(r) {
    if (r.kind === 'preset') return apply(r.p);
    apply({ name: r.name, target: 'selected', effects: [{ name: r.name, params: [] }] });
  }

  async function apply(p) {
    hide();
    if (!CS.inCEP) { toast('Quick FX applies effects inside Premiere Pro only.'); return; }
    toast('Applying ' + p.name + '…');
    const template = CS.extensionPath().replace(/\\/g, '/') + '/client/assets/adjustment-layer.prproj';
    const r = await CS.call('QF_apply', JSON.stringify({ name: p.name, target: p.target, effects: p.effects, duration: settings.duration, template }));
    if (!r.ok) { toast(r.error, 'err'); return; }
    try { Usage.tick('quickfx'); } catch (e) {}
    toast(p.name + ' applied to ' + r.applied + ' clip(s).' + (r.warnings.length ? ' ' + r.warnings[0] : ''), r.warnings.length ? 'err' : 'ok');
  }

  /* --------------------------------------------------------- shortcut */
  function matches(e) {
    if (!settings.enabled) return false;
    const k = e.key === ' ' ? ' ' : e.key.length === 1 ? e.key.toLowerCase() : e.key;
    const want = settings.key === ' ' ? ' ' : settings.key.length === 1 ? settings.key.toLowerCase() : settings.key;
    const mod = CS.mac ? (e.metaKey || e.ctrlKey) : e.ctrlKey;   /* the Ctrl of the shortcut is Cmd on a Mac */
    return k === want && !!mod === !!settings.ctrl && !!e.altKey === !!settings.alt && !!e.shiftKey === !!settings.shift;
  }
  let capture = null;
  document.addEventListener('keydown', (e) => {
    if (typeof Race !== 'undefined' && Race.active()) return;   /* the game owns the keyboard while it is up */
    if (capture) { e.preventDefault(); if (['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) return; settings.key = e.key; settings.ctrl = e.ctrlKey || (CS.mac && e.metaKey); settings.alt = e.altKey; settings.shift = e.shiftKey; const cb = capture; capture = null; save(); cb(); return; }
    if (open) {
      if (e.key === 'Escape') { hide(); return; }
      const inSearch = e.target && e.target.id === 'qfx-search';
      if (e.key === 'Enter') { e.preventDefault(); if (results.length) pick(results[selIdx]); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!results.length) return; setSel((selIdx + (e.key === 'ArrowDown' ? 1 : results.length - 1)) % results.length); return; }
      const d = parseInt(e.key, 10);
      if (!inSearch || !$('#qfx-search').value) { if (d >= 1 && d <= presets.length && !e.ctrlKey && !e.altKey) { e.preventDefault(); apply(presets[d - 1]); return; } }
    }
    if (matches(e)) { e.preventDefault(); toggle(); }
  });
  function registerKeys() {
    try {
      if (!window.__adobe_cep__) return;
      const code = settings.key === ' ' ? 32 : settings.key.length === 1 ? settings.key.toUpperCase().charCodeAt(0) : 0;
      const list = settings.enabled && code ? [CS.mac ? { keyCode: code, metaKey: !!settings.ctrl, altKey: !!settings.alt, shiftKey: !!settings.shift } : { keyCode: code, ctrlKey: !!settings.ctrl, altKey: !!settings.alt, shiftKey: !!settings.shift }] : [];
      window.__adobe_cep__.registerKeyEventsInterest(JSON.stringify(list));
    } catch (e) {}
  }
  function syncFab() { const f = $('#qfx-fab'); if (f) f.style.display = (settings.enabled && settings.fab && !pinned) ? '' : 'none'; }

  /* ---------------------------------------------------------- manager */
  function manager() {
    const body = $('#qfx-body'); body.innerHTML = '';
    const row = (label, ctrl, hint) => { const r = h('div', 'row'); const l = h('label', '', label); if (hint) l.innerHTML += ' <span class="hint">' + hint + '</span>'; r.append(l, ctrl); return r; };
    const sw = (v, fn) => { const b = h('button', 'switch' + (v ? ' on' : '')); b.addEventListener('click', () => { const on = !b.classList.contains('on'); b.classList.toggle('on', on); fn(on); }); return b; };
    const sec = (t) => { const s = h('div', 'section'); s.appendChild(h('h4', '', t)); return s; };
    const shortcutBtn = h('button', 'ghost', keyName());
    shortcutBtn.addEventListener('click', () => { shortcutBtn.textContent = 'press keys…'; capture = () => { shortcutBtn.textContent = keyName(); }; });
    const num = h('input'); num.type = 'number'; num.min = 1; num.max = 60; num.step = 0.5; num.value = settings.duration;
    num.addEventListener('change', () => { settings.duration = parseFloat(num.value) || 5; save(); });
    body.append(sec('Wheel'),
      row('Enabled', sw(settings.enabled, v => { settings.enabled = v; save(); })),
      row('Shortcut', shortcutBtn, 'Ctrl+Alt+X is free in Premiere\'s defaults; works while the panel has focus'),
      row('Floating round button', sw(settings.fab, v => { settings.fab = v; save(); })),
      row('Adjustment layer length', num, 'seconds, when nothing is selected'),
      h('div', 'kbd', 'Presets apply to the selected clips, or land on a new adjustment layer above them. Premiere cannot create adjustment layers by script: if the project has none, the preset is applied to the selection instead (create one via File › New › Adjustment Layer once to unlock the layer mode).'),
      sec('Presets'));
    const list = h('div', 'alist');
    presets.forEach((p, i) => {
      const card = h('div', 'qcard');
      const head = h('div', 'inline');
      const name = h('input'); name.type = 'text'; name.value = p.name; name.className = 'qname'; name.addEventListener('change', () => { p.name = name.value; save(); });
      const col = h('input'); col.type = 'color'; col.value = p.color || COLORS[i % 8]; col.addEventListener('input', () => { p.color = col.value; save(); });
      const tgt = h('select', 'sel'); for (const [k, n] of [['selected', 'Selected clips'], ['adjustment', 'Adjustment layer']]) { const o = h('option'); o.value = k; o.textContent = n; tgt.appendChild(o); } tgt.value = p.target; tgt.addEventListener('change', () => { p.target = tgt.value; save(); });
      const del = h('button', 'ghost', '✕'); del.title = 'Delete'; del.addEventListener('click', () => { presets.splice(i, 1); save(); manager(); });
      const up = h('button', 'ghost', '↑'); up.addEventListener('click', () => { if (i > 0) { presets.splice(i - 1, 0, presets.splice(i, 1)[0]); save(); manager(); } });
      const test = h('button', 'primary', 'Apply'); test.addEventListener('click', () => apply(p));
      head.append(col, name, tgt, up, del, test);
      card.appendChild(head);
      for (const fx of p.effects) {
        const fxRow = h('div', 'qfx');
        fxRow.appendChild(h('b', '', fx.name));
        for (const pa of fx.params) {
          const w = h('label', 'qparam', (pa.name || ('#' + pa.i)) + ' ');
          let inp;
          if (typeof pa.value === 'boolean') { inp = h('input'); inp.type = 'checkbox'; inp.checked = pa.value; inp.addEventListener('change', () => { pa.value = inp.checked; save(); }); }
          else if (Array.isArray(pa.value)) { inp = h('input'); inp.type = 'text'; inp.value = pa.value.join(', '); inp.addEventListener('change', () => { pa.value = inp.value.split(',').map(x => parseFloat(x) || 0); save(); }); }
          else { inp = h('input'); inp.type = 'number'; inp.step = 'any'; inp.value = pa.value; inp.addEventListener('change', () => { pa.value = parseFloat(inp.value) || 0; save(); }); }
          w.appendChild(inp); fxRow.appendChild(w);
        }
        card.appendChild(fxRow);
      }
      list.appendChild(card);
    });
    body.appendChild(list);
    const addSel = h('button', 'primary', '＋ Save effects of selected clip as preset');
    addSel.addEventListener('click', addFromSelection);
    const addBlank = h('button', 'ghost', '＋ Blank preset (effect by name)');
    addBlank.addEventListener('click', () => {
      const name = prompt('Effect name exactly as in Premiere (e.g. Gaussian Blur)'); if (!name) return;
      presets.push({ id: 'p' + Date.now().toString(36), name: name, color: COLORS[presets.length % 8], target: 'selected', effects: [{ name, params: [] }] });
      save(); manager();
    });
    const reset = h('button', 'ghost', 'Restore defaults');
    reset.addEventListener('click', () => { presets = JSON.parse(JSON.stringify(DEFAULT_PRESETS)); save(); manager(); });
    const actions = h('div', 'inline'); actions.append(addSel, addBlank, reset);
    body.appendChild(actions);
  }
  async function addFromSelection() {
    if (!CS.inCEP) { toast('Only inside Premiere Pro.'); return; }
    const r = await CS.call('QF_readSelection');
    if (!r.ok) { toast(r.error, 'err'); return; }
    const body = $('#qfx-body'); body.innerHTML = '';
    body.appendChild(h('div', 'kbd', 'Effects on "' + r.clip + '". Tick what the preset should apply, then save.'));
    const picks = [];
    for (const c of r.components) {
      if (c.name === 'Time Remapping') continue;
      const card = h('div', 'qcard');
      const cb = h('input'); cb.type = 'checkbox'; cb.checked = !(c.name === 'Motion' || c.name === 'Opacity');
      const head = h('label', 'inline'); head.append(cb, h('b', '', c.name));
      card.appendChild(head);
      card.appendChild(h('div', 'kbd', c.props.filter(p => p.ok).map(p => p.name + ' = ' + (Array.isArray(p.value) ? p.value.map(v => +(+v).toFixed(3)).join(',') : (typeof p.value === 'number' ? +p.value.toFixed(3) : p.value))).join(' · ')));
      picks.push({ c, cb });
      body.appendChild(card);
    }
    const nameIn = h('input'); nameIn.type = 'text'; nameIn.className = 'qname'; nameIn.value = r.clip.slice(0, 20);
    const tgt = h('select', 'sel'); for (const [k, n] of [['selected', 'Selected clips'], ['adjustment', 'Adjustment layer']]) { const o = h('option'); o.value = k; o.textContent = n; tgt.appendChild(o); }
    const saveBtn = h('button', 'primary', 'Save preset');
    saveBtn.addEventListener('click', () => {
      const effects = picks.filter(p => p.cb.checked).map(p => ({ name: p.c.name, params: p.c.props.filter(x => x.ok && x.value !== null && typeof x.value !== 'string').map(x => ({ i: x.i, name: x.name, value: x.value })) }));
      if (!effects.length) { toast('Tick at least one effect.', 'err'); return; }
      presets.push({ id: 'p' + Date.now().toString(36), name: nameIn.value || 'Preset', color: COLORS[presets.length % 8], target: tgt.value, effects });
      save(); manager(); toast('Preset saved.', 'ok');
    });
    const back = h('button', 'ghost', 'Cancel'); back.addEventListener('click', manager);
    const foot = h('div', 'inline'); foot.append(nameIn, tgt, saveBtn, back);
    body.appendChild(foot);
  }

  function openManager() { manager(); Hub.show('quickfx'); }
  function init(opts) {
    pinned = !!(opts && opts.pinned);
    const fab = $('#qfx-fab'); if (fab) fab.addEventListener('click', toggle);
    $('#qfx-close').addEventListener('click', hide);
    $('#qfx-overlay').addEventListener('click', (e) => { if (e.target.id === 'qfx-overlay') hide(); });
    $('#qfx-add').addEventListener('click', () => { hide(); openManager(); addFromSelection(); });
    $('#qfx-settings').addEventListener('click', () => { hide(); openManager(); });
    $('#qfx-search').addEventListener('input', (e) => renderResults(e.target.value));
    syncFab(); registerKeys();
  }
  return { init, show, hide, toggle, reload, openManager, registerKeys, presets: () => presets };
})();
