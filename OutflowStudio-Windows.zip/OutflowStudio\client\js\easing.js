/* Easing library. Every function maps [0,1] -> ~[0,1]. */
const EASINGS = (() => {
  const c1 = 1.70158, c2 = c1 * 1.525, c3 = c1 + 1, c4 = (2*Math.PI)/3, c5 = (2*Math.PI)/4.5;
  const bounceOut = (x) => {
    const n1 = 7.5625, d1 = 2.75;
    if (x < 1/d1) return n1*x*x;
    if (x < 2/d1) return n1*(x-=1.5/d1)*x + 0.75;
    if (x < 2.5/d1) return n1*(x-=2.25/d1)*x + 0.9375;
    return n1*(x-=2.625/d1)*x + 0.984375;
  };
  return {
    linear:          { name: 'Linear',          fn: x => x },
    easeInSine:      { name: 'In Sine',         fn: x => 1 - Math.cos(x*Math.PI/2) },
    easeOutSine:     { name: 'Out Sine',        fn: x => Math.sin(x*Math.PI/2) },
    easeInOutSine:   { name: 'In-Out Sine',     fn: x => -(Math.cos(Math.PI*x) - 1)/2 },
    easeInQuad:      { name: 'In Quad',         fn: x => x*x },
    easeOutQuad:     { name: 'Out Quad',        fn: x => 1 - (1-x)*(1-x) },
    easeInOutQuad:   { name: 'In-Out Quad',     fn: x => x < 0.5 ? 2*x*x : 1 - Math.pow(-2*x+2, 2)/2 },
    easeInCubic:     { name: 'In Cubic',        fn: x => x*x*x },
    easeOutCubic:    { name: 'Out Cubic',       fn: x => 1 - Math.pow(1-x, 3) },
    easeInOutCubic:  { name: 'In-Out Cubic',    fn: x => x < 0.5 ? 4*x*x*x : 1 - Math.pow(-2*x+2, 3)/2 },
    easeInQuart:     { name: 'In Quart',        fn: x => x*x*x*x },
    easeOutQuart:    { name: 'Out Quart',       fn: x => 1 - Math.pow(1-x, 4) },
    easeInOutQuart:  { name: 'In-Out Quart',    fn: x => x < 0.5 ? 8*x*x*x*x : 1 - Math.pow(-2*x+2, 4)/2 },
    easeInQuint:     { name: 'In Quint',        fn: x => x*x*x*x*x },
    easeOutQuint:    { name: 'Out Quint',       fn: x => 1 - Math.pow(1-x, 5) },
    easeInOutQuint:  { name: 'In-Out Quint',    fn: x => x < 0.5 ? 16*x*x*x*x*x : 1 - Math.pow(-2*x+2, 5)/2 },
    easeInExpo:      { name: 'In Expo',         fn: x => x === 0 ? 0 : Math.pow(2, 10*x - 10) },
    easeOutExpo:     { name: 'Out Expo',        fn: x => x === 1 ? 1 : 1 - Math.pow(2, -10*x) },
    easeInOutExpo:   { name: 'In-Out Expo',     fn: x => x === 0 ? 0 : x === 1 ? 1 : x < 0.5 ? Math.pow(2, 20*x-10)/2 : (2 - Math.pow(2, -20*x+10))/2 },
    easeInCirc:      { name: 'In Circ',         fn: x => 1 - Math.sqrt(1 - x*x) },
    easeOutCirc:     { name: 'Out Circ',        fn: x => Math.sqrt(1 - Math.pow(x-1, 2)) },
    easeInOutCirc:   { name: 'In-Out Circ',     fn: x => x < 0.5 ? (1 - Math.sqrt(1 - Math.pow(2*x, 2)))/2 : (Math.sqrt(1 - Math.pow(-2*x+2, 2)) + 1)/2 },
    easeInBack:      { name: 'In Back',         fn: x => c3*x*x*x - c1*x*x },
    easeOutBack:     { name: 'Out Back',        fn: x => 1 + c3*Math.pow(x-1, 3) + c1*Math.pow(x-1, 2) },
    easeInOutBack:   { name: 'In-Out Back',     fn: x => x < 0.5 ? (Math.pow(2*x, 2)*((c2+1)*2*x - c2))/2 : (Math.pow(2*x-2, 2)*((c2+1)*(x*2-2) + c2) + 2)/2 },
    easeOutElastic:  { name: 'Out Elastic',     fn: x => x === 0 ? 0 : x === 1 ? 1 : Math.pow(2, -10*x)*Math.sin((x*10 - 0.75)*c4) + 1 },
    easeInOutElastic:{ name: 'In-Out Elastic',  fn: x => x === 0 ? 0 : x === 1 ? 1 : x < 0.5 ? -(Math.pow(2, 20*x-10)*Math.sin((20*x - 11.125)*c5))/2 : (Math.pow(2, -20*x+10)*Math.sin((20*x - 11.125)*c5))/2 + 1 },
    easeOutBounce:   { name: 'Out Bounce',      fn: bounceOut },
    easeInOutBounce: { name: 'In-Out Bounce',   fn: x => x < 0.5 ? (1 - bounceOut(1 - 2*x))/2 : (1 + bounceOut(2*x - 1))/2 },
    smoothstep:      { name: 'Smoothstep',      fn: x => x*x*(3 - 2*x) },
    smootherstep:    { name: 'Smootherstep',    fn: x => x*x*x*(x*(x*6 - 15) + 10) },
    snap:            { name: 'Snap (hard cut)', fn: x => x < 0.5 ? 0 : 1 },
    anticipate:      { name: 'Anticipate',      fn: x => x < 0.3 ? -0.15*Math.sin(x/0.3*Math.PI) : 1 - Math.pow(1 - (x-0.3)/0.7, 3) }
  };
})();
function ease(name, x) {
  const e = EASINGS[name] || EASINGS.easeInOutCubic;
  if (x <= 0) return 0; if (x >= 1) return 1;
  return e.fn(x);
}
