/* Remove background: a Node script the panel runs with its own node.exe (same runtime as Remove music).
   Robust Video Matting (RVM, MIT) through onnxruntime-node with DirectML on the GPU. ffmpeg decodes the clip
   to raw frames, every frame goes through the model (the recurrent state carries over, that is what makes it
   stable on video), and ffmpeg encodes the result: a ProRes 4444 clip with alpha, or a ProRes 422 HQ clip when a
   colour or a blurred copy of the original replaces the background.

   node matte.js --in clip.mp4 --out out.mov --model rvm.onnx --ffmpeg ffmpeg.exe --ort <dir with node_modules>
                 [--start 12.5] [--duration 8] [--bg none|color|blur] [--color 00ff00] [--blur 24] [--cpu]
                 [--stab 0..1] [--median 0|1] [--refine 0|1] [--warm 8] [--engine rvm|ben2] [--enc best|medium|small]
                 [--unspill 0|1] [--maxsize 1920] [--threads 0]
                 [--preview <folder> --at 3.2]      (one frame: original.png, alpha.png and fgr.png in that folder, for the live preview)
   Prints "progress 0.37" lines and "done" on stdout. */
'use strict';
const path = require('path'), { spawn, spawnSync } = require('child_process');

const args = {}; for (let i = 2; i < process.argv.length; i++) { const a = process.argv[i]; if (a.startsWith('--')) { const k = a.slice(2); const v = process.argv[i + 1]; if (v == null || v.startsWith('--')) { args[k] = true; } else { args[k] = v; i++; } } }
const need = (k) => { if (!args[k]) { console.error('missing --' + k); process.exit(2); } return args[k]; };
const IN = need('in'), MODEL = need('model'), FFMPEG = need('ffmpeg');
const OUT = args.preview ? null : need('out');
const BG = args.bg || 'none', COLOR = /^[0-9a-f]{6}$/i.test(args.color || '') ? args.color : '00ff00', BLUR = Math.max(2, +args.blur || 24);
const START = +args.start || 0, DURATION = +args.duration || 0, AT = +args.at || 0;
/* edge clean-up: contrast pulls the alpha ramp tighter, shrink/grow erodes or dilates by pixels, feather softens,
   largest keeps only blobs that are at least a fraction of the biggest one (loose cables, debris) */
const CONTRAST = Math.max(0, Math.min(0.45, +args.contrast || 0)), SHRINK = Math.max(-8, Math.min(8, Math.round(+args.shrink || 0))), FEATHER = Math.max(0, Math.min(12, Math.round(+args.feather || 0)));
const LARGEST = args.largest ? Math.max(0.005, Math.min(1, +args.largest || 0.05)) : 0;
const DSR = +args.detail || 0;
/* how much of the previous frame's matte is kept where the picture stands still. The people model has its own
   memory between frames, so it needs only a little; the any-subject model decides every  frame on its own and needs more. */
const STAB = args.stab != null ? Math.max(0, Math.min(1, +args.stab)) : (String(args.engine || 'rvm').toLowerCase() === 'ben2' ? 0.8 : 0.35);
const MED = String(args.median == null ? '1' : args.median) !== '0';   /* the middle of three frames */      /* how much of the previous frame's matte is kept where the picture stands still */
const REFINE = String(args.refine == null ? '1' : args.refine) !== '0';           /* let the matte follow the edges in the picture */
const WARM = Math.max(0, Math.min(30, args.warm == null ? 8 : Math.round(+args.warm)));   /* preview: frames run before the one we show, so it matches the render */
const UNSPILL = String(args.unspill == null ? '1' : args.unspill) !== '0';   /* take the old background back out of the soft edge */
/*  A 4K frame is four times the pixels of HD. Fed whole to the model that is gigabytes of video memory, and on a
    machine where Premiere already holds the rest the driver gives up and the computer locks. The model only needs
    enough pixels to find the subject: anything bigger than this on its long side is scaled down for the model and
    the matte is scaled back up, refined against the full-size picture. The rendered file stays full size. */
const MAXSIZE = Math.max(640, Math.min(4096, Math.round(+args.maxsize || 1920)));
/* how many threads the decoder and the encoder may each use. 0 = as many as there are cores. A lower number keeps
   the whole machine from running flat out, which some computers cannot sustain. */
const THREADS = Math.max(0, Math.min(64, Math.round(+args.threads || 0)));
const ENC = String(args.enc || 'best').toLowerCase();   /* best = the original ProRes 4444, smaller = the same picture at a lower bitrate */
const ENGINE = String(args.engine || 'rvm').toLowerCase();   /* rvm = people, recurrent; ben2 = any subject, per frame */
const LEAD = Math.max(0, +args.lead || 0);   /* seconds of warm-up before a segment that starts mid-clip: decoded and modelled, not written */
const ort = require(path.join(args.ort ? path.join(args.ort, 'node_modules') : 'node_modules', 'onnxruntime-node'));
const say = (s) => process.stdout.write(s + '\n');
const FFPROBE = path.join(path.dirname(FFMPEG), process.platform === 'win32' ? 'ffprobe.exe' : 'ffprobe');

function probe(file) {
  const r = spawnSync(FFPROBE, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,r_frame_rate,nb_frames:stream_tags=rotate:stream_side_data=rotation:format=duration', '-of', 'json', file], { encoding: 'utf8', windowsHide: true });
  if (r.status !== 0) throw new Error('ffprobe failed: ' + (r.stderr || '').slice(-200));
  const j = JSON.parse(r.stdout); const s = j.streams[0];
  const [a, b] = String(s.r_frame_rate || '30/1').split('/').map(Number);
  /*  A phone films sideways and tags the file with a turn. ffmpeg hands us the frames already turned, so a clip
      stored as 3840x2160 arrives as 2160x3840. Reading it the other way round scrambles every row, and the matte
      comes out empty. Take the turn into account here, once. */
  let rot = 0;
  for (const sd of (s.side_data_list || [])) if (sd && sd.rotation != null) rot = +sd.rotation;
  if (!rot && s.tags && s.tags.rotate != null) rot = +s.tags.rotate;
  const turned = Math.abs(Math.round(rot / 90) % 2) === 1;
  return { w: turned ? s.height : s.width, h: turned ? s.width : s.height, rot: rot, fps: b ? a / b : a, duration: +(j.format && j.format.duration) || 0 };
}

/* reads fixed-size frames from a stream without growing buffers */
function frameReader(stream, bytes) {
  let cur = Buffer.allocUnsafe(bytes), filled = 0, ended = false, waiter = null; const ready = [];
  stream.on('data', (chunk) => {
    let off = 0;
    while (off < chunk.length) { const n = Math.min(bytes - filled, chunk.length - off); chunk.copy(cur, filled, off, off + n); filled += n; off += n; if (filled === bytes) { ready.push(cur); cur = Buffer.allocUnsafe(bytes); filled = 0; } }
    if (ready.length >= 4) stream.pause();
    if (waiter) { const w = waiter; waiter = null; w(); }
  });
  stream.on('end', () => { ended = true; if (waiter) { const w = waiter; waiter = null; w(); } });
  stream.on('error', () => { ended = true; if (waiter) { const w = waiter; waiter = null; w(); } });
  return async function next() { while (!ready.length) { if (ended) return null; await new Promise((r) => { waiter = r; }); } const f = ready.shift(); if (ready.length < 2) stream.resume(); return f; };
}

/* a soft, cheap blur: box blur three times at quarter resolution, then bilinear up */
function blurRGB(rgb, W, H, radius) {
  const sw = Math.max(1, Math.round(W / 4)), sh = Math.max(1, Math.round(H / 4)), r = Math.max(1, Math.round(radius / 4));
  const small = new Float32Array(sw * sh * 3);
  for (let y = 0; y < sh; y++) { const sy = Math.min(H - 1, y * 4); for (let x = 0; x < sw; x++) { const sx = Math.min(W - 1, x * 4), i = (sy * W + sx) * 3, o = (y * sw + x) * 3; small[o] = rgb[i]; small[o + 1] = rgb[i + 1]; small[o + 2] = rgb[i + 2]; } }
  const tmp = new Float32Array(small.length);
  const pass = (src, dst, horizontal) => {
    const len = horizontal ? sw : sh, lines = horizontal ? sh : sw;
    for (let l = 0; l < lines; l++) {
      for (let c = 0; c < 3; c++) {
        let acc = 0, cnt = 0;
        const at = (i) => (horizontal ? (l * sw + i) : (i * sw + l)) * 3 + c;
        for (let i = 0; i <= Math.min(r, len - 1); i++) { acc += src[at(i)]; cnt++; }
        for (let i = 0; i < len; i++) {
          dst[at(i)] = acc / cnt;
          const add = i + r + 1, rem = i - r;
          if (add < len) { acc += src[at(add)]; cnt++; }
          if (rem >= 0) { acc -= src[at(rem)]; cnt--; }
        }
      }
    }
  };
  for (let k = 0; k < 3; k++) { pass(small, tmp, true); pass(tmp, small, false); }
  return { data: small, sw, sh };
}
/* --- alpha clean-up: separable passes with plain index maths, a few ms each on a 1080p frame --- */
/* scratch buffers, kept between frames (allocating megabytes per frame was costing more than the filters) */
const SCR = {};
function scratch(name, n) { const k = name + n; let b = SCR[k]; if (!b) { b = SCR[k] = new Float32Array(n); } return b; }
/* separable box mean, used by the guided filter */
function boxMean(src, w, h, r, outName) {
  const tmp = scratch('boxtmp', src.length), out = scratch(outName || 'boxout', src.length);
  for (let y = 0; y < h; y++) {
    const row = y * w; let acc = 0, cnt = 0;
    for (let i = 0; i <= (r < w - 1 ? r : w - 1); i++) { acc += src[row + i]; cnt++; }
    for (let x = 0; x < w; x++) { tmp[row + x] = acc / cnt; const add = x + r + 1, rem = x - r; if (add < w) { acc += src[row + add]; cnt++; } if (rem >= 0) { acc -= src[row + rem]; cnt--; } }
  }
  const acc = scratch('boxa', w), cnt = scratch('boxc', w); acc.fill(0); cnt.fill(0);
  for (let i = 0; i <= (r < h - 1 ? r : h - 1); i++) { const row = i * w; for (let x = 0; x < w; x++) { acc[x] += tmp[row + x]; cnt[x]++; } }
  for (let y = 0; y < h; y++) {
    const row = y * w, add = y + r + 1, rem = y - r;
    for (let x = 0; x < w; x++) out[row + x] = acc[x] / cnt[x];
    if (add < h) { const ra = add * w; for (let x = 0; x < w; x++) { acc[x] += tmp[ra + x]; cnt[x]++; } }
    if (rem >= 0) { const rr = rem * w; for (let x = 0; x < w; x++) { acc[x] -= tmp[rr + x]; cnt[x]--; } }
  }
  return out;
}
/* Guided filter (He et al.), computed at quarter size like the fast version: the matte's soft edge is pulled onto
   the real edge in the picture instead of being a blur, which also stops it wandering from frame to frame. */
const GF = { sw: 0, sh: 0 };
function alphaRefine(a, rgb, W, H) {
  const S = 4, sw = Math.max(2, W / S | 0), sh = Math.max(2, H / S | 0), n = sw * sh, eps = 1e-4;
  if (GF.sw !== sw || GF.sh !== sh) { GF.sw = sw; GF.sh = sh; GF.I = new Float32Array(n); GF.P = new Float32Array(n); GF.IP = new Float32Array(n); GF.II = new Float32Array(n); }
  const I = GF.I, P = GF.P;
  for (let y = 0; y < sh; y++) {
    const sy = Math.min(H - 1, y * S + (S >> 1)), row = sy * W, orow = y * sw;
    for (let x = 0; x < sw; x++) {
      const sx = Math.min(W - 1, x * S + (S >> 1)), s3 = (row + sx) * 3;
      I[orow + x] = (rgb[s3] * 0.299 + rgb[s3 + 1] * 0.587 + rgb[s3 + 2] * 0.114) / 255;
      P[orow + x] = a[row + sx];
    }
  }
  for (let i = 0; i < n; i++) { GF.IP[i] = I[i] * P[i]; GF.II[i] = I[i] * I[i]; }
  const r = 2;
  const mI = boxMean(I, sw, sh, r, 'mI'), mP = boxMean(P, sw, sh, r, 'mP'), mIP = boxMean(GF.IP, sw, sh, r, 'mIP'), mII = boxMean(GF.II, sw, sh, r, 'mII');
  const A = scratch('gfA', n), B = scratch('gfB', n);
  for (let i = 0; i < n; i++) { const cov = mIP[i] - mI[i] * mP[i], vI = mII[i] - mI[i] * mI[i]; const k = cov / (vI + eps); A[i] = k; B[i] = mP[i] - k * mI[i]; }
  const mA = boxMean(A, sw, sh, r, 'mA'), mB = boxMean(B, sw, sh, r, 'mB');
  /* only the soft band is replaced: solid inside and clean outside stay exactly as they were */
  for (let y = 0; y < H; y++) {
    const fy = (y - (S >> 1)) / S, cy = fy < 0 ? 0 : (fy > sh - 1.001 ? sh - 1.001 : fy);
    const y0 = cy | 0, ty = cy - y0, y1 = y0 + 1 < sh ? y0 + 1 : y0, row = y * W;
    for (let x = 0; x < W; x++) {
      const i = row + x, av = a[i];
      if (av <= 0.004 || av >= 0.996) continue;
      const fx = (x - (S >> 1)) / S, cx = fx < 0 ? 0 : (fx > sw - 1.001 ? sw - 1.001 : fx);
      const x0 = cx | 0, tx = cx - x0, x1 = x0 + 1 < sw ? x0 + 1 : x0;
      const i00 = y0 * sw + x0, i10 = y0 * sw + x1, i01 = y1 * sw + x0, i11 = y1 * sw + x1;
      const aa = (mA[i00] * (1 - tx) + mA[i10] * tx) * (1 - ty) + (mA[i01] * (1 - tx) + mA[i11] * tx) * ty;
      const bb = (mB[i00] * (1 - tx) + mB[i10] * tx) * (1 - ty) + (mB[i01] * (1 - tx) + mB[i11] * tx) * ty;
      const s3 = i * 3, g = (rgb[s3] * 0.299 + rgb[s3 + 1] * 0.587 + rgb[s3 + 2] * 0.114) / 255;
      const v = aa * g + bb;
      a[i] = v < 0 ? 0 : v > 1 ? 1 : v;
    }
  }
}
/* Where the picture stands still, keep the matte it had; where it moves, take the new one. Still edges stop
   wobbling and moving ones do not smear. */
function alphaMedian3(a, b, c, out) {
  for (let i = 0; i < out.length; i++) {
    const y = b[i], x = a[i], z = c[i];
    if ((y > 0.996 && x > 0.996 && z > 0.996) || (y < 0.004 && x < 0.004 && z < 0.004)) { out[i] = y; continue; }
    out[i] = x < y ? (y < z ? y : (x < z ? z : x)) : (x < z ? x : (y < z ? z : y));
  }
}
function alphaStabilise(a, rgb, prevA, prevRGB, strength) {
  for (let i = 0, s3 = 0; i < a.length; i++, s3 += 3) {
    const av = a[i], pv = prevA[i];
    if ((av > 0.996 && pv > 0.996) || (av < 0.004 && pv < 0.004)) continue;   /* nothing to hold here */
    const d = (Math.abs(rgb[s3] - prevRGB[s3]) + Math.abs(rgb[s3 + 1] - prevRGB[s3 + 1]) + Math.abs(rgb[s3 + 2] - prevRGB[s3 + 2])) * 0.3333;
    const w = (d <= 4 ? 1 : d >= 20 ? 0 : (20 - d) / 16) * strength;
    if (w > 0) a[i] = a[i] * (1 - w) + prevA[i] * w;
  }
}
/* ---- BEN2: a general subject model. One square 1024 picture in, one mask out, no memory between frames ---- */
const BEN_N = 1024;
const F16 = (() => { const t = new Float32Array(65536); for (let b = 0; b < 65536; b++) { const s = (b & 0x8000) ? -1 : 1, e = (b >> 10) & 0x1f, m = b & 0x3ff; t[b] = e === 0 ? s * 5.9604644775390625e-8 * m : e === 31 ? (m ? NaN : s * Infinity) : s * Math.pow(2, e - 15) * (1 + m / 1024); } return t; })();
/* the frame, averaged down into whatever size the model wants, as three planes of 0..1 */
function boxDown(rgb, W, H, dst, dw, dh) {
  const plane = dw * dh, sx = W / dw, sy = H / dh;
  for (let y = 0; y < dh; y++) {
    const y0 = (y * sy) | 0; let y1 = ((y + 1) * sy) | 0; if (y1 <= y0) y1 = y0 + 1; if (y1 > H) y1 = H;
    for (let x = 0; x < dw; x++) {
      const x0 = (x * sx) | 0; let x1 = ((x + 1) * sx) | 0; if (x1 <= x0) x1 = x0 + 1; if (x1 > W) x1 = W;
      let r = 0, g = 0, b = 0, n = 0;
      for (let yy = y0; yy < y1; yy++) { const row = yy * W * 3; for (let xx = x0; xx < x1; xx++) { const p = row + xx * 3; r += rgb[p]; g += rgb[p + 1]; b += rgb[p + 2]; n++; } }
      const i = y * dw + x, k = 1 / (n * 255);
      dst[i] = r * k; dst[plane + i] = g * k; dst[2 * plane + i] = b * k;
    }
  }
}
/* a mask back up to the frame size, bilinear; the guided filter then puts it on the real edges */
function maskUp(mask, sw, sh, out, W, H) {
  const f16 = mask.BYTES_PER_ELEMENT === 2;
  const at = (i) => { const v = f16 ? F16[mask[i]] : mask[i]; return v < 0 ? 0 : v > 1 ? 1 : v; };
  for (let y = 0; y < H; y++) {
    const fy = (y + 0.5) * sh / H - 0.5, cy = fy < 0 ? 0 : (fy > sh - 1.001 ? sh - 1.001 : fy);
    const y0 = cy | 0, ty = cy - y0, y1 = y0 + 1 < sh ? y0 + 1 : y0, r0 = y0 * sw, r1 = y1 * sw, row = y * W;
    for (let x = 0; x < W; x++) {
      const fx = (x + 0.5) * sw / W - 0.5, cx = fx < 0 ? 0 : (fx > sw - 1.001 ? sw - 1.001 : fx);
      const x0 = cx | 0, tx = cx - x0, x1 = x0 + 1 < sw ? x0 + 1 : x0;
      out[row + x] = (at(r0 + x0) * (1 - tx) + at(r0 + x1) * tx) * (1 - ty) + (at(r1 + x0) * (1 - tx) + at(r1 + x1) * tx) * ty;
    }
  }
}
function alphaLevels(a, lo) { if (!lo) return; const k = 1 / (1 - 2 * lo); for (let i = 0; i < a.length; i++) { const v = (a[i] - lo) * k; a[i] = v < 0 ? 0 : v > 1 ? 1 : v; } }
function alphaMorph(a, W, H, r) {
  const rad = Math.abs(r), grow = r > 0, tmp = scratch('morph', a.length);
  for (let y = 0; y < H; y++) {
    const row = y * W;
    if (grow) { for (let x = 0; x < W; x++) { let v = a[row + x]; const lo = x - rad < 0 ? 0 : x - rad, hi = x + rad >= W ? W - 1 : x + rad; for (let k = lo; k <= hi; k++) { const t = a[row + k]; if (t > v) v = t; } tmp[row + x] = v; } }
    else { for (let x = 0; x < W; x++) { let v = a[row + x]; const lo = x - rad < 0 ? 0 : x - rad, hi = x + rad >= W ? W - 1 : x + rad; for (let k = lo; k <= hi; k++) { const t = a[row + k]; if (t < v) v = t; } tmp[row + x] = v; } }
  }
  for (let y = 0; y < H; y++) {
    const row = y * W, lo = y - rad < 0 ? 0 : y - rad, hi = y + rad >= H ? H - 1 : y + rad;
    for (let x = 0; x < W; x++) a[row + x] = tmp[row + x];
    for (let k = lo; k <= hi; k++) {
      if (k === y) continue;
      const rk = k * W;
      if (grow) { for (let x = 0; x < W; x++) { const t = tmp[rk + x]; if (t > a[row + x]) a[row + x] = t; } }
      else { for (let x = 0; x < W; x++) { const t = tmp[rk + x]; if (t < a[row + x]) a[row + x] = t; } }
    }
  }
}
function alphaFeather(a, W, H, r) {
  const tmp = scratch('feath', a.length);
  if (r === 1) {   /* the common one-pixel soften, without the running-sum bookkeeping */
    for (let y = 0; y < H; y++) {
      const row = y * W;
      tmp[row] = (a[row] + a[row] + a[row + 1]) / 3;
      for (let x = 1; x < W - 1; x++) tmp[row + x] = (a[row + x - 1] + a[row + x] + a[row + x + 1]) / 3;
      tmp[row + W - 1] = (a[row + W - 2] + a[row + W - 1] + a[row + W - 1]) / 3;
    }
    for (let y = 0; y < H; y++) {
      const row = y * W, up = (y > 0 ? y - 1 : 0) * W, dn = (y < H - 1 ? y + 1 : H - 1) * W;
      for (let x = 0; x < W; x++) a[row + x] = (tmp[up + x] + tmp[row + x] + tmp[dn + x]) / 3;
    }
    return;
  }
  for (let y = 0; y < H; y++) { const row = y * W; let acc = 0, cnt = 0; for (let i = 0; i <= Math.min(r, W - 1); i++) { acc += a[row + i]; cnt++; } for (let x = 0; x < W; x++) { tmp[row + x] = acc / cnt; const add = x + r + 1, rem = x - r; if (add < W) { acc += a[row + add]; cnt++; } if (rem >= 0) { acc -= a[row + rem]; cnt--; } } }
  const acc = scratch('featha', W), cnt = scratch('feathc', W); acc.fill(0); cnt.fill(0);
  for (let i = 0; i <= Math.min(r, H - 1); i++) { const row = i * W; for (let x = 0; x < W; x++) { acc[x] += tmp[row + x]; cnt[x]++; } }
  for (let y = 0; y < H; y++) { const row = y * W, add = y + r + 1, rem = y - r; for (let x = 0; x < W; x++) a[row + x] = acc[x] / cnt[x]; if (add < H) { const ra = add * W; for (let x = 0; x < W; x++) { acc[x] += tmp[ra + x]; cnt[x]++; } } if (rem >= 0) { const rr = rem * W; for (let x = 0; x < W; x++) { acc[x] -= tmp[rr + x]; cnt[x]--; } } }
}
/* keep only the blobs that are big enough, measured at quarter resolution. A blob that was kept on the previous
   frame survives at a lower bar, so bits stop popping in and out while the video plays. */
let lastKeep = null;
function alphaLargest(a, W, H, minFrac) {
  const sw = Math.max(1, W >> 2), sh = Math.max(1, H >> 2), lab = new Int32Array(sw * sh);
  const solidAt = (x, y) => a[Math.min(H - 1, y * 4 + 2) * W + Math.min(W - 1, x * 4 + 2)] > 0.5;
  let nLab = 0; const sizes = [0]; const stack = [];
  for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) {
    if (lab[y * sw + x] || !solidAt(x, y)) continue;
    nLab++; let size = 0; stack.push(y * sw + x); lab[y * sw + x] = nLab;
    while (stack.length) { const p = stack.pop(); size++; const px = p % sw, py = (p / sw) | 0; if (px > 0 && !lab[p - 1] && solidAt(px - 1, py)) { lab[p - 1] = nLab; stack.push(p - 1); } if (px < sw - 1 && !lab[p + 1] && solidAt(px + 1, py)) { lab[p + 1] = nLab; stack.push(p + 1); } if (py > 0 && !lab[p - sw] && solidAt(px, py - 1)) { lab[p - sw] = nLab; stack.push(p - sw); } if (py < sh - 1 && !lab[p + sw] && solidAt(px, py + 1)) { lab[p + sw] = nLab; stack.push(p + sw); } }
    sizes.push(size);
  }
  if (nLab <= 1) { lastKeep = null; return; }
  const biggest = Math.max.apply(null, sizes);
  /* a small-label mask: 1 = keep. Grow it by one cell so thin bits next to the subject survive, then zero the rest */
  const keep = new Uint8Array(sw * sh);
  const wasKept = new Uint8Array(nLab + 1);
  if (lastKeep && lastKeep.length === lab.length) for (let i = 0; i < lab.length; i++) if (lab[i] && lastKeep[i]) wasKept[lab[i]] = 1;
  const bar = biggest * minFrac, lowBar = bar * 0.4;
  for (let i = 0; i < lab.length; i++) { const L = lab[i]; if (!L) continue; const sz = sizes[L]; if (sz >= bar || (wasKept[L] && sz >= lowBar)) keep[i] = 1; }
  lastKeep = keep;
  const keep2 = new Uint8Array(keep);
  for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) { const i = y * sw + x; if (keep[i]) continue; if ((x > 0 && keep[i - 1]) || (x < sw - 1 && keep[i + 1]) || (y > 0 && keep[i - sw]) || (y < sh - 1 && keep[i + sw])) keep2[i] = 1; }
  for (let y = 0; y < H; y++) { const ly = Math.min(sh - 1, y >> 2) * sw, row = y * W; for (let x = 0; x < W; x++) { if (!keep2[ly + Math.min(sw - 1, x >> 2)]) a[row + x] = 0; } }
}
/*  A half-transparent edge pixel is part subject and part whatever was behind it, so the old background tints the
    cut-out: a grey wall leaves a grey halo. Take the average background colour from the clear pixels nearby and
    solve the mix back out: F = (C - (1-a)·B) / a. The change is capped, so a wrong guess can only tint slightly. */
const BGM = { cw: 0, ch: 0, cell: 16, ok: false };
function bgMap(rgb, a, W, H) {
  const cell = BGM.cell, cw = Math.max(1, Math.ceil(W / cell)), ch = Math.max(1, Math.ceil(H / cell)), n = cw * ch;
  if (BGM.cw !== cw || BGM.ch !== ch) { BGM.cw = cw; BGM.ch = ch; BGM.r = new Float32Array(n); BGM.g = new Float32Array(n); BGM.b = new Float32Array(n); BGM.n = new Float32Array(n); BGM.q = new Float32Array(n); }
  const R = BGM.r, G = BGM.g, B2 = BGM.b, N = BGM.n, Q = BGM.q;
  R.fill(0); G.fill(0); B2.fill(0); N.fill(0); Q.fill(0);
  for (let y = 0; y < H; y++) {
    const row = y * W, cy = ((y / cell) | 0) * cw;
    for (let x = 0; x < W; x++) {
      if (a[row + x] > 0.02) continue;
      const c = cy + ((x / cell) | 0), s3 = (row + x) * 3;
      const lum = rgb[s3] * 0.299 + rgb[s3 + 1] * 0.587 + rgb[s3 + 2] * 0.114;
      R[c] += rgb[s3]; G[c] += rgb[s3 + 1]; B2[c] += rgb[s3 + 2]; Q[c] += lum * lum; N[c]++;
    }
  }
  let known = 0;
  /*  Only trust a patch of background that is actually one colour. Behind a person there is often a curtain, a
      screen and a lamp within a few pixels of the hair; averaging those and subtracting the result tints the edge.
      Where the background is busy the colour is left alone. */
  for (let i = 0; i < n; i++) {
    if (N[i] > 8) {
      R[i] /= N[i]; G[i] /= N[i]; B2[i] /= N[i];
      const meanL = R[i] * 0.299 + G[i] * 0.587 + B2[i] * 0.114;
      const varL = Q[i] / N[i] - meanL * meanL;
      N[i] = varL > 26 * 26 ? -1 : 1;          /* -1: too busy to guess from */
      if (N[i] === 1) known++;
    } else N[i] = 0;
  }
  BGM.ok = known > n * 0.02;
  if (!BGM.ok) return;
  /* cells with no clear pixels (inside the subject) borrow from their neighbours, so every edge pixel has a guess */
  for (let pass = 0; pass < 8; pass++) {
    let filled = 0;
    for (let cy = 0; cy < ch; cy++) for (let cx = 0; cx < cw; cx++) {
      const i = cy * cw + cx; if (N[i]) continue;
      let r = 0, g = 0, b = 0, k = 0;
      if (cx > 0 && N[i - 1] === 1) { r += R[i - 1]; g += G[i - 1]; b += B2[i - 1]; k++; }
      if (cx < cw - 1 && N[i + 1] === 1) { r += R[i + 1]; g += G[i + 1]; b += B2[i + 1]; k++; }
      if (cy > 0 && N[i - cw] === 1) { r += R[i - cw]; g += G[i - cw]; b += B2[i - cw]; k++; }
      if (cy < ch - 1 && N[i + cw] === 1) { r += R[i + cw]; g += G[i + cw]; b += B2[i + cw]; k++; }
      if (k) { R[i] = r / k; G[i] = g / k; B2[i] = b / k; N[i] = 2; filled++; }
    }
    for (let i = 0; i < n; i++) if (N[i] === 2) N[i] = 1;
    if (!filled) break;
  }
}
const MAXFIX = 48;   /* how far a pixel's colour may be moved; a wrong guess can then only tint it slightly */
function unspill(c, a, bg) {
  const f = (c - (1 - a) * bg) / a, d = f - c;
  const v = c + (d < -MAXFIX ? -MAXFIX : d > MAXFIX ? MAXFIX : d);
  return v < 0 ? 0 : v > 255 ? 255 : v;
}
function sampleBlur(b, x, y, W, H, c) {
  const fx = Math.min(b.sw - 1.001, x / W * b.sw), fy = Math.min(b.sh - 1.001, y / H * b.sh);
  const x0 = fx | 0, y0 = fy | 0, tx = fx - x0, ty = fy - y0;
  const i00 = (y0 * b.sw + x0) * 3 + c, i10 = i00 + 3, i01 = i00 + b.sw * 3, i11 = i01 + 3;
  return (b.data[i00] * (1 - tx) + b.data[i10] * tx) * (1 - ty) + (b.data[i01] * (1 - tx) + b.data[i11] * tx) * ty;
}

(async () => {
  const info = probe(IN);
  let W = info.w, H = info.h; const fps = info.fps || 30;
  /* a preview is only looked at, so a big frame is decoded smaller: nine 4K frames are 224 MB of raw pixels,
     nine of these are a tenth of that, and the model sees the same picture either way */
  let previewVf = null;
  if (args.preview && Math.max(W, H) > MAXSIZE) {
    const k = MAXSIZE / Math.max(W, H);
    W = Math.max(2, Math.round(W * k / 2) * 2); H = Math.max(2, Math.round(H * k / 2) * 2);
    previewVf = 'scale=' + W + ':' + H;
  }
  const dur = DURATION > 0 ? DURATION : Math.max(0, info.duration - START);
  /* exact frame counts from the caller win over time-based ones, so parts of one clip join without a seam */
  const SKIP = args.skipframes != null ? Math.max(0, Math.round(+args.skipframes)) : Math.round(LEAD * fps);
  const total = args.preview ? 1 : (args.frames ? Math.max(1, Math.round(+args.frames)) : Math.max(1, Math.round((dur - LEAD) * fps)));
  const session = await ort.InferenceSession.create(MODEL, { executionProviders: args.cpu ? ['cpu'] : (process.platform === 'win32' ? ['dml', 'cpu'] : ['coreml', 'cpu']) });
  say('backend ' + (args.cpu ? 'cpu' : 'dml') + ' engine ' + ENGINE);
  const BEN = ENGINE === 'ben2';
  const benIn = BEN ? session.inputNames[0] : null, benOut = BEN ? session.outputNames[0] : null;
  /* the size the model is actually fed. A big frame is scaled down for it; the file we write stays full size. */
  const even = (v) => Math.max(2, Math.round(v / 2) * 2);
  const big = !BEN && Math.max(W, H) > MAXSIZE;
  const mw = BEN ? BEN_N : (big ? even(W * MAXSIZE / Math.max(W, H)) : W);
  const mh = BEN ? BEN_N : (big ? even(H * MAXSIZE / Math.max(W, H)) : H);
  say('size ' + W + 'x' + H + (info.rot ? ' (turned ' + info.rot + '°)' : '') + ' · model ' + mw + 'x' + mh + (big ? ' (scaled down to keep the memory sane)' : ''));
  /* the model works at a fraction of the resolution and refines at full size; 0.25 is right for HD, more for small clips */
  /* how much of the frame the model itself looks at. Measured on a 1080p clip: at 512 the matte's edge jitters
     between frames, at ~900 it is far steadier (still-edge flicker 29 -> 19) for a few ms more on the GPU. */
  const ratio = DSR > 0 ? Math.max(0.15, Math.min(1, DSR)) : Math.max(0.25, Math.min(1, 900 / Math.max(mw, mh)));
  const dsr = new ort.Tensor('float32', new Float32Array([ratio]), [1]);
  const zero = () => new ort.Tensor('float32', new Float32Array([0]), [1, 1, 1, 1]);
  let r1 = zero(), r2 = zero(), r3 = zero(), r4 = zero();
  /* one call for either engine: give it a picture, get back a matte (and, for RVM, its spill-free colours) */
  const scaledIn = (BEN || big) ? [new Float32Array(3 * mw * mh), new Float32Array(3 * mw * mh)] : null;
  let inSlot = 0;
  const runFrame = (rgb, W, H) => {
    if (!BEN && !big) return session.run({ src: new ort.Tensor('float32', rgb, [1, 3, H, W]), r1i: r1, r2i: r2, r3i: r3, r4i: r4, downsample_ratio: dsr });
    const buf = scaledIn[inSlot]; inSlot = 1 - inSlot;
    boxDown(rgb, W, H, buf, mw, mh);
    if (!BEN) return session.run({ src: new ort.Tensor('float32', buf, [1, 3, mh, mw]), r1i: r1, r2i: r2, r3i: r3, r4i: r4, downsample_ratio: dsr });
    const feed = {}; feed[benIn] = new ort.Tensor('float32', buf, [1, 3, mh, mw]);
    return session.run(feed);
  };

  if (args.preview) {
    /* the render feeds the model frame after frame, so its matte is steadier than a single still. Run the same
       short run-up here, then show the last frame: the preview and the render now agree. */
    /* every run-up frame costs a full decode of the source, which is slow on a 4K phone clip: fewer of them there */
    const wantWarm = Math.max(info.w, info.h) > MAXSIZE * 1.5 ? Math.min(WARM, 4) : WARM;
    const warm = Math.min(wantWarm, Math.max(0, Math.round(AT * (info.fps || 30))));
    const ss = Math.max(0, AT - warm / (info.fps || 30));
    /* the preview is only looked at, so a big frame is decoded smaller: nine 4K frames are 224 MB, nine of these
       are a tenth of that, and the model sees the same picture either way */
    const decArgs0 = ['-hide_banner', '-loglevel', 'error', '-ss', String(ss), '-i', IN, '-an', '-sn', '-frames:v', String(warm + 1)];
    if (previewVf) decArgs0.push('-vf', previewVf);
    decArgs0.push('-pix_fmt', 'rgb24', '-f', 'rawvideo', 'pipe:1');
    const dec = spawnSync(FFMPEG, decArgs0, { maxBuffer: 2e9, windowsHide: true });
    const all = dec.stdout; if (!all || all.length < W * H * 3) throw new Error('Could not decode a frame at ' + AT + ' s');
    const plane = H * W, frameBytes = plane * 3, got = Math.floor(all.length / frameBytes);
    const src = new Float32Array(3 * H * W);
    let rgb = null, res = null, prevA = null, prevRGB = null, benA = null;
    for (let f = 0; f < got; f++) {
      rgb = all.subarray(f * frameBytes, (f + 1) * frameBytes);
      if (!BEN) for (let i = 0, p = 0; i < plane; i++, p += 3) { src[i] = rgb[p] / 255; src[plane + i] = rgb[p + 1] / 255; src[2 * plane + i] = rgb[p + 2] / 255; }
      res = await runFrame(BEN ? rgb : src, W, H);
      if (!BEN) { r1 = res.r1o; r2 = res.r2o; r3 = res.r3o; r4 = res.r4o; }
      const pa = (BEN || big) ? (benA || (benA = new Float32Array(plane))) : res.pha.data;
      if (BEN || big) maskUp(BEN ? res[benOut].data : res.pha.data, mw, mh, pa, W, H);
      if (REFINE) alphaRefine(pa, rgb, W, H);
      if (STAB > 0 && prevA) alphaStabilise(pa, rgb, prevA, prevRGB, STAB);
      if (!prevA) prevA = new Float32Array(plane);
      prevA.set(pa); prevRGB = rgb;
    }
    const pha = (BEN || big) ? benA : res.pha.data, fgr = (BEN || big) ? null : res.fgr.data;
    const a8 = Buffer.allocUnsafe(plane), f8 = Buffer.allocUnsafe(plane * 3);
    for (let i = 0; i < plane; i++) {
      a8[i] = Math.max(0, Math.min(1, pha[i])) * 255 + 0.5;
      if (fgr) { f8[i * 3] = Math.max(0, Math.min(1, fgr[i])) * 255 + 0.5; f8[i * 3 + 1] = Math.max(0, Math.min(1, fgr[plane + i])) * 255 + 0.5; f8[i * 3 + 2] = Math.max(0, Math.min(1, fgr[2 * plane + i])) * 255 + 0.5; }
      else { const s3 = i * 3; f8[s3] = rgb[s3]; f8[s3 + 1] = rgb[s3 + 1]; f8[s3 + 2] = rgb[s3 + 2]; }
    }
    const png = (buf, fmt, file) => { const r = spawnSync(FFMPEG, ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', fmt, '-s', W + 'x' + H, '-i', 'pipe:0', '-frames:v', '1', '-c:v', 'png', '-compression_level', '1', file], { input: buf, maxBuffer: 1e9, windowsHide: true }); if (r.status !== 0) throw new Error('preview image failed: ' + (r.stderr || '').toString().slice(-200)); };
    png(Buffer.from(rgb), 'rgb24', path.join(args.preview, 'original.png')); png(a8, 'gray', path.join(args.preview, 'alpha.png')); png(f8, 'rgb24', path.join(args.preview, 'fgr.png'));
    say('preview ' + W + 'x' + H); say('done');
    return;
  }

  /* decode */
  const decArgs = ['-hide_banner', '-loglevel', 'error'];
  if (START > 0) decArgs.push('-ss', String(START));
  decArgs.push('-i', IN, '-an', '-sn');
  if (DURATION > 0) decArgs.push('-frames:v', String(total + SKIP));   /* exact frame counts, so segments join without a seam */
  decArgs.push('-pix_fmt', 'rgb24', '-f', 'rawvideo', '-threads', String(THREADS), 'pipe:1');
  const dec = spawn(FFMPEG, decArgs, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let decErr = ''; dec.stderr.on('data', (d) => { decErr += d; });
  const next = frameReader(dec.stdout, W * H * 3);

  /* encode */
  const alpha = BG === 'none';
  const encArgs = ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', alpha ? 'rgba' : 'rgb24', '-s', W + 'x' + H, '-r', String(fps), '-i', 'pipe:0'];
  /* ProRes 4444 keeps the transparency. prores_aw writes the full-fat version Premiere expects; prores_ks can aim
     at a bitrate instead, which is a few times smaller for the same picture. */
  const q = ENC === 'small' ? 11 : ENC === 'medium' ? 6 : 0;
  if (!q) encArgs.push('-c:v', 'prores_aw', '-profile:v', alpha ? '4' : '3', '-pix_fmt', alpha ? 'yuva444p10le' : 'yuv422p10le', '-vendor', 'apl0');
  else if (alpha) encArgs.push('-c:v', 'prores_ks', '-profile:v', '4444', '-qscale:v', String(q), '-alpha_bits', ENC === 'small' ? '8' : '16', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0');
  else encArgs.push('-c:v', 'prores_ks', '-profile:v', '3', '-qscale:v', String(q), '-pix_fmt', 'yuv422p10le', '-vendor', 'apl0');
  encArgs.push('-threads', String(THREADS), OUT);
  const enc = spawn(FFMPEG, encArgs, { windowsHide: true, stdio: ['pipe', 'ignore', 'pipe'] });
  let encErr = ''; enc.stderr.on('data', (d) => { encErr += d; });
  const encDone = new Promise((res, rej) => { enc.on('close', (c) => c === 0 ? res() : rej(new Error('encoder failed: ' + encErr.slice(-300)))); enc.on('error', rej); });
  const write = (buf) => new Promise((res, rej) => { const ok = enc.stdin.write(buf, (e) => e && rej(e)); if (ok) res(); else enc.stdin.once('drain', res); });

  const plane = H * W;
  const src = (BEN || big) ? null : new Float32Array(3 * H * W);   /* only the whole-frame path needs these */
  const bgR = parseInt(COLOR.slice(0, 2), 16), bgG = parseInt(COLOR.slice(2, 4), 16), bgB = parseInt(COLOR.slice(4, 6), 16);
  const outBytes = alpha ? W * H * 4 : W * H * 3;
  const outBufs = [Buffer.allocUnsafe(outBytes), Buffer.allocUnsafe(outBytes)];   /* two, so a frame can be on its way to the encoder while the next one is composed */
  let outIdx = 0, out = outBufs[0], pending = null;
  let n = 0, lastSay = 0;
  const B = { levels: 0, morph: 0, largest: 0, feather: 0, refine: 0, stab: 0, median: 0, unspill: 0, model: 0, prep: 0, compose: 0, write: 0 };
  let prevA = null, prevRGB = null;   /* the previous frame's matte and picture, for the steady-edge filter */
  let hold = null, before = null, medBuf = null;   /* the frame waiting to be written, and the matte before it */
  let skipped = 0;
  const srcB = (BEN || big) ? null : new Float32Array(3 * H * W);
  const prep = (rgb, dst) => { for (let i = 0, p = 0; i < plane; i++, p += 3) { dst[i] = rgb[p] / 255; dst[plane + i] = rgb[p + 1] / 255; dst[2 * plane + i] = rgb[p + 2] / 255; } };
  const start = (buf) => runFrame(buf, W, H);
  let benA = (BEN || big) ? new Float32Array(plane) : null;
  const alphaOf = (res) => {
    if (!BEN && !big) return res.pha.data;
    maskUp(BEN ? res[benOut].data : res.pha.data, mw, mh, benA, W, H);
    return benA;
  };
  /* overlap: the model runs frame N+1 on the GPU while this thread composes and writes frame N */
  let rgb = await next(); if (!rgb) throw new Error('No frames decoded' + (decErr ? ': ' + decErr.slice(-200) : ''));
  let useA = true; if (!BEN && !big) prep(rgb, src);
  let running = start((BEN || big) ? rgb : src);
  for (;;) {
    let tm = performance.now();
    const res = await running; B.model += performance.now() - tm;
    if (!BEN) { r1 = res.r1o; r2 = res.r2o; r3 = res.r3o; r4 = res.r4o; }
    const rgbNext = await next();
    tm = performance.now();
    if (rgbNext) { if (BEN || big) running = start(rgbNext); else { const buf = useA ? srcB : src; prep(rgbNext, buf); running = start(buf); useA = !useA; } } else running = null;
    B.prep += performance.now() - tm;
    if (skipped < SKIP) {
      /* a skipped run-up frame still updates the steady-edge memory, so the first written frame is not a jump */
      const pw = alphaOf(res);
      if (REFINE) alphaRefine(pw, rgb, W, H);
      if (STAB > 0) { if (prevA) alphaStabilise(pw, rgb, prevA, prevRGB, STAB); else prevA = new Float32Array(plane); prevA.set(pw); prevRGB = rgb; }
      skipped++; if (!rgbNext) break; rgb = rgbNext; continue;
    }
    {
    const phaRaw = alphaOf(res), fgrRaw = (BEN || big) ? null : res.fgr.data;
    let tb = performance.now();
    if (REFINE) alphaRefine(phaRaw, rgb, W, H); B.refine += performance.now() - tb; tb = performance.now();
    if (STAB > 0 && prevA) alphaStabilise(phaRaw, rgb, prevA, prevRGB, STAB);
    if (STAB > 0) { if (!prevA) prevA = new Float32Array(plane); prevA.set(phaRaw); prevRGB = rgb; }
    B.stab += performance.now() - tb;
    /* hold one frame back so the matte can be the middle value of three: single-frame wobble drops out */
    const cur = { rgb: rgb, pha: MED ? Float32Array.from(phaRaw) : phaRaw, fgr: fgrRaw };
    if (MED) {
      if (!hold) { hold = cur; if (!rgbNext) { await emit(hold.rgb, hold.pha, hold.fgr); } else { rgb = rgbNext; continue; } }
      else {
        const mid = medBuf || (medBuf = new Float32Array(plane));
        const tmd = performance.now();
        if (before) alphaMedian3(before, hold.pha, cur.pha, mid); else mid.set(hold.pha);
        B.median += performance.now() - tmd;
        await emit(hold.rgb, mid, hold.fgr);
        before = hold.pha; hold = cur;
        if (!rgbNext) { if (before) alphaMedian3(before, hold.pha, hold.pha, mid); else mid.set(hold.pha); await emit(hold.rgb, mid, hold.fgr); }
      }
    } else await emit(cur.rgb, cur.pha, cur.fgr);
    }
    if (!rgbNext) break;
    rgb = rgbNext;
  }
  await finish();

  async function emit(rgb, pha, fgr) {
    let tb = performance.now();
    if (CONTRAST) alphaLevels(pha, CONTRAST); B.levels += performance.now() - tb; tb = performance.now();
    if (SHRINK) alphaMorph(pha, W, H, SHRINK); B.morph += performance.now() - tb; tb = performance.now();
    if (LARGEST) alphaLargest(pha, W, H, LARGEST); B.largest += performance.now() - tb; tb = performance.now();
    if (FEATHER) alphaFeather(pha, W, H, FEATHER); B.feather += performance.now() - tb;
    /* the exact source colours where the matte is solid; the model's spill-free estimate only across the edge */
    out = outBufs[outIdx]; outIdx ^= 1;
    const tc = performance.now();
    const tu = performance.now();
    if (UNSPILL) bgMap(rgb, pha, W, H); else BGM.ok = false;
    B.unspill += performance.now() - tu;
    const blur = BG === 'blur' ? blurRGB(rgb, W, H, BLUR) : null;
    const compose = (i, x, y, o) => {
      const a = Math.max(0, Math.min(1, pha[i]));
      const mix = fgr ? (a >= 0.9 ? 1 : a <= 0.6 ? 0 : (a - 0.6) / 0.3) : 1, s3 = i * 3;
      const fr = fgr ? rgb[s3] * mix + Math.max(0, Math.min(1, fgr[i])) * 255 * (1 - mix) : rgb[s3];
      const fg = fgr ? rgb[s3 + 1] * mix + Math.max(0, Math.min(1, fgr[plane + i])) * 255 * (1 - mix) : rgb[s3 + 1];
      const fb = fgr ? rgb[s3 + 2] * mix + Math.max(0, Math.min(1, fgr[2 * plane + i])) * 255 * (1 - mix) : rgb[s3 + 2];
      let f0 = fr, f1 = fg, f2 = fb;
      if (BGM.ok && a > 0.02 && a < 0.995) {
        const ci = ((y / BGM.cell) | 0) * BGM.cw + ((x / BGM.cell) | 0);
        if (BGM.n[ci] > 0) { f0 = unspill(fr, a, BGM.r[ci]); f1 = unspill(fg, a, BGM.g[ci]); f2 = unspill(fb, a, BGM.b[ci]); }
      }
      let br = bgR, bgg = bgG, bb = bgB;
      if (blur) { br = sampleBlur(blur, x, y, W, H, 0); bgg = sampleBlur(blur, x, y, W, H, 1); bb = sampleBlur(blur, x, y, W, H, 2); }
      out[o] = f0 * a + br * (1 - a) + 0.5; out[o + 1] = f1 * a + bgg * (1 - a) + 0.5; out[o + 2] = f2 * a + bb * (1 - a) + 0.5;
    };
    if (false) {
      /* (the preview is handled above) */
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const i = y * W + x, s = i * 3, o = (y * W * 2 + x) * 3, o2 = (y * W * 2 + W + x) * 3;
        out[o] = rgb[s]; out[o + 1] = rgb[s + 1]; out[o + 2] = rgb[s + 2];
        if (alpha) { const a = Math.max(0, Math.min(1, pha[i])); const ck = (((x >> 5) + (y >> 5)) & 1) ? 200 : 140; out[o2] = col(i, 0) * a + ck * (1 - a) + 0.5; out[o2 + 1] = col(i, 1) * a + ck * (1 - a) + 0.5; out[o2 + 2] = col(i, 2) * a + ck * (1 - a) + 0.5; }
        else compose(i, x, y, o2);
      }
    } else if (alpha) {
      for (let y = 0, i = 0, o = 0, s3 = 0; y < H; y++) {
        const cy = ((y / BGM.cell) | 0) * BGM.cw;
        for (let x = 0; x < W; x++, i++, o += 4, s3 += 3) {
          const a = pha[i] < 0 ? 0 : pha[i] > 1 ? 1 : pha[i];
          let c0, c1, c2;
          if (a >= 0.9 || !fgr) { c0 = rgb[s3]; c1 = rgb[s3 + 1]; c2 = rgb[s3 + 2]; }
          else {
            const mix = a <= 0.6 ? 0 : (a - 0.6) / 0.3, im = 1 - mix;
            let g0 = fgr[i], g1 = fgr[plane + i], g2 = fgr[2 * plane + i];
            g0 = g0 < 0 ? 0 : g0 > 1 ? 255 : g0 * 255; g1 = g1 < 0 ? 0 : g1 > 1 ? 255 : g1 * 255; g2 = g2 < 0 ? 0 : g2 > 1 ? 255 : g2 * 255;
            c0 = rgb[s3] * mix + g0 * im; c1 = rgb[s3 + 1] * mix + g1 * im; c2 = rgb[s3 + 2] * mix + g2 * im;
          }
          if (BGM.ok && a > 0.02 && a < 0.995) {
            const ci = cy + ((x / BGM.cell) | 0);
            if (BGM.n[ci] > 0) { c0 = unspill(c0, a, BGM.r[ci]); c1 = unspill(c1, a, BGM.g[ci]); c2 = unspill(c2, a, BGM.b[ci]); }
          }
          out[o] = c0 + 0.5; out[o + 1] = c1 + 0.5; out[o + 2] = c2 + 0.5; out[o + 3] = a * 255 + 0.5;
        }
      }
    } else {
      for (let y = 0, i = 0; y < H; y++) for (let x = 0; x < W; x++, i++) compose(i, x, y, i * 3);
    }
    B.compose += performance.now() - tc;
    const tw = performance.now();
    /* hand this frame to the encoder and wait for the previous one instead: the encoder then works while the
       next frame is composed, rather than the two taking turns */
    const mine = write(out);
    if (pending) await pending;
    pending = mine;
    B.write += performance.now() - tw;
    n++;
    if (Date.now() - lastSay > 400 || n === total) { lastSay = Date.now(); say('progress ' + Math.min(1, n / total).toFixed(3)); }
  }

  async function finish() {
    if (pending) await pending;
    enc.stdin.end();
    await encDone;
    if (!n) throw new Error('No frames decoded' + (decErr ? ': ' + decErr.slice(-200) : ''));
    say('frames ' + n);
    if (args.bench) say('bench ' + JSON.stringify(Object.fromEntries(Object.entries(B).map(([k, v]) => [k, +(v / Math.max(1, n)).toFixed(1)]))) + ' ms/frame');
    say('done');
  }
})().catch((e) => { console.error('error: ' + (e.message || e)); process.exit(1); });
