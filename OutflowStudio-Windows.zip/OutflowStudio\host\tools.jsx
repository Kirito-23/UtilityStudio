/*  Outflow Studio - timeline toolbox (ExtendScript, ES3). Requires index.jsx, native.jsx, assist.jsx. */

/*  Move every clip that starts at or after fromSec by delta seconds, each clip
    exactly once. Positions are recorded first; a clip whose start already changed
    (because it moved together with a linked clip) is skipped. Clips are moved in
    timeline order so nothing lands on a clip that has not moved yet.            */
function TL_shiftClips(seq, fromSec, delta, eps) {
    var snap = AS_snapshot(seq);
    var r = AS_settleShift(seq, snap, fromSec, delta, eps);
    return { moved: r.moved, failed: r.failed + r.blocked, skipped: r.already };
}

function TL_selected(seq) {
    var out = [];
    for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var tr = seq.videoTracks[t];
        for (var j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j], s = false; try { s = c.isSelected(); } catch (e) {} if (s) out.push({ clip: c, track: t }); }
    }
    return out;
}

/* audio tracks, the same way C3D_addVideoTrack does the video ones */
function TL_addAudioTrack(seq) {
    var before = seq.audioTracks.numTracks;
    try {
        app.enableQE();
        qe.project.getActiveSequence().addTracks(0, 0, 1, 1, before, 0, 1);
    } catch (e) {}
    return app.project.activeSequence.audioTracks.numTracks > before;
}

/*  The nest clip's own audio. Removing a video TrackItem leaves the linked audio sitting on the timeline,
    so it has to be found and removed too: same project item, and it starts where the video started.     */
function TL_linkedAudio(seq, clip) {
    var out = [];
    var nid = null;
    try { nid = clip.projectItem.nodeId; } catch (e0) {}
    if (!nid) return out;
    var s = clip.start.seconds, e = clip.end.seconds;
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
        var tr = seq.audioTracks[t];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j], id = null;
            try { id = c.projectItem.nodeId; } catch (e1) {}
            if (id !== nid) continue;
            if (Math.abs(c.start.seconds - s) < 0.02 && Math.abs(c.end.seconds - e) < 0.02) out.push(c);
        }
    }
    return out;
}

/* the audio Premiere put down along with a video placed at "at" from this item: same item, same start, any length */
function TL_audioPlacedWith(seq, item, at) {
    var out = [], nid = null;
    try { nid = item.nodeId; } catch (e0) {}
    if (!nid) return out;
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
        var tr = seq.audioTracks[t];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j], id = null;
            try { id = c.projectItem.nodeId; } catch (e1) {}
            if (id === nid && Math.abs(c.start.seconds - at) < 0.02) out.push(c);
        }
    }
    return out;
}
/* is this stretch of the track empty? */
function TL_trackFree(track, s, e) {
    for (var j = 0; j < track.clips.numItems; j++) { var c = track.clips[j]; if (c.start.seconds < e - 0.001 && c.end.seconds > s + 0.001) return false; }
    return true;
}
/* one placed clip, cut down to the piece of source that was showing inside the nest */
function TL_trimPlaced(placed, at, len, srcIn, warnings, label) {
    try {
        var ip = new Time(); ip.seconds = srcIn;
        var op = new Time(); op.seconds = srcIn + len;
        placed.inPoint = ip; placed.outPoint = op;
        var st = new Time(); st.seconds = at; placed.start = st;
        var en = new Time(); en.seconds = at + len; placed.end = en;
    } catch (e) { warnings.push("trim " + label + ": " + e); }
}

/* un-nest: replace selected nested-sequence clips by the clips inside them, sound and all */
function TL_unnest() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq), done = 0, warnings = [];
        for (var i = 0; i < sel.length; i++) {
            var clip = sel[i].clip, isSeq = false;
            try { isSeq = clip.projectItem.isSequence(); } catch (e0) {}
            if (!isSeq) continue;
            var nested = null;
            for (var s = 0; s < app.project.sequences.numSequences; s++) {
                var sq = app.project.sequences[s];
                try { if (sq.projectItem && sq.projectItem.nodeId === clip.projectItem.nodeId) nested = sq; } catch (e1) {}
                if (!nested && sq.name === clip.projectItem.name) nested = sq;
            }
            if (!nested) { warnings.push(clip.name + ": nested sequence not found"); continue; }
            var pStart = clip.start.seconds, pEnd = clip.end.seconds, pIn = clip.inPoint.seconds, base = sel[i].track;
            var span = pEnd - pStart;
            /*  The nest goes FIRST - the video clip and the audio linked to it - so its own tracks are free
                for what was inside. Removing it last was why everything came out one track up.          */
            var strays = TL_linkedAudio(seq, clip);
            try { clip.remove(false, false); } catch (e4) { warnings.push("could not remove the nest clip"); continue; }
            for (var z = 0; z < strays.length; z++) { try { strays[z].remove(false, false); } catch (e7) { warnings.push("could not remove the nest's audio"); } }
            seq = app.project.activeSequence;
            /* what the video pass placed, so the audio pass does not place the sound of the same item again */
            var placedAV = {};
            var keyOf = function (c, s0) { var id = ""; try { id = String(c.projectItem.nodeId); } catch (ek) {} return id + "@" + (c.inPoint.seconds + (s0 - c.start.seconds)).toFixed(3); };
            for (var t = 0; t < nested.videoTracks.numTracks; t++) {
                var vt = nested.videoTracks[t];
                for (var j = 0; j < vt.clips.numItems; j++) {
                    var nc = vt.clips[j];
                    var s0 = Math.max(nc.start.seconds, pIn), e0 = Math.min(nc.end.seconds, pIn + span);
                    if (e0 - s0 <= 0.001 || !nc.projectItem) continue;
                    var at = pStart + (s0 - pIn), len = e0 - s0, srcIn = nc.inPoint.seconds + (s0 - nc.start.seconds);
                    /* the track it was on inside the nest, counted from the nest's own track; the next free one above if taken */
                    var need = base + t;
                    while (true) {
                        while (app.project.activeSequence.videoTracks.numTracks <= need) { if (!C3D_addVideoTrack(app.project.activeSequence)) break; }
                        seq = app.project.activeSequence;
                        if (need >= seq.videoTracks.numTracks) break;
                        if (TL_trackFree(seq.videoTracks[need], at, at + len)) break;
                        need++;
                    }
                    if (need >= seq.videoTracks.numTracks) { warnings.push("no track for " + nc.name); continue; }
                    var target = seq.videoTracks[need];
                    var ok = false;
                    try { ok = target.overwriteClip(nc.projectItem, at); } catch (e2) {}
                    if (!ok) { warnings.push("could not place " + nc.name); continue; }
                    var placed = C3D_findClipAt(target, at);
                    if (!placed) { warnings.push("placed but not found: " + nc.name); continue; }
                    TL_trimPlaced(placed, at, len, srcIn, warnings, nc.name);
                    /*  An item with sound arrives with its audio as well (Premiere places both halves): trim
                        that half to the same piece, and remember it so the audio pass leaves it alone.    */
                    var partners = TL_audioPlacedWith(seq, nc.projectItem, at);
                    for (var q = 0; q < partners.length; q++) TL_trimPlaced(partners[q], at, len, srcIn, warnings, "the audio of " + nc.name);
                    placedAV[keyOf(nc, s0)] = true;
                }
            }
            /*  The sound inside the nest that did not come along with a picture: music, voice-over, audio
                the nest had unlinked. Back onto the audio track it was on inside the nest, or the next free
                one when that stretch is taken.                                                           */
            for (var at2 = 0; at2 < nested.audioTracks.numTracks; at2++) {
                var atr = nested.audioTracks[at2];
                for (var k = 0; k < atr.clips.numItems; k++) {
                    var ac = atr.clips[k];
                    var as0 = Math.max(ac.start.seconds, pIn), ae0 = Math.min(ac.end.seconds, pIn + span);
                    if (ae0 - as0 <= 0.001 || !ac.projectItem) continue;
                    if (placedAV[keyOf(ac, as0)]) continue;
                    var aAt = pStart + (as0 - pIn), aLen = ae0 - as0, aSrcIn = ac.inPoint.seconds + (as0 - ac.start.seconds);
                    var needA = at2;
                    while (true) {
                        while (app.project.activeSequence.audioTracks.numTracks <= needA) { if (!TL_addAudioTrack(app.project.activeSequence)) break; }
                        seq = app.project.activeSequence;
                        if (needA >= seq.audioTracks.numTracks) break;
                        if (TL_trackFree(seq.audioTracks[needA], aAt, aAt + aLen)) break;
                        needA++;
                    }
                    if (needA >= seq.audioTracks.numTracks) { warnings.push("no audio track for " + ac.name); continue; }
                    var targetA = seq.audioTracks[needA];
                    var aok = false;
                    try { aok = targetA.overwriteClip(ac.projectItem, aAt); } catch (e5) {}
                    if (!aok) { warnings.push("could not place the audio of " + ac.name); continue; }
                    var pa = C3D_findClipAt(targetA, aAt);
                    if (pa) TL_trimPlaced(pa, aAt, aLen, aSrcIn, warnings, "the audio of " + ac.name);
                }
            }
            done++;
        }
        if (!done) return C3D_err("Select a nested sequence clip first.");
        return C3D_json({ ok: true, done: done, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

function TL_sourceSize(item) {
    var w = 0, h = 0;
    try {
        var xmp = item.getProjectMetadata();
        var m = /VideoInfo[^>]*>\s*(\d+)\s*x\s*(\d+)/i.exec(xmp);
        if (m) { w = parseInt(m[1], 10); h = parseInt(m[2], 10); }
    } catch (e) {}
    return { w: w, h: h };
}

/* mode: "fit" | "fill" */
function TL_fitToFrame(mode) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
        var sel = TL_selected(seq), done = 0, warnings = [];
        for (var i = 0; i < sel.length; i++) {
            var clip = sel[i].clip;
            var sz = TL_sourceSize(clip.projectItem);
            if (!sz.w || !sz.h) { warnings.push(clip.name + ": source size unknown"); continue; }
            var sc = (mode === "fill" ? Math.max(W / sz.w, H / sz.h) : Math.min(W / sz.w, H / sz.h)) * 100;
            var comps = C3D_findComponents(clip);
            if (!comps.motion) { warnings.push(clip.name + ": no Motion"); continue; }
            try { comps.motion.properties[1].setValue(sc, true); done++; } catch (e1) { warnings.push(clip.name + ": " + e1); }
        }
        if (!done && !sel.length) return C3D_err("Select clips first.");
        return C3D_json({ ok: true, done: done, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

function TL_renameSelected(pattern) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (!sel.length) return C3D_err("Select clips first.");
        sel.sort(function (a, b) { return a.clip.start.seconds - b.clip.start.seconds; });
        for (var i = 0; i < sel.length; i++) {
            var n = String(pattern).replace(/\{n\}/g, String(i + 1)).replace(/\{nn\}/g, (i + 1 < 10 ? "0" : "") + (i + 1)).replace(/\{name\}/g, sel[i].clip.name);
            try { sel[i].clip.name = n; } catch (e1) {}
        }
        return C3D_json({ ok: true, done: sel.length });
    } catch (e) { return C3D_err(e); }
}

function TL_labelSelected(labelIndex) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq), done = 0, errors = [];
        if (!sel.length) return C3D_err("Select clips first.");
        for (var i = 0; i < sel.length; i++) {
            var clip = sel[i].clip, ok = false, item = null;
            try { item = clip.projectItem; } catch (e0) {}
            /* 1) the clip itself (newer builds), 2) its project item, 3) string index */
            try { if (clip.setColorLabel) { clip.setColorLabel(labelIndex); ok = true; } } catch (e1) { errors.push("clip: " + e1); }
            if (!ok && item) { try { item.setColorLabel(labelIndex); ok = true; } catch (e2) { errors.push("item: " + e2); } }
            if (!ok && item) { try { item.setColorLabel(String(labelIndex)); ok = true; } catch (e3) { errors.push("item(str): " + e3); } }
            if (!ok && item) {
                try {
                    app.enableQE();
                    var qi = qe.project.getItemAt ? null : null;
                    if (item.setColorLabel === undefined) errors.push("setColorLabel not available in this Premiere version");
                } catch (e4) {}
            }
            if (ok) done++;
        }
        if (!done) return C3D_err("Could not set the label. " + (errors.length ? errors[0] : ""));
        return C3D_json({ ok: true, done: done, warnings: done < sel.length ? [errors[0] || "some clips skipped"] : [] });
    } catch (e) { return C3D_err(e); }
}

function TL_deleteDisabled() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var list = [], t, j;
        for (t = 0; t < seq.videoTracks.numTracks; t++) { var vt = seq.videoTracks[t]; for (j = 0; j < vt.clips.numItems; j++) { var c = vt.clips[j]; var d = false; try { d = c.disabled; } catch (e0) {} if (d) list.push({ s: c.start.seconds, e: c.end.seconds }); } }
        for (t = 0; t < seq.audioTracks.numTracks; t++) { var at = seq.audioTracks[t]; for (j = 0; j < at.clips.numItems; j++) { var a = at.clips[j]; var da = false; try { da = a.disabled; } catch (e1) {} if (da) list.push({ s: a.start.seconds, e: a.end.seconds }); } }
        if (!list.length) return C3D_err("No disabled clips found.");
        list.sort(function (a, b) { return a.s - b.s; });
        var cuts = [], cur = null;
        for (var i = 0; i < list.length; i++) { if (cur && list[i].s <= cur[1] + 0.001) cur[1] = Math.max(cur[1], list[i].e); else { cur = [list[i].s, list[i].e]; cuts.push(cur); } }
        return AS_applyCuts(C3D_json({ cuts: cuts, mode: "ripple", label: "disabled" }));
    } catch (e) { return C3D_err(e); }
}

function TL_closeGaps() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var fps = AS_fps(seq), eps = 0.5 / fps;
        /* union of occupied ranges over all tracks -> gaps */
        var ranges = [], t, j;
        for (t = 0; t < seq.videoTracks.numTracks; t++) { var vt = seq.videoTracks[t]; for (j = 0; j < vt.clips.numItems; j++) ranges.push([vt.clips[j].start.seconds, vt.clips[j].end.seconds]); }
        for (t = 0; t < seq.audioTracks.numTracks; t++) { var at = seq.audioTracks[t]; for (j = 0; j < at.clips.numItems; j++) ranges.push([at.clips[j].start.seconds, at.clips[j].end.seconds]); }
        if (!ranges.length) return C3D_err("The sequence is empty.");
        ranges.sort(function (a, b) { return a[0] - b[0]; });
        var merged = [], cur = null;
        for (var i = 0; i < ranges.length; i++) { if (cur && ranges[i][0] <= cur[1] + eps) cur[1] = Math.max(cur[1], ranges[i][1]); else { cur = [ranges[i][0], ranges[i][1]]; merged.push(cur); } }
        var gaps = [];
        if (merged[0][0] > eps) gaps.push([0, merged[0][0]]);
        for (var g = 1; g < merged.length; g++) gaps.push([merged[g - 1][1], merged[g][0]]);
        if (!gaps.length) return C3D_json({ ok: true, closed: 0 });
        var closed = 0;
        for (var k = gaps.length - 1; k >= 0; k--) {
            var r = TL_shiftClips(app.project.activeSequence, gaps[k][1], -(gaps[k][1] - gaps[k][0]), eps);
            if (r.moved) closed++;
        }
        return C3D_json({ ok: true, closed: closed, gaps: gaps.length });
    } catch (e) { return C3D_err(e); }
}

/* transitions at the cuts between consecutive selected clips */
/*  o = { name: "Constant Power", frames }: an audio transition on every internal cut of every audio track */
/*  One crossfade at a cut, and a check that it is the length asked for. QE's addTransition takes the
    duration as a string whose unit has never been documented: a bare number was ignored, a seconds value
    came out huge, a timecode came out one-sided. So the transition that actually landed is read back
    from the track (duration, start, end) and the first form that yields the right length is kept and
    used for the rest of the run; what was read is logged either way, so a wrong guess is visible.   */
var TL_fadeForm = null, TL_fadeAlign = null, TL_fadeCentre = -1;
/* a QE time value as seconds: a QETime object (ticks / secs / frames), a timecode string, ticks, or seconds */
function TL_qeTimeSecs(v, fps) {
    if (v === null || v === undefined) return -1;
    if (typeof v === "object") {
        var got;
        try { got = v.ticks; if (got !== undefined && got !== null && String(got) !== "") return parseFloat(String(got)) / 254016000000; } catch (e1) {}
        try { got = v.secs; if (got !== undefined && got !== null && String(got) !== "") return parseFloat(String(got)); } catch (e2) {}
        try { got = v.seconds; if (got !== undefined && got !== null && String(got) !== "") return parseFloat(String(got)); } catch (e3) {}
        try { got = v.frames; if (got !== undefined && got !== null && String(got) !== "") return parseFloat(String(got)) / fps; } catch (e4) {}
        try { got = v.timecode; if (got !== undefined && got !== null && String(got) !== "") return TL_qeSeconds(String(got), fps); } catch (e5) {}
        return -1;
    }
    return TL_qeSeconds(v, fps);
}
/* what an object offers, for the log: ExtendScript's reflection works on the host's QE objects too */
function TL_describe(x) {
    var props = [], meths = [];
    try { var ps = x.reflect.properties; for (var i = 0; i < ps.length; i++) props.push(ps[i].name); } catch (e1) {}
    try { var ms = x.reflect.methods; for (var j = 0; j < ms.length; j++) meths.push(ms[j].name); } catch (e2) {}
    return "props[" + props.join(",") + "] methods[" + meths.join(",") + "]";
}
var TL_described = false;
function TL_readTransitions(qt, fps) {
    var out = [];
    try {
        var n = 0; try { n = qt.numTransitions; } catch (e0) {}
        for (var i = 0; i < n; i++) {
            var x = qt.getTransitionAt(i), rec = { obj: x };
            if (!TL_described) { TL_described = true; C3D_log("TL_readTransitions", "track " + TL_describe(qt)); C3D_log("TL_readTransitions", "transition " + TL_describe(x)); try { C3D_log("TL_readTransitions", "start " + TL_describe(x.start)); } catch (eS) {} }
            try { rec.name = String(x.name); } catch (e1) {}
            try { rec.start = TL_qeTimeSecs(x.start, fps); } catch (e2) { rec.start = -1; }
            try { rec.end = TL_qeTimeSecs(x.end, fps); } catch (e3) { rec.end = -1; }
            try { rec.duration = TL_qeTimeSecs(x.duration, fps); } catch (e4) { rec.duration = -1; }
            if (rec.duration < 0 && rec.start >= 0 && rec.end >= 0) rec.duration = rec.end - rec.start;
            out.push(rec);
        }
    } catch (e5) {}
    return out;
}
/* seconds from whatever a QE time string is: timecode, ticks, or seconds */
function TL_qeSeconds(v, fps) {
    var s = String(v || "");
    if (s.indexOf(":") >= 0 || s.indexOf(";") >= 0) { var p = s.split(/[:;]/); if (p.length === 4) return (+p[0]) * 3600 + (+p[1]) * 60 + (+p[2]) + (+p[3]) / fps; }
    var n = parseFloat(s); if (isNaN(n)) return -1;
    if (n > 1e6) return n / 254016000000;
    return n;
}
function TL_addFade(item, qt, tr, cutSec, frames, fps, drop, warnings, label) {
    var want = frames / fps, tol = 0.6 / fps;
    /*  A crossfade straddles the cut, so it is two frames at the least - one each side. Asked for one,
        Premiere makes a one-sided fade instead.                                                          */
    if (frames < 2) frames = 2; want = frames / fps;
    var forms = [
        { name: "timecode", dur: AS_timecode(frames / fps, fps, drop), off: AS_timecode(0, fps, drop) },
        { name: "ticks", dur: String(Math.round(frames / fps * 254016000000)), off: "0" },
        { name: "seconds", dur: (frames / fps).toFixed(4), off: "0.0" },
        { name: "frames", dur: String(frames), off: "0" }
    ];
    /*  Where it sits: 0.5 was meant as "centred" but read back as ending at the cut. The alignment is
        searched like the length was - a candidate is kept when what comes back straddles the cut.     */
    var aligns = TL_fadeAlign !== null ? [TL_fadeAlign] : [0.5, 1, 0, 2, 0.0];
    var straddles = function (g) { return g && g.start <= cutSec - want / 2 + tol && g.end >= cutSec + want / 2 - tol; };
    var order = [];
    if (TL_fadeForm) order.push(TL_fadeForm);
    for (var i = 0; i < forms.length; i++) if (!TL_fadeForm || forms[i].name !== TL_fadeForm.name) order.push(forms[i]);
    var before = TL_readTransitions(qt, fps).length;
    /* the transition at this cut: whichever spans the cut time, else the newest */
    /*  The transition at this cut. The track's list also yields records with an end of 360000 s (a hundred
        hours: an unset end) that "span" every cut - those are ignored, and of the rest the SHORTEST one
        touching the cut is the one just added.                                                          */
    var atCut = function () {
        var list = TL_readTransitions(qt, fps), got = null;
        for (var k = 0; k < list.length; k++) {
            var r = list[k];
            if (!(r.start >= 0 && r.end >= 0) || r.duration > 60 || r.end > 100000) continue;
            if (r.start <= cutSec + tol && r.end >= cutSec - tol && (!got || r.duration < got.duration)) got = r;
        }
        return got;
    };
    var describe = function (g) { return g ? "start " + g.start.toFixed(3) + " end " + g.end.toFixed(3) + " len " + g.duration.toFixed(3) + "s (wanted " + want.toFixed(3) + ")" : "nothing read back"; };
    /*  Once a form and alignment have been proven at a cut they are used for every cut after it, whatever
        the readback says: a cut where Premiere could only fit a shorter, one-sided fade (no media handle
        on one side) is Premiere's best, and trying the other forms there stacked extra transitions.   */
    if (TL_fadeForm && TL_fadeAlign !== null) {
        try { item.addTransition(tr, false, TL_fadeForm.dur, TL_fadeForm.off, TL_fadeAlign, false, true); } catch (e0) { warnings.push(label + " cut " + cutSec.toFixed(2) + ": " + e0); return false; }
        var seen = atCut();
        C3D_log("TL_addFade", "proven " + TL_fadeForm.name + " align " + TL_fadeAlign + " -> " + describe(seen) + " cut " + cutSec.toFixed(3) + (straddles(seen) ? " CENTRED" : seen ? " (as Premiere could fit it)" : ""));
        return true;
    }
    for (var f = 0; f < order.length; f++) {
        var form = order[f], got = null;
        for (var ai = 0; ai < aligns.length; ai++) {
            try { item.addTransition(tr, false, form.dur, form.off, aligns[ai], false, true); } catch (e1) { C3D_log("TL_addFade", form.name + " threw: " + e1); got = null; break; }
            got = atCut();
            C3D_log("TL_addFade", form.name + " align " + aligns[ai] + " -> " + describe(got) + " cut " + cutSec.toFixed(3) + (straddles(got) ? " CENTRED" : ""));
            if (!got) break;
            if (Math.abs(got.duration - want) <= tol && straddles(got)) { TL_fadeForm = form; TL_fadeAlign = aligns[ai]; return true; }
            /* the right length on the wrong side: the transition's own alignment, if it takes one */
            if (Math.abs(got.duration - want) <= tol) {
                var ways = [function () { got.obj.alignment = 0.5; }, function () { got.obj.alignment = 1; }, function () { got.obj.alignment = "Center at Cut"; }, function () { got.obj.alignment = 2; }];
                for (var w = 0; w < ways.length; w++) { try { ways[w](); } catch (e3) { continue; } var g2 = atCut(); if (straddles(g2)) { C3D_log("TL_addFade", "centred through the alignment property (way " + w + "): " + describe(g2)); TL_fadeForm = form; TL_fadeAlign = aligns[ai]; TL_fadeCentre = w; return true; } }
                /* the ends themselves, when they can be moved */
                try { got.obj.start = String(Math.round((cutSec - want / 2) * 254016000000)); got.obj.end = String(Math.round((cutSec + want / 2) * 254016000000)); var g3 = atCut(); if (straddles(g3)) { C3D_log("TL_addFade", "centred by moving its ends: " + describe(g3)); TL_fadeForm = form; TL_fadeAlign = aligns[ai]; return true; } } catch (e4) {}
            }
        }
        if (!got) { if (!TL_fadeForm) TL_fadeForm = form; return true; }      /* no way to check: keep the first form that did not throw */
        if (Math.abs(got.duration - want) <= tol) { TL_fadeForm = form; TL_fadeAlign = aligns[aligns.length - 1]; warnings.push(label + ": crossfade is the right length but sits on one side of the cut"); return true; }
        /*  The wrong length: before the next form, try to set the length on the transition itself, through
            whatever the object offers - a setter, a writable duration, or its ends.                      */
        var ticks = String(Math.round(want * 254016000000)), fixed = false;
        var tries = [
            function () { got.obj.setDuration(ticks); }, function () { got.obj.setDuration(want); }, function () { got.obj.setDuration(AS_timecode(want, fps, drop)); },
            function () { got.obj.duration = ticks; }, function () { got.obj.duration = want; },
            function () { got.obj.setEnd(String(Math.round((cutSec + want / 2) * 254016000000))); got.obj.setStart(String(Math.round((cutSec - want / 2) * 254016000000))); }
        ];
        for (var ti = 0; ti < tries.length && !fixed; ti++) {
            try { tries[ti](); } catch (e2) { continue; }
            var again = atCut();
            if (again && Math.abs(again.duration - want) <= tol) { fixed = true; C3D_log("TL_addFade", "length set on the transition itself (way " + ti + "): " + describe(again)); }
        }
        if (fixed) { TL_fadeForm = form; return true; }
        /* the next form replaces it at the same cut (a transition on a cut that has one takes its place) */
    }
    warnings.push(label + ": crossfade could not be verified (" + describe(atCut()) + ", cut " + cutSec.toFixed(3) + ")");
    return true;
}

function TL_audioTransitions(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        var tr = null;
        try { tr = qe.project.getAudioTransitionByName(o.name || "Constant Power"); } catch (e0) {}
        if (!tr) { try { tr = qe.project.getAudioTransitionByName("Constant Power"); } catch (e1) {} }
        if (!tr) return C3D_err("Audio transition not found: " + o.name);
        var fps = AS_fps(seq), eps = 0.5 / fps, done = 0, warnings = [];
        var drop = false; try { drop = AS_isDropFrame(qeSeq, seq, fps); } catch (eDf) {}
        TL_fadeForm = null; TL_fadeAlign = null; TL_fadeCentre = -1; TL_described = false;
        for (var t = 0; t < seq.audioTracks.numTracks; t++) {
            var track = seq.audioTracks[t], qt = null;
            try { qt = qeSeq.getAudioTrackAt(t); } catch (e2) {}
            if (!qt || !track.clips.numItems) continue;
            /* pair DOM clips with QE items in order (QE lists gaps as Empty items) */
            var qItems = [];
            for (var q = 0; q < qt.numItems; q++) { var it = null; try { it = qt.getItemAt(q); } catch (e3) {} if (it && String(it.type) !== "Empty" && String(it.name) !== "") qItems.push(it); }
            if (qItems.length !== track.clips.numItems) { warnings.push("A" + (t + 1) + ": " + qItems.length + " QE items vs " + track.clips.numItems + " clips, skipped"); continue; }
            for (var j = 0; j < track.clips.numItems - 1; j++) {
                var c = track.clips[j], n = track.clips[j + 1];
                if (Math.abs(n.start.seconds - c.end.seconds) > eps) continue;      /* not a cut, a gap */
                var ok = TL_addFade(qItems[j], qt, tr, c.end.seconds, o.frames || 2, fps, drop, warnings, "A" + (t + 1));
                if (ok) done++;
            }
        }
        C3D_log("TL_audioTransitions", (o.name || "Constant Power") + " " + (o.frames || 2) + "f: " + done + " added, " + warnings.length + " warnings");
        return C3D_json({ ok: true, done: done, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

function TL_transitions(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (o.all) {
            sel = [];
            var trackIdx = (o.track !== undefined && o.track >= 0) ? o.track : 0;
            var tr0 = seq.videoTracks[trackIdx];
            if (tr0) for (var q = 0; q < tr0.clips.numItems; q++) sel.push({ clip: tr0.clips[q], track: trackIdx });
        }
        if (sel.length < 1) return C3D_err("Select the clips first.");
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        var tr = null;
        try { tr = qe.project.getVideoTransitionByName(o.name); } catch (e0) {}
        if (!tr) return C3D_err("Transition not found: " + o.name);
        var done = 0, warnings = [];
        sel.sort(function (a, b) { return a.clip.start.seconds - b.clip.start.seconds; });
        /*  One selected clip has no cut inside the selection, so nothing used to be tried and the message
            blamed Premiere (the Mac report of 2026-09-15). A single clip gets the transition on both of its
            ends instead, which is what people mean when they select one clip and ask for a dissolve.  */
        var edges = !!o.edges || sel.length === 1;
        var tried = 0;
        for (var i = 0; i < sel.length; i++) {
            var qc = C3D_qeClipAt(qeSeq, sel[i].track, sel[i].clip.start.seconds);
            if (!qc) { warnings.push("QE clip not found: " + sel[i].clip.start.seconds.toFixed(2)); continue; }
            var atStart = (i > 0 || edges), atEnd = (i < sel.length - 1 || edges);
            var ok = false, why = "";
            if (atStart) { tried++; try { qc.addTransition(tr, true, o.duration, "0", 1, false, true); ok = true; } catch (e1) { try { qc.addTransition(tr, true); ok = true; } catch (e2) { why = String(e2); } } }
            if (atEnd) { tried++; try { qc.addTransition(tr, false, o.duration, "0", 1, false, true); ok = true; } catch (e3) { try { qc.addTransition(tr, false); ok = true; } catch (e4) { why = String(e4); } } }
            if (ok) done++; else if (why) warnings.push("clip at " + sel[i].clip.start.seconds.toFixed(2) + ": " + why);
        }
        if (!done) {
            if (!tried) return C3D_err("No cut inside the selection. Select two clips that meet, or one clip to dissolve its ends.");
            return C3D_err("Premiere refused to add the transition" + (warnings.length ? " (" + warnings[0] + ")" : "") + ". Clips at the very start of the sequence, or with no handles, cannot take one.");
        }
        return C3D_json({ ok: true, done: done, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/*  Still images cannot take keyframes through the API. Wrap the still in a nested
    sequence (a cleared clone of the active one, so size/fps match) and return the
    nested sequence's project item; the outer clip is video-type and keyframes fine. */
function TL_nestStill(seq, item, duration, name) {
    var before = {}, i;
    for (i = 0; i < app.project.sequences.numSequences; i++) before[app.project.sequences[i].sequenceID] = true;
    try { seq.clone(); } catch (e0) { return null; }
    var nested = null;
    for (i = 0; i < app.project.sequences.numSequences; i++) { var s = app.project.sequences[i]; if (!before[s.sequenceID]) nested = s; }
    if (!nested) return null;
    try { nested.name = name; } catch (e1) {}
    C3D_clearSequence(nested);
    /* audio tracks off the nest so no silent audio lands on the main timeline */
    try {
        app.enableQE(); nested.open();
        var qn = qe.project.getActiveSequence();
        for (var a = nested.audioTracks.numTracks - 1; a >= 0; a--) { try { qn.deleteTrack(false, a); } catch (e2) {} }
    } catch (e3) {}
    try { var t0 = new Time(); t0.ticks = "0"; nested.videoTracks[0].overwriteClip(item, t0); var inner = C3D_findClipAt(nested.videoTracks[0], 0); if (inner) { var en = new Time(); en.seconds = duration; inner.end = en; } } catch (e4) {}
    try { seq.open(); } catch (e5) {}
    try { app.project.openSequence(seq.sequenceID); } catch (e6) {}
    var pi = null; try { pi = nested.projectItem; } catch (e7) {}
    if (!pi) { var root = app.project.rootItem; for (var k = 0; k < root.children.numItems; k++) { var c = root.children[k]; var isSeq = false; try { isSeq = c.isSequence(); } catch (e8) {} if (isSeq && c.name === name) pi = c; } }
    return pi;
}

/* o = { path, start, duration, scale, posX, posY (0..1), opacity, name, track (-1 = new top), cropKeys, nest } */
function TL_placeImage(json) {
    try {
        C3D_KEYS_WRITTEN = 0;
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var root = app.project.rootItem;
        var bin = C3D_toolBin("Outflow Tools") || root;
        var item = C3D_importPath(o.path, bin);
        if (!item) return C3D_err("Could not import " + o.path);
        var nestedItem = null;
        if (o.cropKeys && o.cropKeys.length > 1 || o.nest) {
            nestedItem = TL_nestStill(seq, item, o.duration, (o.name || "Overlay") + " nest");
            if (nestedItem) { try { nestedItem.moveBin(bin); } catch (e00) {} item = nestedItem; }
            seq = app.project.activeSequence;
        }
        if (!C3D_addVideoTrack(seq)) return C3D_err("Could not add a track.");
        seq = app.project.activeSequence;
        var idx = seq.videoTracks.numTracks - 1, track = seq.videoTracks[idx];
        var ok = false;
        try { ok = track.overwriteClip(item, o.start); } catch (e1) {}
        if (!ok) return C3D_err("Could not place the image.");
        var clip = C3D_findClipAt(track, o.start);
        if (!clip) return C3D_err("Placed but not found.");
        try { var en = new Time(); en.seconds = o.start + o.duration; clip.end = en; } catch (e2) {}
        try { clip.name = o.name || "Overlay"; } catch (e3) {}
        var comps = C3D_findComponents(clip), warnings = [];
        if (nestedItem) warnings.length = 0;
        if (comps.motion) {
            try { if (o.scale && !nestedItem) comps.motion.properties[1].setValue(o.scale, true); } catch (e4) { warnings.push("scale: " + e4); }
            try {
                if (o.posX !== undefined) {
                    var pos = comps.motion.properties[0];
                    var norm = C3D_isNormalized(pos);
                    pos.setValue(norm ? [o.posX, o.posY] : [o.posX * seq.frameSizeHorizontal, o.posY * seq.frameSizeVertical], true);
                }
            } catch (e5) { warnings.push("position: " + e5); }
        }
        if (comps.opacity && o.opacity !== undefined) { try { comps.opacity.properties[0].setValue(o.opacity, true); } catch (e6) {} }
        /* optional Crop keyframes (progress bar): o.cropKeys = [[t, right%], ...] */
        if (o.cropKeys && o.cropKeys.length) {
            try {
                app.enableQE();
                var qc = C3D_qeClipAt(qe.project.getActiveSequence(), idx, o.start);
                if (qc && C3D_qeAddEffect(qc, "Crop")) {
                    clip = C3D_findClipAt(app.project.activeSequence.videoTracks[idx], o.start) || clip;
                    var cc = C3D_componentByName(clip, "Crop");
                    var side = o.cropSide || "Right";
                    var prop = cc ? TR_propByName(cc, side) : null;
                    if (prop) { var nk = C3D_setKeys(prop, o.cropKeys, 0, function (kk) { return kk[1]; }, warnings, "crop"); if (!nk) warnings.push("crop keyframes were not written"); }
                    else warnings.push("Crop parameter '" + side + "' not found");
                } else warnings.push("Crop effect not added");
            } catch (e7) { warnings.push("crop: " + e7); }
        }
        return C3D_json({ ok: true, track: idx, nested: !!nestedItem, keyframes: C3D_KEYS_WRITTEN, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/* import an SRT and create a caption track from it */
function TL_captionsFromSRT(path, startAt) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var root = app.project.rootItem;
        var bin = C3D_toolBin("Outflow Captions") || root;
        app.project.importFiles([path], true, bin, false);
        var item = C3D_findItemByPath(bin, path, 0) || C3D_findItemByPath(root, path, 0);
        if (!item && bin.children.numItems) item = bin.children[bin.children.numItems - 1];
        if (!item) return C3D_err("Could not import the SRT file.");
        var fmt = 0;
        try { if (Sequence.CAPTION_FORMAT_SUBTITLE !== undefined) fmt = Sequence.CAPTION_FORMAT_SUBTITLE; } catch (e0) {}
        var ok = false, err = "";
        try { ok = seq.createCaptionTrack(item, startAt || 0, fmt); } catch (e1) { err = String(e1); }
        if (!ok) { try { ok = seq.createCaptionTrack(item, startAt || 0); } catch (e2) { err += " " + e2; } }
        if (!ok) return C3D_err("createCaptionTrack failed (needs Premiere 15.4+). " + err);
        return C3D_json({ ok: true });
    } catch (e) { return C3D_err(e); }
}

function TL_placeAudio(path, start, name) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var root = app.project.rootItem;
        var bin = C3D_toolBin("Outflow Tools") || root;
        var item = C3D_importPath(path, bin);
        if (!item) return C3D_err("Could not import " + path);
        var dur = 1; try { dur = item.getOutPoint().seconds - item.getInPoint().seconds; } catch (e0) {}
        var ai = OS_findFreeAudioTrack(seq, start, start + dur);
        if (ai >= seq.audioTracks.numTracks && !OS_addAudioTrack(seq)) return C3D_err("No free audio track.");
        seq = app.project.activeSequence;
        var track = seq.audioTracks[ai];
        var ok = false;
        try { ok = track.overwriteClip(item, start); } catch (e1) {}
        if (!ok) return C3D_err("Could not place the audio.");
        if (name) { try { var c = C3D_findClipAt(track, start); if (c) c.name = name; } catch (e2) {} }
        return C3D_json({ ok: true, track: ai, duration: dur });
    } catch (e) { return C3D_err(e); }
}

function TL_markers() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var out = [], m = seq.markers.getFirstMarker();
        var guard = 0;
        while (m && guard++ < 5000) { out.push({ start: m.start.seconds, end: m.end.seconds, name: m.name, comments: m.comments }); m = seq.markers.getNextMarker(m); }
        var end = 0; try { end = parseFloat(seq.end) / C3D_TICKS_PER_SECOND; } catch (e0) {}
        return C3D_json({ ok: true, markers: out, duration: end, name: seq.name });
    } catch (e) { return C3D_err(e); }
}

function TL_addMarkers(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var n = 0;
        for (var i = 0; i < o.times.length; i++) { try { var mk = seq.markers.createMarker(o.times[i]); mk.name = (o.name || "beat") + " " + (i + 1); n++; } catch (e1) {} }
        return C3D_json({ ok: true, added: n });
    } catch (e) { return C3D_err(e); }
}

function TL_razorTimes(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence(), fps = AS_fps(seq), n = 0, eps = 0.5 / fps;
        var drop = AS_isDropFrame(qeSeq, seq, fps);
        for (var i = 0; i < o.times.length; i++) { var r = AS_razorVerified(qeSeq, app.project.activeSequence, o.times[i], fps, drop, eps, false); if (r.ok) { n++; drop = r.drop; } }
        return C3D_json({ ok: true, cuts: n });
    } catch (e) { return C3D_err(e); }
}

function TL_exportStills(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var n = 0, warnings = [];
        var qs = null; try { app.enableQE(); qs = qe.project.getActiveSequence(); } catch (eq) {}
        var fps = AS_fps(seq), df = false; try { df = AS_isDropFrame(qs, seq, fps); } catch (ed) {}
        for (var i = 0; i < o.times.length; i++) {
            var t = new Time(); t.seconds = o.times[i];
            var p = o.dir + "/" + (o.prefix || "still") + "_" + (i + 1 < 10 ? "0" : "") + (i + 1) + ".png";
            var wrote = false, called = false;
            try { if (typeof seq.exportFramePNG === "function") { seq.exportFramePNG(t, p); called = true; } } catch (e1) { warnings.push(String(e1)); }
            if (!called && qs) { try { qs.exportFramePNG(AS_timecode(o.times[i], fps, df), ($.os.indexOf("Windows") === 0 ? p.replace(/\//g, "\\") : p)); called = true; } catch (e2) { warnings.push("QE export: " + e2); } }
            if (!called) warnings.push("this Premiere build has no frame export call");
            for (var w = 0; w < 30; w++) { if (new File(p).exists) { wrote = true; break; } $.sleep(100); }
            if (wrote) n++; else warnings.push("frame " + (i + 1) + " was not written (" + p + ")");
        }
        return C3D_json({ ok: true, exported: n, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

function TL_export(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var res = "";
        try { res = String(seq.exportAsMediaDirect(o.out, o.preset, o.inOut ? app.encoder.ENCODE_IN_TO_OUT : app.encoder.ENCODE_ENTIRE)); } catch (e1) { return C3D_err("Export failed: " + e1); }
        var f = new File(o.out);
        return C3D_json({ ok: f.exists, result: res, error: f.exists ? "" : ("Premiere did not write " + o.out + ". " + res) });
    } catch (e) { return C3D_err(e); }
}

/* names of every video effect Premiere knows (for the Quick FX search box) */
function QF_effectList() {
    try {
        app.enableQE();
        var list = null;
        try { list = qe.project.getVideoEffectList(); } catch (e0) {}
        if (!list) { try { list = qe.project.getRemainingVideoEffects(); } catch (e1) {} }
        var out = [];
        if (list) { for (var i = 0; i < list.length; i++) out.push(String(list[i])); }
        return C3D_json({ ok: true, effects: out });
    } catch (e) { return C3D_err(e); }
}

/*  Developer probe: what does Premiere expose about masks on the selected clip? Draw a mask on the clip
    first (any way), select it, run this. Everything is written to the panel log.                    */
function OS_probeMask() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (!sel.length) return C3D_err("Select the clip that has the mask.");
        var clip = sel[0].clip, out = [];
        var names = function (o, what) { var r = []; try { var arr = o.reflect[what]; for (var i = 0; i < arr.length; i++) r.push(String(arr[i].name)); } catch (e) { r.push("(reflect failed: " + e + ")"); } return r; };
        var brief = function (v) { try { if (v === null || v === undefined) return String(v); if (v instanceof Array) return "[" + v.join(",").slice(0, 60) + "]"; return String(v).slice(0, 60); } catch (e) { return "?"; } };
        out.push("ExtendScript clip: " + clip.name + " · components " + clip.components.numItems);
        out.push("clip methods: " + names(clip, "methods").join(" "));
        out.push("clip props: " + names(clip, "properties").join(" "));
        for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i];
            var mn = ""; try { mn = String(comp.matchName); } catch (e0) {}
            out.push("  comp[" + i + "] " + comp.displayName + " (" + mn + ") props " + comp.properties.numItems + " · methods: " + names(comp, "methods").join(" ") + " · fields: " + names(comp, "properties").join(" "));
            for (var k = 0; k < comp.properties.numItems; k++) {
                var pr = comp.properties[k], v = null; try { v = pr.getValue(); } catch (e1) { v = "(no value)"; }
                var pm = ""; try { pm = String(pr.matchName); } catch (e2) {}
                out.push("    prop[" + k + "] " + pr.displayName + " (" + pm + ") = " + brief(v));
            }
        }
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        var qc = C3D_qeClipAt(qeSeq, sel[0].track, clip.start.seconds);
        if (!qc) out.push("QE clip: not found");
        else {
            out.push("QE clip methods: " + names(qc, "methods").join(" "));
            out.push("QE clip props: " + names(qc, "properties").join(" "));
            var nc = 0; try { nc = qc.numComponents; } catch (e3) {}
            for (var c = 0; c < nc; c++) {
                var qcomp = null; try { qcomp = qc.getComponentAt(c); } catch (e4) {}
                if (!qcomp) continue;
                out.push("  QE comp[" + c + "] " + qcomp.name + " · methods: " + names(qcomp, "methods").join(" ") + " · fields: " + names(qcomp, "properties").join(" "));
                var np = 0; try { np = qcomp.numProperties; } catch (e5) {}
                for (var q = 0; q < np; q++) { var qp = null; try { qp = qcomp.getPropertyAt(q); } catch (e6) {} if (qp) { var qv = ""; try { qv = brief(qp.value); } catch (e7) {} out.push("    QE prop[" + q + "] " + qp.name + " = " + qv + " · methods: " + names(qp, "methods").slice(0, 12).join(" ")); } }
            }
        }
        out.push("app.executeCommand: " + (typeof app.executeCommand) + " · qe.executeConsoleCommand: " + (typeof qe.executeConsoleCommand) + " · app methods with mask/tool: " + (function () { var m = names(app, "methods"), r = []; for (var x = 0; x < m.length; x++) if (/mask|tool|command/i.test(m[x])) r.push(m[x]); return r.join(" "); })());
        for (var j = 0; j < out.length; j++) C3D_log("MASKPROBE", out[j]);
        var maskish = []; for (var y = 0; y < out.length && maskish.length < 12; y++) if (/mask/i.test(out[y])) maskish.push(out[y]);
        return C3D_json({ ok: true, lines: out.length, maskish: maskish });
    } catch (e) { return C3D_err(e); }
}

/*  Developer probe 2: can a script add an Opacity effect through QE, and does an unassigned mask on the
    clip then attach itself to it (Premiere does that for effects added by hand)? Reports the component
    list before and after, for several ways of naming the effect.                                     */
function OS_probeAddOpacity() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (!sel.length) return C3D_err("Select the clip with the unassigned mask.");
        var clip = sel[0].clip;
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        var qc = C3D_qeClipAt(qeSeq, sel[0].track, clip.start.seconds);
        if (!qc) return C3D_err("QE clip not found.");
        var list = function () { var r = []; for (var i = 0; i < clip.components.numItems; i++) r.push(clip.components[i].displayName + "(" + clip.components[i].properties.numItems + ")"); return r.join(", "); };
        var out = ["before: " + list()];
        var tries = ["Opacity", "AE.ADBE Opacity", "Alpha Adjust", "Transform"];
        for (var t = 0; t < tries.length; t++) {
            var fx = null, res = "";
            try { fx = qe.project.getVideoEffectByName(tries[t]); } catch (e0) { res = "lookup threw " + e0; }
            if (!fx) { out.push(tries[t] + ": not found" + (res ? " (" + res + ")" : "")); continue; }
            var ok = false; try { ok = qc.addVideoEffect(fx); } catch (e1) { res = "add threw " + e1; }
            out.push(tries[t] + ": add -> " + ok + (res ? " " + res : "") + " · after: " + list());
            if (ok && tries[t] !== "Opacity" && tries[t] !== "AE.ADBE Opacity") break;   /* one extra effect is enough to see the mask move */
        }
        for (var j = 0; j < out.length; j++) C3D_log("MASKPROBE2", out[j]);
        return C3D_json({ ok: true, lines: out });
    } catch (e) { return C3D_err(e); }
}

/*  Mask to Opacity. A mask drawn with Premiere's own mask tools lands under "Unassigned Masks" and has to
    be dragged onto Opacity by hand. Premiere attaches an unassigned mask to whatever effect is added next,
    and it accepts a second Opacity from a script (found 2026-09-15) - so adding one is the drag.       */
function TL_maskToOpacity() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (!sel.length) return C3D_err("Select the clip you drew the mask on.");
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        var fx = null; try { fx = qe.project.getVideoEffectByName("Opacity"); } catch (e0) {}
        if (!fx) return C3D_err("Premiere did not hand out the Opacity effect.");
        var done = 0, warnings = [];
        for (var i = 0; i < sel.length; i++) {
            var qc = C3D_qeClipAt(qeSeq, sel[i].track, sel[i].clip.start.seconds);
            if (!qc) { warnings.push("clip at " + sel[i].clip.start.seconds.toFixed(2) + " not found"); continue; }
            var ok = false; try { ok = qc.addVideoEffect(fx); } catch (e1) { warnings.push(String(e1)); }
            if (ok) done++;
        }
        if (!done) return C3D_err("Premiere refused to add Opacity" + (warnings.length ? " (" + warnings[0] + ")" : "") + ".");
        return C3D_json({ ok: true, done: done, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/*  Developer probe 3: every method and field the scripting objects offer, looking for anything that could
    switch the active tool or run a menu command. qe, qe.project, qe.source, app and its monitors.     */
function OS_probeTools() {
    try {
        var names = function (o, what) { var r = []; try { var arr = o.reflect[what]; for (var i = 0; i < arr.length; i++) r.push(String(arr[i].name)); } catch (e) { r.push("(reflect failed: " + e + ")"); } return r; };
        var targets = [];
        targets.push(["app", app]);
        try { targets.push(["app.sourceMonitor", app.sourceMonitor]); } catch (e1) {}
        try { targets.push(["app.projectManager", app.projectManager]); } catch (e2) {}
        try { targets.push(["app.properties", app.properties]); } catch (e3) {}
        app.enableQE();
        targets.push(["qe", qe]);
        try { targets.push(["qe.project", qe.project]); } catch (e4) {}
        try { targets.push(["qe.source", qe.source]); } catch (e5) {}
        try { targets.push(["qe.project.getActiveSequence()", qe.project.getActiveSequence()]); } catch (e6) {}
        try { targets.push(["qe.ea", qe.ea]); } catch (e7) {}
        var out = [];
        for (var t = 0; t < targets.length; t++) {
            out.push(targets[t][0] + " methods: " + names(targets[t][1], "methods").join(" "));
            out.push(targets[t][0] + " fields: " + names(targets[t][1], "properties").join(" "));
        }
        for (var j = 0; j < out.length; j++) C3D_log("TOOLPROBE", out[j]);
        var hits = []; for (var k = 0; k < out.length; k++) { var m = out[k].match(/\b\w*(tool|command|menu|key|shortcut|mask)\w*/gi); if (m) for (var q = 0; q < m.length; q++) hits.push(m[q]); }
        return C3D_json({ ok: true, lines: out.length, hits: hits });
    } catch (e) { return C3D_err(e); }
}

/*  The undo stack index: it moves when the person does something undoable in Premiere - drawing a mask is
    one such step - and not for a selection or a tool switch. The Mask button watches it while armed.  */
function TL_undoIndex() {
    try {
        app.enableQE();
        var i = qe.project.undoStackIndex();
        return C3D_json({ ok: true, index: Number(i) });
    } catch (e) { return C3D_err(e); }
}

/*  For Auto track: where the playhead stands inside the selected clip, and how long a frame is. The panel
    tracks forward when there is clip after the playhead and backward when there is clip before it.   */
function TL_maskTrackInfo() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (!sel.length) return C3D_err("Select the clip with the mask.");
        var clip = sel[0].clip, at = 0;
        try { at = Number(seq.getPlayerPosition().seconds); } catch (e0) {}
        var frame = 1 / 25; try { frame = Number(seq.timebase) / 254016000000; } catch (e1) {}
        if (!(frame > 0)) frame = 1 / 25;
        return C3D_json({ ok: true, at: at, s: clip.start.seconds, e: clip.end.seconds, frame: frame, name: clip.name });
    } catch (e) { return C3D_err(e); }
}
function TL_setPlayhead(sec) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var tm = new Time(); tm.seconds = Number(sec); seq.setPlayerPosition(tm.ticks);
        return C3D_json({ ok: true });
    } catch (e) { return C3D_err(e); }
}

/*  Duplicate above, part 1. The copy is made by Premiere itself (Copy, then Paste, sent as keys by the
    panel), because a scripted copy loses the clip's effects. This sets the stage: the playhead at the
    clip's start, the first free video track above it as the only targeted track (audio untargeted, so the
    paste brings the video alone), a new track added when none is free.                                 */
function TL_dupPrepare() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (!sel.length) return C3D_err("Select the clip first.");
        var clip = sel[0].clip, from = sel[0].track, s = clip.start.seconds, e = clip.end.seconds;
        var target = -1;
        for (var t = from + 1; t < seq.videoTracks.numTracks; t++) { if (TL_trackFree(seq.videoTracks[t], s, e)) { target = t; break; } }
        if (target < 0) {
            var before = seq.videoTracks.numTracks;
            try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, before, 0, 0, 0, 0, 0); } catch (e0) {}
            if (seq.videoTracks.numTracks <= before) return C3D_err("No free track above the clip, and Premiere would not add one.");
            target = before;
        }
        var warnings = [];
        for (var v = 0; v < seq.videoTracks.numTracks; v++) { try { seq.videoTracks[v].setTargeted(v === target, true); } catch (e1) { warnings.push("target V" + (v + 1) + ": " + e1); } }
        for (var a = 0; a < seq.audioTracks.numTracks; a++) { try { seq.audioTracks[a].setTargeted(false, true); } catch (e2) {} }
        try { var tm = new Time(); tm.seconds = s; seq.setPlayerPosition(tm.ticks); } catch (e3) { warnings.push("playhead: " + e3); }
        return C3D_json({ ok: true, track: target, from: from, start: s, end: e, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}
/*  Duplicate above, part 2: after the paste, the copy on the target track at the start becomes the only
    selected clip, so the mask is drawn on it and Opacity lands on it.                                */
function TL_dupSelect(track, start, from) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var tr = seq.videoTracks[track];
        if (!tr) return C3D_err("Track V" + (track + 1) + " is gone.");
        var copy = null;
        for (var j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j]; if (Math.abs(c.start.seconds - start) < 0.02) { copy = c; break; } }
        if (!copy) return C3D_json({ ok: true, found: false });
        for (var v = 0; v < seq.videoTracks.numTracks; v++) { var vt = seq.videoTracks[v]; for (var k = 0; k < vt.clips.numItems; k++) { try { if (vt.clips[k].isSelected()) vt.clips[k].setSelected(false, true); } catch (e0) {} } }
        for (var a = 0; a < seq.audioTracks.numTracks; a++) { var at = seq.audioTracks[a]; for (var q = 0; q < at.clips.numItems; q++) { try { if (at.clips[q].isSelected()) at.clips[q].setSelected(false, true); } catch (e1) {} } }
        copy.setSelected(true, true);
        return C3D_json({ ok: true, found: true, name: copy.name });
    } catch (e) { return C3D_err(e); }
}

/*  A video-only subclip of one piece of a source, kept in the Outflow > Mask bin and reused by name. Placing
    the whole item put its audio on the timeline too, over whatever was there (found 2026-09-16: a trimmed
    clip came back with its full-length sound and an out-of-sync badge). A subclip with takeAudio = 0 has
    no audio to place. The argument shapes differ between Premiere builds, so two are tried.           */
function TL_videoOnly(item, inSec, outSec, name, warnings) {
    var bin = null; try { bin = C3D_toolBin("Mask"); } catch (e0) {}
    if (bin) { for (var i = 0; i < bin.children.numItems; i++) { var c = bin.children[i]; if (c.name === name && c.type !== ProjectItemType.BIN) return c; } }
    var sub = null;
    try { sub = item.createSubClip(name, inSec, outSec, 0, 1, 0); } catch (e1) {}
    if (!sub) { try { var ti = new Time(); ti.seconds = inSec; var to = new Time(); to.seconds = outSec; sub = item.createSubClip(name, ti, to, 0, 1, 0); } catch (e2) {} }
    if (!sub) { warnings.push("no video-only copy of " + item.name + ", the whole clip was placed"); return null; }
    if (bin) { try { sub.moveBin(bin); } catch (e3) {} }
    return sub;
}
/*  Duplicate above, by script. A video-only subclip of the same piece goes on the first free video track
    above (a track is added when none is free), with the Motion and Opacity values copied across; the copy
    becomes the only selected clip. Keyframed values and other effects are not copied - the warnings say so.
    When the subclip cannot be made (a nest, say) the whole item is placed and its audio removed again. */
function TL_dupAbove() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var sel = TL_selected(seq);
        if (!sel.length) return C3D_err("Select the clip first.");
        var clip = sel[0].clip, from = sel[0].track, s = clip.start.seconds, e = clip.end.seconds, warnings = [];
        var target = -1;
        for (var t = from + 1; t < seq.videoTracks.numTracks; t++) { if (TL_trackFree(seq.videoTracks[t], s, e)) { target = t; break; } }
        if (target < 0) {
            var before = seq.videoTracks.numTracks;
            try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, before, 0, 0, 0, 0, 0); } catch (e0) {}
            if (seq.videoTracks.numTracks <= before) return C3D_err("No free track above the clip, and Premiere would not add one.");
            target = before;
        }
        var srcIn = clip.inPoint.seconds, srcOut = clip.outPoint.seconds;
        var item = TL_videoOnly(clip.projectItem, srcIn, srcOut, clip.name + " (mask copy " + srcIn.toFixed(2) + "-" + srcOut.toFixed(2) + ")", warnings);
        var whole = !item; if (whole) item = clip.projectItem;
        /* the audio clips that were there before, so only what the placement adds is removed again */
        var aBefore = {};
        if (whole) for (var a = 0; a < seq.audioTracks.numTracks; a++) { var atb = seq.audioTracks[a]; for (var b = 0; b < atb.clips.numItems; b++) { try { aBefore[a + ":" + atb.clips[b].start.ticks + ":" + atb.clips[b].end.ticks] = 1; } catch (eb) {} } }
        var tr = seq.videoTracks[target], ok = false;
        try { ok = tr.overwriteClip(item, s); } catch (e1) { warnings.push("place: " + e1); }
        if (!ok) return C3D_err("Premiere would not place the copy on V" + (target + 1) + "." + (warnings.length ? " " + warnings[0] : ""));
        var copy = C3D_findClipAt(tr, s);
        if (!copy) return C3D_err("The copy was placed but not found on V" + (target + 1) + ".");
        /*  The subclip is the piece already; it is only trimmed when its length came out wrong (in which
            case the in point is tried against the source first, then against the subclip's own start). */
        var len = e - s, got = -1; try { got = copy.end.seconds - copy.start.seconds; } catch (eg) {}
        if (whole || Math.abs(got - len) > 0.002) {
            TL_trimPlaced(copy, s, len, srcIn, warnings, "copy");
            try { got = copy.end.seconds - copy.start.seconds; } catch (eg2) {}
            if (!whole && Math.abs(got - len) > 0.002) TL_trimPlaced(copy, s, len, 0, warnings, "copy");
        }
        if (whole) for (var a2 = 0; a2 < seq.audioTracks.numTracks; a2++) {
            var at = seq.audioTracks[a2];
            for (var q = at.clips.numItems - 1; q >= 0; q--) {
                var ac = at.clips[q], key = "";
                try { key = a2 + ":" + ac.start.ticks + ":" + ac.end.ticks; } catch (ek) {}
                var same = false; try { same = String(ac.projectItem.nodeId) === String(clip.projectItem.nodeId); } catch (en) {}
                if (!aBefore[key] && same) { try { ac.remove(false, false); } catch (e2) { warnings.push("audio copy: " + e2); } }
            }
        }
        /* Motion and Opacity, value for value, where nothing is keyframed */
        var NAMES = { "Motion": 1, "Opacity": 1 };
        for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i], nm = String(comp.displayName);
            if (!NAMES[nm]) continue;
            var comp2 = null;
            for (var k = 0; k < copy.components.numItems; k++) { if (String(copy.components[k].displayName) === nm) { comp2 = copy.components[k]; break; } }
            if (!comp2) continue;
            for (var p = 0; p < comp.properties.numItems && p < comp2.properties.numItems; p++) {
                var pr = comp.properties[p], pr2 = comp2.properties[p], tv = false;
                try { tv = pr.isTimeVarying(); } catch (e3) {}
                if (tv) { warnings.push(nm + " " + pr.displayName + " has keyframes, not copied"); continue; }
                var v = null; try { v = pr.getValue(); } catch (e4) { continue; }
                if (v === null || v === undefined) continue;
                try { pr2.setValue(v, true); } catch (e5) {}
            }
        }
        var extra = 0;
        for (var i2 = 0; i2 < clip.components.numItems; i2++) { var n2 = String(clip.components[i2].displayName); if (!NAMES[n2] && n2 !== "Time Remapping") extra++; }
        if (extra) warnings.push(extra + " other effect(s) on the original were not copied");
        for (var v2 = 0; v2 < seq.videoTracks.numTracks; v2++) { var vt = seq.videoTracks[v2]; for (var c2 = 0; c2 < vt.clips.numItems; c2++) { try { if (vt.clips[c2].isSelected()) vt.clips[c2].setSelected(false, true); } catch (e6) {} } }
        for (var a3 = 0; a3 < seq.audioTracks.numTracks; a3++) { var at3 = seq.audioTracks[a3]; for (var c3 = 0; c3 < at3.clips.numItems; c3++) { try { if (at3.clips[c3].isSelected()) at3.clips[c3].setSelected(false, true); } catch (e7) {} } }
        copy.setSelected(true, true);
        return C3D_json({ ok: true, track: target, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}
