/* Local, free transcription with whisper.cpp (github.com/ggerganov/whisper.cpp).
   First use downloads the official Windows build and a ggml model; afterwards
   everything runs offline. Produces word-level timestamps. */
const LocalWhisper = (() => {
  const nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null);
  const cp = nodeReq ? nodeReq('child_process') : null;
  const MODELS = {
    tiny: { name: 'Tiny (75 MB, fastest)', file: 'ggml-tiny.bin' },
    base: { name: 'Base (142 MB, fast)', file: 'ggml-base.bin' },
    small: { name: 'Small (466 MB, accurate)', file: 'ggml-small.bin' },
    medium: { name: 'Medium (1.5 GB, most accurate, slow)', file: 'ggml-medium.bin' }
  };
  const MODEL_URL = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/';

  function home() { return CS.dataDir('whisper'); }
  /* whisper.cpp publishes no Mac binary; Homebrew's whisper-cpp does, as whisper-cli */
  const BREW = ['/opt/homebrew/bin/brew', '/usr/local/bin/brew'];
  const MAC_EXES = ['/opt/homebrew/bin/whisper-cli', '/usr/local/bin/whisper-cli', '/opt/homebrew/bin/whisper-cpp', '/usr/local/bin/whisper-cpp'];
  const macExe = () => { try { return MAC_EXES.find((p) => CS.fs.existsSync(p)) || null; } catch (e) { return null; } };
  /* prefer whisper-cli.exe: in recent releases main.exe is only a deprecation stub that exits with 1 */
  function findExe(dir) {
    const found = [];
    const walk = (d, depth) => {
      if (depth > 4 || !CS.fs.existsSync(d)) return;
      for (const f of CS.fs.readdirSync(d)) {
        const p = CS.path.join(d, f);
        let st; try { st = CS.fs.statSync(p); } catch (e) { continue; }
        if (st.isDirectory()) walk(p, depth + 1);
        else if (/^whisper-cli(\.exe)?$/i.test(f)) found.push({ p, pri: 0 });
        else if (/^main(\.exe)?$/i.test(f)) found.push({ p, pri: 1 });
      }
    };
    walk(dir, 0);
    found.sort((a, b) => a.pri - b.pri);
    return found.length ? found[0].p : null;
  }
  function status() {
    if (!CS.fs || !CS.path) return { exe: null, models: {}, dir: '', isWindows: true };
    const custom = (Hub.keys().whisperExe || '').trim();
    const exe = (custom && CS.fs && CS.fs.existsSync(custom)) ? custom : (CS.fs ? (findExe(home()) || (CS.mac ? macExe() : null)) : null);
    const models = {};
    if (CS.fs) for (const k of Object.keys(MODELS)) models[k] = CS.fs.existsSync(CS.path.join(home(), MODELS[k].file));
    return { exe, models, dir: home(), isWindows: !CS.os || CS.os.platform() === 'win32' };
  }
  function run(cmd, args, onErrLine) {
    return new Promise((resolve, reject) => {
      const p = CS.track(cp.spawn(cmd, args, { windowsHide: true }));
      let out = '', err = '';
      p.stdout.on('data', d => { out += d; });
      p.stderr.on('data', d => { const s = String(d); err += s; if (onErrLine) onErrLine(s); });
      p.on('error', reject);
      p.on('close', (code) => {
        if (p.cancelled) return reject(new Error('Cancelled.'));
        if (code === 0) return resolve({ out, err });
        const base = cmd.replace(/^.*[\\\/]/, '');
        const tail = (err || out || '').trim().split('\n').slice(-4).join(' ').slice(-300);
        reject(new Error(base + ' exited with code ' + code + (tail ? ': ' + tail : '')));
      });
    });
  }
  /*  A Mac without Homebrew: one line in Terminal installs Homebrew and the engine together (Homebrew asks for
      the Mac's password once, that is macOS, not us). Shown as a card with a Copy button, like the Mac install. */
  function macSetupCard() {
    const LINE = '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"; $([ -x /opt/homebrew/bin/brew ] && echo /opt/homebrew/bin/brew || echo /usr/local/bin/brew) install whisper.cpp';
    let m = document.getElementById('mac-whisper-card');
    if (!m) { m = document.createElement('div'); m.className = 'update'; m.id = 'mac-whisper-card'; document.body.appendChild(m); }
    m.innerHTML = '<div class="ubox"><div class="ueyebrow">Transcription on a Mac</div><h2>One Terminal line, once</h2>' +
      '<p class="small">Auto Edit and captions use a transcription engine that installs through Homebrew, the standard Mac installer. It takes a few minutes, once.</p>' +
      '<ul class="ulist"><li>Press <b>Command-Space</b>, type <b>Terminal</b>, press Return.</li><li>Paste the line below and press <b>Return</b>. Type your Mac password when it asks (nothing shows while you type).</li><li>When it says it is done, come back here and press the button again.</li></ul>' +
      '<pre style="white-space:pre-wrap;word-break:break-all;font-size:11px;background:#000;border:1px solid var(--line);border-radius:8px;padding:8px;margin:6px 0">' + LINE.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</pre>' +
      '<div class="ubtns"><button class="primary" id="mac-whisper-copy">Copy the line</button><button class="ghost" id="mac-whisper-close">Close</button></div></div>';
    document.getElementById('mac-whisper-copy').addEventListener('click', (e) => { try { CS.clipboardWrite(LINE); e.target.textContent = 'Copied'; } catch (x) {} });
    document.getElementById('mac-whisper-close').addEventListener('click', () => m.classList.remove('show'));
    m.classList.add('show');
  }
  async function install(onProgress) {
    if (!cp || !CS.fs) throw new Error('Local transcription needs the panel to run inside Premiere Pro.');
    const st = status();
    if (CS.mac) {
      const brew = BREW.find((p) => CS.fs.existsSync(p));
      if (!brew) { macSetupCard(); throw new Error('Set up the transcription engine first: the steps are on screen.'); }
      onProgress(-1, 'Installing the transcription engine through Homebrew (a few minutes, once)');
      /* the formula is called whisper.cpp now (it was whisper-cpp until 2026); the old name as a fallback */
      try { await run(brew, ['install', 'whisper.cpp'], (l) => onProgress(-1, String(l).trim().slice(0, 80))); }
      catch (e) { await run(brew, ['install', 'whisper-cpp'], (l) => onProgress(-1, String(l).trim().slice(0, 80))); }
      const found = macExe();
      if (!found) throw new Error('Homebrew finished but whisper-cli was not found. Set its path as a custom engine in Settings.');
      onProgress(1, 'Transcription engine ready');
      return found;
    }
    /*  No GitHub API here any more: it allows 60 calls an hour per address, shared by everyone behind the
        same one, and answered "rate limit exceeded". And the newest release is not always a build with
        binaries (v1.9.4 carried none, which read as "No Windows build was found"). The newest build is
        tried by its direct link, then a release known to have the Windows zip.                        */
    const NAME = 'whisper-bin-x64.zip', PIN = 'v1.9.2';
    const urls = ['https://github.com/ggml-org/whisper.cpp/releases/latest/download/' + NAME, 'https://github.com/ggml-org/whisper.cpp/releases/download/' + PIN + '/' + NAME];
    const zip = CS.path.join(home(), NAME);
    let got = false, last = null;
    for (const u of urls) {
      onProgress(0, 'Downloading the transcription engine');
      try { await Net.download(u, zip, (p) => onProgress(p * 0.9, 'Downloading the transcription engine' + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : ''))); got = true; break; }
      catch (e) { last = e; if (!/HTTP 40[34]/.test(String((e && e.message) || e))) throw e; }
    }
    if (!got) throw new Error('The transcription engine could not be downloaded: ' + ((last && last.message) || 'no Windows build found'));
    onProgress(0.92, 'Unpacking');
    const dest = CS.path.join(home(), 'bin');
    await CS.unzip(zip, dest);
    try { CS.fs.unlinkSync(zip); } catch (e) {}
    const exe = findExe(dest);
    if (!exe) throw new Error('The transcription engine was not found after unpacking (antivirus?).');
    onProgress(1, 'Transcription engine ready');
    return exe;
  }
  async function ensureModel(key, onProgress) {
    const m = MODELS[key] || MODELS.base;
    const file = CS.path.join(home(), m.file);
    if (CS.fs.existsSync(file)) return file;
    await Net.download(MODEL_URL + m.file, file, (p) => onProgress(p, 'Downloading model ' + m.file + (p >= 0 ? ' · ' + Math.round(p * 100) + '%' : '')));
    return file;
  }
  /*  Long recordings go to the engine in pieces. Whisper works in 30-second windows and carries its
      state along; past a quarter of an hour the word timings drift and it starts inventing words over
      pauses, and every cut that depends on word times lands beside the word it meant. Pieces of about
      ten minutes, cut at the quietest moment near the boundary so no word is split, keep each run short
      enough to stay exact. The pieces are joined with their offsets.                                 */
  /*  Measured on a real 21-minute talk (2026-09-15): one run over the whole file kept its timing to the
      end (0.2 s median against a run of just the tail), while pieces of ten minutes gained nothing and
      invented words over the applause at the very end. So pieces are kept only for recordings so long
      that a single run is a memory risk; a normal long talk goes through whole.                     */
  const PIECE_S = 1800, MAX_SINGLE_S = 3600, SEARCH_S = 20;
  function splitWav16k(wavPath) {
    const buf = CS.fs.readFileSync(wavPath);
    /* the data chunk is not always at byte 44: ffmpeg writes a LIST chunk before it */
    let dataAt = 44, dataLen = buf.length - 44;
    for (let o = 12; o + 8 <= buf.length;) { const id = buf.toString('latin1', o, o + 4), len = buf.readUInt32LE(o + 4); if (id === 'data') { dataAt = o + 8; dataLen = Math.min(len, buf.length - dataAt); break; } o += 8 + len + (len & 1); }
    const n = Math.floor(dataLen / 2), sr = 16000;
    const total = n / sr;
    if (total <= MAX_SINGLE_S) return null;
    const rms = (from, to) => { let s = 0, c = 0; for (let i = from; i < to; i += 4) { const v = buf.readInt16LE(dataAt + i * 2) / 32768; s += v * v; c++; } return c ? Math.sqrt(s / c) : 0; };
    const cuts = [0];
    let at = PIECE_S;
    while (total - at > PIECE_S * 0.5) {
      /* the quietest 300 ms in a window around the wanted boundary */
      let best = at, bestV = Infinity;
      for (let t = at - SEARCH_S; t <= at + SEARCH_S; t += 0.15) {
        const a = Math.floor(t * sr), b = Math.min(n, a + Math.floor(0.3 * sr)); if (a < 0 || b <= a) continue;
        const v = rms(a, b); if (v < bestV) { bestV = v; best = t + 0.15; }
      }
      cuts.push(best); at = best + PIECE_S;
    }
    cuts.push(total);
    const pieces = [];
    for (let i = 0; i + 1 < cuts.length; i++) {
      const a = Math.floor(cuts[i] * sr), b = Math.min(n, Math.floor(cuts[i + 1] * sr)), len = b - a;
      const Buf = window.Buffer || window.cep_node.Buffer;
      const out = Buf.alloc(44 + len * 2);
      /* a plain 44-byte header of its own: 16 kHz, mono, 16-bit */
      out.write('RIFF', 0); out.writeUInt32LE(36 + len * 2, 4); out.write('WAVE', 8); out.write('fmt ', 12); out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20); out.writeUInt16LE(1, 22); out.writeUInt32LE(sr, 24); out.writeUInt32LE(sr * 2, 28); out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34); out.write('data', 36); out.writeUInt32LE(len * 2, 40);
      buf.copy(out, 44, dataAt + a * 2, dataAt + b * 2);
      const file = wavPath.replace(/\.wav$/i, '') + '_p' + (i + 1) + '.wav';
      CS.fs.writeFileSync(file, out);
      pieces.push({ file, offset: a / sr, seconds: len / sr });
    }
    return pieces;
  }
  /* wavPath: 16 kHz mono WAV. Returns [{s, e, w}] in seconds. */
  async function transcribe(wavPath, modelKey, language, onProgress) {
    let st = status();
    if (!st.exe || /[\\\/]main\.exe$/i.test(st.exe)) { st.exe = await install(onProgress); }
    const model = await ensureModel(modelKey, onProgress);
    let pieces = null;
    try { pieces = splitWav16k(wavPath); } catch (e) { pieces = null; }
    if (!pieces) return transcribeOne(st.exe, model, wavPath, modelKey, language, onProgress, 0);
    const words = [];
    const totalS = pieces.reduce((a, p) => a + p.seconds, 0);
    let doneS = 0;
    for (let i = 0; i < pieces.length; i++) {
      const p = pieces[i];
      const sub = (f, t) => onProgress((doneS + f * p.seconds) / totalS, 'Transcribing part ' + (i + 1) + ' of ' + pieces.length + (t && /\d+%/.test(t) ? ' · ' + (/\d+%/.exec(t) || [''])[0] : ''));
      let ws = [];
      try { ws = await transcribeOne(st.exe, model, p.file, modelKey, language, sub, p.offset); }
      catch (e) { if (!/No speech recognised/.test(String(e.message || e))) throw e; }   /* a silent piece is fine */
      for (const w of ws) words.push(w);
      doneS += p.seconds;
      try { CS.fs.unlinkSync(p.file); } catch (e) {}
    }
    if (!words.length) throw new Error('No speech recognised.');
    return words;
  }
  async function transcribeOne(exePath, model, wavPath, modelKey, language, onProgress, offset) {
    const outBase = wavPath.replace(/\.wav$/i, '') + '_tr';
    const threads = Math.max(2, Math.min(8, (CS.os ? CS.os.cpus().length : 4) - 1));
    const args = ['-m', model, '-f', wavPath, '-l', language || 'auto', '-oj', '-ojf', '-of', outBase, '-ml', '1', '-sow', '-t', String(threads), '-pp'];
    onProgress(0, 'Transcribing (' + (modelKey || 'base') + ')');
    const watch = (line) => { const m = /progress\s*=\s*(\d+)%/.exec(line); if (m) onProgress(+m[1] / 100, 'Transcribing · ' + m[1] + '%'); };
    await run(exePath, args, watch);
    const jsonPath = outBase + '.json';
    if (!CS.fs.existsSync(jsonPath)) throw new Error('The transcription produced no output.');
    const d = JSON.parse(CS.fs.readFileSync(jsonPath, 'utf8'));
    /*  A segment's END is not the end of the word: it runs on to wherever the next word starts, so on a
        sentence with pauses every word looked about a second too long, no gap between words was ever
        visible (so captions never broke on a pause), and the highlight sat on a word long after it was
        said. The word's own tokens carry the real times - the trailing comma or full stop is a token of
        its own, timed late, so it is kept out of the end time.                                        */
    const SPECIAL = /^\[_/;                        /* [_BEG_], [_TT_561] and friends */
    const PUNCT = /^[\s.,!?;:'"\u2019\u201c\u201d\-)(]+$/;
    const words = [];
    for (const seg of (d.transcription || [])) {
      const txt = String(seg.text || '').trim();
      if (!txt) continue;
      const segS = (seg.offsets ? seg.offsets.from : 0) / 1000, segE = (seg.offsets ? seg.offsets.to : 0) / 1000;
      const parts = txt.split(/\s+/);
      let s = segS, e = segE;
      const toks = (seg.tokens || []).filter((t) => !SPECIAL.test(String(t.text || '')));
      if (toks.length) {
        const real = toks.filter((t) => !PUNCT.test(String(t.text || '')));
        const use = real.length ? real : toks;
        const first = use[0].offsets, last = use[use.length - 1].offsets;
        if (first && last) { s = first.from / 1000; e = last.to / 1000; }
      }
      if (!(e > s)) e = s + 0.08;
      /* -ml 1 gives one word per segment; a segment holding several is rare and has nothing better */
      if (parts.length === 1) { words.push({ s, e, w: parts[0] }); continue; }
      const d0 = Math.max(0.05, (e - s)) / parts.length;
      parts.forEach((w, i) => words.push({ s: s + i * d0, e: s + (i + 1) * d0, w }));
    }
    /*  A word may not start before the one before it ended, and a word with no length at all makes the
        caption animation jump. Both happen at segment seams.                                          */
    for (let i = 0; i < words.length; i++) {
      const w = words[i], prev = words[i - 1];
      if (prev && w.s < prev.e) w.s = prev.e;
      if (!(w.e > w.s)) w.e = w.s + 0.08;
    }
    /*  Sound annotations are not words. The engine writes "[Applause]", "(upbeat music)", "(audience
        clapping)" into the transcript, one token each, and over a long music bed it writes them again and
        again. Auto Edit then saw repeated "words" and cut them as retakes and fillers, real speech next
        to them included. Anything between [ ] or ( ) goes, up to five tokens long.                  */
    const clean = [];
    for (let i = 0; i < words.length; i++) {
      const w = words[i].w;
      if (/^[\[(]/.test(w)) {
        let j = i, closed = false;
        for (; j < words.length && j < i + 5; j++) { if (/[\])]$/.test(words[j].w)) { closed = true; break; } }
        if (closed) { i = j; continue; }
      }
      clean.push(words[i]);
    }
    if (!clean.length) throw new Error('No speech recognised.');
    if (offset) for (const w of clean) { w.s += offset; w.e += offset; }
    return clean;
  }
  const engines = () => { const st = status(); const chosen = (() => { try { return localStorage.getItem('os.whisperModel') || 'base'; } catch (e) { return 'base'; } })(); const m = MODELS[chosen] || MODELS.base; return [
    { id: 'whisper', name: 'Transcription engine', size: '15 MB', uses: 'Auto Edit, captions, take and filler tools', ready: !!st.exe, install },
    { id: 'whisper-model', name: 'Language model · ' + m.name, size: '', uses: 'Auto Edit, captions', ready: !!st.models[chosen], install: (p) => ensureModel(chosen, p) }
  ]; };
  return { MODELS, status, install, ensureModel, transcribe, home, engines };
})();
