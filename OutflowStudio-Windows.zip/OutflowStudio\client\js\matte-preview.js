/* Live preview for Remove background: the model runs once for a frame and writes the original, its alpha and its
   foreground estimate as images; the clean-up (contrast, shrink/grow, loose bits, softness) and the background
   (checkerboard, colour, blur) are then applied here on a canvas as the sliders move. Same maths as matte/matte.js. */
const MattePreview = (() => {
  const MAXW = 960;
  let orig = null, alpha0 = null, fgr = null, W = 0, H = 0, canvas = null, blurCanvas = null, blurFor = -1, pending = false;
  const load = (src) => new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('preview image failed')); im.src = src; });
  const grab = (im, w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.drawImage(im, 0, 0, w, h); return g.getImageData(0, 0, w, h); };
  async function set(files, target) {
    canvas = target;
    const [a, b, c] = await Promise.all([load(files.original), load(files.alpha), load(files.fgr)]);
    const scale = Math.min(1, MAXW / a.naturalWidth);
    W = Math.max(2, Math.round(a.naturalWidth * scale)); H = Math.max(2, Math.round(a.naturalHeight * scale));
    orig = grab(a, W, H).data; fgr = grab(c, W, H).data;
    const ad = grab(b, W, H).data; alpha0 = new Float32Array(W * H); for (let i = 0; i < W * H; i++) alpha0[i] = ad[i * 4] / 255;
    blurFor = -1;
    canvas.width = W; canvas.height = H;
  }
  const has = () => !!orig;
  /* --- the same clean-up as the Node script, on the preview-sized alpha --- */
  function levels(a, lo) { if (!lo) return; const k = 1 / (1 - 2 * lo); for (let i = 0; i < a.length; i++) { const v = (a[i] - lo) * k; a[i] = v < 0 ? 0 : v > 1 ? 1 : v; } }
  function morph(a, r) {
    const rad = Math.abs(r), grow = r > 0, tmp = new Float32Array(a.length);
    for (let y = 0; y < H; y++) {
      const row = y * W;
      if (grow) { for (let x = 0; x < W; x++) { let v = a[row + x]; const lo = x - rad < 0 ? 0 : x - rad, hi = x + rad >= W ? W - 1 : x + rad; for (let k = lo; k <= hi; k++) { const t = a[row + k]; if (t > v) v = t; } tmp[row + x] = v; } }
      else { for (let x = 0; x < W; x++) { let v = a[row + x]; const lo = x - rad < 0 ? 0 : x - rad, hi = x + rad >= W ? W - 1 : x + rad; for (let k = lo; k <= hi; k++) { const t = a[row + k]; if (t < v) v = t; } tmp[row + x] = v; } }
    }
    for (let y = 0; y < H; y++) {
      const row = y * W, lo = y - rad < 0 ? 0 : y - rad, hi = y + rad >= H ? H - 1 : y + rad;
      for (let x = 0; x < W; x++) a[row + x] = tmp[row + x];
      for (let k = lo; k <= hi; k++) {
        if (k === y) continue;
        const rk = k * W;
        if (grow) { for (let x = 0; x < W; x++) { const t = tmp[rk + x]; if (t > a[row + x]) a[row + x] = t; } }
        else { for (let x = 0; x < W; x++) { const t = tmp[rk + x]; if (t < a[row + x]) a[row + x] = t; } }
      }
    }
  }
  function feather(a, r) {
    const tmp = new Float32Array(a.length);
    const pass = (src, dst, horizontal) => { const len = horizontal ? W : H, lines = horizontal ? H : W; for (let l = 0; l < lines; l++) { let acc = 0, cnt = 0; const at = (i) => horizontal ? (l * W + i) : (i * W + l); for (let i = 0; i <= Math.min(r, len - 1); i++) { acc += src[at(i)]; cnt++; } for (let i = 0; i < len; i++) { dst[at(i)] = acc / cnt; const add = i + r + 1, rem = i - r; if (add < len) { acc += src[at(add)]; cnt++; } if (rem >= 0) { acc -= src[at(rem)]; cnt--; } } } };
    pass(a, tmp, true); pass(tmp, a, false);
  }
  function largest(a, minFrac) {
    const sw = Math.max(1, W >> 2), sh = Math.max(1, H >> 2), lab = new Int32Array(sw * sh);
    const solid = (x, y) => a[Math.min(H - 1, y * 4 + 2) * W + Math.min(W - 1, x * 4 + 2)] > 0.5;
    let nLab = 0; const sizes = [0], stack = [];
    for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) {
      if (lab[y * sw + x] || !solid(x, y)) continue;
      nLab++; let size = 0; stack.push(y * sw + x); lab[y * sw + x] = nLab;
      while (stack.length) { const p = stack.pop(); size++; const px = p % sw, py = (p / sw) | 0; for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = px + dx, ny = py + dy; if (nx < 0 || ny < 0 || nx >= sw || ny >= sh) continue; const q = ny * sw + nx; if (lab[q] || !solid(nx, ny)) continue; lab[q] = nLab; stack.push(q); } }
      sizes.push(size);
    }
    if (nLab <= 1) return;
    const biggest = Math.max.apply(null, sizes), keep = sizes.map((s) => s >= biggest * minFrac);
    for (let y = 0; y < H; y++) { const ly = Math.min(sh - 1, y >> 2); for (let x = 0; x < W; x++) { const lx = Math.min(sw - 1, x >> 2), l = lab[ly * sw + lx]; if (l && !keep[l]) a[y * W + x] = 0; else if (!l && a[y * W + x] > 0) { const n1 = lab[Math.max(0, ly - 1) * sw + lx], n2 = lab[Math.min(sh - 1, ly + 1) * sw + lx], n3 = lab[ly * sw + Math.max(0, lx - 1)], n4 = lab[ly * sw + Math.min(sw - 1, lx + 1)]; if (!((n1 && keep[n1]) || (n2 && keep[n2]) || (n3 && keep[n3]) || (n4 && keep[n4]))) a[y * W + x] = 0; } } }
  }
  function blurred(px) {
    if (blurCanvas && blurFor === px) return blurCanvas.getContext('2d').getImageData(0, 0, W, H).data;
    const src = document.createElement('canvas'); src.width = W; src.height = H; src.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(orig), W, H), 0, 0);
    blurCanvas = document.createElement('canvas'); blurCanvas.width = W; blurCanvas.height = H;
    const g = blurCanvas.getContext('2d'); g.filter = 'blur(' + Math.max(1, px * W / 1920) + 'px)'; g.drawImage(src, 0, 0); g.filter = 'none';
    blurFor = px;
    return g.getImageData(0, 0, W, H).data;
  }
  /* draw with the current settings; coalesced to one draw per frame */
  function render(st) {
    if (!orig || !canvas) return;
    if (pending) { pending = st; return; }
    pending = st;
    requestAnimationFrame(() => { const s = pending; pending = false; draw(s); });
  }
  function draw(st) {
    const a = new Float32Array(alpha0);
    if (st.contrast) levels(a, st.contrast);
    if (st.shrink) morph(a, Math.round(st.shrink * W / 1920) || (st.shrink > 0 ? 1 : -1));
    if (st.largest) largest(a, 0.05);
    if (st.feather) feather(a, Math.max(1, Math.round(st.feather * W / 1920)));
    const out = new Uint8ClampedArray(W * H * 4);
    const bg = st.bg === 'blur' ? blurred(st.blur) : null;
    const cr = parseInt((st.color || '00ff00').slice(0, 2), 16), cg = parseInt((st.color || '00ff00').slice(2, 4), 16), cb = parseInt((st.color || '00ff00').slice(4, 6), 16);
    for (let y = 0, i = 0; y < H; y++) for (let x = 0; x < W; x++, i++) {
      const al = a[i], o = i * 4, mix = al >= 0.9 ? 1 : al <= 0.6 ? 0 : (al - 0.6) / 0.3;
      let br, bgc, bb;
      if (st.bg === 'color') { br = cr; bgc = cg; bb = cb; }
      else if (bg) { br = bg[o]; bgc = bg[o + 1]; bb = bg[o + 2]; }
      else { const ck = (((x >> 4) + (y >> 4)) & 1) ? 200 : 140; br = bgc = bb = ck; }
      for (let c = 0; c < 3; c++) { const fgc = orig[o + c] * mix + fgr[o + c] * (1 - mix); out[o + c] = fgc * al + [br, bgc, bb][c] * (1 - al); }
      out[o + 3] = 255;
    }
    canvas.getContext('2d').putImageData(new ImageData(out, W, H), 0, 0);
  }
  return { set, has, render };
})();
