/*  Outflow Studio - host script: Zoom Montage (ExtendScript, ES3)
    Lays a run of clips back to back at the playhead, each trimmed to the piece the user picked, and gives every one
    of them a zoom on a Transform effect (on the clip, or on an adjustment layer above it).
    Requires index.jsx (bins, tracks, logging), transitions.jsx (adjustment layers) and curves.jsx (MC_*).          */

/* Trim a source item down to the chosen piece. A subclip leaves the user's own item alone, which matters because the
   same clip may appear twice in one montage with a different window each time. Not every Premiere build accepts the
   same argument shapes, so this tries them in turn and says so when it has to fall back. */
function MG_subclip(item, inSec, outSec, name, takeAudio, warnings) {
    var sub = null, wantA = takeAudio ? 1 : 0;
    try { sub = item.createSubClip(name, inSec, outSec, 0, 1, wantA); } catch (e1) {}
    if (!sub) {
        try {
            var ti = new Time(); ti.seconds = inSec;
            var to = new Time(); to.seconds = outSec;
            sub = item.createSubClip(name, ti, to, 0, 1, wantA);
        } catch (e2) {}
    }
    if (!sub) warnings.push("subclip failed for " + name + ", used the whole clip with in/out points");
    return sub;
}

/* The fallback when subclips are not available: move the source item's own in/out. The caller puts them back. */
function MG_setItemInOut(item, inSec, outSec, warnings) {
    var had = null;
    try { had = { i: item.getInPoint(1).seconds, o: item.getOutPoint(1).seconds }; } catch (e0) { had = null; }
    var ok = false;
    try { item.setInPoint(inSec, 4); item.setOutPoint(outSec, 4); ok = true; } catch (e1) {}
    if (!ok) { try { item.setInPoint(inSec); item.setOutPoint(outSec); ok = true; } catch (e2) { warnings.push("could not set in/out on " + item.name); } }
    return had;
}

/* Set a track item's end and check it took. Every layer but the last was being trimmed by the next one's overwrite,
   so a silently failed trim only showed up on the last layer, running to the end of the adjustment item. */
function MG_trim(item, endSec, warnings) {
    var got = -1;
    try { var en = new Time(); en.seconds = endSec; item.end = en; } catch (e1) {}
    try { got = item.end.seconds; } catch (e2) {}
    if (got >= 0 && Math.abs(got - endSec) < 0.002) return true;
    try { item.end = String(Math.round(endSec * C3D_TICKS_PER_SECOND)); } catch (e3) {}
    try { got = item.end.seconds; } catch (e4) {}
    if (got >= 0 && Math.abs(got - endSec) < 0.002) return true;
    warnings.push("could not trim to " + endSec.toFixed(2) + "s (it is " + (got >= 0 ? got.toFixed(2) + "s" : "unknown") + ")");
    return false;
}

/* An adjustment layer over one clip, on a track chosen once for the whole run. */
function MG_layer(adj, tIdx, s, e, name, warnings) {
    var seq = app.project.activeSequence;
    if (tIdx < 0 || tIdx >= seq.videoTracks.numTracks) { warnings.push("no track for the layer at " + s.toFixed(2) + "s"); return null; }
    var track = seq.videoTracks[tIdx], ok = false;
    try { ok = track.overwriteClip(adj, s); } catch (e1) {}
    if (!ok) { try { var tm = new Time(); tm.seconds = s; ok = track.overwriteClip(adj, tm); } catch (e2) {} }
    if (!ok) { warnings.push("could not place the layer at " + s.toFixed(2) + "s"); return null; }
    var target = C3D_findClipAt(track, s);
    if (!target) { warnings.push("layer not found after placing it at " + s.toFixed(2) + "s"); return null; }
    MG_trim(target, e, warnings);
    try { if (Math.abs(target.start.seconds - s) > 0.001) warnings.push("the layer landed " + (target.start.seconds - s).toFixed(3) + "s off"); } catch (e5) {}
    try { target.name = name; } catch (e4) {}
    return target;
}

/* Place one item at start on a track, with the same fallbacks the rest of the panel uses. */
function MG_place(track, item, start) {
    var ok = false;
    try { ok = track.overwriteClip(item, start); } catch (e1) {}
    if (!ok) { try { var tm = new Time(); tm.seconds = start; ok = track.overwriteClip(item, tm); } catch (e2) {} }
    if (!ok) { try { ok = track.insertClip(item, start); } catch (e3) {} }
    return ok;
}

/*  The music the montage should follow: the audio clip the user selected, or failing that whatever sits under the
    playhead. Returns its real start and end on the timeline, so a trimmed clip is listened to only where it plays.
    { track }  ->  { ok, found, start, end, track, name }                                                           */
function MG_musicRange(json) {
    try {
        var o = json ? C3D_loadPayload(json) : {};
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var want = (typeof o.track === "number") ? o.track : -1;
        var head = 0; try { head = seq.getPlayerPosition().seconds; } catch (e0) {}
        var t, j, c, sel = null, under = null;
        for (t = 0; t < seq.audioTracks.numTracks; t++) {
            if (want >= 0 && t !== want) continue;
            var tr = seq.audioTracks[t];
            for (j = 0; j < tr.clips.numItems; j++) {
                c = tr.clips[j];
                var isSel = false;
                try { isSel = c.isSelected(); } catch (e1) {}
                if (isSel) {
                    var a = c.start.seconds, b = c.end.seconds;
                    if (!sel) sel = { start: a, end: b, track: t, name: c.name };
                    else { if (a < sel.start) sel.start = a; if (b > sel.end) sel.end = b; }
                }
                if (!under && c.start.seconds <= head + 0.001 && c.end.seconds > head + 0.001) under = { start: c.start.seconds, end: c.end.seconds, track: t, name: c.name };
            }
        }
        /* selectedOnly: the clip you clicked, nothing else - not even what plays under the playhead */
        var r = o.selectedOnly ? sel : (sel || under);
        if (!r) return C3D_json({ ok: true, found: false, playhead: head });
        C3D_log("MG_musicRange", (sel ? "selected" : "under the playhead") + " '" + r.name + "' " + r.start.toFixed(2) + "-" + r.end.toFixed(2) + "s on A" + (r.track + 1));
        return C3D_json({ ok: true, found: true, how: sel ? "selection" : "playhead", start: r.start, end: r.end, track: r.track, name: r.name, playhead: head });
    } catch (e) { return C3D_err(e); }
}

/*  Build the montage.
    { start, track, mode: "transform" | "adjustment", template, shutter, binName, name,
      rows: [ { path, name, in, dur, keys: [[tFromClipStart, scalePercent], ...] } ] }
    Returns the placed clips so Revert can take them away again.                                                    */
function MG_build(json) {
    try {
        var o = C3D_loadPayload(json), warnings = [], i;
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        if (!o.rows || !o.rows.length) return C3D_err("No clips to place.");
        var fps = AS_fps(seq), eps = 0.5 / fps;
        var root = app.project.rootItem;

        /* the subclips live in their own bin so the user's own bins stay tidy */
        var binName = o.binName || "Zoom Montage";
        var bin = C3D_toolBin(binName) || root;

        /* how long the whole run is, so one free track can hold all of it */
        var total = 0;
        for (i = 0; i < o.rows.length; i++) total += o.rows[i].dur;
        var start = (typeof o.start === "number" && o.start >= 0) ? o.start : seq.getPlayerPosition().seconds;
        var tIdx = (typeof o.track === "number" && o.track >= 0) ? o.track : C3D_findFreeTrack(seq, start, start + total + eps);
        var guard = 0;
        while (tIdx >= app.project.activeSequence.videoTracks.numTracks && guard < 8) {
            if (!C3D_addVideoTrack(app.project.activeSequence)) return C3D_err("No free video track. Add one and try again.");
            guard++;
        }
        seq = app.project.activeSequence;
        var track = seq.videoTracks[tIdx];

        /* 1. place every piece, back to back */
        var placed = [], cursor = start, restore = [];
        for (i = 0; i < o.rows.length; i++) {
            var row = o.rows[i];
            var item = C3D_findItemByPath(root, row.path, 0);
            if (!item) {
                try { app.project.importFiles([row.path], true, bin, false); } catch (eI) {}
                item = C3D_findItemByPath(bin, row.path, 0) || C3D_findItemByPath(root, row.path, 0);
            }
            if (!item) { warnings.push("not in the project: " + row.name); continue; }

            var use = item;
            if (!row.still) {   /* a still has no timeline of its own: it goes in whole and is trimmed to length below */
                var inS = row["in"], outS = row["in"] + row.dur;
                use = MG_subclip(item, inS, outS, (row.name || "clip") + " · " + (i + 1), o.audio !== false, warnings);
                if (!use) { restore.push({ item: item, had: MG_setItemInOut(item, inS, outS, warnings) }); use = item; }
            }

            if (!MG_place(track, use, cursor)) { warnings.push("could not place " + row.name + " at " + cursor.toFixed(2) + "s"); continue; }
            var clip = C3D_findClipAt(track, cursor);
            if (!clip) { warnings.push("placed but not found: " + row.name); continue; }
            /* Premiere snaps a clip to the sequence's frame grid, so where it asked to go and where it landed are not
               always the same place. Everything after this point uses where it really landed: the next clip butts up
               against it, and the adjustment layer sits exactly over it. */
            var realStart = cursor;
            try { if (clip.start.seconds >= 0) realStart = clip.start.seconds; } catch (eS) {}
            MG_trim(clip, realStart + row.dur, warnings);
            var realEnd = realStart + row.dur;
            try { if (clip.end.seconds > realStart + eps) realEnd = clip.end.seconds; } catch (eX) {}
            placed.push({ start: realStart, end: realEnd, keys: row.keys, interp: row.interp, name: row.name });
            if (!row.still && realEnd < realStart + row.dur - eps) warnings.push(row.name + " ran out of media, it is shorter than asked");
            cursor = realEnd;
        }
        /* the source items get their own in/out back: only the montage should see the trim */
        for (i = 0; i < restore.length; i++) {
            var r = restore[i];
            if (r.had) { try { r.item.setInPoint(r.had.i, 4); r.item.setOutPoint(r.had.o, 4); } catch (eR) {} }
        }
        if (!placed.length) return C3D_err("Nothing could be placed. " + (warnings.length ? warnings[0] : ""));

        /* 2. the zoom, one clip at a time. Scale is a plain number, so no point conversion is needed. */
        C3D_KEYS_WRITTEN = 0;
        var mode = o.mode || "transform", layers = [], adj = null, layerTrack = -1;
        if (mode === "adjustment") {
            adj = TR_findVideoAL(root, 0);
            if (!adj) adj = TR_importAdjustmentTemplate(o.template);
            if (!adj) adj = QF_findAdjustmentItem(root, 0);
            if (!adj) { warnings.push("no adjustment layer could be made, zoomed the clips themselves"); mode = "transform"; }
            else {
                layerTrack = TR_trackAbove(app.project.activeSequence, start, start, cursor, eps);
                var g2 = 0;
                while (layerTrack >= app.project.activeSequence.videoTracks.numTracks && g2 < 8) {
                    if (!C3D_addVideoTrack(app.project.activeSequence)) break;
                    g2++;
                }
                if (layerTrack >= app.project.activeSequence.videoTracks.numTracks) { warnings.push("no track for the layers, zoomed the clips themselves"); mode = "transform"; }
            }
        }
        for (i = 0; i < placed.length; i++) {
            var p = placed[i];
            var target = C3D_findClipAt(app.project.activeSequence.videoTracks[tIdx], p.start);
            if (!target) { warnings.push("clip gone before the zoom: " + p.name); continue; }
            var cs = p.start, ce = p.end;
            try { cs = target.start.seconds; ce = target.end.seconds; } catch (eC) {}
            var tt = target, ti2 = tIdx, qeStart = cs, layer = null;
            if (mode === "adjustment") {
                var L = MG_layer(adj, layerTrack, cs, ce, (o.name || "Zoom Montage") + " " + (i + 1), warnings);
                if (L) { tt = L; ti2 = layerTrack; qeStart = cs; layer = { track: layerTrack, start: cs, end: ce }; }
                else warnings.push("zoomed clip " + (i + 1) + " itself");
            }
            var params = [
                { name: "Uniform Scale", keys: [[0, true]] },
                { name: "Scale Height", alias: ["Scale"], keys: p.keys, interp: p.interp },
                { name: "Use Composition's Shutter Angle", keys: [[0, false]], optional: true },
                { name: "Shutter Angle", keys: [[0, o.shutter || 180]], optional: true }
            ];
            MC_applyEffects(tt, ti2, qeStart, [{ name: "Transform", params: params }], warnings);
            if (layer) layers.push(layer);
        }

        /* the layers, once more, now that the effects are on and nothing else will touch them */
        for (i = 0; i < layers.length; i++) {
            var lt = app.project.activeSequence.videoTracks[layers[i].track];
            var li = lt ? C3D_findClipAt(lt, layers[i].start) : null;
            if (li) MG_trim(li, layers[i].end, warnings);
        }

        C3D_log("MG_build", "placed " + placed.length + " clip(s) on V" + (tIdx + 1) + " from " + start.toFixed(2) + "s, " +
            C3D_KEYS_WRITTEN + " keyframes, mode " + mode + (warnings.length ? ", " + warnings.length + " warning(s)" : ""));
        var starts = [];
        for (i = 0; i < placed.length; i++) starts.push(placed[i].start);
        return C3D_json({ ok: true, track: tIdx, start: start, end: cursor, clips: placed.length, starts: starts,
            keyframes: C3D_KEYS_WRITTEN, mode: mode, layers: layers, bin: binName, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/*  Take a montage away again: the adjustment layers first, then the clips themselves, addressed by the exact starts
    MG_build reported.  { track, starts: [sec], layers: [{ track, start }] }                                        */
function MG_revert(json) {
    try {
        var o = C3D_loadPayload(json), warnings = [], removed = 0, i;
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var kill = function (tIdx, at) {
            if (tIdx === null || tIdx === undefined || tIdx < 0 || tIdx >= app.project.activeSequence.videoTracks.numTracks) return false;
            var tr = app.project.activeSequence.videoTracks[tIdx], c = C3D_findClipAt(tr, at);
            if (!c) return false;
            try { c.remove(false, false); removed++; return true; } catch (e1) { warnings.push("could not remove what is at " + at.toFixed(2) + "s"); return false; }
        };
        for (i = 0; i < (o.layers || []).length; i++) kill(o.layers[i].track, o.layers[i].start);
        for (i = 0; i < (o.starts || []).length; i++) kill(o.track, o.starts[i]);
        C3D_log("MG_revert", "removed " + removed + " item(s)");
        return C3D_json({ ok: true, removed: removed, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}
