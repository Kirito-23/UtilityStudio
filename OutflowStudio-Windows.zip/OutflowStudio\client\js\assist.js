/* Auto Edit. Word edits: Word Captions, Take Cleaner, Filler Words, Profanity, B-roll ideas.
   Visual & audio edits: Auto Cut, Speaker Switch, Punch Zoom, Beat Markers, Reframe Pack.
   Auto Edit chains auto cut → transcript → takes → fillers → profanity → transitions. */
const Assist = (() => {
  const $ = (s) => document.querySelector(s);
  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const fmt = (s) => { s = Math.max(0, s); const m = Math.floor(s / 60); return m + ':' + (s - m * 60).toFixed(1).padStart(4, '0'); };
  let transcript = null;   /* { words:[{s,e,w}], source } shared by the word tools */
  const listeners = [];
  const onTranscript = (fn) => listeners.push(fn);
  function setTranscript(words, source) { transcript = { words, source }; for (const fn of listeners) fn(); }
  const norm = (w) => String(w).toLowerCase().replace(/[^\p{L}\p{N}']/gu, '');
  const loadCfg = (key, def) => { const o = Object.assign({}, def); try { Object.assign(o, JSON.parse(localStorage.getItem(key) || '{}')); } catch (e) {} return o; };
  const saveCfg = (key, o) => { try { localStorage.setItem(key, JSON.stringify(o)); } catch (e) {} };
  const mergeRanges = (list) => { list.sort((a, b) => a[0] - b[0]); const out = []; for (const c of list) { const last = out[out.length - 1]; if (last && c[0] <= last[1] + 0.02) last[1] = Math.max(last[1], c[1]); else out.push(c.slice()); } return out; };

  /* ---------------------------------------------------------------- ui bits */
  function row(label, control, hint) {
    const r = h('div', 'row');
    const l = h('label', '', label); if (hint) l.innerHTML += ' <span class="hint">' + hint + '</span>';
    r.append(l, control); return r;
  }
  function range(get, set, min, max, step, unit, onInput) {
    const wrap = h('div', 'slider');
    const r = h('input'); r.type = 'range'; r.min = min; r.max = max; r.step = step; r.value = get();
    const v = h('span', 'val');
    const f = (x) => (step >= 1 ? Math.round(x) : (+x).toFixed(step < 0.1 ? 2 : 1)) + (unit || '');
    v.textContent = f(r.value);
    r.addEventListener('input', () => { set(parseFloat(r.value)); v.textContent = f(r.value); if (onInput) onInput(); });
    wrap.append(r, v); return wrap;
  }
  function rangeNum(get, set, min, max, step, unit, onInput) {
    const wrap = h('div', 'slider');
    const r = h('input'); r.type = 'range'; r.min = min; r.max = max; r.step = step; r.value = get();
    const n = h('input'); n.type = 'number'; n.min = min; n.max = max; n.step = step; n.value = get(); n.style.width = '64px';
    const u = h('span', 'val', unit || ''); u.style.width = 'auto';
    r.addEventListener('input', () => { n.value = r.value; set(parseFloat(r.value)); if (onInput) onInput(); });
    n.addEventListener('change', () => { const v = Math.max(min, Math.min(max, parseFloat(n.value) || 0)); n.value = v; r.value = v; set(v); if (onInput) onInput(); });
    wrap.append(r, n, u);
    wrap.setValue = (v) => { r.value = v; n.value = v; };
    return wrap;
  }
  function select(options, value, onChange) {
    const s = h('select', 'sel');
    for (const [k, n] of options) { const o = h('option'); o.value = k; o.textContent = n; s.appendChild(o); }
    s.value = String(value);
    s.addEventListener('change', () => onChange(s.value));
    return s;
  }
  function toggle(value, onChange) {
    const b = h('button', 'switch' + (value ? ' on' : ''));
    b.addEventListener('click', () => { const on = !b.classList.contains('on'); b.classList.toggle('on', on); onChange(on); });
    return b;
  }
  function color(value, onChange) { const c = h('input'); c.type = 'color'; c.value = value; c.addEventListener('input', () => onChange(c.value)); return c; }
  function button(label, cls, fn) { const b = h('button', cls || 'ghost', label); b.addEventListener('click', fn); return b; }
  function section(title) { const s = h('div', 'section'); s.appendChild(h('h4', '', title)); return s; }
  function noteBox() { const n = h('div', 'st-note'); n.set = (html, kind) => { n.innerHTML = html || ''; n.className = 'st-note' + (kind ? ' ' + kind : '') + (html ? ' show' : ''); }; return n; }
  const progress = {
    show(t) { $('#progress').classList.add('show'); this.title(t || 'Working…'); this.progress(0, ''); },
    hide() { $('#progress').classList.remove('show'); },
    title(t) { $('#prog-title').textContent = t; },
    progress(p, txt) { $('#prog-bar').style.width = Math.round(p * 100) + '%'; $('#prog-text').textContent = txt || ''; }
  };
  let cancelled = false;
  async function busy(title, fn) {
    cancelled = false; progress.show(title);
    try { return await fn(); }
    catch (e) { if (cancelled || CS.isCancel(null, e)) toast('Cancelled.', ''); else toast(e.message || String(e), 'err'); return null; }
    finally { progress.hide(); }
  }
  async function seqRange() {
    if (!CS.inCEP) throw new Error('This tool works inside Premiere Pro only.');
    const r = await CS.call('AS_range');
    if (!r.ok) throw new Error(r.error);
    return r;
  }
  function pickRange(info, mode) {
    if (mode === 'selected' && info.selection.length) return { start: Math.min(...info.selection.map(s => s.start)), end: Math.max(...info.selection.map(s => s.end)) };
    if (mode === 'inout' && info.hasInOut) return { start: info.inPoint, end: info.outPoint };
    return { start: 0, end: info.duration };
  }
  const rangeOptions = [['inout', 'In / Out points (or whole sequence)'], ['selected', 'Selected clips'], ['whole', 'Whole sequence']];
  /*  pickRange gives one span from the first selected clip to the last, which is what exporting audio needs.
      Captions need the clips themselves: two clips with a gap between them must not get a caption over the
      gap, and a phrase must not run from one clip into the next.                                          */
  function pickSpans(info, mode) {
    if (mode === 'selected' && info.selection.length) {
      const spans = info.selection.map((c) => ({ start: c.start, end: c.end })).sort((a, b) => a.start - b.start);
      const out = [spans[0]];
      for (const sp of spans.slice(1)) {
        const last = out[out.length - 1];
        if (sp.start <= last.end + 0.001) last.end = Math.max(last.end, sp.end);   /* clips that touch are one span */
        else out.push(sp);
      }
      return out;
    }
    return [pickRange(info, mode)];
  }
  /* the words of a transcript that fall inside those spans, cut into phrases per span */
  function wordsInSpans(words, spans) {
    const out = [];
    for (const sp of spans) {
      const inside = words.filter((w) => w.s >= sp.start - 0.01 && w.s <= sp.end).map((w) => Object.assign({}, w));
      if (!inside.length) continue;
      inside[inside.length - 1].brk = true;   /* never group across the end of a clip */
      out.push.apply(out, inside);
    }
    return out;
  }
  const srtTime = (s) => { const ms = Math.round(s * 1000); const hh = Math.floor(ms / 3600000), mm = Math.floor(ms / 60000) % 60, ss = Math.floor(ms / 1000) % 60, mss = ms % 1000; return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0') + ':' + String(ss).padStart(2, '0') + ',' + String(mss).padStart(3, '0'); };
  async function outDir(sub) {
    const p = await CS.call('OS_getPaths');
    const base = (p.ok && (p.projectDir || p.documents)) || CS.os.homedir();
    const d = CS.path.join(base, 'OutflowStudio', sub); CS.mkdirp(d); return d;
  }
  function transcriptView(container, words, isMarked, onToggle) {
    container.innerHTML = '';
    if (!words || !words.length) { container.appendChild(h('div', 'kbd', 'No transcript loaded yet.')); return; }
    const box = h('div', 'tview');
    words.forEach((w, i) => {
      const s = h('span', 'tw' + (isMarked && isMarked(w, i) ? ' cut' : ''), w.w);
      s.title = fmt(w.s);
      if (onToggle) { s.classList.add('clickable'); s.addEventListener('click', () => onToggle(w, i)); }
      box.appendChild(s); box.appendChild(document.createTextNode(' '));
    });
    container.appendChild(box);
  }
  function shiftTranscript(cuts) {
    if (!transcript) return;
    const keep = [];
    for (const w of transcript.words) {
      if (cuts.some(c => w.s >= c[0] - 0.001 && w.s < c[1])) continue;
      const before = cuts.filter(c => c[1] <= w.s + 0.001).reduce((a, c) => a + (c[1] - c[0]), 0);
      keep.push({ s: w.s - before, e: w.e - before, w: w.w, brk: w.brk });
    }
    transcript.words = keep;
    for (const fn of listeners) fn();
  }

  /* ---------------------------------------------------------------- defaults */
  const DEF = {
    silence: { range: 'inout', threshold: -35, auto: true, minSilence: 0.35, padLeft: 0.06, padRight: 0.02, lock: false, spike: 0.33, mode: 'ripple' },
    takes: { minWords: 4, window: 30, lead: 0.08, stops: true },
    stops: { maxWords: 6, gap: 0.35, lead: 0.05, llm: false },
    filler: { custom: [], skip: [], pad: 0.03, phrases: false },
    profanity: { ban: [], allow: [], mode: 'mute', beep: false, beepFile: '', pad: 0.02 },
    auto: { range: 'inout', silence: true, transcribe: true, takes: true, stops: true, filler: true, profanity: true, transitions: true, frames: 2, transition: 'Constant Power', model: 'base', language: '' },
    podcast: { range: 'inout', map: {}, wide: -1, camAudio: {}, sync: true, silence: true, speaker: true, zoom: true, captions: true, reframe: false, minShot: 1.5, zoomAmount: 1.12, zoomThreshold: -22, language: '', model: 'base', maxLag: 60 }
  };
  const FILLERS = ['uh', 'um', 'uhm', 'umm', 'erm', 'hmm', 'hm', 'mm', 'mmm', 'ah', 'eh', 'ehm', 'euh', 'euhm', 'ähm', 'äh', 'euf'];
  const PHRASES = ['you know', 'sort of', 'kind of', 'i mean', 'basically', 'literally', 'actually'];
  const PROFANITY = ['fuck', 'fucking', 'fucked', 'fucker', 'motherfucker', 'shit', 'shitty', 'bullshit', 'bitch', 'bitches', 'asshole', 'ass', 'bastard', 'dick', 'cock', 'pussy', 'cunt', 'slut', 'whore', 'piss', 'goddamn', 'nigger', 'nigga', 'faggot', 'retard', 'kanker', 'kut', 'godverdomme', 'tering', 'tyfus', 'klootzak', 'hoer', 'scheisse', 'merde', 'putain'];

  /* ---------------------------------------------------------------- core */
  const Core = {
    /* how far a camera's audio runs behind the microphones (seconds, + = camera is late), by cross-correlating the
       loudness envelopes; coarse at the envelope window, then refined at 2 ms on the raw samples. score 0..1 */
    alignLag(ref, cam, maxLag) {
      const win = ref.win, L = Math.round((maxLag || 60) / win);
      const prep = (env) => { const n = Math.min(env.length, Math.round(600 / win)); const a = new Float32Array(n); let m = 0; for (let i = 0; i < n; i++) { a[i] = Math.max(-60, env[i]); m += a[i]; } m /= n; let ss = 0; for (let i = 0; i < n; i++) { a[i] -= m; ss += a[i] * a[i]; } const s = Math.sqrt(ss / n) || 1; for (let i = 0; i < n; i++) a[i] /= s; return a; };
      const A = prep(ref.env), B = prep(cam.env), n = Math.min(A.length, B.length);
      let best = 0, bestV = -1e9;
      for (let lag = -L; lag <= L; lag++) {
        let s = 0, c = 0;
        const i0 = Math.max(0, -lag), i1 = Math.min(n, n - lag);
        for (let i = i0; i < i1; i += 1) { s += A[i] * B[i + lag]; c++; }
        if (c < n / 4) continue;
        const v = s / c;
        if (v > bestV) { bestV = v; best = lag; }
      }
      let seconds = best * win, score = Math.max(0, Math.min(1, bestV));
      /* refine on the raw samples around the coarse answer */
      try {
        if (ref.samples && cam.samples && ref.sampleRate === cam.sampleRate) {
          const sr = ref.sampleRate, fw = 0.002, fine = (s) => AudioTool.envelope(s, sr, fw).env;
          const FA = prep(fine(ref.samples)), FB = prep(fine(cam.samples)), fn = Math.min(FA.length, FB.length);
          const c0 = Math.round(seconds / fw), R = Math.round(win / fw) * 2;
          let fb = c0, fv = -1e9;
          for (let lag = c0 - R; lag <= c0 + R; lag++) {
            let s = 0, c = 0;
            const i0 = Math.max(0, -lag), i1 = Math.min(fn, fn - lag);
            for (let i = i0; i < i1; i++) { s += FA[i] * FB[i + lag]; c++; }
            if (c < fn / 4) continue;
            const v = s / c; if (v > fv) { fv = v; fb = lag; }
          }
          if (fv > -1e9) seconds = fb * fw;
        }
      } catch (e) { Log.warn('podcast', 'fine sync skipped: ' + e.message); }
      return { seconds, score };
    },
    /* which camera shows at every moment: the loudest microphone wins, with a minimum shot length and a switch margin */
    speakerSegments(envs, cams, camTracks, wide, st, r) {
      const win = envs[0].win, n = Math.min(...envs.map(e => e.env.length));
      const camIdx = (track) => camTracks.indexOf(track);
      const segs = [];
      let cur = -1, curStart = 0;
      const smoothN = Math.max(1, Math.round(0.3 / win));
      for (let i = 0; i < n; i++) {
        let best = -1, bestV = -1e9, second = -1e9;
        for (let m = 0; m < envs.length; m++) {
          let s = 0, c = 0; for (let k = -smoothN; k <= smoothN; k++) { const j = i + k; if (j >= 0 && j < n) { s += envs[m].env[j]; c++; } }
          const v = s / c;
          if (v > bestV) { second = bestV; bestV = v; best = m; } else if (v > second) second = v;
        }
        let want = (bestV >= st.threshold) ? camIdx(cams[best]) : (wide >= 0 ? camIdx(wide) : cur);
        if (want < 0) want = cur < 0 ? camIdx(cams[best]) : cur;
        const t = r.start + i * win;
        if (cur < 0) { cur = want; curStart = t; continue; }
        if (want !== cur) {
          const louderEnough = bestV - second >= st.margin || bestV < st.threshold;
          if (t - curStart >= st.minShot && louderEnough) { segs.push({ s: curStart, e: t, cam: cur }); cur = want; curStart = t; }
        }
      }
      segs.push({ s: curStart, e: r.end, cam: cur });
      return segs;
    },
    silenceCuts(audio, st) {
      const thr = st.auto ? AudioTool.autoThreshold(audio) : st.threshold;
      return { thr, cuts: AudioTool.detectSilences(audio, { thresholdDb: thr, minSilence: st.minSilence, padLeft: st.padLeft, padRight: st.padRight, spike: st.spike }).map(c => [c[0] + audio.start, c[1] + audio.start]) };
    },
    async applyCuts(cuts, mode, label, audioOnly) {
      const r = await CS.call('AS_applyCuts', JSON.stringify({ cuts, mode, label, audioOnly: !!audioOnly }));
      if (!r.ok) throw new Error(r.error);
      if (mode === 'ripple') shiftTranscript(cuts);
      return r;
    },
    async transcribe(model, language, range, onProgress) {
      onProgress(0, 'Exporting audio');
      const audio = await AudioTool.exportRange(range.start, range.end, null, 'whisper');
      const wavPath = audio.file.replace(/\.wav$/i, '') + '_16k.wav';
      CS.fs.writeFileSync(wavPath, AudioTool.wav16k(audio.samples, audio.sampleRate));
      const words = await LocalWhisper.transcribe(wavPath, model, language, (p, t) => onProgress(Math.max(0, p), t || 'Transcribing'));
      setTranscript(words.map(w => ({ s: w.s + audio.start, e: w.e + audio.start, w: w.w })), 'local · ' + model);
      return words.length;
    },
    findTakes(st) {
      if (!transcript) return [];
      const W = transcript.words, N = W.map(w => norm(w.w)), found = [];
      let i = 0;
      const content = (w) => /^\d+$/.test(w) || w.length >= 4;
      while (i < N.length) {
        let hit = null;
        for (let j = i + 1; j < N.length && W[j].s - W[i].s <= st.window; j++) {
          /* walk both phrases in parallel; one substituted word is allowed once the phrase has started */
          let L = 0, mism = 0, matched = 0, strong = 0, lastMatch = -1;
          while (i + L < j && j + L < N.length && N[i + L] && N[j + L]) {
            if (N[i + L] === N[j + L]) { matched++; if (content(N[i + L])) strong++; lastMatch = L; L++; }
            else if (L > 0 && mism < 1) { mism++; L++; }
            else break;
          }
          L = lastMatch + 1;
          const exact = matched >= st.minWords;
          const fuzzy = L >= 3 && matched >= L - 1 && strong >= 2;
          const soon = W[j].s - W[i].s <= 8;            /* a 3-word fuzzy echo 20 s later is just speech, not a retake */
          if ((exact || (fuzzy && soon)) && (!hit || L > hit.L)) hit = { i, j, L, exact };
        }
        if (hit) { found.push({ s: Math.max(0, W[hit.i].s - st.lead), e: Math.max(0, W[hit.j].s - st.lead), text: W.slice(hit.i, hit.i + hit.L).map(w => w.w).join(' '), on: true }); i = hit.j; }
        else i++;
      }
      return found;
    },
    /*  Cut-off sentences. Someone starts a sentence, gives up on it halfway and starts again: "So the thing
        about- So what I wanted to say". The transcript shows it as a short run of words that never gets a
        full stop, then a pause, then a capital letter (or the same first word again). Whisper writes the
        break itself when it hears one: a dash or an ellipsis on the last word. Only short runs count - a
        long sentence that trails off is speech, not a false start - and a sentence that closes properly
        with . ! ? is never touched, however short.                                                      */
    findStops(st) {
      if (!transcript) return [];
      const W = transcript.words, out = [];
      const END = /[.!?]["'\u2019\u201d)]*$/, BROKEN = /(-|\u2014|\u2026|\.\.\.)["'\u2019\u201d)]*$/, COMMA = /,$/;
      const cap = (w) => /^[A-Z\u00c0-\u00de]/.test(String(w).replace(/^["'\u201c(]+/, ''));
      const startsSentence = (i) => i === 0 || END.test(W[i - 1].w) || (W[i].s - W[i - 1].e) >= st.gap;
      let i = 0;
      while (i < W.length) {
        if (!startsSentence(i)) { i++; continue; }
        let j = i, broke = false;
        for (; j < W.length && j - i < st.maxWords; j++) {
          const w = W[j], next = W[j + 1];
          if (END.test(w.w) || !next) break;                       /* closed properly, or the end: not a false start */
          const pause = next.s - w.e, restart = norm(next.w) === norm(W[i].w) && norm(W[i].w).length > 1;
          if (BROKEN.test(w.w) && (pause >= st.gap / 2 || cap(next.w) || restart)) { broke = true; break; }
          if (pause >= st.gap && !COMMA.test(w.w) && (cap(next.w) || restart)) { broke = true; break; }
        }
        if (broke) { out.push({ i, j, s: Math.max(0, W[i].s - st.lead), e: W[j].e, text: W.slice(i, j + 1).map(w => w.w).join(' '), on: true }); i = j + 1; }
        else i++;
      }
      return out;
    },
    /*  The same question put to a language model with the user's own key from Settings - never a shared one.
        "Was this sentence given up on, or only paused?" is a judgment the six-word rule above cannot make
        on the ambiguous ones. The whole transcript goes up once, numbered, with the pauses written in, and
        the answer is a list of word ranges. It replaces the rule's list when it arrives; when the key is
        missing or the request fails the rule's list stands and the run says so.                          */
    openaiKey() { try { return (Hub.keys().openai || (window.BUILTIN_KEYS || {}).openai || '').trim(); } catch (e) { return ''; } },
    async judgeStops(st) {
      const key = Core.openaiKey(); if (!key || !transcript) return null;
      const W = transcript.words;
      let text = '';
      for (let i = 0; i < W.length; i++) {
        const gap = i ? W[i].s - W[i - 1].e : 0;
        if (gap >= 0.3) text += ' [pause ' + gap.toFixed(1) + 's]';
        text += ' ' + i + ':' + W[i].w;
      }
      const system = 'You read a spoken-word transcript from a video recording. Each word is numbered "index:word"; pauses of 0.3 s or longer are written as [pause 0.6s]. Find every FALSE START: a sentence the speaker begins, abandons before finishing, and then starts over or moves on from - for example "So the thing about- [pause] So what I wanted to say". Report the abandoned words only (from the first word of the abandoned attempt to its last word before the restart), never the sentence that replaced it. Do not report sentences that were finished, hesitations inside a sentence that then continues, filler words, or repeated complete sentences. Reply with JSON only: {"stops":[{"from":12,"to":15},...]}. An empty list is a valid answer.';
      const nodeReq = (window.cep_node && window.cep_node.require) || window.require;
      const https = nodeReq('https'), Buf = window.Buffer || window.cep_node.Buffer;
      const body = Buf.from(JSON.stringify({ model: 'gpt-4o-mini', temperature: 0, response_format: { type: 'json_object' }, messages: [{ role: 'system', content: system }, { role: 'user', content: text.trim() }] }));
      const raw = await new Promise((resolve, reject) => {
        const req = https.request({ hostname: 'api.openai.com', path: '/v1/chat/completions', method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json', 'Content-Length': body.length } }, (res) => {
          const chunks = []; res.on('data', c => chunks.push(c));
          res.on('end', () => { const t = Buf.concat(chunks).toString('utf8'); if (res.statusCode >= 400) reject(new Error('OpenAI: HTTP ' + res.statusCode + ' ' + t.slice(0, 160))); else resolve(t); });
        });
        req.on('error', reject);
        req.setTimeout(120000, () => req.destroy(new Error('OpenAI request timed out')));
        req.write(body); req.end();
      });
      let ranges = [];
      try { ranges = JSON.parse(JSON.parse(raw).choices[0].message.content).stops || []; } catch (e) { throw new Error('OpenAI: unreadable answer'); }
      const out = [];
      for (const r of ranges) {
        const i = Math.max(0, Math.floor(Number(r.from))), j = Math.min(W.length - 1, Math.floor(Number(r.to)));
        /* a fragment is short and something must follow it; a "false start" that is the whole speech is a misread */
        if (!(j >= i) || j - i > 12 || j >= W.length - 1) continue;
        if (out.some(o => i <= o.j && j >= o.i)) continue;
        out.push({ i, j, s: Math.max(0, W[i].s - st.lead), e: W[j].e, text: W.slice(i, j + 1).map(w => w.w).join(' '), on: true, llm: true });
      }
      return out.sort((a, b) => a.i - b.i);
    },
    /* the rule's list, or the model's when the toggle is on and the key works; the second value says which */
    async stops(st) {
      const rule = Core.findStops(st);
      if (!st.llm) return { list: rule, how: 'rule' };
      if (!Core.openaiKey()) return { list: rule, how: 'rule', note: 'no OpenAI key in Settings, used the built-in rule' };
      try { const j = await Core.judgeStops(st); return j ? { list: j, how: 'openai' } : { list: rule, how: 'rule' }; }
      catch (e) { Log.warn('autoedit', 'cut-off sentences: ' + e.message); return { list: rule, how: 'rule', note: e.message + ', used the built-in rule' }; }
    },
    findFillers(st) {
      if (!transcript) return [];
      const set = new Set(FILLERS.concat(st.custom).map(norm).filter(w => !st.skip.map(norm).includes(w)));
      const skip = st.skip.map(norm), W = transcript.words, hits = [];
      for (let i = 0; i < W.length; i++) {
        const n = norm(W[i].w);
        if (set.has(n)) { hits.push({ i, j: i, s: W[i].s - st.pad, e: W[i].e + st.pad, on: true }); continue; }
        if (st.phrases && i + 1 < W.length) { const two = n + ' ' + norm(W[i + 1].w); if (PHRASES.includes(two) && !skip.includes(two)) { hits.push({ i, j: i + 1, s: W[i].s - st.pad, e: W[i + 1].e + st.pad, on: true }); continue; } }
        if (st.phrases && PHRASES.includes(n) && !skip.includes(n)) hits.push({ i, j: i, s: W[i].s - st.pad, e: W[i].e + st.pad, on: true });
      }
      return hits;
    },
    findProfanity(st) {
      if (!transcript) return [];
      const set = new Set(PROFANITY.concat(st.ban).map(norm).filter(w => !st.allow.map(norm).includes(w)));
      return transcript.words.map((w, i) => ({ i, w, on: set.has(norm(w.w)) })).filter(x => x.on);
    },
    async applyProfanity(hits, st) {
      const cuts = mergeRanges(hits.map(x => [Math.max(0, x.w.s - st.pad), x.w.e + st.pad]));
      if (!cuts.length) return { count: 0 };
      if (st.mode === 'cut') { const r = await Core.applyCuts(cuts, 'ripple', 'profanity'); return { count: r.applied }; }
      await Core.applyCuts(cuts, 'disable', 'profanity', true);
      let beeps = 0;
      if (st.beep) {
        let file = st.beepFile;
        if (!file || !CS.fs.existsSync(file)) {
          file = CS.path.join(await outDir('sfx'), 'beep_1khz.wav');
          if (!CS.fs.existsSync(file)) { const sr = 48000, n = sr; const smp = new Float32Array(n); for (let i = 0; i < n; i++) smp[i] = Math.sin(i / sr * 1000 * Math.PI * 2) * 0.5 * Math.min(1, i / 400, (n - i) / 400); CS.fs.writeFileSync(file, AudioTool.wav16k(smp, sr)); }
        }
        for (const c of cuts) { const rr = await CS.call('TL_placeAudio', file, c[0], 'beep'); if (rr.ok) beeps++; }
      }
      return { count: cuts.length, beeps };
    },
    async transitionsAll(name, frames, track) {
      const r = await CS.call('TL_transitions', JSON.stringify({ name, duration: frames, edges: false, all: true, track: track || 0 }));
      if (!r.ok) throw new Error(r.error);
      return r;
    }
  };

  /* ------------------------------------------------------------------ tools */
  const CATS = [
    { id: 'auto', name: 'One button', icon: 'quickfx', tools: [
      { id: 'autoedit', icon: 'assist', name: 'Auto Edit', hot: true, desc: 'Auto cut → transcribe → clean takes → fillers → profanity → smooth transitions. One click.' }
    ] },
    { id: 'words', name: 'Word edits', icon: 'words', tools: [
      { id: 'captions', icon: 'captions', name: 'Word Captions', hot: true, desc: 'Free offline transcript → editable Premiere captions or animated PNG captions.' },
      { id: 'takes', icon: 'takes', name: 'Take Cleaner', desc: 'Repeated sentences: keep the last take, cut the earlier ones.' },
      { id: 'filler', icon: 'filler', name: 'Filler Words', desc: 'Cut uh, um, hmm… with a list you control.' },
      { id: 'profanity', icon: 'profanity', name: 'Profanity Filter', desc: 'Mute, beep or cut banned words.' },
      { id: 'broll', icon: 'broll', name: 'B-roll Ideas', desc: 'Keywords from the transcript, straight into stock search.' }
    ] },
    { id: 'visual', name: 'Visual & audio edits', icon: 'visual', tools: [
      { id: 'silence', icon: 'silence', name: 'Auto Cut', desc: 'Finds the pauses in your audio and ripple-cuts them out.' },
      { id: 'speaker', icon: 'speaker', name: 'Speaker Switch', hot: true, desc: 'Podcast multicam: cuts to whoever is talking. The full podcast flow lives under Auto Edit › Podcast.' },
      { id: 'zoom', icon: 'zoom', name: 'Punch Zoom', desc: 'Dynamic zoom-ins on loud moments or at intervals.' },
      { id: 'beats', icon: 'beats', name: 'Beat Markers', desc: 'Markers on the beat of a music track, optionally cut clips on them.' },
      { id: 'reframe', icon: 'reframe', name: 'Reframe Pack', hot: true, desc: '9:16, 1:1, 4:5 … versions with Premiere Auto Reframe.' }
    ] }
  ];
  const builders = {};


  /* ---- Podcast mode: sync cameras, cut silence, switch to whoever talks, punch zoom, captions, vertical versions ---- */
  function buildPodcast(body) {
    const st = loadCfg('os.podcast', DEF.podcast);
    const save = () => saveCfg('os.podcast', st);
    const note = noteBox(), log = h('div', 'alog'), mics = h('div'), cams = h('div');
    const tog = (key, title, desc) => row(title, toggle(st[key], v => { st[key] = v; save(); }), desc);
    let info = null;
    body.append(
      h('div', 'kbd', 'Each camera on its own video track, each guest on their own microphone track. Podcast mode runs in this order: sync the cameras to the microphones, cut the silence on every track, cut to whoever is talking, punch-zoom the loud moments, add captions, and make a vertical version. Everything runs on your PC.'),
      row('Range', select(rangeOptions, st.range, v => { st.range = v; save(); })),
      h('div', 'kbd', 'Microphones → the camera that shows that guest. Name your tracks ("Cam Kevin", "Mic Kevin") and the panel pre-fills this.'), mics,
      h('div', 'kbd', 'Cameras → the audio track that came with that camera (used only to sync it; leave "none" for the camera the mics are on)'), cams);
    const loader = trackLoader(body, note, (i) => {
      info = i; mics.innerHTML = ''; cams.innerHTML = '';
      const camOpts = [['-1', 'none']].concat(i.videoTracks.map(v => [String(v.index), 'V' + (v.index + 1) + (v.name && !/^V\d+$/.test(v.name) ? ' ' + v.name : '')]));
      const audOpts = [['-1', 'none']].concat(i.audioTracks.filter(a => a.clips).map(a => [String(a.index), 'A' + (a.index + 1) + (a.name && !/^A\d+$/.test(a.name) ? ' ' + a.name : '')]));
      for (const a of i.audioTracks) {
        if (!a.clips) continue;
        if (st.map[a.index] === undefined || st.map[a.index] === -1) st.map[a.index] = guessCamera(a, i.videoTracks);
        mics.appendChild(row('A' + (a.index + 1) + (a.name && !/^A\d+$/.test(a.name) ? ' ' + a.name : '') + ' → camera', select(camOpts, String(st.map[a.index]), v => { st.map[a.index] = +v; save(); })));
      }
      mics.appendChild(row('Wide shot when nobody talks', select(camOpts, String(st.wide), v => { st.wide = +v; save(); })));
      for (const v of i.videoTracks) {
        if (!v.clips) continue;
        if (st.camAudio[v.index] === undefined) st.camAudio[v.index] = -1;
        cams.appendChild(row('V' + (v.index + 1) + (v.name && !/^V\d+$/.test(v.name) ? ' ' + v.name : '') + ' ← camera audio', select(audOpts, String(st.camAudio[v.index]), v2 => { st.camAudio[v.index] = +v2; save(); })));
      }
      save();
    });
    body.appendChild(loader.reload);
    body.append(
      tog('sync', '1 · Sync cameras', 'lines every camera up with the microphones by sound, to the frame'),
      tog('silence', '2 · Auto cut', 'settings from the Auto Cut tool'),
      tog('speaker', '3 · Switch to whoever talks', 'settings from the Speaker Switch tool'),
      row('Minimum shot', range(() => st.minShot, v => { st.minShot = v; save(); }, 0.5, 8, 0.1, ' s')),
      tog('zoom', '4 · Punch zoom on loud moments', 'a subtle push-in on the emphasis'),
      row('Zoom amount', range(() => st.zoomAmount, v => { st.zoomAmount = v; save(); }, 1.03, 1.4, 0.01, '×')),
      tog('captions', '5 · Captions', 'transcribes the finished cut locally, adds a caption track'),
      row('Language', select([['', 'Auto detect'], ['en', 'English'], ['nl', 'Dutch'], ['de', 'German'], ['fr', 'French'], ['es', 'Spanish'], ['it', 'Italian'], ['pt', 'Portuguese']], st.language, v => { st.language = v; save(); })),
      tog('reframe', '6 · Vertical version', 'also makes a 9:16 copy of the finished edit as a new sequence, the current one stays as it is'),
      button('Run Podcast edit', 'primary big', () => busy('Podcast edit', async () => {
        log.innerHTML = '';
        const add = (txt, ok) => { log.appendChild(h('div', 'aline' + (ok === false ? ' bad' : ''), (ok === false ? '✕ ' : '✓ ') + txt)); Log[ok === false ? 'warn' : 'info']('podcast', txt); };
        Log.section('Podcast edit');
        Log.info('podcast', 'settings', st);
        info = await seqRange();
        let r = pickRange(info, st.range);
        const micTracks = Object.keys(st.map).map(Number).filter(a => st.map[a] >= 0 && info.audioTracks.some(t => t.index === a && t.clips));
        if ((st.speaker || st.sync) && !micTracks.length) throw new Error('Map at least one microphone track to a camera first.');
        const camTracks = Array.from(new Set(micTracks.map(a => st.map[a]).concat(st.wide >= 0 ? [st.wide] : [])));
        const fps = info.fps || 25;
        /* 1 · sync: every camera with its own audio track is cross-correlated against the microphone mix */
        if (st.sync) {
          progress.title('Syncing cameras'); progress.progress(0.02, 'exporting microphones');
          const ref = await AudioTool.exportRange(r.start, r.end, micTracks, 'ref');
          const camsToSync = Object.keys(st.camAudio).map(Number).filter(v => st.camAudio[v] >= 0 && !micTracks.includes(st.camAudio[v]) && info.videoTracks.some(t => t.index === v && t.clips));
          let k = 0;
          for (const v of camsToSync) {
            const a = st.camAudio[v]; k++;
            progress.title('Syncing camera V' + (v + 1)); progress.progress(0.02 + 0.18 * k / camsToSync.length, 'listening');
            const cam = await AudioTool.exportRange(r.start, r.end, [a], 'cam' + v);
            const lag = Core.alignLag(ref, cam, st.maxLag);
            Log.info('podcast', 'sync', { camera: v, audio: a, lag: lag.seconds, score: lag.score });
            if (lag.score < 0.15) { add('V' + (v + 1) + ': could not find a match with the microphones, left as is', false); continue; }
            const delta = -Math.round(lag.seconds * fps) / fps;
            if (Math.abs(delta) < 0.5 / fps) { add('V' + (v + 1) + ' was already in sync'); continue; }
            const res = await CS.call('AS_shiftTracks', JSON.stringify({ videos: [v], audios: [a], delta }));
            if (!res.ok) throw new Error(res.error);
            add('V' + (v + 1) + ' moved ' + (delta > 0 ? 'later' : 'earlier') + ' by ' + Math.abs(delta).toFixed(3) + ' s (' + res.moved + ' clip(s))' + (res.failed ? ', ' + res.failed + ' could not move' : ''), !res.failed);
          }
          if (!camsToSync.length) add('nothing to sync: give each camera its audio track above', false);
          info = await seqRange(); r = pickRange(info, st.range);
        }
        /* 2 · silence, on the microphone mix, cut across every track */
        if (st.silence) {
          progress.title('Cutting silence'); progress.progress(0.25, 'exporting audio');
          const audio = await AudioTool.exportRange(r.start, r.end, micTracks.length ? micTracks : null, 'silence');
          const cs = Core.silenceCuts(audio, loadCfg('os.silence', DEF.silence));
          if (cs.cuts.length) {
            progress.progress(0.3, cs.cuts.length + ' silences');
            const res = await Core.applyCuts(cs.cuts, 'ripple', 'silence');
            const total = cs.cuts.reduce((a, c) => a + (c[1] - c[0]), 0);
            add(res.applied + ' silences cut, ' + total.toFixed(1) + ' s shorter' + (res.warnings.length ? ' · ' + res.warnings[0] : ''), !res.warnings.length);
            if (st.range === 'inout' && info.hasInOut) await CS.call('AS_setInOut', JSON.stringify({ start: r.start, end: r.end - total }));
          } else add('no silence long enough to cut');
          info = await seqRange(); r = pickRange(info, st.range);
        }
        /* 3 · speaker switch: a new track with the talking camera, the originals muted */
        let cutTrack = -1;
        if (st.speaker) {
          const spk = loadCfg('os.speaker', { threshold: -40, margin: 3 });
          const envs = [];
          for (let i = 0; i < micTracks.length; i++) {
            progress.title('Listening to mic ' + (i + 1) + ' / ' + micTracks.length); progress.progress(0.35 + 0.15 * i / micTracks.length, 'A' + (micTracks[i] + 1));
            envs.push(await AudioTool.exportRange(r.start, r.end, [micTracks[i]], 'mic' + micTracks[i]));
          }
          const segs = Core.speakerSegments(envs, micTracks.map(a => st.map[a]), camTracks, st.wide, { minShot: st.minShot, threshold: spk.threshold, margin: spk.margin }, r);
          progress.title('Building the cut'); progress.progress(0.55, segs.length + ' shots');
          const res = await CS.call('AS_buildMulticam', JSON.stringify({ segments: segs, camTracks, name: 'Podcast cut' }));
          if (!res.ok) throw new Error(res.error);
          cutTrack = res.track;
          const scratch = Object.keys(st.camAudio).map(Number).map(v => st.camAudio[v]).filter(a => a >= 0 && !micTracks.includes(a));
          await CS.call('AS_muteTracks', JSON.stringify({ videos: camTracks, audios: Array.from(new Set(scratch)) }));
          add(res.placed + ' shots on V' + (res.track + 1) + ', camera tracks muted' + (res.warnings.length ? ' · ' + res.warnings[0] : ''), !res.warnings.length);
        }
        /* 4 · punch zoom on the loud moments of the cut */
        if (st.zoom) {
          progress.title('Finding the loud moments'); progress.progress(0.6, '');
          const audio = await AudioTool.exportRange(r.start, r.end, micTracks.length ? micTracks : null, 'zoom');
          const inDur = 0.25, hold = 1.2, outDur = 0.6;
          const times = AudioTool.peaks(audio, { thresholdDb: st.zoomThreshold, minGap: inDur + hold + outDur + 1.5 }).map(t => t + r.start);
          if (times.length) {
            const targets = cutTrack >= 0 ? { track: cutTrack } : (camTracks.length ? { track: camTracks[0] } : 'selected');
            const res = await CS.call('AS_applyZooms', JSON.stringify({ targets, zooms: times.map(t => ({ t, amount: st.zoomAmount, inDur, hold, outDur })), anchor: [0.5, 0.4], width: info.width, height: info.height }));
            if (!res.ok) add('zooms: ' + res.error, false); else add(times.length + ' punch zooms on ' + res.clips + ' clip(s)');
          } else add('no loud moments for a zoom');
        }
        /* 5 · captions from a fresh transcript of the finished cut */
        if (st.captions) {
          progress.title('Transcribing'); progress.progress(0.65, '');
          const n = await Core.transcribe(st.model, st.language, r, (p, t) => { progress.title(t); progress.progress(0.65 + p * 0.25, ''); });
          const words = transcript ? transcript.words.filter(w => w.s >= r.start - 0.01 && w.s <= r.end) : [];
          const phrases = Captions.groupWords(words, capStyle.maxWords, capStyle.gap);
          if (phrases.length) {
            const cues = phrases.map(ph => ({ s: ph.s, e: ph.e + ph.hold, text: ph.words.map(w => capStyle.upper ? w.w.toUpperCase() : w.w).join(' ') }));
            const file = CS.path.join(await outDir('captions'), 'podcast_' + Date.now().toString(36) + '.srt');
            CS.fs.writeFileSync(file, cues.map((c, i) => (i + 1) + '\n' + srtTime(c.s) + ' --> ' + srtTime(c.e) + '\n' + c.text + '\n').join('\n'), 'utf8');
            const res = await CS.call('TL_captionsFromSRT', file, 0);
            if (!res.ok) add('captions: ' + res.error, false); else add(n + ' words transcribed, ' + cues.length + ' captions added');
          } else add('nothing to caption', false);
        }
        /* 6 · vertical version */
        if (st.reframe) {
          progress.title('Vertical version'); progress.progress(0.92, 'Auto Reframe');
          const res = await CS.call('AS_reframe', JSON.stringify({ formats: [{ num: 9, den: 16, name: '9:16' }], motion: 'default', nested: false }));
          if (!res.ok) add('vertical version: ' + res.error, false); else add('created ' + res.made.join(', '));
        }
        progress.progress(1, 'done');
        try { Usage.tick('assist:podcast'); } catch (e) {}
        toast('Podcast edit done.', 'ok');
      })),
      log, note);
  }

  /* builds the track rows of a tool; retries every few seconds while no sequence is open, and on "Reload tracks" */
  function trackLoader(body, note, build) {
    let timer = null, info = null;
    const load = async () => {
      if (timer) { clearTimeout(timer); timer = null; }
      try { info = await seqRange(); note.set(''); build(info); }
      catch (e) { note.set(e.message + (/sequence/i.test(e.message) ? ' The tracks appear here as soon as one is open.' : ''), 'err'); if (body.isConnected) timer = setTimeout(load, 2500); }
    };
    const reload = row('Tracks changed?', button('Reload tracks', 'ghost small', load));
    load();
    return { get info() { return info; }, load, reload };
  }

  /* a microphone track named like a video track ("Mic Kevin" / "Cam Kevin", "Kevin audio" / "Kevin") maps to it */
  function guessCamera(audioTrack, videoTracks) {
    const words = (s) => String(s || '').toLowerCase().split(/[^a-z0-9]+/).filter(w => w.length > 1 && !/^(mic|mics|cam|camera|audio|video|track|a\d*|v\d*|sound|voice|guest|host)$/.test(w));
    const aw = words(audioTrack.name); if (!aw.length) return -1;
    let best = -1, bestN = 0;
    for (const v of videoTracks) { const n = words(v.name).filter(w => aw.includes(w)).length; if (n > bestN) { bestN = n; best = v.index; } }
    return best;
  }

  /* ---- Auto Edit ---- */
  builders.autoedit = (body) => {
    const st = loadCfg('os.auto', DEF.auto);
    const save = () => saveCfg('os.auto', st);
    const note = noteBox(), log = h('div', 'alog'), review = h('div', 'review');
    /* the Simple toggles mirror the same settings the Advanced tab edits; refreshed when you come back to Simple */
    const stepToggles = [];
    /*  A step toggle flipped while a review is open flips that category in the review too: filler words off
        means every filler word goes from filled to outlined - kept in the cut - without re-running anything. */
    const STEP_CAT = { takes: 'take', stops: 'stop', filler: 'fill', profanity: 'prof', silence: 'sil' };
    let reviewSetCat = null;
    const step = (key, title, desc) => { const t = toggle(st[key], v => { st[key] = v; save(); if (reviewSetCat && STEP_CAT[key]) reviewSetCat(STEP_CAT[key], v); }); stepToggles.push([key, t]); return row(title, t, desc); };
    /* Simple: the run panel. Advanced: every step's full tool, one sub-tab each, sharing the same saved settings. */
    const simple = h('div'), advanced = h('div'), podcast = h('div'); advanced.style.display = 'none'; podcast.style.display = 'none';
    const mkTabs = (defs, onPick) => { const bar = h('div', 'tabbar'); defs.forEach((d, i) => { const b = h('button', 'tab' + (i === 0 ? ' on' : ''), (d.icon ? icon(d.icon, 14) : '') + '<span>' + d.name + '</span>'); b.addEventListener('click', () => { bar.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === b)); onPick(d); }); bar.appendChild(b); }); return bar; };
    body.appendChild(mkTabs([{ id: 'simple', name: 'Simple', icon: 'star' }, { id: 'advanced', name: 'Advanced', icon: 'toolbox' }, { id: 'podcast', name: 'Podcast', icon: 'speaker' }], (d) => { simple.style.display = d.id === 'simple' ? '' : 'none'; advanced.style.display = d.id === 'advanced' ? '' : 'none'; podcast.style.display = d.id === 'podcast' ? '' : 'none'; if (d.id === 'simple') stepToggles.forEach(([k, t]) => t.classList.toggle('on', !!st[k])); }));
    const STEPS = [
      { id: 'silence', name: 'Auto cut', icon: 'silence', build: (c) => builders.silence(c) },
      { id: 'captions', name: 'Transcribe', icon: 'captions', build: (c) => builders.captions(c) },
      { id: 'takes', name: 'Clean takes', icon: 'takes', build: (c) => builders.takes(c) },
      { id: 'filler', name: 'Filler words', icon: 'filler', build: (c) => builders.filler(c) },
      { id: 'profanity', name: 'Profanity', icon: 'profanity', build: (c) => builders.profanity(c) },
      { id: 'transitions', name: 'Audio cuts', icon: 'audio', build: (c) => c.append(h('div', 'kbd', 'Video cuts stay hard. Every audio cut gets a very short crossfade so the sound does not click. A crossfade straddles the cut, so two frames is the shortest: one each side.'), row('Smooth audio cuts', toggle(st.transitions, v => { st.transitions = v; save(); })), row('Crossfade length', rangeNum(() => Math.max(2, st.frames || 2), v => { st.frames = v; save(); }, 2, 12, 1, 'frames')), row('Crossfade', select([['Constant Power', 'Constant Power'], ['Constant Gain', 'Constant Gain'], ['Exponential Fade', 'Exponential Fade']], /Cross Dissolve|Film Dissolve|Dip to|Morph/.test(st.transition || '') ? 'Constant Power' : (st.transition || 'Constant Power'), v => { st.transition = v; save(); }))) }
    ];
    const advBody = h('div'), built = {};
    const showStep = (d) => { advBody.querySelectorAll(':scope > div').forEach(x => x.style.display = 'none'); if (!built[d.id]) { const c = h('div'); built[d.id] = c; advBody.appendChild(c); d.build(c); } built[d.id].style.display = ''; };
    advanced.append(h('div', 'kbd', 'Each step\'s own tool with all its settings. Changes here are saved and used by Run Auto Edit.'), mkTabs(STEPS, showStep), advBody);
    showStep(STEPS[0]);
    body.append(simple, advanced, podcast);
    buildPodcast(podcast);
    simple.append(
      h('div', 'kbd', 'Transcribes first, cuts by words, then removes silence last (which also closes any gap left by the word cuts). Each step uses the settings you saved in its own tool (see Advanced).'),
      row('Range', select(rangeOptions, st.range, v => { st.range = v; save(); })),
      step('transcribe', '1 · Transcribe (local, free)', 'transcribes the untouched timeline'),
      row('Model', select(Object.entries(LocalWhisper.MODELS).map(([k, v]) => [k, v.name]), st.model, v => { st.model = v; save(); })),
      row('Language', select([['', 'Auto detect'], ['en', 'English'], ['nl', 'Dutch'], ['de', 'German'], ['fr', 'French'], ['es', 'Spanish'], ['it', 'Italian'], ['pt', 'Portuguese']], st.language, v => { st.language = v; save(); })),
      step('takes', '2 · Clean takes', 'keep the last take of repeated sentences'),
      step('stops', '2b · Cut-off sentences', 'a sentence given up halfway and started again'),
      (() => { const sc = loadCfg('os.stops', DEF.stops); return row('Second opinion with your OpenAI key', toggle(!!sc.llm, v => { sc.llm = v; saveCfg('os.stops', sc); }), 'your own key from Settings, one request per run, judges which sentences were really given up on'); })(),
      step('filler', '3 · Remove filler words', 'uh, um, hmm… plus your list'),
      step('profanity', '4 · Profanity', 'mute or cut, as set in the Profanity tool'),
      step('silence', '5 · Auto cut', 'runs last, so it also swallows any gap the word cuts left behind'),
      step('transitions', '6 · Smooth audio cuts', 'a 2-frame Constant Power crossfade on every audio cut, so nothing clicks (settings in Advanced)'),
      button('Run Auto Edit', 'primary big', () => busy('Auto Edit', async () => {
        log.innerHTML = ''; review.innerHTML = ''; review.style.display = 'none';
        const add = (txt, ok) => { log.appendChild(h('div', 'aline' + (ok === false ? ' bad' : ''), (ok === false ? '✕ ' : '✓ ') + txt)); Log[ok === false ? 'warn' : 'info']('autoedit', txt); };
        Log.section('Auto Edit · analyse');
        Log.info('autoedit', 'settings', st);
        const info = await seqRange();
        const range = pickRange(info, st.range);
        Log.info('autoedit', 'range', { mode: st.range, range, seq: { name: info.name, fps: info.fps, duration: info.duration, inPoint: info.inPoint, outPoint: info.outPoint, hasInOut: info.hasInOut, selection: (info.selection || []).length } });
        /* ---- phase 1: analyse only, the timeline is untouched until the review is confirmed ---- */
        if (st.transcribe || ((st.takes || st.stops || st.filler || st.profanity) && !transcript)) {
          progress.title('Transcribing');
          const n = await Core.transcribe(st.model, st.language, range, (p, t) => { progress.title(t); progress.progress(0.05 + p * 0.7, ''); });
          add('transcribed ' + n + ' words');
        }
        const words = transcript ? transcript.words : [];
        /* one mark per word: { cat: 'take' | 'fill' | 'prof' | 'man', on } — takes remember their lead-in */
        const marks = words.map(() => null);
        const plan = { words, marks, silences: [], thr: null, takes: [], lead: loadCfg('os.takes', DEF.takes).lead || 0 };
        if (st.takes) { plan.takes = Core.findTakes(loadCfg('os.takes', DEF.takes)); for (const f of plan.takes) words.forEach((w, i) => { if (w.s >= f.s - 0.001 && w.s < f.e && !marks[i]) marks[i] = { cat: 'take', on: true, text: f.text }; }); }
        if (st.stops) {
          progress.title('Cut-off sentences');
          const r = await Core.stops(loadCfg('os.stops', DEF.stops));
          for (const x of r.list) for (let i = x.i; i <= x.j; i++) if (!marks[i]) marks[i] = { cat: 'stop', on: true, text: x.text };
          add(r.list.length + ' cut-off sentence(s)' + (r.how === 'openai' ? ' (OpenAI)' : '') + (r.note ? ' · ' + r.note : ''), !r.note);
        }
        if (st.filler) for (const x of Core.findFillers(loadCfg('os.filler', DEF.filler))) for (let i = x.i; i <= x.j; i++) marks[i] = { cat: 'fill', on: true };
        /* what the plan holds, in the log: the first thing to look at when someone says it cut too much */
        try { const n = {}; for (const m of marks) if (m) n[m.cat] = (n[m.cat] || 0) + 1; Log.info('assist', 'plan', { words: words.length, seconds: words.length ? +(words[words.length - 1].e - words[0].s).toFixed(1) : 0, takes: plan.takes.length, marks: n }); } catch (e) {}
        if (st.profanity) for (const x of Core.findProfanity(loadCfg('os.profanity', DEF.profanity))) marks[x.i] = { cat: 'prof', on: true };
        if (st.silence) {
          progress.title('Analysing silence'); progress.progress(0.8, 'exporting audio');
          const sil = loadCfg('os.silence', DEF.silence);
          const audio = await AudioTool.exportRange(range.start, range.end, null, 'silence');
          const r = Core.silenceCuts(audio, sil);
          plan.audio = audio;
          const span = range.end - range.start, total = r.cuts.reduce((a, c) => a + (c[1] - c[0]), 0), longest = r.cuts.reduce((a, c) => Math.max(a, c[1] - c[0]), 0);
          Log.info('autoedit', 'silence', { thr: r.thr, span: +span.toFixed(2), total: +total.toFixed(2), longest: +longest.toFixed(2), cuts: r.cuts.map(c => [+c[0].toFixed(2), +c[1].toFixed(2)]) });
          plan.thr = r.thr;
          if (r.cuts.length && (total > 0.8 * span || longest > Math.max(20, 0.5 * span))) { add('silence detection looks wrong (' + fmt(total) + ' of ' + fmt(span) + ', longest ' + fmt(longest) + '), skipped', false); Log.error('autoedit', 'silence sanity guard tripped'); }
          else {
            plan.silences = r.cuts.map(c => ({ s: c[0], e: c[1], on: true }));
            if (plan.silences.length) {
              const f = plan.silences[0], l = plan.silences[plan.silences.length - 1];
              if (f.s - range.start < 0.4) f.s = range.start;
              if (range.end - l.e < 0.4) l.e = range.end;
            }
          }
        }
        Log.info('autoedit', 'plan', { takes: plan.takes.map(f => [+f.s.toFixed(2), +f.e.toFixed(2), f.text]), marked: marks.filter(Boolean).length, silences: plan.silences.length });
        renderReview(plan, range, info);
      })),
      review, log, note);
    /* ---- review: colour-coded transcript. Click a word to flip it, drag across words (or shift-click) to flip many.
            Filled = removed, outlined = kept. Unmarked words can be selected to remove them by hand. ---- */
    let reviewFinish = null;
    function renderReview(plan, range, info) {
      review.innerHTML = ''; review.style.display = '';
      const { words, marks } = plan;
      const legend = h('div', 'rv-legend', '<span class="rv-k r-take clickable" data-cat="take">repeated take</span><span class="rv-k r-stop clickable" data-cat="stop">cut-off sentence</span><span class="rv-k r-fill clickable" data-cat="fill">filler word</span><span class="rv-k r-prof clickable" data-cat="prof">banned word</span><span class="rv-k r-man clickable" data-cat="man">removed by you</span><span class="rv-k r-sil clickable" data-cat="sil">silence</span><span class="hint">filled = removed · outlined = kept · click a word, or drag / shift-click over several · click a label to keep or remove all of that kind</span>');
      /* one kind at a time: all on, or all off (outlined = kept) */
      const catOn = (cat) => cat === 'sil' ? plan.silences.some(x => x.on) : marks.some(m => m && m.cat === cat && m.on);
      const setCat = (cat, on) => { if (cat === 'sil') plan.silences.forEach(x => { x.on = on; }); else marks.forEach(m => { if (m && m.cat === cat) m.on = on; }); draw(); };
      legend.querySelectorAll('[data-cat]').forEach(k => { k.title = 'Keep or remove every ' + k.textContent; k.addEventListener('click', () => setCat(k.dataset.cat, !catOn(k.dataset.cat))); });
      reviewSetCat = setCat;
      const summary = h('div', 'kbd');
      const tv = h('div', 'tview rv');
      /* the Auto Cut waveform: pink = silence that goes; click a pink block to keep it, click again to remove it */
      const env = plan.audio ? h('canvas', 'env') : null;
      if (env) {
        env.width = 900; env.height = 110;
        env.title = 'Click a pink block to keep that silence, click again to cut it';
        env.addEventListener('click', (e) => { const rc = env.getBoundingClientRect(); const t = plan.audio.start + (e.clientX - rc.left) / rc.width * plan.audio.duration; const hit = plan.silences.find(x => t >= x.s && t <= x.e) || plan.silences.reduce((best, x) => (Math.min(Math.abs(x.s - t), Math.abs(x.e - t)) < 0.25 && (!best || Math.min(Math.abs(x.s - t), Math.abs(x.e - t)) < Math.min(Math.abs(best.s - t), Math.abs(best.e - t)))) ? x : best, null); if (hit) { hit.on = !hit.on; draw(); } });
      }
      const drawEnv = () => { if (env) AudioTool.drawEnvelope(env, plan.audio, plan.silences.filter(x => x.on).map(x => [x.s, x.e]), plan.audio.start); };
      const spans = [];
      let anchor = -1, dragging = false, dragEnd = -1, lastClick = -1;
      const selRange = () => anchor < 0 || dragEnd < 0 ? null : [Math.min(anchor, dragEnd), Math.max(anchor, dragEnd)];
      const paintSel = () => { const r = selRange(); spans.forEach((s, i) => s.classList.toggle('sel', !!r && i >= r[0] && i <= r[1])); };
      const flipRange = (a, b) => {
        const idx = []; for (let i = a; i <= b; i++) idx.push(i);
        const marked = idx.filter(i => marks[i]);
        if (!marked.length) { for (const i of idx) marks[i] = { cat: 'man', on: true }; }          /* nothing detected here: remove by hand */
        else { const anyOn = marked.some(i => marks[i].on); for (const i of marked) marks[i].on = !anyOn; }
        draw();
      };
      const total = () => {
        let t = 0; runs().forEach(r => { t += r.e - r.s; }); plan.silences.filter(x => x.on).forEach(x => { t += x.e - x.s; }); return t;
      };
      /* consecutive removed words of one kind become one cut; the pause up to the next kept word goes with it */
      function runs() {
        const out = []; let i = 0;
        while (i < words.length) {
          const m = marks[i];
          if (!m || !m.on || m.cat === 'prof') { i++; continue; }
          let j = i; while (j + 1 < words.length && marks[j + 1] && marks[j + 1].on && marks[j + 1].cat !== 'prof') j++;
          const next = words[j + 1];
          const hasTake = marks.slice(i, j + 1).some(x => x.cat === 'take' || x.cat === 'stop');
          const s = Math.max(0, words[i].s - (m.cat === 'take' ? plan.lead : 0.03));
          /* a take run swallows the pause up to the retake; a plain word run keeps a hair of padding */
          const e = hasTake && next ? next.s : Math.min(words[j].e + 0.03, next ? next.s : words[j].e + 0.03);
          out.push({ s, e, cat: m.cat, from: i, to: j });
          i = j + 1;
        }
        return out;
      }
      plan.runs = runs;
      const draw = () => {
        tv.innerHTML = ''; spans.length = 0;
        let silIdx = 0;
        const sils = plan.silences.slice().sort((a, b) => a.s - b.s);
        const chip = (x) => { const c = h('span', 'tw r-sil' + (x.on ? '' : ' keep'), '··· ' + (x.e - x.s).toFixed(1) + 's'); c.title = 'silence ' + fmt(x.s) + ' → ' + fmt(x.e) + ' · click to keep / remove'; c.addEventListener('click', () => { x.on = !x.on; draw(); }); tv.appendChild(c); tv.appendChild(document.createTextNode(' ')); };
        words.forEach((w, i) => {
          while (silIdx < sils.length && sils[silIdx].e <= w.s + 0.001) { chip(sils[silIdx]); silIdx++; }
          const m = marks[i];
          const s = h('span', 'tw clickable' + (m ? ' r-' + m.cat + (m.on ? '' : ' keep') : ''), w.w);
          s.title = fmt(w.s) + (m && m.text ? (m.cat === 'stop' ? ' · cut-off sentence "' + m.text + '"' : ' · repeated take "' + m.text + '"') : '');
          s.dataset.i = i;
          s.addEventListener('mousedown', (e) => { e.preventDefault(); if (e.shiftKey && lastClick >= 0) { flipRange(Math.min(lastClick, i), Math.max(lastClick, i)); lastClick = i; return; } anchor = i; dragEnd = i; dragging = true; paintSel(); });
          s.addEventListener('mouseenter', () => { if (dragging) { dragEnd = i; paintSel(); } });
          spans.push(s);
          tv.appendChild(s); tv.appendChild(document.createTextNode(' '));
        });
        while (silIdx < sils.length) { chip(sils[silIdx]); silIdx++; }
        legend.querySelectorAll('[data-cat]').forEach(k => k.classList.toggle('keep', !catOn(k.dataset.cat)));
        const rs = runs();
        drawEnv();
        summary.textContent = rs.filter(r => r.cat === 'take').length + ' take cuts · ' + rs.filter(r => r.cat === 'stop').length + ' cut-off sentences · ' + rs.filter(r => r.cat === 'fill').length + ' filler cuts · ' + marks.filter(m => m && m.on && m.cat === 'prof').length + ' banned words · ' + rs.filter(r => r.cat === 'man').length + ' manual cuts · ' + plan.silences.filter(x => x.on).length + ' silences' + (plan.thr !== null ? ' at ' + plan.thr + ' dB' : '') + ' · ' + fmt(total()) + ' removed of ' + fmt(range.end - range.start);
      };
      const finish = () => { if (!dragging) return; dragging = false; const r = selRange(); anchor = -1; dragEnd = -1; if (r) { lastClick = r[0] === r[1] ? r[0] : r[1]; flipRange(r[0], r[1]); } paintSel(); };
      if (reviewFinish) window.removeEventListener('mouseup', reviewFinish);
      reviewFinish = finish;
      window.addEventListener('mouseup', finish);
      draw();
      const apply = button('Apply these edits', 'primary big', () => busy('Applying', async () => { review.style.display = 'none'; reviewSetCat = null; window.removeEventListener('mouseup', finish); await applyPlan(plan, range, info); }));
      const cancel = button('Cancel', 'ghost', () => { review.style.display = 'none'; review.innerHTML = ''; reviewSetCat = null; window.removeEventListener('mouseup', finish); });
      review.append(section('Review before cutting'), legend, summary, tv);
      if (env) review.append(h('div', 'kbd', 'Silence (pink is removed, click to keep)'), env);
      review.append(apply, cancel);
      review.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    /* ranges recorded before earlier cuts: drop the ones that were cut away, slide the rest left */
    const shiftRanges = (list, cuts) => {
      const out = [];
      const mapT = (t) => t - cuts.filter(c => c[1] <= t + 0.001).reduce((a, c) => a + (c[1] - c[0]), 0);
      for (const r of list) {
        let parts = [[r.s, r.e]];
        for (const c of cuts) {
          const nextParts = [];
          for (const p of parts) {
            if (c[1] <= p[0] || c[0] >= p[1]) { nextParts.push(p); continue; }          /* no overlap */
            if (c[0] > p[0]) nextParts.push([p[0], c[0]]);                                /* head survives */
            if (c[1] < p[1]) nextParts.push([c[1], p[1]]);                                /* tail survives */
          }
          parts = nextParts;
        }
        for (const p of parts) if (p[1] - p[0] > 0.02) out.push(Object.assign({}, r, { s: mapT(p[0]), e: mapT(p[1]) }));
      }
      return out;
    };
    /* cuts separated by less than a blink become one cut, so no silent slivers survive between them */
    const mergeClose = (cuts, gap) => { const out = []; for (const c of cuts.slice().sort((a, b) => a[0] - b[0])) { const l = out[out.length - 1]; if (l && c[0] - l[1] < gap) l[1] = Math.max(l[1], c[1]); else out.push(c.slice()); } return out; };
    /* ---- phase 2: apply the confirmed plan in order (word cuts, profanity, silence, audio smoothing) ---- */
    async function applyPlan(plan, range0, info) {
      try { Usage.tick('autoedit'); } catch (e) {}
      const add = (txt, ok) => { log.appendChild(h('div', 'aline' + (ok === false ? ' bad' : ''), (ok === false ? '✕ ' : '✓ ') + txt)); Log[ok === false ? 'warn' : 'info']('autoedit', txt); };
      Log.section('Auto Edit · apply');
      let range = Object.assign({}, range0);
      /*  Every list still to be applied is kept in the timeline's CURRENT coordinates and re-mapped after each
          step by the cuts that step made. The old way kept one growing list of "done" cuts and mapped every
          later list against all of them at once, which only works when every entry is in the same coordinate
          system - the profanity step's cuts were not (they were computed after the word cuts had already
          shifted the timeline), so with profanity set to "cut" the silence cuts that followed landed early
          by the length of the banned words. Re-mapping step by step cannot mix systems.                    */
      const pending = {
        prof: plan.words.map((w, i) => ({ i, w })).filter(x => plan.marks[x.i] && plan.marks[x.i].on && plan.marks[x.i].cat === 'prof').map(x => ({ s: x.w.s, e: x.w.e, w: x.w.w })),
        sil: plan.silences.filter(x => x.on).map(x => ({ s: x.s, e: x.e })),
      };
      const remap = (cuts) => { pending.prof = shiftRanges(pending.prof, cuts); pending.sil = shiftRanges(pending.sil, cuts); };
      const shrink = async (cuts) => {
        const saved = cuts.reduce((a, c) => a + Math.max(0, Math.min(c[1], range.end) - Math.max(c[0], range.start)), 0);
        if (!(saved > 0)) return;
        range = { start: range.start, end: Math.max(range.start, range.end - saved) };
        Log.info('autoedit', 'range shrunk by ' + saved.toFixed(2), range);
        if (st.range === 'inout' && info.hasInOut) { const r = await CS.call('AS_setInOut', JSON.stringify(range)); Log.info('autoedit', 'in/out moved', r); }
      };
      const stepCut = async (label, ranges) => {
        const cuts = mergeClose(mergeRanges(ranges.map(x => [x.s, x.e]).filter(c => c[1] > c[0] + 0.05)), 0.15);
        Log.info('autoedit', label + ' cuts', cuts);
        if (!cuts.length) return 0;
        const r = await Core.applyCuts(cuts, 'ripple', label);
        Log.info('autoedit', label + ' result', r);
        await shrink(cuts);
        remap(cuts);
        add(r.applied + ' ' + label + ' removed' + (r.warnings.length ? ' · ' + r.warnings.join(' · ').slice(0, 300) : ''), !r.warnings.length);
        return r.applied;
      };
      const rs = plan.runs();
      progress.title('1/4 Word cuts'); progress.progress(0.15, '');
      if (rs.length) await stepCut('word cuts (takes, fillers, manual)', rs); else add('no words to remove');
      progress.title('2/4 Profanity'); progress.progress(0.45, '');
      const pst = loadCfg('os.profanity', DEF.profanity);
      if (pending.prof.length) {
        const hits = pending.prof;
        const r = await Core.applyProfanity(hits.map(x => ({ w: { s: x.s, e: x.e, w: x.w } })), pst);
        if (pst.mode === 'cut') { const cuts = mergeRanges(hits.map(x => [Math.max(0, x.s - pst.pad), x.e + pst.pad])); await shrink(cuts); remap(cuts); }
        add(r.count + ' banned words ' + (pst.mode === 'cut' ? 'cut' : 'muted') + (r.beeps ? ', ' + r.beeps + ' beeps' : ''));
      } else add('no banned words to handle');
      progress.title('3/4 Silence'); progress.progress(0.65, '');
      if (pending.sil.length) await stepCut('silences', pending.sil); else add('no silences to remove');
      if (st.transitions) {
        progress.title('4/4 Smoothing audio cuts'); progress.progress(0.92, '');
        try {
          const name = /Cross Dissolve|Film Dissolve|Dip to|Morph/.test(st.transition || '') ? 'Constant Power' : (st.transition || 'Constant Power');
          const r = await CS.call('TL_audioTransitions', JSON.stringify({ name, frames: st.frames || 2 }));
          if (!r.ok) throw new Error(r.error);
          add((st.frames || 2) + '-frame ' + name + ' on ' + r.done + ' audio cuts' + (r.warnings.length ? ' · ' + r.warnings[0] : ''), !r.warnings.length);
        } catch (e) { add('audio smoothing: ' + e.message, false); }
      }
      progress.progress(1, 'done');
      toast('Auto Edit finished.', 'ok');
    }
  };

  /* ---- Auto Cut ---- */
  builders.silence = (body) => {
    const st = loadCfg('os.silence', DEF.silence);
    const save = () => saveCfg('os.silence', st);
    let audio = null, cuts = [];
    const note = noteBox(), cv = h('canvas', 'env'); cv.width = 900; cv.height = 110;
    (() => { const g = cv.getContext('2d'); g.fillStyle = '#1e2a3a'; g.fillRect(0, 0, 900, 110); g.fillStyle = '#7f8aa3'; g.font = '20px sans-serif'; g.textAlign = 'center'; g.fillText('Analyze to see the waveform; cuts show in pink as you drag the sliders', 450, 62); })();
    const summary = h('div', 'kbd');
    let thrCtl, padRCtl, padLCtl;
    const recompute = () => {
      save();
      if (!audio) return;
      const res = Core.silenceCuts(audio, st);
      if (st.auto) { st.threshold = res.thr; thrCtl.setValue(res.thr); }
      cuts = res.cuts;
      AudioTool.drawEnvelope(cv, audio, cuts, audio.start);
      const saved = cuts.reduce((a, c) => a + (c[1] - c[0]), 0);
      summary.textContent = cuts.length + ' cuts · removes ' + fmt(saved) + ' of ' + fmt(audio.duration) + ' (' + Math.round(saved / Math.max(0.1, audio.duration) * 100) + '%)';
    };
    thrCtl = rangeNum(() => st.threshold, v => { st.threshold = v; st.auto = false; autoSw.classList.remove('on'); }, -70, -5, 1, 'dB', recompute);
    const autoSw = toggle(st.auto, v => { st.auto = v; recompute(); });
    const thrRow = h('div', 'inline'); thrRow.append(thrCtl, h('span', 'hint', 'Auto'), autoSw);
    padLCtl = rangeNum(() => st.padLeft, v => { st.padLeft = v; if (st.lock) { st.padRight = v; padRCtl.setValue(v); } }, 0, 1, 0.01, 's', recompute);
    padRCtl = rangeNum(() => st.padRight, v => { st.padRight = v; if (st.lock) { st.padLeft = v; padLCtl.setValue(v); } }, 0, 1, 0.01, 's', recompute);
    const lockSw = toggle(st.lock, v => { st.lock = v; if (v) { st.padRight = st.padLeft; padRCtl.setValue(st.padLeft); recompute(); } });
    body.append(
      row('Range', select(rangeOptions, st.range, v => { st.range = v; save(); })),
      button('Analyze audio', 'primary', () => busy('Exporting audio from Premiere', async () => {
        const info = await seqRange();
        const r = pickRange(info, st.range);
        progress.title('Analyzing ' + fmt(r.end - r.start));
        audio = await AudioTool.exportRange(r.start, r.end, null, 'silence');
        recompute(); note.set('');
      })),
      cv, summary,
      section('Threshold'), row('Below this is silent', thrRow),
      section('Minimum duration'), row('Silence longer than this is cut', rangeNum(() => st.minSilence, v => st.minSilence = v, 0.05, 3, 0.01, 's', recompute)),
      section('Padding'),
      row('Left (after speech)', padLCtl, 'air kept before the cut'),
      row('Right (before speech)', padRCtl, 'air kept after the cut'),
      row('Lock left = right', lockSw),
      section('Remove short audio spikes'), row('Audible bits shorter than this are cut too', rangeNum(() => st.spike, v => st.spike = v, 0, 2, 0.01, 's', recompute)),
      section('Apply'),
      row('Apply as', select([['ripple', 'Ripple cut (remove and close gaps)'], ['disable', 'Disable clips inside silences'], ['markers', 'Markers only']], st.mode, v => { st.mode = v; save(); })),
      button('Apply cuts', 'primary', () => busy('Cutting', async () => {
        if (!cuts.length) throw new Error('Analyze first, or lower the threshold.');
        const r = await Core.applyCuts(cuts, st.mode, 'silence');
        toast((st.mode === 'markers' ? r.applied + ' markers added.' : r.applied + ' silences cut.') + (r.warnings.length ? ' ' + r.warnings[0] : ''), r.warnings.length ? 'err' : 'ok');
        audio = null; cuts = []; summary.textContent = 'Done. Analyze again for a fresh pass.';
      })),
      note);
  };

  /* ---- Word Captions ---- */
  /* out of the box: the Gold big-word style, which is what the tool is for */
  let capStyle = Captions.applyPreset(Object.assign({}, Captions.DEFAULT_STYLE, { cumulative: true, range: 'inout' }), 'gold');
  try { Object.assign(capStyle, JSON.parse(localStorage.getItem('os.capStyle') || '{}')); } catch (e) {}
  /* the glow used to be one number; keep what people had set */
  /*  The mode used to default to Premiere's own caption track, and every saved style carries whatever it
      was then - saveStyle() runs on any change, so almost everyone has one. Move the people who never
      chose a mode themselves; leave anyone who did.                                                    */
  if (!capStyle.outputPicked && capStyle.output === 'native') capStyle.output = 'png';
  /*  A style saved before the presets existed carries hero: 0 and no preset, which would override Gold and
      leave plain white captions. Give those people the default too - but never anyone who picked a preset
      or chose the plain Premiere mode themselves.                                                       */
  if (!capStyle.preset && !capStyle.outputPicked) Captions.applyPreset(capStyle, 'gold');
  if (capStyle.glow !== undefined) { if (capStyle.glowSize === undefined) capStyle.glowSize = capStyle.glow; if (capStyle.glowStrength === undefined) capStyle.glowStrength = capStyle.glow > 0 ? 1 : 0; delete capStyle.glow; }
  const saveStyle = () => saveCfg('os.capStyle', capStyle);
  /* the word tools transcribe on their own when there is no transcript yet (local whisper, last chosen model) */
  async function ensureTranscript(mode) {
    if (transcript && transcript.words.length) return true;
    let model = 'base'; try { model = localStorage.getItem('os.whisperModel') || 'base'; } catch (e) {}
    const info = await seqRange();
    const n = await Core.transcribe(model, '', pickRange(info, mode || 'inout'), (p, t) => { progress.title(t); progress.progress(p, ''); });
    if (!n) throw new Error('The transcript came back empty.');
    toast('Transcript ready: ' + n + ' words.', 'ok');
    return true;
  }
  builders.captions = (body) => {
    const st = capStyle;
    const checkRange = (info) => {
      if (st.range === 'selected' && !info.selection.length) throw new Error('Select the clips you want captions on in the timeline, then click again.');
    };
    const note = noteBox(), status = h('div', 'st-note'), tview = h('div');
    const refresh = () => {
      if (transcript) { status.className = 'st-note show ok'; status.innerHTML = '<b>' + icon('check', 14) + ' Transcript ready</b> · ' + transcript.words.length + ' words · ' + transcript.source; transcriptView(tview, transcript.words); }
      else { status.className = 'st-note show'; status.textContent = 'No transcript yet. Transcribe below or import one.'; tview.innerHTML = ''; }
    };
    onTranscript(refresh);
    let language = '';
    const lang = select([['', 'Auto detect'], ['en', 'English'], ['nl', 'Dutch'], ['de', 'German'], ['fr', 'French'], ['es', 'Spanish'], ['it', 'Italian'], ['pt', 'Portuguese']], '', v => language = v);
    let model = 'base';
    try { model = localStorage.getItem('os.whisperModel') || 'base'; } catch (e) {}
    const modelSel = select(Object.entries(LocalWhisper.MODELS).map(([k, v]) => [k, v.name]), model, v => { model = v; try { localStorage.setItem('os.whisperModel', v); } catch (e) {} });
    const localBtn = button('Transcribe (local, free)', 'primary', () => busy('Preparing', async () => {
      const info = await seqRange();
      checkRange(info);
      const n = await Core.transcribe(model, language, pickRange(info, st.range), (p, t) => { progress.title(t); progress.progress(p, ''); });
      toast('Transcript ready: ' + n + ' words.', 'ok');
    }));
    const importBtn = button('Import SRT / VTT / JSON', 'ghost', async () => {
      const text = await CS.pickTextFile('Subtitle or transcript file', ['srt', 'vtt', 'json', 'txt']);
      if (!text) return;
      try {
        if (/^\s*[\[{]/.test(text)) {
          const d = JSON.parse(text);
          const ws = (d.words || (d.segments && d.segments.flatMap(s => s.words || [])) || []).map(w => ({ s: w.start !== undefined ? w.start : w.s, e: w.end !== undefined ? w.end : w.e, w: (w.word || w.w || '').trim() })).filter(w => w.w);
          if (!ws.length) throw new Error('No word timings found in the JSON.');
          setTranscript(ws, 'JSON');
        } else {
          const cues = Captions.parseSubtitles(text);
          if (!cues.length) throw new Error('No cues found. Is this an SRT/VTT file?');
          setTranscript(Captions.cuesToWords(cues), 'subtitles (' + cues.length + ' cues)');
        }
        toast('Transcript ready.', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    });
    const cloudBtn = button('Cloud (OpenAI)', 'ghost', () => busy('Exporting audio', async () => {
      const key = (Hub.keys().openai || (window.BUILTIN_KEYS || {}).openai || '').trim();
      if (!key) throw new Error('Add an OpenAI API key in Settings first, or use the free local transcription.');
      const info = await seqRange();
      checkRange(info);
      const r = pickRange(info, st.range);
      const audio = await AudioTool.exportRange(r.start, r.end, null, 'whisper');
      progress.title('Transcribing with Whisper');
      const wav = AudioTool.wav16k(audio.samples, audio.sampleRate);
      if (wav.length > 24.5 * 1024 * 1024) throw new Error('Longer than the API accepts in one go (about 12 minutes). Set In/Out points on a shorter part.');
      const res = await Captions.whisper(wav, key, language);
      setTranscript(res.words.map(w => ({ s: w.s + audio.start, e: w.e + audio.start, w: w.w })), 'Whisper API');
      toast('Transcript ready: ' + res.words.length + ' words.', 'ok');
    }));
    const r1 = h('div', 'inline'); r1.append(localBtn, modelSel, lang);
    const r2 = h('div', 'inline'); r2.append(importBtn, cloudBtn);
    const ws = LocalWhisper.status();
    body.append(section('Transcript'), r1, h('div', 'kbd', ws.exe ? 'Transcription engine installed · models: ' + (Object.keys(ws.models).filter(k => ws.models[k]).join(', ') || 'none yet') : 'First run downloads the transcription engine (about 15 MB) and the chosen model, then everything runs offline.'), r2, status, tview);
    refresh();

    /*  The preview is the shape of the sequence, not always 16:9. Caption size is a percentage of the
        frame HEIGHT and wrapping is a percentage of its WIDTH, so on the wrong shape the preview lies
        about both. Outside Premiere there is no sequence to ask, so 16:9 it is.                      */
    let frameW = 640, frameH = 360;
    const pv = h('canvas', 'cap-preview');
    const sizePreview = (W, H) => {
      if (!(W > 0 && H > 0)) return;
      frameW = W; frameH = H;
      const long = 640, k = long / Math.max(W, H);
      pv.width = Math.max(120, Math.round(W * k)); pv.height = Math.max(120, Math.round(H * k));
    };
    sizePreview(frameW, frameH);
    if (CS.inCEP) seqRange().then((info) => { sizePreview(info.width, info.height); buildGallery(); }).catch(() => {});
    const sample = { s: 0, e: 2.6, hold: 0.6, words: [{ s: 0, e: 0.5, w: 'Captions' }, { s: 0.5, e: 0.95, w: 'that' }, { s: 0.95, e: 1.5, w: 'follow' }, { s: 1.5, e: 2.0, w: 'every' }, { s: 2.0, e: 2.6, w: 'word' }] };
    /*  One tile per preset, each drawn with its own sample line so the colour and the big word are
        visible before anything is rendered. Clicking one switches to animated captions and applies it. */
    const gal = h('div', 'cap-gal');
    /* [before, the big word, after] - the middle word is forced to be the big one so the tile always
       shows the preset the way it is meant to look */
    const SHOTS = [
      ['if your name', 'makes', 'money'],   ['do not want a', 'bookkeeper', ''],
      ['listing', 'sale', 'houses'],        ['if your content', 'never', 'shows you'],
      ['will not remember', 'who', 'posted it'], ['create', 'This', 'text effect'],
      ['why your shorts', 'flop', ''],      ['ask someone', 'beautiful', '']
    ];
    const buildGallery = () => {
      gal.innerHTML = '';
      Captions.PRESETS.forEach((pr, i) => {
        const tile = h('button', 'cap-tile' + (st.preset === pr.id && st.output === 'png' ? ' on' : ''));
        const cv = h('canvas');
        const k = 300 / Math.max(frameW, frameH);
        cv.width = Math.max(80, Math.round(frameW * k)); cv.height = Math.max(80, Math.round(frameH * k));
        const shot = SHOTS[i % SHOTS.length];
        const ws = [];
        let at = 0, heroAt = -1;
        shot.forEach((part, k) => {
          for (const word of String(part).split(' ')) {
            if (!word) continue;
            if (k === 1 && heroAt < 0) heroAt = ws.length;
            ws.push({ s: at, e: at + 0.3, w: word }); at += 0.3;
          }
        });
        const ph = { s: 0, e: at, hold: 1, words: ws, hero: heroAt };
        const demo = Captions.applyPreset(Object.assign({}, Captions.DEFAULT_STYLE), pr.id);
        demo.size = 11; demo.y = 50;
        Captions.drawFrame(cv.getContext('2d'), cv.width, cv.height, ph, at + 0.4, demo);
        tile.append(cv, h('span', 'nm', pr.name));
        tile.addEventListener('click', () => { Captions.applyPreset(st, pr.id); saveStyle(); buildStyle(); buildGallery(); });
        gal.appendChild(tile);
      });
    };
    const t0 = performance.now();
    const loop = (ts) => { if (!pv.isConnected) return; if (st.output !== 'native') Captions.drawFrame(pv.getContext('2d'), pv.width, pv.height, sample, ((ts - t0) / 1000) % 3.6, st); requestAnimationFrame(loop); };
    requestAnimationFrame(loop);
    const styleBox = h('div');
    const fonts = ['Arial Black', 'Impact', 'Arial', 'Verdana', 'Tahoma', 'Segoe UI', 'Georgia', 'Trebuchet MS', 'Montserrat', 'Poppins', 'Inter', 'Bebas Neue', 'Oswald', 'Roboto'];
    const buildStyle = () => {
      styleBox.innerHTML = '';
      const native = st.output === 'native';
      pv.style.display = native ? 'none' : '';
      gal.style.display = native ? 'none' : '';
      styleBox.append(
        row('Words per caption', range(() => st.maxWords, v => { st.maxWords = v; saveStyle(); }, 1, 8, 1)),
        row('New caption after pause of', range(() => st.gap, v => { st.gap = v; saveStyle(); }, 0.2, 3, 0.1, ' s'))
      );
      if (native) {
        styleBox.append(
          row('Word by word', toggle(st.cumulative, v => { st.cumulative = v; saveStyle(); }), 'words appear as they are spoken'),
          row('Uppercase', toggle(st.upper, v => { st.upper = v; saveStyle(); })),
          h('div', 'kbd', 'Creates a real Premiere caption track: instant, and you style it once in Essential Graphics (font, size, colour, background). Word-level colour highlights are only possible in the animated mode.')
        );
        return;
      }
      styleBox.append(
        row('One big word', toggle(!!st.hero, v => { st.hero = v ? 1 : 0; saveStyle(); buildStyle(); }), 'the word that carries the line goes large and coloured'),
        st.hero ? row('Big word size', range(() => st.heroScale, v => { st.heroScale = v; saveStyle(); }, 1, 3, 0.05, '\u00d7')) : h('span'),
        st.hero ? row('Big word in capitals', toggle(!!st.heroUpper, v => { st.heroUpper = v ? 1 : 0; saveStyle(); })) : h('span'),
        st.hero ? row('Glow size', range(() => st.glowSize, v => { st.glowSize = v; saveStyle(); }, 0, 1.5, 0.02)) : h('span'),
        st.hero ? row('Glow strength', range(() => st.glowStrength, v => { st.glowStrength = v; saveStyle(); }, 0, 2, 0.05)) : h('span'),
        row('Slanted', toggle(!!st.italic, v => { st.italic = v ? 1 : 0; saveStyle(); })),
        row('Animation', select(Object.entries(Captions.STYLES).map(([k, v]) => [k, v.name + ' — ' + v.desc]), st.style, v => { st.style = v; saveStyle(); })),
        row('Font', select(fonts.map(f => [f, f]), st.font, v => { st.font = v; saveStyle(); })),
        row('Weight', select([['400', 'Regular'], ['700', 'Bold'], ['900', 'Black']], String(st.weight), v => { st.weight = +v; saveStyle(); })),
        row('Size', range(() => st.size, v => { st.size = v; saveStyle(); }, 2, 14, 0.1, '%')),
        row('Text colour', color(st.color, v => { st.color = v; saveStyle(); })),
        row('Highlight colour', color(st.hi, v => { st.hi = v; saveStyle(); })),
        row('Box colour', color(st.boxColor, v => { st.boxColor = v; saveStyle(); }), 'Highlight box style'),
        row('Outline', range(() => st.stroke, v => { st.stroke = v; saveStyle(); }, 0, 2, 0.05)),
        row('Shadow', range(() => st.shadow, v => { st.shadow = v; saveStyle(); }, 0, 2, 0.05)),
        row('Uppercase', toggle(st.upper, v => { st.upper = v; saveStyle(); })),
        row('Vertical position', range(() => st.y, v => { st.y = v; saveStyle(); }, 5, 95, 1, '%')),
        row('Line background', range(() => st.lineBg, v => { st.lineBg = v; saveStyle(); }, 0, 1, 0.05)),
        row('Animation speed', range(() => st.anim, v => { st.anim = v; saveStyle(); }, 0.05, 0.6, 0.01, ' s')),
        h('div', 'kbd', 'Animated captions are rendered as transparent PNG clips (one per caption). Slower, but every animation style works.')
      );
    };
    body.append(section('Output'),
      row('Captions on', select(rangeOptions, st.range, v => { st.range = v; saveStyle(); }), 'select clips in the timeline to caption only those'),
      row('Mode', select([['png', 'Animated captions (styled)'], ['native', 'Premiere captions (instant, editable)']], st.output, v => { st.output = v; st.outputPicked = true; saveStyle(); buildStyle(); buildGallery(); })),
      gal, pv, styleBox, section('Render'),
      button('Add captions to timeline', 'primary', () => busy('Preparing captions', async () => {
        const info = await seqRange();
        checkRange(info);
        if (!transcript || !transcript.words.length) await ensureTranscript(st.range);
        const spans = pickSpans(info, st.range);
        const words = wordsInSpans(transcript.words, spans);
        const phrases = Captions.groupWords(words, st.maxWords, st.gap);
        if (!phrases.length) throw new Error(st.range === 'selected' ? 'No words inside the selected clips.' : 'No words inside the current In/Out range.');
        if (st.output === 'native') {
          const cues = [];
          for (const ph of phrases) {
            const txt = (w) => st.upper ? w.w.toUpperCase() : w.w;
            if (st.cumulative) ph.words.forEach((w, k) => { const e = k < ph.words.length - 1 ? ph.words[k + 1].s : ph.e + ph.hold; if (e - w.s > 0.02) cues.push({ s: w.s, e: e - 0.001, text: ph.words.slice(0, k + 1).map(txt).join(' ') }); });
            else cues.push({ s: ph.s, e: ph.e + ph.hold, text: ph.words.map(txt).join(' ') });
          }
          const file = CS.path.join(await outDir('captions'), 'captions_' + Date.now().toString(36) + '.srt');
          CS.fs.writeFileSync(file, cues.map((c, i) => (i + 1) + '\n' + srtTime(c.s) + ' --> ' + srtTime(c.e) + '\n' + c.text + '\n').join('\n'), 'utf8');
          const res = await CS.call('TL_captionsFromSRT', file, 0);
          if (!res.ok) {
            /* older Premiere without createCaptionTrack: fall back to rendered captions */
            toast('Premiere refused the caption track (' + res.error + '). Rendering animated captions instead.');
            const res2 = await Captions.render(phrases, st, info, progress, () => cancelled);
            toast(res2.placed + ' caption clips placed on V' + (res2.track + 1) + '.', 'ok');
            return;
          }
          toast(cues.length + ' captions added as a caption track. Style them in Essential Graphics.', 'ok');
        } else {
          const res = await Captions.render(phrases, st, info, progress, () => cancelled);
          if (res.rateWarn) toast('Premiere would not take the frame rate for the caption clips, so they may run at the wrong speed. Tell me which Premiere version this is.', 'err');
          else if (res.drift > 0.001) toast(res.placed + ' caption clips placed on V' + (res.track + 1) + ', but Premiere moved one by up to ' + Math.round(res.drift * 1000) + ' ms.', 'err');
          else toast(res.placed + ' caption clips placed on V' + (res.track + 1) + '.', 'ok');
        }
      })),
      note);
    buildStyle(); buildGallery();
  };

  /* ---- Take Cleaner ---- */
  builders.takes = (body) => {
    const st = loadCfg('os.takes', DEF.takes);
    const save = () => saveCfg('os.takes', st);
    const note = noteBox(), list = h('div'), tview = h('div'), status = h('div', 'kbd');
    let found = [];
    const marked = () => found.filter(f => f.on).map(f => [f.s, f.e]);
    const refresh = () => { status.textContent = transcript ? transcript.words.length + ' words · ' + transcript.source : 'No transcript yet: load one in Word Captions first.'; transcriptView(tview, transcript && transcript.words, (w) => marked().some(c => w.s >= c[0] - 0.001 && w.s < c[1])); };
    onTranscript(refresh);
    const findTakes = async () => {
      if (!transcript) { busy('Transcribing', async () => { await ensureTranscript(); findTakes(); }); return; }
      found = Core.findTakes(st);
      if (st.stops) {
        const r = await Core.stops(loadCfg('os.stops', DEF.stops));
        if (r.note) toast(r.note, 'err');
        for (const x of r.list) if (!found.some(f => x.s < f.e && x.e > f.s)) found.push(Object.assign(x, { stop: true }));
      }
      found.sort((a, b) => a.s - b.s);
      list.innerHTML = '';
      if (!found.length) list.appendChild(h('div', 'kbd', 'No repeated takes' + (st.stops ? ' or cut-off sentences' : '') + ' found.'));
      for (const f of found) {
        const r = h('div', 'row');
        r.append(h('label', '', '<b>' + fmt(f.s) + ' → ' + fmt(f.e) + '</b> <span class="hint">"' + f.text + (f.stop ? '" cut off' : '…" repeated') + '</span>'), toggle(true, v => { f.on = v; refresh(); }));
        list.appendChild(r);
      }
      refresh();
    };
    body.append(status,
      row('Minimum repeated words', range(() => st.minWords, v => { st.minWords = v; save(); }, 2, 10, 1)),
      row('Look-ahead window', range(() => st.window, v => { st.window = v; save(); }, 5, 120, 1, ' s'), 'a retake must start within this time'),
      row('Cut-off sentences too', toggle(st.stops !== false, v => { st.stops = v; save(); }), 'a sentence given up halfway and started again'),
      (() => { const sc = loadCfg('os.stops', DEF.stops); return row('Second opinion with your OpenAI key', toggle(!!sc.llm, v => { sc.llm = v; saveCfg('os.stops', sc); }), 'your own key from Settings, one request per search'); })(),
      button('Find repeated takes', 'primary', findTakes),
      list, h('div', 'kbd', 'Red words are removed.'), tview,
      button('Cut the earlier takes', 'primary', () => busy('Cutting', async () => {
        const cuts = mergeRanges(marked().filter(c => c[1] > c[0] + 0.1));
        if (!cuts.length) throw new Error('Nothing selected to cut.');
        const r = await Core.applyCuts(cuts, 'ripple', 'retake');
        found = []; list.innerHTML = ''; refresh();
        toast(r.applied + ' takes removed.' + (r.warnings.length ? ' ' + r.warnings[0] : ''), r.warnings.length ? 'err' : 'ok');
      })),
      note);
    refresh();
  };

  /* ---- Filler Words ---- */
  builders.filler = (body) => {
    const st = loadCfg('os.filler', DEF.filler);
    const save = () => saveCfg('os.filler', st);
    const note = noteBox(), tview = h('div'), status = h('div', 'kbd');
    let hits = [];
    const draw = () => transcriptView(tview, transcript && transcript.words, (w, i) => hits.some(x => x.on && i >= x.i && i <= x.j), (w, i) => { const x = hits.find(x => i >= x.i && i <= x.j); if (x) x.on = !x.on; else hits.push({ i, j: i, s: w.s - st.pad, e: w.e + st.pad, on: true }); update(); });
    const update = () => { if (!transcript) { status.textContent = 'No transcript yet: load one in Word Captions first.'; return; } status.textContent = hits.filter(x => x.on).length + ' filler words · ' + fmt(hits.filter(x => x.on).reduce((a, x) => a + (x.e - x.s), 0)) + ' removed'; draw(); };
    const analyze = () => { hits = Core.findFillers(st); update(); };
    onTranscript(analyze);
    const custom = h('input'); custom.type = 'text'; custom.className = 'qname'; custom.value = st.custom.join(', '); custom.placeholder = 'extra words, comma separated';
    custom.addEventListener('change', () => { st.custom = custom.value.split(',').map(s => s.trim()).filter(Boolean); save(); analyze(); });
    const skip = h('input'); skip.type = 'text'; skip.className = 'qname'; skip.value = st.skip.join(', '); skip.placeholder = 'words to never cut';
    skip.addEventListener('change', () => { st.skip = skip.value.split(',').map(s => s.trim()).filter(Boolean); save(); analyze(); });
    body.append(status,
      h('div', 'kbd', 'Built-in list: ' + FILLERS.join(', ')),
      row('Extra filler words', custom), row('Never cut these', skip),
      row('Also phrases', toggle(st.phrases, v => { st.phrases = v; save(); analyze(); }), PHRASES.join(', ')),
      row('Padding', range(() => st.pad, v => { st.pad = v; save(); analyze(); }, 0, 0.2, 0.01, ' s')),
      h('div', 'kbd', 'Red words are removed. Click a word to toggle it.'), tview,
      button('Cut filler words', 'primary', () => busy('Cutting', async () => {
        const cuts = mergeRanges(hits.filter(x => x.on).map(x => [Math.max(0, x.s), x.e]));
        if (!cuts.length) throw new Error('Nothing to cut.');
        const r = await Core.applyCuts(cuts, 'ripple', 'filler');
        analyze();
        toast(r.applied + ' filler words cut.' + (r.warnings.length ? ' ' + r.warnings[0] : ''), r.warnings.length ? 'err' : 'ok');
      })),
      note);
    analyze();
  };

  /* ---- Profanity Filter ---- */
  builders.profanity = (body) => {
    const st = loadCfg('os.profanity', DEF.profanity);
    const save = () => saveCfg('os.profanity', st);
    const note = noteBox(), tview = h('div'), status = h('div', 'kbd');
    let hits = [];
    const draw = () => transcriptView(tview, transcript && transcript.words, (w, i) => hits.some(x => x.i === i), toggleWord);
    const toggleWord = (w, i) => { const k = hits.findIndex(x => x.i === i); if (k >= 0) hits.splice(k, 1); else hits.push({ i, w, on: true }); status.textContent = hits.length + ' banned word(s) selected'; draw(); };
    const analyze = () => { if (!transcript) { status.textContent = 'No transcript yet: load one in Word Captions first.'; return; } hits = Core.findProfanity(st); status.textContent = hits.length + ' banned word(s) found'; draw(); };
    onTranscript(analyze);
    const ban = h('input'); ban.type = 'text'; ban.className = 'qname'; ban.value = st.ban.join(', '); ban.placeholder = 'extra banned words';
    ban.addEventListener('change', () => { st.ban = ban.value.split(',').map(s => s.trim()).filter(Boolean); save(); analyze(); });
    const allow = h('input'); allow.type = 'text'; allow.className = 'qname'; allow.value = st.allow.join(', '); allow.placeholder = 'words to allow';
    allow.addEventListener('change', () => { st.allow = allow.value.split(',').map(s => s.trim()).filter(Boolean); save(); analyze(); });
    const beepBtn = button(st.beepFile ? st.beepFile.split(/[\\/]/).pop() : 'Built-in 1 kHz beep', 'ghost', () => { const p = CS.pickFiles(); if (p && p[0]) { st.beepFile = p[0]; beepBtn.textContent = p[0].split(/[\\/]/).pop(); save(); } });
    const resetBeep = button('Reset', 'ghost', () => { st.beepFile = ''; beepBtn.textContent = 'Built-in 1 kHz beep'; save(); });
    const beepRow = h('div', 'inline'); beepRow.append(beepBtn, resetBeep);
    body.append(status,
      h('div', 'kbd', 'Built-in list covers common English and Dutch profanity. Add or allow words below; click words in the text to toggle.'),
      row('Ban these too', ban), row('Allow these', allow),
      row('Action', select([['mute', 'Mute the word (audio only)'], ['cut', 'Cut the word out (ripple)']], st.mode, v => { st.mode = v; save(); })),
      row('Beep sound', toggle(st.beep, v => { st.beep = v; save(); }), 'off by default'),
      row('Beep file', beepRow),
      row('Padding', range(() => st.pad, v => { st.pad = v; save(); }, 0, 0.2, 0.01, ' s')),
      tview,
      button('Apply', 'primary', () => busy('Applying', async () => {
        if (!hits.length) throw new Error('No banned words selected.');
        const r = await Core.applyProfanity(hits, st);
        analyze();
        toast(r.count + ' word(s) ' + (st.mode === 'cut' ? 'cut' : 'muted') + (r.beeps ? ', ' + r.beeps + ' beeps placed' : '') + '.', 'ok');
      })),
      note);
    analyze();
  };

  /* ---- B-roll ideas ---- */
  builders.broll = (body) => {
    const STOP = new Set('the and that this with have from they were been their there what when your which about would there these other into more some could them than then also just like very will your you our not but for are was his her its had has can all any one two out up down over been being does did doing very really thing things going gonna want know think said say because make made'.split(' '));
    const box = h('div', 'inline'), status = h('div', 'kbd');
    const build = () => {
      box.innerHTML = '';
      if (!transcript) { status.textContent = 'No transcript yet: load one in Word Captions first.'; return; }
      const freq = {};
      for (const w of transcript.words) { const n = norm(w.w); if (n.length < 4 || STOP.has(n) || /^\d+$/.test(n)) continue; freq[n] = (freq[n] || 0) + 1; }
      const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 18);
      status.textContent = top.length ? 'Most used words in the transcript. Click to search stock footage.' : 'Nothing useful found.';
      for (const [w, c] of top) box.appendChild(button(w + ' · ' + c, 'ghost', () => { Stock.open('videos'); $('#st-q').value = w; Stock.search(true); }));
    };
    onTranscript(build);
    body.append(status, box); build();
  };

  /* ---- Speaker Switch ---- */
  builders.speaker = (body) => {
    const st = { minShot: 1.5, threshold: -40, margin: 3, wide: -1, range: 'inout' };
    const map = {};
    const note = noteBox(), table = h('div');
    body.append(h('div', 'kbd', 'Map each guest\'s microphone track to the camera track that shows them. Silence goes to the wide shot.'), table);
    const loader = trackLoader(body, note, (i) => {
      table.innerHTML = '';
      const camOpts = [['-1', 'not used']].concat(i.videoTracks.map(v => [String(v.index), 'V' + (v.index + 1) + (v.name && !/^V\d+$/.test(v.name) ? ' ' + v.name : '')]));
      for (const a of i.audioTracks) {
        if (!a.clips) continue;
        if (map[a.index] === undefined) map[a.index] = guessCamera(a, i.videoTracks);
        table.appendChild(row('A' + (a.index + 1) + (a.name && !/^A\d+$/.test(a.name) ? ' ' + a.name : '') + ' → camera', select(camOpts, String(map[a.index]), v => map[a.index] = +v)));
      }
      table.appendChild(row('Wide shot when nobody talks', select(camOpts, String(st.wide), v => st.wide = +v)));
    });
    body.appendChild(loader.reload);
    let info = null;
    body.append(
      row('Range', select(rangeOptions, st.range, v => st.range = v)),
      row('Minimum shot length', range(() => st.minShot, v => st.minShot = v, 0.5, 6, 0.1, ' s')),
      row('Speech threshold', range(() => st.threshold, v => st.threshold = v, -70, -10, 1, ' dB')),
      row('Switch margin', range(() => st.margin, v => st.margin = v, 0, 12, 0.5, ' dB'), 'how much louder a mic must be to take over'),
      button('Analyze mics & build cut', 'primary', () => busy('Exporting microphone tracks', async () => {
        info = loader.info || await seqRange();
        const mics = Object.keys(map).map(Number).filter(a => map[a] >= 0);
        if (mics.length < 1) throw new Error('Map at least one microphone to a camera.');
        const r = pickRange(info, st.range);
        const envs = [];
        for (let i = 0; i < mics.length; i++) {
          progress.title('Exporting mic ' + (i + 1) + ' / ' + mics.length); progress.progress(i / mics.length, 'A' + (mics[i] + 1));
          envs.push(await AudioTool.exportRange(r.start, r.end, [mics[i]], 'mic' + mics[i]));
        }
        const win = envs[0].win, n = Math.min(...envs.map(e => e.env.length));
        const cams = mics.map(a => map[a]);
        const camTracks = Array.from(new Set(cams.concat(st.wide >= 0 ? [st.wide] : [])));
        const camIdx = (track) => camTracks.indexOf(track);
        const segs = [];
        let cur = -1, curStart = 0;
        const smoothN = Math.max(1, Math.round(0.3 / win));
        for (let i = 0; i < n; i++) {
          let best = -1, bestV = -1e9, second = -1e9;
          for (let m = 0; m < envs.length; m++) {
            let s = 0, c = 0; for (let k = -smoothN; k <= smoothN; k++) { const j = i + k; if (j >= 0 && j < n) { s += envs[m].env[j]; c++; } }
            const v = s / c;
            if (v > bestV) { second = bestV; bestV = v; best = m; } else if (v > second) second = v;
          }
          let want = (bestV >= st.threshold) ? camIdx(cams[best]) : (st.wide >= 0 ? camIdx(st.wide) : cur);
          if (want < 0) want = cur < 0 ? camIdx(cams[best]) : cur;
          const t = r.start + i * win;
          if (cur < 0) { cur = want; curStart = t; continue; }
          if (want !== cur) {
            const louderEnough = bestV - second >= st.margin || bestV < st.threshold;
            if (t - curStart >= st.minShot && louderEnough) { segs.push({ s: curStart, e: t, cam: cur }); cur = want; curStart = t; }
          }
        }
        segs.push({ s: curStart, e: r.end, cam: cur });
        progress.title('Building cut'); progress.progress(1, segs.length + ' shots');
        const res = await CS.call('AS_buildMulticam', JSON.stringify({ segments: segs, camTracks, name: 'Speaker cut' }));
        if (!res.ok) throw new Error(res.error);
        toast(res.placed + ' shots placed on V' + (res.track + 1) + '. Mute or hide the original camera tracks.' + (res.warnings.length ? ' ' + res.warnings[0] : ''), 'ok');
      })),
      note);
  };

  /* ---- Punch Zoom ---- */
  builders.zoom = (body) => {
    const st = { mode: 'loud', amount: 1.15, inDur: 0.25, hold: 1.2, outDur: 0.6, interval: 4, threshold: -22, ax: 50, ay: 40, target: 'selected', track: 0 };
    const note = noteBox();
    const trackSel = select([['0', 'V1']], '0', v => st.track = +v);
    seqRange().then(i => { trackSel.innerHTML = ''; for (const v of i.videoTracks) { const o = h('option'); o.value = v.index; o.textContent = 'V' + (v.index + 1); trackSel.appendChild(o); } }).catch(() => {});
    body.append(
      row('Apply to', select([['selected', 'Selected clips'], ['track', 'Every clip on a track']], st.target, v => st.target = v)),
      row('Track', trackSel),
      row('Trigger', select([['loud', 'Loud moments (emphasis)'], ['interval', 'Every N seconds'], ['alternate', 'Alternate per clip (jump-cut look)']], st.mode, v => st.mode = v)),
      row('Zoom amount', range(() => st.amount, v => st.amount = v, 1.03, 1.6, 0.01, '×')),
      row('Zoom in', range(() => st.inDur, v => st.inDur = v, 0.05, 1.5, 0.05, ' s')),
      row('Hold', range(() => st.hold, v => st.hold = v, 0, 5, 0.1, ' s')),
      row('Zoom out', range(() => st.outDur, v => st.outDur = v, 0.05, 2, 0.05, ' s')),
      row('Interval', range(() => st.interval, v => st.interval = v, 1, 20, 0.5, ' s'), 'for the interval trigger'),
      row('Loudness threshold', range(() => st.threshold, v => st.threshold = v, -50, -5, 1, ' dB'), 'for the loud trigger'),
      row('Focus point X', range(() => st.ax, v => st.ax = v, 0, 100, 1, '%')),
      row('Focus point Y', range(() => st.ay, v => st.ay = v, 0, 100, 1, '%'), 'where the zoom pushes into (face ≈ 50 / 40)'),
      button('Apply zooms', 'primary', () => busy('Planning zooms', async () => {
        const info = await seqRange();
        const targets = st.target === 'selected' ? 'selected' : { track: st.track };
        const clips = st.target === 'selected' ? info.selection : [];
        if (st.target === 'selected' && !clips.length) throw new Error('Select one or more clips in the timeline first.');
        const r = clips.length ? { start: Math.min(...clips.map(c => c.start)), end: Math.max(...clips.map(c => c.end)) } : pickRange(info, 'whole');
        const total = st.inDur + st.hold + st.outDur;
        let times = [];
        if (st.mode === 'loud') {
          progress.title('Exporting audio');
          const audio = await AudioTool.exportRange(r.start, r.end, null, 'zoom');
          times = AudioTool.peaks(audio, { thresholdDb: st.threshold, minGap: total + 0.8 }).map(t => t + r.start);
        } else if (st.mode === 'interval') { for (let t = r.start + 0.5; t + total < r.end; t += st.interval) times.push(t); }
        let zooms;
        if (st.mode === 'alternate') {
          if (!clips.length) throw new Error('Alternate mode needs selected clips.');
          zooms = clips.filter((c, i) => i % 2 === 1).map(c => ({ t: c.start + 0.01, amount: st.amount, inDur: 0.02, hold: (c.end - c.start) - 0.06, outDur: 0.02 }));
        } else zooms = times.map(t => ({ t, amount: st.amount, inDur: st.inDur, hold: st.hold, outDur: st.outDur }));
        if (!zooms.length) throw new Error('No zoom moments found. Lower the threshold or use the interval trigger.');
        const res = await CS.call('AS_applyZooms', JSON.stringify({ targets, zooms, anchor: [st.ax / 100, st.ay / 100], width: info.width, height: info.height }));
        if (!res.ok) throw new Error(res.error);
        toast(zooms.length + ' zooms planned, keyframed on ' + res.clips + ' clip(s).' + (res.warnings.length ? ' ' + res.warnings[0] : ''), 'ok');
      })),
      note);
  };

  /* ---- Beat Markers ---- */
  builders.beats = (body) => {
    const st = { track: -1, sensitivity: 0.5, minGap: 0.25, cut: false, range: 'inout' };
    const note = noteBox();
    const trackSel = select([['-1', 'Whole mix']], '-1', v => st.track = +v);
    seqRange().then(i => { for (const a of i.audioTracks) { const o = h('option'); o.value = a.index; o.textContent = 'A' + (a.index + 1) + (a.name && !/^A\d+$/.test(a.name) ? ' ' + a.name : ''); trackSel.appendChild(o); } }).catch(() => {});
    body.append(
      row('Music track', trackSel), row('Range', select(rangeOptions, st.range, v => st.range = v)),
      row('Sensitivity', range(() => st.sensitivity, v => st.sensitivity = v, 0.05, 1, 0.05)),
      row('Minimum gap', range(() => st.minGap, v => st.minGap = v, 0.1, 2, 0.05, ' s')),
      row('Also razor selected clips on the beats', toggle(st.cut, v => st.cut = v)),
      button('Add beat markers', 'primary', () => busy('Exporting audio', async () => {
        const info = await seqRange();
        const r = pickRange(info, st.range);
        const audio = await AudioTool.exportRange(r.start, r.end, st.track >= 0 ? [st.track] : null, 'beats');
        const env = audio.env, win = audio.win;
        const flux = new Float32Array(env.length);
        for (let i = 1; i < env.length; i++) flux[i] = Math.max(0, env[i] - env[i - 1]);
        const sorted = Array.from(flux).sort((a, b) => a - b);
        const thr = sorted[Math.floor(sorted.length * (1 - st.sensitivity * 0.25))] || 1;
        const times = [];
        let last = -1e9;
        for (let i = 1; i < flux.length - 1; i++) if (flux[i] >= thr && flux[i] >= flux[i - 1] && flux[i] >= flux[i + 1]) { const t = r.start + i * win; if (t - last >= st.minGap) { times.push(t); last = t; } }
        if (!times.length) throw new Error('No beats found. Raise the sensitivity.');
        const res = await CS.call('TL_addMarkers', JSON.stringify({ times, name: 'beat' }));
        if (!res.ok) throw new Error(res.error);
        let cutsMsg = '';
        if (st.cut) { const rc = await CS.call('TL_razorTimes', JSON.stringify({ times })); if (rc.ok) cutsMsg = ' · ' + rc.cuts + ' razor cuts'; }
        toast(res.added + ' beat markers added' + cutsMsg + '.', 'ok');
      })),
      note);
  };

  /* ---- Reframe Pack ---- */
  builders.reframe = (body) => {
    const formats = [
      { num: 9, den: 16, name: '9:16 Reels / TikTok / Shorts', on: true },
      { num: 1, den: 1, name: '1:1 Square', on: true },
      { num: 4, den: 5, name: '4:5 Portrait post', on: false },
      { num: 16, den: 9, name: '16:9 Landscape', on: false },
      { num: 4, den: 3, name: '4:3', on: false }
    ];
    const st = { motion: 'default', nested: false };
    const note = noteBox();
    for (const f of formats) body.appendChild(row(f.name, toggle(f.on, v => f.on = v)));
    body.append(
      row('Tracking', select([['slower', 'Slower motion (calm)'], ['default', 'Default'], ['faster', 'Faster motion (action)']], st.motion, v => st.motion = v)),
      row('Nest clips first', toggle(st.nested, v => st.nested = v), 'keeps effects intact'),
      button('Create versions', 'primary', () => busy('Auto Reframe', async () => {
        const sel = formats.filter(f => f.on);
        if (!sel.length) throw new Error('Pick at least one format.');
        const r = await CS.call('AS_reframe', JSON.stringify({ formats: sel.map(f => ({ num: f.num, den: f.den, name: f.name.split(' ')[0] })), motion: st.motion, nested: st.nested }));
        if (!r.ok) throw new Error(r.error);
        toast('Created: ' + r.made.join(', ') + (r.warnings.length ? ' · ' + r.warnings[0] : ''), 'ok');
      })),
      h('div', 'kbd', 'Uses Premiere\'s built-in Auto Reframe. Each version is a new sequence next to the original.'),
      note);
  };

  /* --------------------------------------------------------------- screens */
  function openMenu() {
    const list = $('#assist-list'); list.innerHTML = '';
    for (const c of CATS) {
      list.appendChild(h('div', 'cat', icon(c.icon, 14) + ' ' + c.name));
      const group = h('div', 'alist');
      for (const t of c.tools) {
        const b = h('button', 'arow' + (t.hot ? ' hot' : ''));
        b.innerHTML = '<span class="ico">' + icon(t.icon, 22) + '</span><span class="txt"><b>' + t.name + (t.hot ? ' <em class="pill">new</em>' : '') + '</b><span>' + t.desc + '</span></span><span class="chev">›</span>';
        b.addEventListener('click', () => openTool(t.id));
        group.appendChild(b);
      }
      list.appendChild(group);
    }
    Hub.show('assist');
  }
  function openTool(id) {
    try { Usage.tick('assist:' + id); } catch (e) {}
    const t = CATS.flatMap(c => c.tools).find(x => x.id === id);
    $('#tool-title').textContent = t.name;
    $('#tool-back').onclick = openMenu;
    const body = $('#tool-body'); body.innerHTML = '';
    listeners.length = 0;
    builders[id](body);
    Hub.show('tool');
    /* tools that work on words start transcribing straight away */
    if (['takes', 'filler', 'profanity', 'broll'].includes(id) && !transcript && CS.inCEP) busy('Transcribing', ensureTranscript);
  }
  function init() { $('#prog-cancel').addEventListener('click', () => { cancelled = true; }); }
  return { openMenu, openTool, init, transcript: () => transcript, Core };
})();
