/* Vault: API keys encrypted at rest with Windows DPAPI (per user account), and
   every panel setting mirrored to %APPDATA%\OutflowStudio\settings.json so it
   survives CEP cache resets. In a plain browser the vault falls back to
   obfuscated localStorage (not secure, preview only). */
const Vault = (() => {
  let nodeReq = null;
  try { nodeReq = (window.cep_node && window.cep_node.require) || (typeof window.require === 'function' ? window.require : null); } catch (e) {}
  const cp = nodeReq ? nodeReq('child_process') : null;
  const SECRET_KEYS = ['pexels', 'giphy', 'tenor', 'freesound', 'openai'];
  function dir() {
    const env = (window.process && window.process.env) || (window.cep_node && window.cep_node.process && window.cep_node.process.env) || {};
    const base = (CS.os && CS.os.platform() === 'darwin') ? CS.path.join(CS.os.homedir(), 'Library', 'Application Support') : (env.APPDATA || (CS.os ? CS.os.homedir() : ''));
    const d = CS.path.join(base, 'OutflowStudio');
    try { CS.mkdirp(d); } catch (e) {}
    return d;
  }
  const available = () => !!(cp && CS.fs && CS.os && CS.os.platform() === 'win32');
  /*  On a Mac the keys live in the login Keychain, under one item, as base64 JSON: the `security` tool
      needs no dialog for an item the same program made. Same shape as DPAPI: encrypted at rest, this
      user only.                                                                                       */
  const keychain = () => !!(cp && CS.fs && CS.os && CS.os.platform() === 'darwin');
  const Buf = nodeReq ? nodeReq('buffer').Buffer : null;
  function keychainGet() {
    try { const out = cp.execFileSync('security', ['find-generic-password', '-a', 'outflow', '-s', 'OutflowStudio', '-w'], { encoding: 'utf8', timeout: 15000, stdio: ['ignore', 'pipe', 'ignore'] }); return Buf.from(String(out).trim(), 'base64').toString('utf8'); }
    catch (e) { return null; }
  }
  function keychainSet(json) { cp.execFileSync('security', ['add-generic-password', '-a', 'outflow', '-s', 'OutflowStudio', '-w', Buf.from(json, 'utf8').toString('base64'), '-U'], { timeout: 15000, stdio: 'ignore' }); }
  /* DPAPI through PowerShell; input travels via a temp file (no quoting problems) */
  function dpapi(mode, text) {
    const tmp = CS.path.join(dir(), 'vault_' + Date.now().toString(36) + '.tmp');
    CS.fs.writeFileSync(tmp, text, 'utf8');
    const ps = mode === 'protect'
      ? "Add-Type -AssemblyName System.Security; $t=[IO.File]::ReadAllText('" + tmp.replace(/'/g, "''") + "'); [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($t),$null,'CurrentUser'))"
      : "Add-Type -AssemblyName System.Security; $t=[IO.File]::ReadAllText('" + tmp.replace(/'/g, "''") + "'); [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($t.Trim()),$null,'CurrentUser'))";
    try {
      const out = cp.execFileSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 15000, encoding: 'utf8' });
      return String(out).trim();
    } finally { try { CS.fs.unlinkSync(tmp); } catch (e) {} }
  }
  const keysFile = () => CS.path.join(dir(), 'keys.dat');
  const settingsFile = () => CS.path.join(dir(), 'settings.json');

  function loadKeys() {
    let keys = {};
    try {
      if (available() && CS.fs.existsSync(keysFile())) keys = JSON.parse(dpapi('unprotect', CS.fs.readFileSync(keysFile(), 'utf8')) || '{}');
      else if (keychain() && keychainGet()) keys = JSON.parse(keychainGet() || '{}');
      else {
        const raw = localStorage.getItem('os.keys.v') || localStorage.getItem('os.keys');
        if (raw) keys = JSON.parse(raw.startsWith('{') ? raw : decodeURIComponent(escape(atob(raw))));
        if ((available() || keychain()) && Object.keys(keys).length) { saveKeys(keys); }
      }
    } catch (e) { keys = {}; }
    return keys;
  }
  function saveKeys(keys) {
    const json = JSON.stringify(keys);
    if (available()) {
      try {
        CS.fs.writeFileSync(keysFile(), dpapi('protect', json), 'utf8');
        try { localStorage.removeItem('os.keys'); localStorage.removeItem('os.keys.v'); } catch (e) {}
        return 'dpapi';
      } catch (e) { /* fall through */ }
    }
    if (keychain()) {
      try { keychainSet(json); try { localStorage.removeItem('os.keys'); localStorage.removeItem('os.keys.v'); } catch (e) {} return 'keychain'; } catch (e) { /* fall through */ }
    }
    try { localStorage.setItem('os.keys.v', btoa(unescape(encodeURIComponent(json)))); localStorage.removeItem('os.keys'); } catch (e) {}
    return 'local';
  }
  function status() { return { encrypted: (available() && CS.fs.existsSync(keysFile())) || (keychain() && !!keychainGet()), method: available() ? 'Windows DPAPI (this user account only)' : keychain() ? 'macOS Keychain (this user account only)' : 'browser storage (preview only, not encrypted)', file: available() ? keysFile() : '' }; }

  /* ---- settings mirror: every os.* / c3d.* localStorage key -> settings.json ---- */
  let timer = null;
  function mirrorNow() {
    if (!CS.fs) return;
    try {
      const all = {};
      for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (/^(os|c3d)\./.test(k) && k !== 'os.keys' && k !== 'os.keys.v') all[k] = localStorage.getItem(k); }
      CS.fs.writeFileSync(settingsFile(), JSON.stringify(all), 'utf8');
    } catch (e) {}
  }
  function restore() {
    if (!CS.fs) return;
    try {
      if (!CS.fs.existsSync(settingsFile())) return;
      const all = JSON.parse(CS.fs.readFileSync(settingsFile(), 'utf8'));
      for (const k of Object.keys(all)) if (localStorage.getItem(k) === null) localStorage.setItem(k, all[k]);
    } catch (e) {}
  }
  function hookStorage() {
    if (!CS.fs) return;
    const orig = Storage.prototype.setItem;
    Storage.prototype.setItem = function (k, v) { orig.call(this, k, v); if (/^(os|c3d)\./.test(k)) { clearTimeout(timer); timer = setTimeout(mirrorNow, 800); } };
  }
  function init() { restore(); hookStorage(); }
  return { loadKeys, saveKeys, status, init, mirrorNow, SECRET_KEYS };
})();
