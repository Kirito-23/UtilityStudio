/*  Outflow Studio - stock media import (ExtendScript, ES3). Requires index.jsx + native.jsx. */

function OS_getPaths() {
    try {
        var projDir = "";
        try { if (app.project.path) { var pf = new File(app.project.path); if (pf.parent) projDir = pf.parent.fsName; } } catch (e0) {}
        var docs = "";
        try { docs = Folder.myDocuments.fsName; } catch (e1) {}
        return C3D_json({ ok: true, projectDir: projDir, documents: docs, hasSequence: !!app.project.activeSequence });
    } catch (e) { return C3D_err(e); }
}

function OS_findFreeAudioTrack(seq, s, e) {
    var top = -1;
    for (var i = 0; i < seq.audioTracks.numTracks; i++) {
        var tr = seq.audioTracks[i];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j];
            if (c.start.seconds < e && c.end.seconds > s) top = i;
        }
    }
    return top + 1;
}

function OS_addAudioTrack(seq) {
    var before = seq.audioTracks.numTracks;
    try { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, before, 0, 1); } catch (e) {}
    return app.project.activeSequence.audioTracks.numTracks > before;
}

/*  A subclip of the whole item with only its video or only its audio, kept next to the item and reused
    by name. The argument shapes differ between Premiere builds, so two are tried.                    */
function OS_subclipOf(item, bin, name, takeVideo, takeAudio) {
    for (var i = 0; i < bin.children.numItems; i++) { var c = bin.children[i]; if (c.name === name && c.type !== ProjectItemType.BIN) return c; }
    var inSec = 0, outSec = 5;
    try { inSec = item.getInPoint().seconds; outSec = item.getOutPoint().seconds; } catch (e0) {}
    var sub = null;
    try { sub = item.createSubClip(name, inSec, outSec, 0, takeVideo, takeAudio); } catch (e1) {}
    if (!sub) { try { var ti = new Time(); ti.seconds = inSec; var to = new Time(); to.seconds = outSec; sub = item.createSubClip(name, ti, to, 0, takeVideo, takeAudio); } catch (e2) {} }
    if (sub) { try { sub.moveBin(bin); } catch (e3) {} }
    return sub;
}
function OS_selectOnly(seq, clips) {
    for (var v = 0; v < seq.videoTracks.numTracks; v++) { var vt = seq.videoTracks[v]; for (var i = 0; i < vt.clips.numItems; i++) { try { if (vt.clips[i].isSelected()) vt.clips[i].setSelected(false, true); } catch (e0) {} } }
    for (var a = 0; a < seq.audioTracks.numTracks; a++) { var at = seq.audioTracks[a]; for (var j = 0; j < at.clips.numItems; j++) { try { if (at.clips[j].isSelected()) at.clips[j].setSelected(false, true); } catch (e1) {} } }
    for (var k = 0; k < clips.length; k++) { try { clips[k].setSelected(true, true); } catch (e2) {} }
}

/*  path: downloaded file, binName: project bin, insert: also place at the playhead,
    kind: "photo" | "video" | "audio" | "gif", hasAudio: the video file carries sound.
    Nothing on the timeline is ever written over: the video goes on a free track above every clip at
    the playhead, the audio on a free track below every audio clip, tracks added when none is free. A
    video with sound is placed as two subclips (video only, audio only) and linked, because
    overwriteClip puts the sound wherever it likes - it wrote over existing audio (2026-09-18).      */
function OS_importMedia(path, binName, insert, kind, hasAudio) {
    try {
        var f = new File(path);
        if (!f.exists) return C3D_err("File not found: " + path);
        var root = app.project.rootItem;
        var bin = C3D_toolBin(binName) || root;
        var item = C3D_importPath(path, bin);
        if (!item) return C3D_err("Premiere could not import " + path);
        if (!insert) return C3D_json({ ok: true, imported: true, placed: false });

        var seq = app.project.activeSequence;
        if (!seq) return C3D_json({ ok: true, imported: true, placed: false, note: "Imported into the project. Open a sequence to place clips." });
        var start = seq.getPlayerPosition().seconds;
        var dur = 5;
        try { dur = item.getOutPoint().seconds - item.getInPoint().seconds; if (!(dur > 0)) dur = 5; } catch (e1) {}
        var track = null, label = "";
        if (kind === "video" && hasAudio !== false) {   /* unknown counts as "maybe": the audio subclip below tells */
            var vi2 = C3D_findFreeTrack(seq, start, start + dur);
            if (vi2 >= seq.videoTracks.numTracks && !C3D_addVideoTrack(seq)) return C3D_err("No empty video track at the playhead. Add one and try again.");
            seq = app.project.activeSequence;
            var ai2 = OS_findFreeAudioTrack(seq, start, start + dur);
            if (ai2 >= seq.audioTracks.numTracks && !OS_addAudioTrack(seq)) return C3D_err("No empty audio track at the playhead. Add one and try again.");
            seq = app.project.activeSequence;
            var aSub = OS_subclipOf(item, bin, item.name + " (audio)", 0, 1);
            var vSub = aSub ? OS_subclipOf(item, bin, item.name + " (video)", 1, 0) : null;
            if (vSub && aSub) {
                var vt2 = seq.videoTracks[vi2], at2 = seq.audioTracks[ai2], okV = false, okA = false;
                try { okV = vt2.overwriteClip(vSub, start); } catch (e4) {}
                if (!okV) { try { var tv = new Time(); tv.seconds = start; okV = vt2.overwriteClip(vSub, tv); } catch (e5) {} }
                if (!okV) return C3D_err("Imported, but the clip could not be placed on V" + (vi2 + 1));
                try { okA = at2.overwriteClip(aSub, start); } catch (e6) {}
                if (!okA) { try { var ta = new Time(); ta.seconds = start; okA = at2.overwriteClip(aSub, ta); } catch (e7) {} }
                var vc = C3D_findClipAt(vt2, start), ac = okA ? C3D_findClipAt(at2, start) : null, linked = false;
                if (vc && ac) { OS_selectOnly(seq, [vc, ac]); try { linked = !!seq.linkSelection(); } catch (e8) {} }
                return C3D_json({ ok: true, imported: true, placed: true, track: "V" + (vi2 + 1) + (okA ? " + A" + (ai2 + 1) : ""), start: start, linked: linked, note: okA ? "" : "The sound could not be placed." });
            }
            /* no sound in the file (no audio subclip could be made), or no subclips on this build: the item itself, on the free video track */
            track = seq.videoTracks[vi2]; label = "V" + (vi2 + 1);
        } else if (kind === "audio") {
            var ai = OS_findFreeAudioTrack(seq, start, start + dur);
            if (ai >= seq.audioTracks.numTracks && !OS_addAudioTrack(seq)) return C3D_err("No empty audio track at the playhead. Add one and try again.");
            seq = app.project.activeSequence;
            track = seq.audioTracks[ai]; label = "A" + (ai + 1);
        } else {
            var vi = C3D_findFreeTrack(seq, start, start + dur);
            if (vi >= seq.videoTracks.numTracks && !C3D_addVideoTrack(seq)) return C3D_err("No empty video track at the playhead. Add one and try again.");
            seq = app.project.activeSequence;
            track = seq.videoTracks[vi]; label = "V" + (vi + 1);
        }
        var ok = false;
        try { ok = track.overwriteClip(item, start); } catch (e2) {}
        if (!ok) { try { var tm = new Time(); tm.seconds = start; ok = track.overwriteClip(item, tm); } catch (e3) {} }
        if (!ok) return C3D_err("Imported, but the clip could not be placed on " + label);
        return C3D_json({ ok: true, imported: true, placed: true, track: label, start: start });
    } catch (e) { return C3D_err(e); }
}
