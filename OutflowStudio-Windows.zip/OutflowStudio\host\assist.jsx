/*  Outflow Studio - edit assistants (ExtendScript, ES3). Requires index.jsx + native.jsx. */

function AS_fps(seq) { return C3D_TICKS_PER_SECOND / parseFloat(seq.timebase); }

function AS_range() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var fps = AS_fps(seq);
        var end = 0;
        try { end = parseFloat(seq.end) / C3D_TICKS_PER_SECOND; } catch (e0) {}
        var inS = 0, outS = end, hasIO = false;
        try {
            var ip = seq.getInPointAsTime().seconds, op = seq.getOutPointAsTime().seconds;
            if (op > ip && ip >= 0 && op < 1e8) { inS = ip; outS = op; hasIO = true; }
        } catch (e1) {}
        var sel = [];
        for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j], s = false;
                try { s = c.isSelected(); } catch (e2) {}
                if (s) sel.push({ track: t, start: c.start.seconds, end: c.end.seconds, name: c.name });
            }
        }
        /*  A sequence is not always square-pixel, and its settings are the authority on the frame size.
            A caption drawn at the frame size but interpreted with a different pixel aspect comes out
            stretched, which is exactly what it looked like.                                          */
        var par = 1, fw = seq.frameSizeHorizontal, fh = seq.frameSizeVertical;
        try {
            var sset = seq.getSettings();
            if (sset) {
                if (sset.videoFrameWidth) fw = sset.videoFrameWidth;
                if (sset.videoFrameHeight) fh = sset.videoFrameHeight;
                var pv = parseFloat(sset.videoPixelAspectRatio);
                if (pv > 0.01 && pv < 100) par = pv;
            }
        } catch (ep) {}
        var vt = [], at = [];
        for (var v = 0; v < seq.videoTracks.numTracks; v++) vt.push({ index: v, name: seq.videoTracks[v].name || ("V" + (v + 1)), clips: seq.videoTracks[v].clips.numItems });
        for (var a = 0; a < seq.audioTracks.numTracks; a++) at.push({ index: a, name: seq.audioTracks[a].name || ("A" + (a + 1)), clips: seq.audioTracks[a].clips.numItems });
        C3D_log("AS_range", "seq '" + seq.name + "' fps " + fps + " dur " + end.toFixed(3) + " in/out " + inS + "/" + outS + " hasIO " + hasIO + " sel " + sel.length + " vt " + vt + " at " + at);
        return C3D_json({ ok: true, fps: fps, width: fw, height: fh, par: par, duration: end, inPoint: inS, outPoint: outS, hasInOut: hasIO, selection: sel, videoTracks: vt, audioTracks: at, playhead: seq.getPlayerPosition().seconds, name: seq.name });
    } catch (e) { return C3D_err(e); }
}

/*  o = { out, preset, start, end, solo: [audioTrackIdx] | null }  */
function AS_exportAudio(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var pf = new File(o.preset);
        if (!pf.exists) return C3D_err("WAV export preset not found: " + o.preset);
        var savedIn = null, savedOut = null;
        try { savedIn = seq.getInPointAsTime().seconds; savedOut = seq.getOutPointAsTime().seconds; } catch (e0) {}
        var mutes = [];
        for (var a = 0; a < seq.audioTracks.numTracks; a++) {
            var m = false; try { m = seq.audioTracks[a].isMuted(); } catch (e1) {}
            mutes.push(m);
            if (o.solo) {
                var keep = false;
                for (var k = 0; k < o.solo.length; k++) if (o.solo[k] === a) keep = true;
                try { seq.audioTracks[a].setMute(keep ? 0 : 1); } catch (e2) {}
            }
        }
        try { seq.setInPoint(o.start); seq.setOutPoint(o.end); } catch (e3) {}
        var res = "";
        try { res = String(seq.exportAsMediaDirect(o.out, o.preset, app.encoder.ENCODE_IN_TO_OUT)); }
        catch (e4) { res = "exportAsMediaDirect failed: " + e4; }
        if (o.solo) for (var b = 0; b < seq.audioTracks.numTracks; b++) { try { seq.audioTracks[b].setMute(mutes[b] ? 1 : 0); } catch (e5) {} }
        try {
            if (savedIn !== null && savedOut !== null && savedOut > savedIn && savedOut < 1e8) { seq.setInPoint(savedIn); seq.setOutPoint(savedOut); }
        } catch (e6) {}
        var f = new File(o.out);
        var inNow = "?", outNow = "?"; try { inNow = seq.getInPointAsTime().seconds; outNow = seq.getOutPointAsTime().seconds; } catch (e7) {}
        C3D_log("AS_exportAudio", "range " + o.start + "-" + o.end + " savedIO " + savedIn + "/" + savedOut + " nowIO " + inNow + "/" + outNow + " solo " + (o.solo ? o.solo.join(",") : "-") + " result '" + res + "' exists " + f.exists + " bytes " + (f.exists ? f.length : 0) + " out " + o.out);
        return C3D_json({ ok: f.exists, exists: f.exists, result: res, error: f.exists ? "" : ("Premiere did not write the audio file. " + res) });
    } catch (e) { return C3D_err(e); }
}

/*  SMPTE timecode for a time in seconds. Drop-frame (semicolons) for 29.97 / 59.94
    when the sequence displays drop-frame; the frame count is converted so the
    razor lands on the exact frame Premiere shows.                              */
function AS_timecode(sec, fps, drop) {
    var nominal = Math.round(fps);
    var fn = Math.round(sec * fps);
    if (drop) {
        var dropFrames = Math.round(fps * 0.066666);          /* 2 @ 29.97, 4 @ 59.94 */
        var fpm = nominal * 60 - dropFrames, fp10 = Math.round(fps * 600);
        var d = Math.floor(fn / fp10), m = fn % fp10;
        if (m > dropFrames) fn += dropFrames * 9 * d + dropFrames * Math.floor((m - dropFrames) / fpm);
        else fn += dropFrames * 9 * d;
    }
    var fr = fn % nominal, totalSec = Math.floor(fn / nominal);
    var s = totalSec % 60, mi = Math.floor(totalSec / 60) % 60, h = Math.floor(totalSec / 3600);
    var p = function (n) { return (n < 10 ? "0" : "") + n; };
    return p(h) + ":" + p(mi) + ":" + p(s) + (drop ? ";" : ":") + p(fr);
}

/* does this sequence display drop-frame timecode? (look at an existing clip's timecode) */
function AS_isDropFrame(qeSeq, seq, fps) {
    if (Math.abs(fps - Math.round(fps)) < 0.01) return false;
    try {
        for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var qt = qeSeq.getVideoTrackAt(t);
            for (var k = 0; k < qt.numItems; k++) {
                var it = qt.getItemAt(k);
                var tc = it && it.start ? String(it.start.timecode || "") : "";
                if (tc && /\d/.test(tc)) return tc.indexOf(";") >= 0;
            }
        }
    } catch (e) {}
    return true;
}

/* is there still a clip that spans across sec (i.e. the razor did not land there)? */
function AS_unsplitAt(seq, sec, eps, audioOnly) {
    var t, j, bad = 0;
    if (!audioOnly) for (t = 0; t < seq.videoTracks.numTracks; t++) { var vt = seq.videoTracks[t]; for (j = 0; j < vt.clips.numItems; j++) { var c = vt.clips[j]; if (c.start.seconds < sec - eps && c.end.seconds > sec + eps) bad++; } }
    for (t = 0; t < seq.audioTracks.numTracks; t++) { var at = seq.audioTracks[t]; for (j = 0; j < at.clips.numItems; j++) { var a = at.clips[j]; if (a.start.seconds < sec - eps && a.end.seconds > sec + eps) bad++; } }
    return bad;
}

/*  Razor every track at sec and verify that no clip spans sec afterwards.
    Tries the sequence's timecode style first, then the other one.            */
function AS_razorVerified(qeSeq, seq, sec, fps, drop, eps, audioOnly) {
    var styles = drop ? [true, false] : [false, true];
    for (var sIdx = 0; sIdx < styles.length; sIdx++) {
        var tc = AS_timecode(sec, fps, styles[sIdx]), t;
        var tryRazor = function (qt) { if (!qt) return; try { qt.razor(tc); } catch (e1) {} };
        if (!audioOnly) for (t = 0; t < seq.videoTracks.numTracks; t++) { var qv = null; try { qv = qeSeq.getVideoTrackAt(t); } catch (e2) {} tryRazor(qv); }
        for (t = 0; t < seq.audioTracks.numTracks; t++) { var qa = null; try { qa = qeSeq.getAudioTrackAt(t); } catch (e3) {} tryRazor(qa); }
        if (AS_unsplitAt(app.project.activeSequence, sec, eps, audioOnly) === 0) return { ok: true, drop: styles[sIdx] };
    }
    return { ok: false };
}

/* move the sequence in/out points (the working range shrinks as content is rippled away) */
function AS_setInOut(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        try { seq.setInPoint(o.start); seq.setOutPoint(o.end); } catch (e1) { return C3D_err("setInPoint/setOutPoint: " + e1); }
        var i = "?", oo = "?"; try { i = seq.getInPointAsTime().seconds; oo = seq.getOutPointAsTime().seconds; } catch (e2) {}
        C3D_log("AS_setInOut", "asked " + o.start + "-" + o.end + " now " + i + "-" + oo);
        return C3D_json({ ok: true, inPoint: i, outPoint: oo });
    } catch (e) { return C3D_err(e); }
}

/* nodeId -> { start, end, track, kind } for every clip (a snapshot taken before a change) */
function AS_snapshot(seq) {
    var m = {}, t, j;
    for (t = 0; t < seq.videoTracks.numTracks; t++) { var vt = seq.videoTracks[t]; for (j = 0; j < vt.clips.numItems; j++) { var c = vt.clips[j]; m[c.nodeId] = { start: c.start.seconds, end: c.end.seconds, track: t, kind: "v" }; } }
    for (t = 0; t < seq.audioTracks.numTracks; t++) { var at = seq.audioTracks[t]; for (j = 0; j < at.clips.numItems; j++) { var a = at.clips[j]; m[a.nodeId] = { start: a.start.seconds, end: a.end.seconds, track: t, kind: "a" }; } }
    return m;
}
function AS_trackOf(seq, rec) { return rec.kind === "v" ? seq.videoTracks[rec.track] : seq.audioTracks[rec.track]; }
function AS_fresh(seq, rec, nodeId) {
    var tr = AS_trackOf(seq, rec);
    if (!tr) return null;
    for (var j = 0; j < tr.clips.numItems; j++) if (String(tr.clips[j].nodeId) === String(nodeId)) return tr.clips[j];
    return null;
}

/*  Close a gap: every clip recorded in snap that started at/after fromSec should
    end up delta seconds earlier. Clips Premiere already moved (ripple, linked
    audio) are left alone; a clip is only moved when its destination is free.  */
function AS_settleShift(seq, snap, fromSec, delta, eps) {
    var ids = [], id;
    for (id in snap) if (snap.hasOwnProperty(id) && snap[id].start >= fromSec - eps) ids.push(id);
    ids.sort(function (a, b) { return (snap[a].start - snap[b].start) || (snap[a].kind === "v" ? -1 : 1); });
    var res = { moved: 0, already: 0, blocked: 0, failed: 0, gone: 0, blocker: "" };
    var pending = ids.slice(), pass;
    /* several passes: a clip whose destination was occupied by a clip that moves later gets another chance */
    for (pass = 0; pass < 3 && pending.length; pass++) {
        var next = [];
        for (var i = 0; i < pending.length; i++) {
            id = pending[i];
            var rec = snap[id], clip = AS_fresh(seq, rec, id);
            if (!clip) { if (pass === 0) res.gone++; continue; }
            var cur = clip.start.seconds, dest = rec.start + delta, len = rec.end - rec.start;
            if (Math.abs(cur - dest) < eps) { if (pass === 0) res.already++; continue; }
            if (Math.abs(cur - rec.start) > eps) { if (pass === 0) res.failed++; continue; }        /* somewhere unexpected: leave it */
            var tr = AS_trackOf(seq, rec), free = true, who = null;
            for (var j = 0; j < tr.clips.numItems; j++) {
                var o = tr.clips[j];
                if (String(o.nodeId) === String(id)) continue;
                if (o.start.seconds < dest + len - eps && o.end.seconds > dest + eps) { free = false; who = o; break; }
            }
            if (!free) {
                next.push(id);
                if (!res.blocker) { var nm = ""; try { nm = who.name; } catch (e0) {} res.blocker = (rec.kind === "v" ? "V" : "A") + (rec.track + 1) + " clip at " + cur.toFixed(2) + "s wants " + dest.toFixed(2) + "s but '" + nm + "' sits at " + who.start.seconds.toFixed(2) + "-" + who.end.seconds.toFixed(2) + "s"; }
                continue;
            }
            /* TrackItem.move(Time) shifts the clip (documented as relative); some builds treat it as absolute, so verify and retry */
            var chk = null, pos = cur;
            try { var mv = new Time(); mv.seconds = dest - cur; clip.move(mv); } catch (e1) { C3D_log("AS_settleShift", "move threw: " + e1); }
            chk = AS_fresh(seq, rec, id); pos = chk ? chk.start.seconds : cur;
            if (Math.abs(pos - dest) >= eps) {
                try { var mv2 = new Time(); mv2.seconds = dest; (chk || clip).move(mv2); } catch (e1b) {}
                chk = AS_fresh(seq, rec, id); pos = chk ? chk.start.seconds : cur;
            }
            if (chk && Math.abs(pos - dest) < eps) res.moved++;
            else { res.failed++; C3D_log("AS_settleShift", "could not move " + (chk ? C3D_clipDesc(chk) : id) + " from " + cur.toFixed(3) + " to " + dest.toFixed(3) + " (now " + pos.toFixed(3) + ")"); }
        }
        pending = next;
    }
    res.blocked = pending.length;
    return res;
}

/*  After a ripple cut at s the next clips on every track must start at s. If Premiere's
    ripple delete did not shift them (sync lock off, linked audio, tiny cuts…) and the
    settle pass could not either, shift everything after the gap by its width.        */
function AS_closeGapAt(seq, s, eps) {
    var g = 1e9, t, j, tracks = [];
    for (t = 0; t < seq.videoTracks.numTracks; t++) tracks.push(seq.videoTracks[t]);
    for (t = 0; t < seq.audioTracks.numTracks; t++) tracks.push(seq.audioTracks[t]);
    for (t = 0; t < tracks.length; t++) {
        for (j = 0; j < tracks[t].clips.numItems; j++) {
            var c = tracks[t].clips[j], cs = c.start.seconds, ce = c.end.seconds;
            if (cs <= s + eps && ce > s + eps) return 0;               /* something still covers s: no gap */
            if (cs > s + eps && cs - s < g) g = cs - s;
        }
    }
    if (g >= 1e8 || g < eps) return 0;
    var snap = AS_snapshot(seq);
    AS_settleShift(seq, snap, s + g, -g, eps);
    return g;
}

/* the clip that lies inside [s, e] on a track, fetched fresh (objects go stale after edits) */
function AS_pieceAt(track, s, e, eps) {
    if (!track) return null;
    for (var j = 0; j < track.clips.numItems; j++) {
        var c = track.clips[j];
        if (c.start.seconds >= s - eps && c.end.seconds <= e + eps) return c;
    }
    return null;
}


/*  Batch ripple: razor every boundary, delete every piece inside a cut without rippling, then move
    each remaining clip left once by the total length of the cuts before it. One move per clip instead
    of one ripple per cut, so a 30-minute clip with hundreds of silences takes seconds, not minutes. */
function AS_applyCutsBatch(o, qeSeq, fps, eps, audioOnly, drop, warnings) {
    var i, t, j, seq = app.project.activeSequence;
    var snapF = function (x) { return Math.round(x * fps) / fps; };
    var raw = [];
    for (i = 0; i < o.cuts.length; i++) { var s0 = snapF(o.cuts[i][0]), e0 = snapF(o.cuts[i][1]); if (e0 - s0 >= 1.5 / fps) raw.push([s0, e0]); }
    raw.sort(function (a, b) { return a[0] - b[0]; });
    var cuts = [];
    for (i = 0; i < raw.length; i++) { var last = cuts[cuts.length - 1]; if (last && raw[i][0] <= last[1] + eps) last[1] = Math.max(last[1], raw[i][1]); else cuts.push([raw[i][0], raw[i][1]]); }
    C3D_log("AS_applyCutsBatch", (o.label || "cut") + ": " + cuts.length + " cut(s) after snapping and merging");
    if (!cuts.length) return C3D_json({ ok: true, applied: 0, warnings: warnings, stats: {}, dropFrame: drop, batch: true });
    /* 1) razor every boundary (razors move nothing), last cut first */
    for (i = cuts.length - 1; i >= 0; i--) {
        var r1 = AS_razorVerified(qeSeq, app.project.activeSequence, cuts[i][1], fps, drop, eps, audioOnly);
        if (!r1.ok) return C3D_err("The razor did not land at " + cuts[i][1].toFixed(2) + "s (timecode format). Nothing was removed. Sequence fps " + fps.toFixed(3) + ", drop-frame " + drop + ".");
        drop = r1.drop;
        var r0 = AS_razorVerified(qeSeq, app.project.activeSequence, cuts[i][0], fps, drop, eps, audioOnly);
        if (!r0.ok) return C3D_err("The razor did not land at " + cuts[i][0].toFixed(2) + "s. Nothing was removed.");
    }
    seq = app.project.activeSequence;
    var tracks = [];
    if (!audioOnly) for (t = 0; t < seq.videoTracks.numTracks; t++) tracks.push(seq.videoTracks[t]);
    for (t = 0; t < seq.audioTracks.numTracks; t++) tracks.push(seq.audioTracks[t]);
    /*  2) delete every piece that lies inside a cut, no ripple: the gaps stay for now.
        Cut by cut across every track, not track by track: the old order emptied the whole video track,
        then A1, then A2, then A3, which on screen looked like four separate edits. Now each cut disappears
        from all tracks in one go. The pieces are found in a single scan, then removed last cut first, so
        the indices of everything still to be removed stay valid; each is checked against the cut again
        before it goes, because a linked partner may already have taken it.                              */
    var cutIndex = function (cs, ce) { for (var k = 0; k < cuts.length; k++) { if (cuts[k][0] > ce + eps) return -1; if (cs >= cuts[k][0] - eps && ce <= cuts[k][1] + eps) return k; } return -1; };
    var inCut = function (cs, ce) { return cutIndex(cs, ce) >= 0; };
    var pieces = [];
    for (t = 0; t < tracks.length; t++) {
        pieces[t] = [];
        for (j = 0; j < tracks[t].clips.numItems; j++) {
            var p0 = tracks[t].clips[j], ps, pe;
            try { ps = p0.start.seconds; pe = p0.end.seconds; } catch (eP) { continue; }
            var kk = cutIndex(ps, pe);
            if (kk >= 0) pieces[t].push({ j: j, k: kk });
        }
    }
    var removed = 0;
    for (var kc = cuts.length - 1; kc >= 0; kc--) {
        for (t = 0; t < tracks.length; t++) {
            var list = pieces[t];
            for (var q = list.length - 1; q >= 0; q--) {
                if (list[q].k !== kc || list[q].j >= tracks[t].clips.numItems) continue;
                var c = tracks[t].clips[list[q].j], cs, ce;
                try { cs = c.start.seconds; ce = c.end.seconds; } catch (eS) { continue; }
                if (cutIndex(cs, ce) !== kc) continue;
                try { c.remove(false, false); removed++; } catch (e3) { warnings.push("remove: " + e3); }
            }
        }
    }
    /* the safety net: anything a linked removal shuffled out of reach of the indices above */
    for (t = 0; t < tracks.length; t++) {
        for (var pass = 0; pass < 4; pass++) {
            var again = 0;
            for (j = tracks[t].clips.numItems - 1; j >= 0; j--) {
                var c2 = tracks[t].clips[j], cs2, ce2;
                try { cs2 = c2.start.seconds; ce2 = c2.end.seconds; } catch (eS2) { continue; }
                if (!inCut(cs2, ce2)) continue;
                try { c2.remove(false, false); removed++; again++; } catch (e4) { warnings.push("remove: " + e4); }
            }
            if (!again) break;
        }
    }
    C3D_log("AS_applyCutsBatch", "removed " + removed + " piece(s)");
    /* 3) close every gap at once: a clip moves left by the total length of the cuts that end before it */
    seq = app.project.activeSequence;
    var snap = AS_snapshot(seq);
    var shiftBefore = function (start) { var sh = 0; for (var k = 0; k < cuts.length; k++) { if (cuts[k][1] <= start + eps) sh += cuts[k][1] - cuts[k][0]; else break; } return sh; };
    var ids = [], id;
    for (id in snap) if (snap.hasOwnProperty(id)) ids.push(id);
    ids.sort(function (a, b) { return (snap[a].start - snap[b].start) || (snap[a].kind === "v" ? -1 : 1); });
    var res = { moved: 0, already: 0, failed: 0, gone: 0 };
    for (i = 0; i < ids.length; i++) {
        id = ids[i];
        var rec = snap[id], sh = shiftBefore(rec.start);
        if (sh < eps) { res.already++; continue; }
        var clip = AS_fresh(seq, rec, id);
        if (!clip) { res.gone++; continue; }
        var cur = clip.start.seconds, dest = rec.start - sh;
        if (Math.abs(cur - dest) < eps) { res.already++; continue; }   /* moved along with a linked partner */
        try { var mv = new Time(); mv.seconds = dest - cur; clip.move(mv); } catch (e1) { C3D_log("AS_applyCutsBatch", "move threw: " + e1); }
        var chk = AS_fresh(seq, rec, id), pos = chk ? chk.start.seconds : cur;
        if (Math.abs(pos - dest) >= eps) {
            try { var mv2 = new Time(); mv2.seconds = dest; (chk || clip).move(mv2); } catch (e2) {}
            chk = AS_fresh(seq, rec, id); pos = chk ? chk.start.seconds : cur;
        }
        if (chk && Math.abs(pos - dest) < eps) res.moved++;
        else { res.failed++; C3D_log("AS_applyCutsBatch", "could not move " + (chk ? C3D_clipDesc(chk) : id) + " from " + cur.toFixed(3) + " to " + dest.toFixed(3) + " (now " + pos.toFixed(3) + ")"); }
    }
    if (res.failed) warnings.push(res.failed + " clip(s) could not be moved into place; check the timeline.");
    C3D_log("AS_applyCutsBatch", "done: " + cuts.length + " cuts, removed " + removed + ", moved " + res.moved + " already " + res.already + " failed " + res.failed + " gone " + res.gone);
    return C3D_json({ ok: true, applied: cuts.length, warnings: warnings, stats: { removed: removed, moved: res.moved, already: res.already, blocked: 0, failed: res.failed }, dropFrame: drop, batch: true });
}

/*  o = { cuts: [[s,e],...] ascending, mode: "ripple" | "markers" | "disable" | "remove", label, audioOnly }
    ripple: razor every track at both ends, delete what is inside, then close the
    gap by ripple-deleting one spanning clip (Premiere shifts all tracks itself);
    if no clip spans the gap, clips are moved with linked audio taken into account. */
function AS_applyCuts(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var fps = AS_fps(seq), warnings = [], i, t, j;
        var snap = function (x) { return Math.round(x * fps) / fps; };
        if (o.mode === "markers") {
            for (i = 0; i < o.cuts.length; i++) {
                try { var mk = seq.markers.createMarker(o.cuts[i][0]); mk.name = (o.label || "cut") + " " + (i + 1); mk.end = o.cuts[i][1]; } catch (e0) { warnings.push("marker " + i + ": " + e0); }
            }
            return C3D_json({ ok: true, applied: o.cuts.length, warnings: warnings });
        }
        var qeSeq = null;
        try { app.enableQE(); qeSeq = qe.project.getActiveSequence(); } catch (e1) {}
        if (!qeSeq) return C3D_err("QE DOM not available (needed to razor clips).");
        var applied = 0, eps = 0.5 / fps, audioOnly = !!o.audioOnly;
        var drop = AS_isDropFrame(qeSeq, seq, fps);
        /* the batch path is the default for ripple cuts; o.legacy = true keeps the one-ripple-per-cut way */
        if (o.mode === "ripple" && !o.legacy) return AS_applyCutsBatch(o, qeSeq, fps, eps, audioOnly, drop, warnings);
        var stats = { moved: 0, already: 0, blocked: 0, failed: 0 };
        for (i = o.cuts.length - 1; i >= 0; i--) {
            var s = snap(o.cuts[i][0]), e = snap(o.cuts[i][1]);
            C3D_log("AS_applyCuts", o.label + " cut " + i + ": " + o.cuts[i][0].toFixed(3) + "-" + o.cuts[i][1].toFixed(3) + " snapped " + s.toFixed(3) + "-" + e.toFixed(3) + " mode " + o.mode);
            if (e - s < 1.5 / fps) { C3D_log("AS_applyCuts", "  skipped (shorter than 1.5 frames)"); continue; }
            /* 1) razor at both ends and make sure the cuts landed on the frame */
            var r1 = AS_razorVerified(qeSeq, app.project.activeSequence, e, fps, drop, eps, audioOnly);
            if (!r1.ok) return C3D_err("The razor did not land at " + e.toFixed(2) + "s (timecode format). Nothing was removed. Sequence fps " + fps.toFixed(3) + ", drop-frame " + drop + ".");
            drop = r1.drop;
            var r0 = AS_razorVerified(qeSeq, app.project.activeSequence, s, fps, drop, eps, audioOnly);
            if (!r0.ok) return C3D_err("The razor did not land at " + s.toFixed(2) + "s. Nothing was removed.");
            seq = app.project.activeSequence;
            /* 2) collect the pieces inside the cut */
            var tracks = [];
            if (!audioOnly) for (t = 0; t < seq.videoTracks.numTracks; t++) tracks.push(seq.videoTracks[t]);
            for (t = 0; t < seq.audioTracks.numTracks; t++) tracks.push(seq.audioTracks[t]);
            var inside = [];
            for (t = 0; t < tracks.length; t++) {
                var tr = tracks[t];
                for (j = tr.clips.numItems - 1; j >= 0; j--) {
                    var c = tr.clips[j];
                    if (c.start.seconds >= s - eps && c.end.seconds <= e + eps) inside.push({ clip: c, trackIdx: t, spans: (c.start.seconds <= s + eps && c.end.seconds >= e - eps), video: t < (audioOnly ? 0 : seq.videoTracks.numTracks) });
                }
            }
            var insideDesc = [];
            for (j = 0; j < inside.length; j++) insideDesc.push((inside[j].video ? "V" : "A") + inside[j].trackIdx + (inside[j].spans ? "*" : "") + " " + C3D_clipDesc(inside[j].clip));
            C3D_log("AS_applyCuts", "  razor ok (drop " + drop + "), " + inside.length + " piece(s) inside: " + insideDesc.join(" | "));
            if (o.mode === "disable") {
                for (j = 0; j < inside.length; j++) { try { inside[j].clip.disabled = true; } catch (e2) {} }
                applied++; continue;
            }
            /* 3) snapshot everything, delete the pieces (one spanning video piece is kept
                  for Premiere's own ripple delete), then settle whatever did not move */
            var shift = e - s;
            var snapBefore = AS_snapshot(seq);
            var keeper = -1;
            if (o.mode === "ripple") for (j = 0; j < inside.length; j++) if (inside[j].spans && inside[j].video) { keeper = j; break; }
            if (keeper < 0 && o.mode === "ripple") for (j = 0; j < inside.length; j++) if (inside[j].spans) { keeper = j; break; }
            /* remember where the keeper lives: its object goes stale once linked pieces are removed */
            var keepTrack = keeper >= 0 ? inside[keeper].trackIdx : -1;
            var insideIds = {};
            for (j = 0; j < inside.length; j++) { try { insideIds[String(inside[j].clip.nodeId)] = true; } catch (ei) {} }
            for (j = 0; j < inside.length; j++) { if (j === keeper) continue; try { inside[j].clip.remove(false, false); } catch (e3) { warnings.push("remove: " + e3); } }
            if (keeper >= 0) {
                var kfresh = null;
                try { kfresh = AS_pieceAt(tracks[keepTrack], s, e, eps); } catch (ek) {}
                if (!kfresh) kfresh = inside[keeper].clip;
                var rippled = false;
                C3D_log("AS_applyCuts", "  keeper " + (keeper >= 0 ? C3D_clipDesc(kfresh) : "none") + " on track " + keepTrack);
                try { kfresh.remove(true, true); rippled = true; } catch (e4) { C3D_log("AS_applyCuts", "  ripple remove threw: " + e4); }
                if (!rippled) { try { kfresh = AS_pieceAt(tracks[keepTrack], s, e, eps) || kfresh; kfresh.remove(false, false); } catch (e5) { warnings.push("keeper remove: " + e5); } }
            }
            /* sweep: a piece we meant to delete that is still there (stale object earlier) goes now, found by id.
               Never by position: after a successful ripple the next clips legitimately sit inside [s, e]. */
            seq = app.project.activeSequence;
            for (t = 0; t < tracks.length; t++) {
                var swept = 0;
                for (var guard = tracks[t].clips.numItems - 1; guard >= 0; guard--) {
                    var cand = tracks[t].clips[guard];
                    if (!insideIds[String(cand.nodeId)]) continue;
                    if (cand.start.seconds < s - eps || cand.end.seconds > e + eps) continue;
                    try { cand.remove(false, false); swept++; } catch (e6) {}
                }
                if (swept) { warnings.push("cut at " + s.toFixed(2) + "s: " + swept + " leftover piece(s) removed on the second try"); C3D_log("AS_applyCuts", "  swept " + swept + " leftover piece(s) on track " + t); }
            }
            C3D_log("AS_applyCuts", "  after delete: rippled " + (typeof rippled !== "undefined" ? rippled : "n/a") + "; next clip on V1 starts at " + (function () { try { var v = seq.videoTracks[0]; var best = 1e9; for (var q = 0; q < v.clips.numItems; q++) { var cs = v.clips[q].start.seconds; if (cs > s - eps && cs < best) best = cs; } return best === 1e9 ? "none" : best.toFixed(3); } catch (ex) { return "?"; } })());
            if (o.mode === "ripple") {
                var res = AS_settleShift(app.project.activeSequence, snapBefore, e, -shift, eps);
                C3D_log("AS_applyCuts", "  settle from " + e.toFixed(3) + " by -" + shift.toFixed(3) + ": moved " + res.moved + " already " + res.already + " blocked " + res.blocked + " failed " + res.failed + " gone " + res.gone + (res.blocker ? " | " + res.blocker : ""));
                stats.moved += res.moved; stats.already += res.already; stats.blocked += res.blocked; stats.failed += res.failed;
                if (res.blocked || res.failed) warnings.push("Gap at " + s.toFixed(2) + "s: " + res.blocked + " clip(s) blocked, " + res.failed + " could not be moved" + (res.blocker ? " (" + res.blocker + ")" : "") + ".");
                var closed = 0; try { closed = AS_closeGapAt(app.project.activeSequence, s, eps); } catch (e6) {}
                if (closed) { stats.closed = (stats.closed || 0) + 1; C3D_log("AS_applyCuts", "  closeGapAt closed a " + closed.toFixed(3) + "s gap at " + s.toFixed(3)); }
            }
            applied++;
        }
        C3D_log("AS_applyCuts", "done: applied " + applied + " stats " + stats.moved + "/" + stats.already + "/" + stats.blocked + "/" + stats.failed + " warnings " + warnings.length + (function () { try { var v = app.project.activeSequence.videoTracks[0]; var last = 0; for (var q = 0; q < v.clips.numItems; q++) if (v.clips[q].end.seconds > last) last = v.clips[q].end.seconds; return " V1 clips " + v.clips.numItems + " lastEnd " + last.toFixed(3); } catch (ex) { return ""; } })());
        return C3D_json({ ok: true, applied: applied, warnings: warnings, stats: stats, dropFrame: drop });
    } catch (e) { return C3D_err(e); }
}

/*  o = { firstFile, fps, duration, track (-1 = new top track), start, name, bin }   */
function AS_placeAt(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var root = app.project.rootItem;
        var bin = C3D_toolBin(o.bin) || root;
        app.project.importFiles([o.firstFile], true, bin, true);
        var item = C3D_findItemByPath(bin, o.firstFile, 0) || C3D_findItemByPath(root, o.firstFile, 0);
        if (!item) return C3D_err("Import failed for " + o.firstFile);
        /*  The frame rate MUST take. A PNG sequence left at Premiere's guess plays at the wrong speed:
            the caption's own animation runs fast or slow and the clip is the wrong length, which reads
            as the captions sliding out of sync. index.jsx already learned this - check the return and
            fall back to an override.                                                                  */
        var rateOk = false;
        try {
            var interp = item.getFootageInterpretation();
            if (interp) {
                interp.frameRate = o.fps;
                /* the PNGs are square-pixel; tell Premiere so, or a non-square sequence stretches them */
                if (o.par) { try { interp.pixelAspectRatio = o.par; } catch (ep1) {} }
                rateOk = item.setFootageInterpretation(interp) ? true : false;
            }
        } catch (e1) {}
        if (!rateOk) { try { item.setOverrideFrameRate(o.fps); rateOk = true; } catch (e1b) {} }
        try { item.name = o.name; } catch (e2) {}
        var idx = o.track;
        if (idx < 0) {
            if (!C3D_addVideoTrack(seq)) return C3D_err("Could not add a video track.");
            seq = app.project.activeSequence;
            idx = seq.videoTracks.numTracks - 1;
        }
        while (idx >= app.project.activeSequence.videoTracks.numTracks) { if (!C3D_addVideoTrack(app.project.activeSequence)) return C3D_err("Could not add a video track."); }
        seq = app.project.activeSequence;
        var track = seq.videoTracks[idx];
        /*  Place on an exact tick, not on a float of seconds: at 29.97 the seconds for a frame do not
            land on Premiere's grid, and half a frame is visible on a caption that pops in over three.  */
        var startTicks = String(Math.round(o.start * C3D_TICKS_PER_SECOND));
        var ok = false;
        try { ok = track.overwriteClip(item, startTicks); } catch (e3) {}
        if (!ok) { try { var tm = new Time(); tm.seconds = o.start; ok = track.overwriteClip(item, tm); } catch (e4) {} }
        if (!ok) { try { ok = track.overwriteClip(item, o.start); } catch (e4b) {} }
        if (!ok) return C3D_err("Could not place " + o.name + " on V" + (idx + 1));
        /*  Where it really landed, and how long it really is. Premiere snaps, and an imported still
            sequence does not always come in at the length we asked for.                              */
        var placed = C3D_findClipAt(track, o.start), landed = o.start, length = o.duration || 0, warnings = [];
        if (placed) {
            try { landed = placed.start.seconds; } catch (e5) {}
            if (o.duration > 0 && typeof MG_trim === "function") MG_trim(placed, landed + o.duration, warnings);
            try { length = placed.end.seconds - placed.start.seconds; } catch (e6) {}
        }
        return C3D_json({ ok: true, track: idx, start: landed, length: length, rate: rateOk, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/*  o = { segments: [{s, e, cam}], camTracks: [videoTrackIdx per cam], name }   */
function AS_buildMulticam(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        if (!C3D_addVideoTrack(seq)) return C3D_err("Could not add the target video track.");
        seq = app.project.activeSequence;
        var target = seq.videoTracks[seq.videoTracks.numTracks - 1];
        var tIdx = seq.videoTracks.numTracks - 1;
        var placed = 0, warnings = [], eps = 0.5 / AS_fps(seq);
        for (var i = 0; i < o.segments.length; i++) {
            var sg = o.segments[i];
            var camTrack = seq.videoTracks[o.camTracks[sg.cam]];
            if (!camTrack) { warnings.push("camera " + (sg.cam + 1) + " track missing"); continue; }
            var src = null;
            for (var j = 0; j < camTrack.clips.numItems; j++) {
                var c = camTrack.clips[j];
                if (c.start.seconds <= sg.s + eps && c.end.seconds > sg.s + eps) { src = c; break; }
            }
            if (!src || !src.projectItem) { warnings.push("no clip on camera " + (sg.cam + 1) + " at " + sg.s.toFixed(2) + "s"); continue; }
            var segEnd = Math.min(sg.e, src.end.seconds);
            if (segEnd - sg.s < 2 * eps) continue;
            var audioBefore = [];
            for (var a = 0; a < seq.audioTracks.numTracks; a++) audioBefore.push(seq.audioTracks[a].clips.numItems);
            var ok = false;
            try { ok = target.overwriteClip(src.projectItem, sg.s); } catch (e1) {}
            if (!ok) { warnings.push("segment " + i + " not placed"); continue; }
            var nc = C3D_findClipAt(target, sg.s);
            if (nc) {
                try {
                    var ip = new Time(); ip.seconds = src.inPoint.seconds + (sg.s - src.start.seconds);
                    var op = new Time(); op.seconds = ip.seconds + (segEnd - sg.s);
                    nc.inPoint = ip; nc.outPoint = op;
                    var st = new Time(); st.seconds = sg.s; nc.start = st;
                    var en = new Time(); en.seconds = segEnd; nc.end = en;
                    nc.name = (o.name || "Speaker cut") + " cam " + (sg.cam + 1);
                } catch (e2) { warnings.push("trim " + i + ": " + e2); }
            }
            /* drop the audio that came along with the video */
            for (var b = 0; b < seq.audioTracks.numTracks; b++) {
                var at = seq.audioTracks[b];
                if (at.clips.numItems > audioBefore[b]) {
                    for (var k = at.clips.numItems - 1; k >= 0; k--) {
                        var ac = at.clips[k];
                        if (Math.abs(ac.start.seconds - sg.s) < eps) { try { ac.remove(false, false); } catch (e3) {} break; }
                    }
                }
            }
            placed++;
        }
        return C3D_json({ ok: true, placed: placed, track: tIdx, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/*  o = { targets: "selected" | { track }, zooms: [{t, amount, inDur, hold, outDur}], anchor: [ax, ay], width, height }   */
function AS_applyZooms(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var clips = [], t, j;
        for (t = 0; t < seq.videoTracks.numTracks; t++) {
            if (o.targets !== "selected" && o.targets.track !== t) continue;
            var tr = seq.videoTracks[t];
            for (j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j], sel = true;
                if (o.targets === "selected") { sel = false; try { sel = c.isSelected(); } catch (e0) {} }
                if (sel) clips.push(c);
            }
        }
        if (!clips.length) return C3D_err("Select the clip(s) to zoom first.");
        var done = 0, warnings = [];
        for (var ci = 0; ci < clips.length; ci++) {
            var clip = clips[ci];
            var comps = C3D_findComponents(clip);
            if (!comps.motion) { warnings.push(clip.name + ": no Motion component"); continue; }
            var scaleP = comps.motion.properties[1], posP = comps.motion.properties[0];
            var baseScale = 100, basePos = [0.5, 0.5];
            try { baseScale = scaleP.getValue(); } catch (e1) {}
            try { basePos = posP.getValue(); } catch (e2) {}
            var norm = C3D_isNormalized(posP);
            var cs = clip.start.seconds, ce = clip.end.seconds, cin = clip.inPoint.seconds;
            var sk = [], pk = [];
            var pushKey = function (tt, sc) {
                var mt = cin + (tt - cs);
                var f = (sc / baseScale) - 1;
                var ax = norm ? o.anchor[0] : o.anchor[0] * o.width, ay = norm ? o.anchor[1] : o.anchor[1] * o.height;
                var px = basePos[0] - (ax - basePos[0]) * f, py = basePos[1] - (ay - basePos[1]) * f;
                sk.push([mt, sc]); pk.push([mt, px, py]);
            };
            var any = false;
            for (var z = 0; z < o.zooms.length; z++) {
                var zz = o.zooms[z];
                if (zz.t < cs || zz.t + zz.inDur + zz.hold + zz.outDur > ce) continue;
                var big = baseScale * zz.amount;
                pushKey(zz.t, baseScale);
                pushKey(zz.t + zz.inDur, big);
                pushKey(zz.t + zz.inDur + zz.hold, big);
                pushKey(zz.t + zz.inDur + zz.hold + zz.outDur, baseScale);
                any = true;
            }
            if (!any) continue;
            C3D_setKeys(scaleP, sk, 0, function (kk) { return kk[1]; }, warnings, "scale");
            C3D_setKeys(posP, pk, 0, function (kk) { return [kk[1], kk[2]]; }, warnings, "position");
            done++;
        }
        return C3D_json({ ok: true, clips: done, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}

/*  o = { formats: [{num, den, name}], motion: "default"|"slower"|"faster", nested }   */
function AS_reframe(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var made = [], warnings = [];
        for (var i = 0; i < o.formats.length; i++) {
            var f = o.formats[i];
            var newName = seq.name + " " + f.name;
            var ns = null;
            try { ns = seq.autoReframeSequence(f.num, f.den, o.motion || "default", newName, o.nested ? true : false); }
            catch (e1) { warnings.push(f.name + ": Auto Reframe not available (" + e1 + "), made a resized copy instead"); }
            if (!ns) {
                /* fallback: clone the sequence and change its frame size (no reframing) */
                try {
                    var before = {}; for (var q = 0; q < app.project.sequences.numSequences; q++) before[app.project.sequences[q].sequenceID] = true;
                    seq.clone();
                    for (var q2 = 0; q2 < app.project.sequences.numSequences; q2++) { var sq = app.project.sequences[q2]; if (!before[sq.sequenceID]) ns = sq; }
                    if (ns) {
                        ns.name = newName;
                        var sset = ns.getSettings();
                        var H = sset.videoFrameHeight || seq.frameSizeVertical, Wn = Math.round(H * f.num / f.den / 2) * 2;
                        sset.videoFrameWidth = Wn; sset.videoFrameHeight = H;
                        ns.setSettings(sset);
                    }
                } catch (e2) { warnings.push(f.name + ": " + e2); }
            }
            if (ns) made.push(newName);
            try { app.project.openSequence(seq.sequenceID); } catch (e2) {}
        }
        if (!made.length) return C3D_err("Could not create the versions: " + warnings.join(" · "));
        return C3D_json({ ok: true, made: made, warnings: warnings });
    } catch (e) { return C3D_err(e); }
}


/*  Podcast mode helpers.
    AS_shiftTracks: o = { videos: [trackIdx], audios: [trackIdx], delta: seconds }. Moves every clip on those tracks by
    delta (camera sync). Linked audio moves with its video by itself; a clip already at its destination is skipped.  */
function AS_shiftTracks(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var fps = AS_fps(seq), eps = 0.5 / fps, delta = Math.round(o.delta * fps) / fps;
        if (Math.abs(delta) < eps) return C3D_json({ ok: true, moved: 0, already: 0, failed: 0, delta: 0 });
        var videos = o.videos || [], audios = o.audios || [];
        var want = function (rec) {
            var k, list = rec.kind === "v" ? videos : audios;
            for (k = 0; k < list.length; k++) if (list[k] === rec.track) return true;
            return false;
        };
        var snap = AS_snapshot(seq), ids = [], id;
        for (id in snap) if (snap.hasOwnProperty(id) && want(snap[id])) ids.push(id);
        /* moving left: earliest first; moving right: latest first, so nothing lands on a neighbour */
        ids.sort(function (a, b) { return delta < 0 ? snap[a].start - snap[b].start : snap[b].start - snap[a].start; });
        var res = { moved: 0, already: 0, failed: 0 }, i;
        for (i = 0; i < ids.length; i++) {
            id = ids[i];
            var rec = snap[id], dest = rec.start + delta;
            if (dest < -eps) { res.failed++; C3D_log("AS_shiftTracks", "clip would start before 0: track " + rec.track + " at " + rec.start.toFixed(2)); continue; }
            var clip = AS_fresh(seq, rec, id);
            if (!clip) { res.failed++; continue; }
            var cur = clip.start.seconds;
            if (Math.abs(cur - dest) < eps) { res.already++; continue; }
            try { var mv = new Time(); mv.seconds = dest - cur; clip.move(mv); } catch (e1) { C3D_log("AS_shiftTracks", "move threw: " + e1); }
            var chk = AS_fresh(seq, rec, id), pos = chk ? chk.start.seconds : cur;
            if (Math.abs(pos - dest) >= eps) { try { var mv2 = new Time(); mv2.seconds = dest; (chk || clip).move(mv2); } catch (e2) {} chk = AS_fresh(seq, rec, id); pos = chk ? chk.start.seconds : cur; }
            if (chk && Math.abs(pos - dest) < eps) res.moved++; else res.failed++;
        }
        C3D_log("AS_shiftTracks", "delta " + delta.toFixed(3) + " videos " + videos + " audios " + audios + " -> moved " + res.moved + " already " + res.already + " failed " + res.failed);
        return C3D_json({ ok: true, moved: res.moved, already: res.already, failed: res.failed, delta: delta });
    } catch (e) { return C3D_err(e); }
}

/*  o = { videos: [idx], audios: [idx], mute: true|false }  */
function AS_muteTracks(json) {
    try {
        var o = C3D_loadPayload(json);
        var seq = app.project.activeSequence;
        if (!seq) return C3D_err("Open a sequence first.");
        var n = 0, i, flag = o.mute === false ? 0 : 1;
        for (i = 0; i < (o.videos || []).length; i++) { try { seq.videoTracks[o.videos[i]].setMute(flag); n++; } catch (e1) {} }
        for (i = 0; i < (o.audios || []).length; i++) { try { seq.audioTracks[o.audios[i]].setMute(flag); n++; } catch (e2) {} }
        return C3D_json({ ok: true, tracks: n });
    } catch (e) { return C3D_err(e); }
}
